import { createRoot } from 'react-dom/client';
import './index.css';

export function createElement(vnode: any) {
  const element = document.createElement('div');
  const { slot } = vnode.props;
  if (slot !== undefined) {
    element.setAttribute('slot', slot);
  }
  createRoot(element).render(vnode);
  return element;
}

// TODO(nisitao): auto generate in the hydration layer
export { default as KsAreaChart, type KsAreaChartProps } from './components/KsAreaChart';
export { default as KsBarChart, type KsBarChartProps } from './components/KsBarChart';
export { default as KsCommonChart, type KsCommonChartProps } from './components/KsCommonChart';
export { default as KsDonutChart, type KsDonutChartProps } from './components/KsDonutChart';
export { default as KsGaugeChart, type KsGaugeChartProps } from './components/KsGaugeChart';
export { default as KsLineChart, type KsLineChartProps } from './components/KsLineChart';
export { default as KsScatterChart, type KsScatterChartProps } from './components/KsScatterChart';
export { default as KsWordCloudChart, type KsWordCloudChartProps } from './components/KsWordCloudChart';
export { default as KsLegends, type KsLegendsProps } from './components/KsLegends';

export { type Components as Charts, type JSX as ComponentProps } from '@fe-infra/chart';
