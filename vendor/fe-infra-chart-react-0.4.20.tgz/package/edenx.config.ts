import { moduleTools, defineConfig } from '@edenx/module-tools';
import { modulePluginDoc } from '@edenx/plugin-module-doc';

export default defineConfig({
  plugins: [moduleTools(), modulePluginDoc()],
  buildPreset: 'npm-component',
});
