# @fe-infra/chart-react

## [0.4.20] - 2026-03-16

### Changed

- Updated dependencies - ([87afc9197](https://code.byted.org/ad/byted-web-components/commit/87afc9197)).
  - @fe-infra/keystone-design-tokens@2.0.21
  - @fe-infra/chart@1.0.12

## [0.4.19] - 2026-03-04

### Changed

- Updated dependencies - ([d303b2248](https://code.byted.org/ad/byted-web-components/commit/d303b2248)).
  - @byted-keystone/react-output-target@0.2.8
  - @fe-infra/chart@1.0.11

## [0.4.18] - 2026-02-04

### Changed

- Updated dependencies - ([3958f0b05](https://code.byted.org/ad/byted-web-components/commit/3958f0b05)).
  - @byted-keystone/react-output-target@0.2.7
  - @fe-infra/chart@1.0.11

## [0.4.17] - 2026-02-03

### Changed

- Updated dependencies - ([695004aae](https://code.byted.org/ad/byted-web-components/commit/695004aae)).
  - @byted-keystone/react-output-target@0.2.6
  - @fe-infra/chart@1.0.11

## [0.4.16] - 2026-01-21

### Changed

- Updated dependencies - ([f35e8ca5a](https://code.byted.org/ad/byted-web-components/commit/f35e8ca5a)).
  /change Updated dependencies - ([46f99fa53](https://code.byted.org/ad/byted-web-components/commit/46f99fa53)).
  - @fe-infra/chart@1.0.11
  - @byted-keystone/react-output-target@0.2.5

### Fixed

- (ChartTooltip) Fixed the issue where the tooltip of the chart did not display 0 but instead showed an empty string when value=0 - ([f35e8ca5a](https://code.byted.org/ad/byted-web-components/commit/f35e8ca5a)).

## [0.4.15] - 2026-01-13

### Changed

- Updated dependencies - ([fb01aa2c5](https://code.byted.org/ad/byted-web-components/commit/fb01aa2c5)).
  - @fe-infra/keystone-design-tokens@2.0.20
  - @fe-infra/chart@1.0.10

## [0.4.14] - 2025-12-24

### Changed

- Updated dependencies - ([d0042ce82](https://code.byted.org/ad/byted-web-components/commit/d0042ce82)).
  - @byted-keystone/react-output-target@0.2.4
  - @fe-infra/chart@1.0.9

## [0.4.13] - 2025-12-23

### Changed

- Updated dependencies - ([ecef4d9ea](https://code.byted.org/ad/byted-web-components/commit/ecef4d9ea)).
  - @byted-keystone/react-output-target@0.2.3

## [0.4.12] - 2025-11-24

### Changed

- Updated dependencies - ([774505c58](https://code.byted.org/ad/byted-web-components/commit/774505c58)).
  - @byted-keystone/react-output-target@0.2.2
  - @fe-infra/chart@1.0.9

## [0.4.11] - 2025-11-19

### Changed

- Updated dependencies - ([4183deb0a](https://code.byted.org/ad/byted-web-components/commit/4183deb0a)).
  - @fe-infra/keystone-design-tokens@2.0.19
  - @fe-infra/chart@1.0.9

## [0.4.10] - 2025-10-29

### Changed

- Updated dependencies - ([806c63de9](https://code.byted.org/ad/byted-web-components/commit/806c63de9)).
  - @fe-infra/chart@1.0.8

## [0.4.9] - 2025-10-15

### Changed

- Updated dependencies - ([c115e8bbf](https://code.byted.org/ad/byted-web-components/commit/c115e8bbf)).
  - @byted-keystone/react-output-target@0.2.1
  - @fe-infra/chart@1.0.7

## [0.4.8] - 2025-10-10

### Changed

- Updated dependencies - ([8571bb6d7](https://code.byted.org/ad/byted-web-components/commit/8571bb6d7)).
  - @byted-keystone/react-output-target@0.2.0
  - @fe-infra/chart@1.0.7

## [0.4.7] - 2025-10-08

## [0.4.6] - 2025-10-08

## [0.4.5] - 2025-10-07

## [0.4.4] - 2025-09-29

## [0.4.3] - 2025-09-26

## [0.4.2] - 2025-09-25

### Changed

- Updated dependencies - ([37bb60096](https://code.byted.org/ad/byted-web-components/commit/37bb60096)).
  - @byted-keystone/react-output-target@0.1.12
  - @fe-infra/chart@1.0.2

## [0.4.1] - 2025-09-24

## [0.4.0] - 2025-09-24

### Added

- (KsLegends) Added new legend component with pagination support for better control over chart legend display - ([9f3bd3603](https://code.byted.org/ad/byted-web-components/commit/9f3bd3603)).
- (KsAreaChart, KsBarChart, KsCommonChart, KsLineChart, KsScatterChart, KsPieChart) Added integrated tooltip rendering using built-in VChart tooltip system instead of custom handlers - ([9f3bd3603](https://code.byted.org/ad/byted-web-components/commit/9f3bd3603)).

### Changed

- (KsAreaChart, KsBarChart, KsCommonChart, KsLineChart, KsScatterChart) **[BREAKING]** Removed custom tooltip handler implementation in favor of VChart's native tooltip system - ([9f3bd3603](https://code.byted.org/ad/byted-web-components/commit/9f3bd3603)).
- Updated dependencies - ([9f3bd3603](https://code.byted.org/ad/byted-web-components/commit/9f3bd3603)).
  - @fe-infra/chart@1.0.0

## [0.3.4] - 2025-09-19

### Changed

- Updated dependencies - ([f10bf6c83](https://code.byted.org/ad/byted-web-components/commit/f10bf6c83)).
  - @byted-keystone/react-output-target@0.1.11
  - @fe-infra/keystone-design-tokens@2.0.18
  - @fe-infra/chart@0.3.3

## [0.3.3] - 2025-09-17

### Changed

- Updated dependencies - ([1b553bf37](https://code.byted.org/ad/byted-web-components/commit/1b553bf37)).
  - @byted-keystone/react-output-target@0.1.10
  - @fe-infra/chart@0.3.2

## [0.3.2] - 2025-09-05

### Changed

- Updated dependencies - ([1a054d81e](https://code.byted.org/ad/byted-web-components/commit/1a054d81e)).
  - @fe-infra/chart@0.3.2

## 0.0.59

### Patch Changes

- 305bde58e: fix tooltip position
- 8e381c5fc: Fixed tree-shaking function. All packages now support tree shaking.
- Updated dependencies [305bde58e]
- Updated dependencies [8e381c5fc]
  - @fe-infra/chart@0.0.56

## 0.0.58

- 7a213727e: chart: trimPadding of bottom axes
  search:search add ksCategoryChange event && fix dropdown selectable
  dropdown menu: add loadFail props
  input selector: add loadFail props
  dropdown menu button: support renderContent
  field presenter: fix clear bug
  multiple-cascader: support selectable is false
  new component:
  - ks-multiple-input
  - ks-cascader-columns
- Updated dependencies [7a213727e]
  - @fe-infra/chart@0.0.55

## 0.0.57

- 011d14d12: fix chart tooltip bug
- Updated dependencies [011d14d12]
  - @fe-infra/chart@0.0.54

## 0.0.56

- Updated dependencies [16a240fd7]
  - @byted-keystone/react-output-target@0.1.9
  - @fe-infra/chart@0.0.53

## 0.0.55

- Updated dependencies [10daf7645]
- Updated dependencies [65dc1af22]
  - @fe-infra/keystone-design-tokens@2.0.16
  - @byted-keystone/react-output-target@0.1.8
- bc5d979b9: chart support marktooltip hide delay
- Updated dependencies [bc5d979b9]
  - @fe-infra/chart@0.0.52

## 0.0.53

- 00a996b84: can not scroll when modal is active
- Updated dependencies [00a996b84]
  - @fe-infra/chart@0.0.51

## 0.0.52

- 416c45bb7: nux popover add content slot

## 0.0.51

- Updated dependencies [be325e402]
  - @byted-keystone/react-output-target@0.1.7
  - @fe-infra/chart@0.0.50

## 0.0.50

- 70fbbb030: data vis 0.0.7
- Updated dependencies [70fbbb030]
- @fe-infra/chart@0.0.49

## 0.0.48

- @fe-infra/chart@0.0.48

## 0.0.47

- @fe-infra/chart@0.0.47

## 0.0.46

- @fe-infra/chart@0.0.46

## 0.0.45

- @fe-infra/chart@0.0.45

## 0.0.44

- @fe-infra/chart@0.0.44

## 0.0.43

- ba01463fd: 1.0.5 update, update search、tab、switch、progress、dropdown-menu、side-navigation and slider
- Updated dependencies [ba01463fd]
  - @fe-infra/keystone-design-tokens@2.0.15
  - @fe-infra/chart@0.0.43

## 0.0.42

- Updated dependencies [22f210257]
  - @fe-infra/keystone-design-tokens@2.0.14
  - @fe-infra/chart@0.0.42

## 0.0.41

- @fe-infra/chart@0.0.41

## 0.0.40

- @fe-infra/chart@0.0.40

## 0.0.39

- Updated dependencies [51e02a607]
  - @fe-infra/keystone-design-tokens@2.0.13
  - @fe-infra/chart@0.0.39

## 0.0.38

- @fe-infra/chart@0.0.38

## 0.0.37

- @fe-infra/chart@0.0.37

## 0.0.36

- Updated dependencies [7ffb6daea]
  - @fe-infra/keystone-design-tokens@2.0.12
  - @fe-infra/chart@0.0.36

## 0.0.35

- 258434cb2: fix status-indicator、pagination's style
- 66c3c3119: add block state and ratio for thumbnail
- Updated dependencies [258434cb2]
- Updated dependencies [66c3c3119]
  - @fe-infra/keystone-design-tokens@2.0.11
  - @fe-infra/chart@0.0.35

## 0.0.34

- @fe-infra/chart@0.0.34

## 0.0.33

- @fe-infra/chart@0.0.33

## 0.0.32

- 214c8bc5e: add play slot for asset-tile
- 0c7048cb5: fix the stepper's style
- 214c8bc5e: add block state and ratio for thumbnail
- 694996bf8: fix the upload style
- Updated dependencies [214c8bc5e]
- Updated dependencies [0c7048cb5]
- Updated dependencies [694996bf8]
  - @fe-infra/chart@0.0.32

## 0.0.31

- @fe-infra/chart@0.0.31

## 0.0.30

- @fe-infra/chart@0.0.30

## 0.0.29

- @fe-infra/chart@0.0.29

## 0.0.28

- 9f1632b43: add loading state for dropdown
- a7e6530ce: fix the empty-states's style
- f4f714a88: fix the nux-popover's vertical mode style
- 3b3a970e2: fix the popover
- Updated dependencies [9f1632b43]
- Updated dependencies [a7e6530ce]
- Updated dependencies [f4f714a88]
- Updated dependencies [3b3a970e2]
  - @fe-infra/keystone-design-tokens@2.0.10
  - @fe-infra/chart@0.0.28

## 0.0.27

- @fe-infra/chart@0.0.27

## 0.0.26

- @fe-infra/chart@0.0.26

## 0.0.25

- @fe-infra/chart@0.0.25

## 0.0.24

- @fe-infra/chart@0.0.24

## 0.0.23

- @fe-infra/chart@0.0.23

## 0.0.22

- 75b57e385: fix the spinner's lg size
- Updated dependencies [75b57e385]
  - @fe-infra/keystone-design-tokens@2.0.9
  - @fe-infra/chart@0.0.22

## 0.0.21

- @fe-infra/chart@0.0.21

## 0.0.20

- 7f9730cc1: Conditional judgment switch slot rendering
- 7f9730cc1: fix the tile horizontal mode selection's position
- Updated dependencies [7f9730cc1]
  - @fe-infra/chart@0.0.20
  - @fe-infra/keystone-design-tokens@2.0.8

## 0.0.19

- 5d49cb4e3: fix the segemented selection's style
- Updated dependencies [5d49cb4e3]
  - @fe-infra/keystone-design-tokens@2.0.7
  - @fe-infra/chart@0.0.19

## 0.0.18

- 38d96b61b: fix: supplement neutral overlay color tokens
- Updated dependencies [38d96b61b]
  - @fe-infra/keystone-design-tokens@2.0.6
  - @fe-infra/chart@0.0.18

## 0.0.17

- 8d82b6488: Conditional judgment switch slot rendering
- Updated dependencies [8d82b6488]
  - @fe-infra/chart@0.0.17

## 0.0.16

- ff2660910: Conditional judgment switch slot rendering
- Updated dependencies [ff2660910]
  - @fe-infra/chart@0.0.16

## 0.0.15

- Updated dependencies [537764b4a]
  - @fe-infra/keystone-design-tokens@2.0.5
  - @fe-infra/chart@0.0.15

## 0.0.14

- Updated dependencies [4ed8aabe7]
  - @fe-infra/keystone-design-tokens@2.0.4
  - @fe-infra/chart@0.0.14

## 0.0.13

- @fe-infra/chart@0.0.13

## 0.0.12

- @fe-infra/chart@0.0.12

## 0.0.11

- @fe-infra/chart@0.0.11

## 0.0.10

- @fe-infra/chart@0.0.10

## 0.0.9

- Updated dependencies [6f41bd564]
  - @fe-infra/keystone-design-tokens@2.0.3
  - @fe-infra/chart@0.0.9

## 0.0.8

- @fe-infra/chart@0.0.8

## 0.0.7

- 83d3171c8: fix tooltip style
- Updated dependencies [83d3171c8]
  - @fe-infra/chart@0.0.7

## 0.0.6

- Updated dependencies [823d82587]
  - @fe-infra/keystone-design-tokens@2.0.2
  - @fe-infra/chart@0.0.6

## 0.0.5

- Updated dependencies [2f4977cc4]
  - @fe-infra/keystone-design-tokens@2.0.1
  - @fe-infra/chart@0.0.5

## 0.0.4

- Updated dependencies [80356147f]
  - @fe-infra/keystone-design-tokens@2.0.0
  - @fe-infra/chart@0.0.4

## 0.0.3

- 8eae3f8f0: fix vue slot
- Updated dependencies [8eae3f8f0]
  - @fe-infra/chart@0.0.3

## 0.0.2

- 49fbc0c49: initial chart
  - @fe-infra/chart@0.0.2

## [0.3.1] - 2025-07-18

### Changed

- Updated dependencies - ([011709718](https://code.byted.org/ad/byted-web-components/commit/011709718)).
  - @fe-infra/keystone-design-tokens@2.0.17
  - @fe-infra/chart@0.3.1
