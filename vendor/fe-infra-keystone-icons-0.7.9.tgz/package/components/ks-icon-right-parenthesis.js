import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconRightParenthesis$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconRightParenthesis$1 =

    proxyCustomElement(class KsIconRightParenthesis extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-right-parenthesis';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'e94844d850b9502550e73f5e509f5aa9688f20a6', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'b959e0508da305e05d2f9e0beb305dbf5b4700e8', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'd4ed108cd3c9713a60deb0df4b5380665d734767', d: "M18.9724 42.5824C24.0593 39.6454 29.0276 34.2629 29.0276 24.0002C29.0276 13.7376 23.3854 7.96591 18.9724 5.41806", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-right-parenthesis"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconRightParenthesis$1;},KsIconRightParenthesis$1 = GetKsIconRightParenthesis$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-right-parenthesis"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-right-parenthesis":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconRightParenthesis$1(transTagName));
        }
        break;
    }});
}

const KsIconRightParenthesis = KsIconRightParenthesis$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconRightParenthesis, defineCustomElement };
//# sourceMappingURL=ks-icon-right-parenthesis.js.map
//# sourceMappingURL=ks-icon-right-parenthesis.js.map