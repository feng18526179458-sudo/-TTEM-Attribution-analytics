import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconMessage$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconMessage$1 =

    proxyCustomElement(class KsIconMessage extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-message';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'e86722c22cb66088c4fe256079b78ee7b375508b', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: '05a4996d08a44b57fdba411bd0716788a79f8641', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'cababa27be2d6f0eb8fc56c431b4943c1b641c86', d: "M4.5 24C4.5 13.23 13.23 4.5 24 4.5S43.5 13.23 43.5 24 34.769 43.5 24 43.5H6A1.5 1.5 0 0 1 4.5 42V24z", stroke: icon.color, "stroke-width": icon.strokeWidth }), h("g", { key: 'f0d2c72f1f6a7ef50e04d886c2303c505154447d', fill: icon.color }, h("circle", { key: '15c346b16c9c2a857b049f503284e9012ef78a01', cx: "23.965", cy: "24.75", r: "2.25" }), h("circle", { key: '6f7c1db87cc3fb307e2cd868456f387d66056519', cx: "32.965", cy: "24.75", r: "2.25" }), h("circle", { key: 'bfd2f380056543354ac42e05bc4ea70ae845e9e2', cx: "14.965", cy: "24.75", r: "2.25" }))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-message"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconMessage$1;},KsIconMessage$1 = GetKsIconMessage$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-message"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-message":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconMessage$1(transTagName));
        }
        break;
    }});
}

const KsIconMessage = KsIconMessage$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconMessage, defineCustomElement };
//# sourceMappingURL=ks-icon-message.js.map
//# sourceMappingURL=ks-icon-message.js.map