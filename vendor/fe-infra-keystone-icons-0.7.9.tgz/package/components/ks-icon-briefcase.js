import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconBriefcase$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconBriefcase$1 =

    proxyCustomElement(class KsIconBriefcase extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-briefcase';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '6d02da95b7c48aa77c9303ece18ec69ea43004bf', class: "ks-icon", "ks-icon": true }, h("svg", { key: '5b976eb1ffe2fad9055ab6deb9d307f92684b7a0', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: '614ec56b5f51672233d9ec89541a399c8dc06939', d: "M4.501 16.501a1.5 1.5 0 0 1 1.5-1.5h36a1.5 1.5 0 0 1 1.5 1.5v21a1.5 1.5 0 0 1-1.5 1.5h-36a1.5 1.5 0 0 1-1.5-1.5v-21z" }), h("path", { key: 'a2421a96844363589aff5b05a3e1cb38ebaa794d', d: "M4.501 22.501l19.5 3 19.5-3", "stroke-linecap": "round" }), h("path", { key: '3007fc7ba96dbf69da6c321aa8a7e9cb53ef72ca', d: "M15.002 14.969c0-4.953 4.047-8.968 9-8.968h0c4.953 0 9 4.015 9 8.968h0c0 .018-.015.032-.032.032H15.035c-.018 0-.032-.015-.032-.032h0z" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-briefcase"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconBriefcase$1;},KsIconBriefcase$1 = GetKsIconBriefcase$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-briefcase"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-briefcase":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconBriefcase$1(transTagName));
        }
        break;
    }});
}

const KsIconBriefcase = KsIconBriefcase$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconBriefcase, defineCustomElement };
//# sourceMappingURL=ks-icon-briefcase.js.map
//# sourceMappingURL=ks-icon-briefcase.js.map