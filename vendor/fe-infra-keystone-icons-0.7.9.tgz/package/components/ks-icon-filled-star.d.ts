import type { Components, JSX } from "../dist/types/components";

interface KsIconFilledStar extends Components.KsIconFilledStar, HTMLElement {}
export const KsIconFilledStar: {
    prototype: KsIconFilledStar;
    new (): KsIconFilledStar;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
