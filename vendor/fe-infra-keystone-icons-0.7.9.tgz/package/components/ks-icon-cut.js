import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconCut$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconCut$1 =

    proxyCustomElement(class KsIconCut extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-cut';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'ea253777a63f4187d0c8a7d0aa41c0df9f113873', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'aae077014a40dfb254ad59c456970a0f933ece6c', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'a92afe3eec714aea87853ccc35c4229889a0c168', d: "M23.25 18.039l-4.409 3.123c-.77-1.157-1.834-2.143-3.152-2.834-4.192-2.199-9.373-.582-11.572 3.61s-.582 9.373 3.61 11.572c3.135 1.644 6.823 1.155 9.403-.949l4.941-4.436m8.973-15.63l7.175-4.989.859 1.219a6.86 6.86 0 0 1-1.655 9.555l-7.076 4.98m-9.137 11.657l2.221-24.715a6.86 6.86 0 0 1 7.448-6.211l1.486.135-2.138 23.611c1.387.088 2.773.516 4.03 1.312 4 2.531 5.191 7.826 2.66 11.827s-7.826 5.191-11.826 2.66c-2.991-1.893-4.411-5.331-3.879-8.618z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" }), h("g", { key: '13da7c5f44186925cf23d4aa432520e9e7a41bdb', fill: icon.color }, h("use", { key: 'c759748ffe600532607ab928137c4ef2ea2637b9', href: "#B" }), h("use", { key: '3a2dbefefad5ff2233d867003c0ffe0f9c174775', href: "#B", x: "18.322", y: "10.967" })), h("defs", { key: '31acaa17555d78f514274e66daf676ed3d1110aa' }, h("path", { key: 'c9d5b9e122a9bd6c91cf86dcad404bf5e7a95eb4', id: "B", d: "M14.944 25.713c0 2.012-1.631 3.643-3.643 3.643s-3.643-1.631-3.643-3.643 1.631-3.643 3.643-3.643 3.643 1.631 3.643 3.643z" }))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-cut"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconCut$1;},KsIconCut$1 = GetKsIconCut$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-cut"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-cut":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconCut$1(transTagName));
        }
        break;
    }});
}

const KsIconCut = KsIconCut$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconCut, defineCustomElement };
//# sourceMappingURL=ks-icon-cut.js.map
//# sourceMappingURL=ks-icon-cut.js.map