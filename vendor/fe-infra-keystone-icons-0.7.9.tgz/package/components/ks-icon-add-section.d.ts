import type { Components, JSX } from "../dist/types/components";

interface KsIconAddSection extends Components.KsIconAddSection, HTMLElement {}
export const KsIconAddSection: {
    prototype: KsIconAddSection;
    new (): KsIconAddSection;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
