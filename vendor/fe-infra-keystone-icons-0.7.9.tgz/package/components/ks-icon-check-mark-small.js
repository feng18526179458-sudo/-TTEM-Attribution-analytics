import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconCheckMarkSmall$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconCheckMarkSmall$1 =

    proxyCustomElement(class KsIconCheckMarkSmall extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-check-mark-small';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'cf5991eed1e1fdd8b080982de09c67b870789581', class: "ks-icon", "ks-icon": true }, h("svg", { key: '957d827c076b67b5e556aeb99a32eef096a113b1', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '88e47ecf08927c008682c7ffab47e4fa623a9fec', d: "M11.4 25.167l7.754 9.333 17.446-21", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-check-mark-small"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconCheckMarkSmall$1;},KsIconCheckMarkSmall$1 = GetKsIconCheckMarkSmall$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-check-mark-small"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-check-mark-small":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconCheckMarkSmall$1(transTagName));
        }
        break;
    }});
}

const KsIconCheckMarkSmall = KsIconCheckMarkSmall$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconCheckMarkSmall, defineCustomElement };
//# sourceMappingURL=ks-icon-check-mark-small.js.map
//# sourceMappingURL=ks-icon-check-mark-small.js.map