import type { Components, JSX } from "../dist/types/components";

interface KsIconDivide extends Components.KsIconDivide, HTMLElement {}
export const KsIconDivide: {
    prototype: KsIconDivide;
    new (): KsIconDivide;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
