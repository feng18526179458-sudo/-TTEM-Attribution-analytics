import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconTest$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconTest$1 =

    proxyCustomElement(class KsIconTest extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-test';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '305bfb39190678ec5b22107601b9368874e2d622', class: "ks-icon", "ks-icon": true }, h("svg", { key: '65c05869b890b735ed74b991e3272110db1187ef', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: '6ba461bb0540869e127a07fbbd12eeb7499365a9', d: "M15.001 4.863h18" }), h("path", { key: '95ef52f641d25b96041195affe7d9ba0a3063c49', d: "M18 4.863v17.625a1.5 1.5 0 0 1-.177.706L7.176 43.157A1.5 1.5 0 0 0 8.5 45.363h31a1.5 1.5 0 0 0 1.324-2.206L30.176 23.194a1.5 1.5 0 0 1-.177-.706V4.863" }), h("path", { key: '394ea0f1ae448553eddcbae07341b39938a17f63', d: "M18.003 10.501h6m-6 6h6m-6 6h6" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-test"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconTest$1;},KsIconTest$1 = GetKsIconTest$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-test"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-test":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconTest$1(transTagName));
        }
        break;
    }});
}

const KsIconTest = KsIconTest$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconTest, defineCustomElement };
//# sourceMappingURL=ks-icon-test.js.map
//# sourceMappingURL=ks-icon-test.js.map