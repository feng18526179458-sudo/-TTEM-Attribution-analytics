import type { Components, JSX } from "../dist/types/components";

interface KsIconFilledCaution extends Components.KsIconFilledCaution, HTMLElement {}
export const KsIconFilledCaution: {
    prototype: KsIconFilledCaution;
    new (): KsIconFilledCaution;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
