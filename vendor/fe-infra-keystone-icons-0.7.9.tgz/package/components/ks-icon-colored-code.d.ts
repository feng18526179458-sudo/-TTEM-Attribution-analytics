import type { Components, JSX } from "../dist/types/components";

interface KsIconColoredCode extends Components.KsIconColoredCode, HTMLElement {}
export const KsIconColoredCode: {
    prototype: KsIconColoredCode;
    new (): KsIconColoredCode;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
