import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconStrikeThrough$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconStrikeThrough$1 =

    proxyCustomElement(class KsIconStrikeThrough extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-strike-through';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '34cc9f08df05c142aa2b5cae96609fb1541d071a', class: "ks-icon", "ks-icon": true }, h("svg", { key: '39d7124b6fe7079a5da5891c866a3508f21ab5e8', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'd488944304c2f7f40c8f56c057ea83cbb871d6c5', d: "M5.037 24h37.924m-9.693-9.269A9.27 9.27 0 0 0 24 5.462a9.27 9.27 0 0 0-9.269 9.269A9.27 9.27 0 0 0 24 24a9.27 9.27 0 0 1 9.269 9.269A9.27 9.27 0 0 1 24 42.537a9.27 9.27 0 0 1-9.269-9.269", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-strike-through"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconStrikeThrough$1;},KsIconStrikeThrough$1 = GetKsIconStrikeThrough$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-strike-through"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-strike-through":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconStrikeThrough$1(transTagName));
        }
        break;
    }});
}

const KsIconStrikeThrough = KsIconStrikeThrough$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconStrikeThrough, defineCustomElement };
//# sourceMappingURL=ks-icon-strike-through.js.map
//# sourceMappingURL=ks-icon-strike-through.js.map