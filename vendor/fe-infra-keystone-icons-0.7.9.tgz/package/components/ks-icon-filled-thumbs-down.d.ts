import type { Components, JSX } from "../dist/types/components";

interface KsIconFilledThumbsDown extends Components.KsIconFilledThumbsDown, HTMLElement {}
export const KsIconFilledThumbsDown: {
    prototype: KsIconFilledThumbsDown;
    new (): KsIconFilledThumbsDown;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
