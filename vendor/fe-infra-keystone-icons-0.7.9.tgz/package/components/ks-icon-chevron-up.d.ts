import type { Components, JSX } from "../dist/types/components";

interface KsIconChevronUp extends Components.KsIconChevronUp, HTMLElement {}
export const KsIconChevronUp: {
    prototype: KsIconChevronUp;
    new (): KsIconChevronUp;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
