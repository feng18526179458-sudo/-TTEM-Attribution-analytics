import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledThumbsDown$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledThumbsDown$1 =

    proxyCustomElement(class KsIconFilledThumbsDown extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-thumbs-down';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '09b3a80b84c5db0e42edece2e976a1a787ff9417', class: "ks-icon", "ks-icon": true }, h("svg", { key: '81e9b1427cf092bc05864e9400e6f79bda887c59', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: '4f44f980a2470ceaeb129047d1283bb6726d2ccc', d: "M34.496 28.489L27.99 38.61c-.152.236-.413.379-.694.379h0a3.3 3.3 0 0 1-3.3-3.3v-7.2H9.485a1.5 1.5 0 0 1-1.442-1.912l5.143-18a1.5 1.5 0 0 1 1.442-1.088h19.868v20.999z", fill: icon.color }), h("path", { key: '7fb43e936b53eab42c3264605dacda2e731c4f59', d: "M40.496 26.989a1.5 1.5 0 0 1-1.5 1.5h-4.5v-21h4.5a1.5 1.5 0 0 1 1.5 1.5v18z" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-thumbs-down"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFilledThumbsDown$1;},KsIconFilledThumbsDown$1 = GetKsIconFilledThumbsDown$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-thumbs-down"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-thumbs-down":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledThumbsDown$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledThumbsDown = KsIconFilledThumbsDown$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledThumbsDown, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-thumbs-down.js.map
//# sourceMappingURL=ks-icon-filled-thumbs-down.js.map