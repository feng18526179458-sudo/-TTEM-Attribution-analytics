import type { Components, JSX } from "../dist/types/components";

interface KsIconColoredZalo extends Components.KsIconColoredZalo, HTMLElement {}
export const KsIconColoredZalo: {
    prototype: KsIconColoredZalo;
    new (): KsIconColoredZalo;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
