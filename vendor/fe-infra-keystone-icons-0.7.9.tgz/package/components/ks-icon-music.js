import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconMusic$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconMusic$1 =

    proxyCustomElement(class KsIconMusic extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-music';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'f6e7d6a96287c3bfd810522bbc6476e717cbea56', class: "ks-icon", "ks-icon": true }, h("svg", { key: '0128c3757c8f6c6337f3a2a22737be02eba5eadd', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("g", { key: 'e9a7249fa8a0c828777d09dede2cd67cbfdd45a1', stroke: icon.color, "stroke-width": icon.strokeWidth }, h("use", { key: '6efb7c15b797a5fb26eddc2d77c9413287180b4a', href: "#B" }), h("use", { key: '566ed91e0653869b993a1b916671abc3831e6e42', href: "#B", x: "21.522", y: "-2.69" }), h("path", { key: 'c901d28d2f7622f793003d55d4576b642d42ac5c', d: "M17.806 35.586l4.955-24.776a3 3 0 0 1 2.57-2.388l15.242-1.905a3 3 0 0 1 3.314 3.565l-4.563 22.815", "stroke-linecap": "round" })), h("defs", { key: '46116917325c13789edbea29e8614468cfea8563' }, h("path", { key: '8b2696a643429611c4781925f81fdac08d886835', id: "B", d: "M17.644 36.931a6.57 6.57 0 0 1-6.569 6.569 6.57 6.57 0 0 1-6.569-6.569 6.57 6.57 0 0 1 6.569-6.569 6.57 6.57 0 0 1 6.569 6.569z" }))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-music"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconMusic$1;},KsIconMusic$1 = GetKsIconMusic$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-music"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-music":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconMusic$1(transTagName));
        }
        break;
    }});
}

const KsIconMusic = KsIconMusic$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconMusic, defineCustomElement };
//# sourceMappingURL=ks-icon-music.js.map
//# sourceMappingURL=ks-icon-music.js.map