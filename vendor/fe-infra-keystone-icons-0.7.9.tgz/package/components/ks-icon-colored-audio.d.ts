import type { Components, JSX } from "../dist/types/components";

interface KsIconColoredAudio extends Components.KsIconColoredAudio, HTMLElement {}
export const KsIconColoredAudio: {
    prototype: KsIconColoredAudio;
    new (): KsIconColoredAudio;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
