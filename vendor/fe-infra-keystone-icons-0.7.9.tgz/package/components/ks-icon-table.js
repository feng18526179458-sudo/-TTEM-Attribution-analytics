import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconTable$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconTable$1 =

    proxyCustomElement(class KsIconTable extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-table';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '760b82c3ecff2f044969fd25e340e063a81f20fe', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'fe4736165c4dd27d6edcb566fb54da02d63ae960', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("rect", { key: '5941160bd1e6ba671af8ee695d6fd327cc9fde44', x: "5.357", y: "5.357", width: "37.286", height: "37.286", rx: "4.617" }), h("path", { key: '71c4b7ed1279dfca2f910cd62766d4f41ccf2cc2', d: "M13.303 42.857V6.262" }), h("path", { key: 'ecf90f11c1d60dbba4f086345d111a93fb975632', d: "M43.865 12.849H6.857" }), h("path", { key: '08ca6f6b72259d7b9003815129e0e9c57a4c344e', d: "M19.352 32.606h12.235V19.909M23.424 36.68l-1.36-1.36-2.721-2.721 4.081-4.081m4.081-4.534l1.36-1.36 2.721-2.721 4.081 4.081", "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-table"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconTable$1;},KsIconTable$1 = GetKsIconTable$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-table"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-table":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconTable$1(transTagName));
        }
        break;
    }});
}

const KsIconTable = KsIconTable$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconTable, defineCustomElement };
//# sourceMappingURL=ks-icon-table.js.map
//# sourceMappingURL=ks-icon-table.js.map