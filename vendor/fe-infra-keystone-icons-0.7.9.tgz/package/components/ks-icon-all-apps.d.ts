import type { Components, JSX } from "../dist/types/components";

interface KsIconAllApps extends Components.KsIconAllApps, HTMLElement {}
export const KsIconAllApps: {
    prototype: KsIconAllApps;
    new (): KsIconAllApps;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
