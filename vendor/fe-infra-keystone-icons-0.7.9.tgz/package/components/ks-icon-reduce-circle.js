import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconReduceCircle$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconReduceCircle$1 =

    proxyCustomElement(class KsIconReduceCircle extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-reduce-circle';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '692b2983939a4e60eab3fbc1bf0c3c8b956468b0', class: "ks-icon", "ks-icon": true }, h("svg", { key: '6b930f8870d44d7871c701dfef27a78fc3c376ad', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: '76a884feae92be65016f000c770d0560aaf3ac84', d: "M12 24h24", "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: 'f4c3d30980ec1aea189caa48d74a16f894fbdf10', d: "M4.466 24.015c0-10.769 8.73-19.5 19.5-19.5s19.5 8.73 19.5 19.5-8.73 19.5-19.5 19.5-19.5-8.73-19.5-19.5z" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-reduce-circle"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconReduceCircle$1;},KsIconReduceCircle$1 = GetKsIconReduceCircle$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-reduce-circle"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-reduce-circle":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconReduceCircle$1(transTagName));
        }
        break;
    }});
}

const KsIconReduceCircle = KsIconReduceCircle$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconReduceCircle, defineCustomElement };
//# sourceMappingURL=ks-icon-reduce-circle.js.map
//# sourceMappingURL=ks-icon-reduce-circle.js.map