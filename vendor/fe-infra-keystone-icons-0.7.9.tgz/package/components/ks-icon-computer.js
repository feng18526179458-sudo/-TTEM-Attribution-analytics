import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconComputer$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconComputer$1 =

    proxyCustomElement(class KsIconComputer extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-computer';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'f9fefc834691d904e6715b5b61e4b79f6b51476a', class: "ks-icon", "ks-icon": true }, h("svg", { key: '3944ea0ea2f0ae4f52e41ab9fce3d91cee6ca258', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("rect", { key: '8662f54915d273f8806de20d041cf963a303811b', x: "4.5", y: "7.5", width: "39", height: "24", rx: "1.5" }), h("path", { key: '8b5f27b4ed3f7e2f119c0f58287ce3ee068cdd04', d: "M20.062 38.753a1.5 1.5 0 0 0 1.48 1.747h4.917a1.5 1.5 0 0 0 1.48-1.747l-1-6a1.5 1.5 0 0 0-1.48-1.253h-2.917a1.5 1.5 0 0 0-1.48 1.253l-1 6z" }), h("path", { key: '7ef4ce09d38df0910159a2df6cd6385d76a5bb1b', d: "M10.5 40.5h27", "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-computer"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconComputer$1;},KsIconComputer$1 = GetKsIconComputer$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-computer"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-computer":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconComputer$1(transTagName));
        }
        break;
    }});
}

const KsIconComputer = KsIconComputer$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconComputer, defineCustomElement };
//# sourceMappingURL=ks-icon-computer.js.map
//# sourceMappingURL=ks-icon-computer.js.map