import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconPlayCircle$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconPlayCircle$1 =

    proxyCustomElement(class KsIconPlayCircle extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-play-circle';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'ce3c137be0e42f840a1aab3c121efe09b178c13a', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'b0afee2227bbb1fae49c2819f9ae08e4f8ce816d', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("circle", { key: '0e2077aee8f526990ada8302fd386f78f5d34b33', cx: "24", cy: "24", stroke: icon.color, "stroke-width": icon.strokeWidth, r: "19.5" }), h("path", { key: 'af92cad02a6043e33c511af39185a8f4968d68b7', d: "M33.497 22.172L21.28 13.146c-.99-.732-2.391-.025-2.391 1.206v18.052c0 1.231 1.401 1.938 2.391 1.206l12.217-9.026a1.5 1.5 0 0 0 0-2.413z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-play-circle"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconPlayCircle$1;},KsIconPlayCircle$1 = GetKsIconPlayCircle$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-play-circle"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-play-circle":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconPlayCircle$1(transTagName));
        }
        break;
    }});
}

const KsIconPlayCircle = KsIconPlayCircle$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconPlayCircle, defineCustomElement };
//# sourceMappingURL=ks-icon-play-circle.js.map
//# sourceMappingURL=ks-icon-play-circle.js.map