import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconChart$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconChart$1 =

    proxyCustomElement(class KsIconChart extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-chart';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '9c4c86cf81ae13e3d7fcca4e24fed2250b234a6a', class: "ks-icon", "ks-icon": true }, h("svg", { key: '052214bdb879b184ab5b7aad3048dc042657e742', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: 'd4c977508ce1bd1978ee2c1ad4a7cebf7f399f77', d: "M3.028 33.24h42.121" }), h("g", { key: 'c2dd972abb064806e571c731c9577cd0d6c47ecb', "stroke-linecap": "round" }, h("path", { key: '4ebc1ebace4850fbbcd2b03f28a6656be4f6239b', d: "M4.65 29.822v6.857M24 29.822v6.857m19.459-6.857v6.857" }), h("path", { key: '1638837d481df3f0a360d0d1a339e200da1a52d8', d: "M5.626 24.015h1.837c5.512 0 9.187-14.7 16.537-14.7s11.025 14.7 16.537 14.7h1.837", "stroke-linejoin": "round" }))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-chart"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconChart$1;},KsIconChart$1 = GetKsIconChart$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-chart"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-chart":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconChart$1(transTagName));
        }
        break;
    }});
}

const KsIconChart = KsIconChart$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconChart, defineCustomElement };
//# sourceMappingURL=ks-icon-chart.js.map
//# sourceMappingURL=ks-icon-chart.js.map