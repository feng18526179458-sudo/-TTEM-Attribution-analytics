import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledThumbsUp$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledThumbsUp$1 =

    proxyCustomElement(class KsIconFilledThumbsUp extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-thumbs-up';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '26e1ffb155e685abfa36b602198106729f6a68be', class: "ks-icon", "ks-icon": true }, h("svg", { key: '6c0227e19f9441d0df51444e5ad1db43d045edda', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: '2ad966417b838eae77bee6c4a3e7036fc1a29667', d: "M13.513 17.991L20.02 7.87c.152-.236.413-.379.694-.379h0a3.3 3.3 0 0 1 3.3 3.3v7.2h14.511a1.5 1.5 0 0 1 1.442 1.912l-5.143 18a1.5 1.5 0 0 1-1.442 1.088H13.513V17.991z", fill: icon.color }), h("path", { key: 'e2653435803b8654abbddc23673ace3c7baf0942', d: "M7.502 19.491a1.5 1.5 0 0 1 1.5-1.5h4.5v20.999h-4.5a1.5 1.5 0 0 1-1.5-1.5v-18z" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-thumbs-up"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFilledThumbsUp$1;},KsIconFilledThumbsUp$1 = GetKsIconFilledThumbsUp$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-thumbs-up"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-thumbs-up":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledThumbsUp$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledThumbsUp = KsIconFilledThumbsUp$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledThumbsUp, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-thumbs-up.js.map
//# sourceMappingURL=ks-icon-filled-thumbs-up.js.map