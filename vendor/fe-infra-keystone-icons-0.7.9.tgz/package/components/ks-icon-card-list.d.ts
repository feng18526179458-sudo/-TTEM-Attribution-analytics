import type { Components, JSX } from "../dist/types/components";

interface KsIconCardList extends Components.KsIconCardList, HTMLElement {}
export const KsIconCardList: {
    prototype: KsIconCardList;
    new (): KsIconCardList;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
