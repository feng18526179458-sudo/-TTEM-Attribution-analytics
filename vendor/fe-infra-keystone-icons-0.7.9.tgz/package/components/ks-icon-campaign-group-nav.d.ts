import type { Components, JSX } from "../dist/types/components";

interface KsIconCampaignGroupNav extends Components.KsIconCampaignGroupNav, HTMLElement {}
export const KsIconCampaignGroupNav: {
    prototype: KsIconCampaignGroupNav;
    new (): KsIconCampaignGroupNav;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
