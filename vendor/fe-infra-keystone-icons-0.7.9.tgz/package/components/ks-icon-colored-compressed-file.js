import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconColoredCompressedFile$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconColoredCompressedFile$1 =

    proxyCustomElement(class KsIconColoredCompressedFile extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-colored-compressed-file';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'c3289c79865a18b6870ed3726b0b96a6a29227d1', class: "ks-icon", "ks-icon": true }, h("svg", { key: '9f1646163a9b266d43c4bda8e64cd8eb15f7f469', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("rect", { key: '2a84d03284f21cf1ac4158baa9011f576a72311a', width: "48", height: "48", rx: "1.556", fill: "#7686a1" }), h("g", { key: 'd3ba3952254bc2a55625bc1ac4a0659cc9a837a1', fill: "#fff" }, h("path", { key: '4b7e903c3eda64aaa643790efb8e27682d6ce0b9', d: "M28 0h-5.333v2.667h-2c-.368 0-.667.298-.667.667V6c0 .368.299.667.667.667h2v2.667h-2c-.368 0-.667.298-.667.667v2.667c0 .368.299.667.667.667h2V16h-2c-.368 0-.667.299-.667.667v2.667c0 .368.299.667.667.667h2v5.333h2.667v-2.667h2c.368 0 .667-.298.667-.667v-2.667c0-.368-.299-.667-.667-.667h-2V16h2c.368 0 .667-.299.667-.667v-2.667c0-.368-.299-.667-.667-.667h-2V9.333h2c.368 0 .667-.298.667-.667V6c0-.368-.299-.667-.667-.667h-2V2.667h2c.368 0 .667-.298.667-.667V0z" }), h("path", { key: '0e637ad8c94fa00edeb71ef9fcd98681b91b118e', "fill-rule": "evenodd", d: "M20.667 25.333c-.368 0-.667.298-.667.667v8c0 .368.299.667.667.667h6.667c.368 0 .667-.298.667-.667v-8c0-.368-.299-.667-.667-.667h-6.667zm1.333 4c-.368 0-.667.298-.667.667v2.667c0 .368.298.667.667.667h4c.368 0 .667-.298.667-.667V30c0-.368-.298-.667-.667-.667h-4z" }))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-colored-compressed-file"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconColoredCompressedFile$1;},KsIconColoredCompressedFile$1 = GetKsIconColoredCompressedFile$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-colored-compressed-file"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-colored-compressed-file":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconColoredCompressedFile$1(transTagName));
        }
        break;
    }});
}

const KsIconColoredCompressedFile = KsIconColoredCompressedFile$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconColoredCompressedFile, defineCustomElement };
//# sourceMappingURL=ks-icon-colored-compressed-file.js.map
//# sourceMappingURL=ks-icon-colored-compressed-file.js.map