import type { Components, JSX } from "../dist/types/components";

interface KsIconDisconnect extends Components.KsIconDisconnect, HTMLElement {}
export const KsIconDisconnect: {
    prototype: KsIconDisconnect;
    new (): KsIconDisconnect;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
