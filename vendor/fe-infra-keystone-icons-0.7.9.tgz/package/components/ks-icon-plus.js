import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconPlus$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconPlus$1 =

    proxyCustomElement(class KsIconPlus extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-plus';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '815e27789c2ebc03db6d048ea13c2857cea6c8f1', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'da87f5fe041269486577f5b25901a95fba77aa98', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: 'debeaf19bf18bf52c877c795415efedfd39902af', d: "M23.997 4.908v38.184" }), h("path", { key: '5a153da1fa12c55dd3138ac3024d4bfb362ec2be', d: "M4.908 24h38.184" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-plus"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconPlus$1;},KsIconPlus$1 = GetKsIconPlus$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-plus"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-plus":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconPlus$1(transTagName));
        }
        break;
    }});
}

const KsIconPlus = KsIconPlus$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconPlus, defineCustomElement };
//# sourceMappingURL=ks-icon-plus.js.map
//# sourceMappingURL=ks-icon-plus.js.map