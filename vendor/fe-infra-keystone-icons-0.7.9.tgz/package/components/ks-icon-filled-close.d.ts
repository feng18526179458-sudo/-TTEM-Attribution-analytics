import type { Components, JSX } from "../dist/types/components";

interface KsIconFilledClose extends Components.KsIconFilledClose, HTMLElement {}
export const KsIconFilledClose: {
    prototype: KsIconFilledClose;
    new (): KsIconFilledClose;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
