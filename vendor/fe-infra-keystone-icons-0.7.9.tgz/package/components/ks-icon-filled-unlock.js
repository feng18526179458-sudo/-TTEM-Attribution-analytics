import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledUnlock$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledUnlock$1 =

    proxyCustomElement(class KsIconFilledUnlock extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-unlock';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
        this.innerColor = 'white';
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'af7599a9e98246287f2c9dcc3acd2717aeac3aab', class: "ks-icon", "ks-icon": true }, h("svg", { key: '107133ef745d1cd56bceac43fd438baa470c02d9', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("circle", { key: 'cab2045a22af9688b0423d3a72b570b72fbcac04', cx: "23", cy: "31", fill: icon.color, r: "14" }), h("g", { key: '60cd4e20cbb0c1904250eb07396656d376b28f96', fill: this.innerColor }, h("path", { key: '17dc9c553fb5fa69b8bac6fdf6ba8168a252d113', d: "M25.698 28.2a2.7 2.7 0 1 1-5.4 0 2.7 2.7 0 0 1 5.4 0z", stroke: this.innerColor, "stroke-width": icon.strokeWidth }), h("path", { key: '71f60010ef2c64763361ec89115ec9b1213da08a', d: "M21.494 37.999a1.5 1.5 0 1 0 3 0h-3zm0-11.2v11.2h3v-11.2h-3z" })), h("path", { key: 'eabccb15db7b5b0751831b1c7706816ab86d9700', d: "M32.998 25.5V14.25a9.75 9.75 0 0 0-9.75-9.75h0a9.75 9.75 0 0 0-9.75 9.75V15", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-unlock"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"],
      "innerColor": [1, "inner-color"]
    }]);return innerKsIconFilledUnlock$1;},KsIconFilledUnlock$1 = GetKsIconFilledUnlock$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-unlock"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-unlock":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledUnlock$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledUnlock = KsIconFilledUnlock$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledUnlock, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-unlock.js.map
//# sourceMappingURL=ks-icon-filled-unlock.js.map