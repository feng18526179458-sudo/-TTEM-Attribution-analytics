import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconTiktokBlack$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconTiktokBlack$1 =

    proxyCustomElement(class KsIconTiktokBlack extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-tiktok-black';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '79b56a59e60ff44a4174563bb0481c0ea47eff78', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'c6734a8350b2a37bfebf5ceabe9c78aa74fd8dc3', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("g", { key: 'de7840db9c9cc1fedcf1e15f3599e27e3c4917ab', "clip-path": "url(#A)" }, h("g", { key: '9e1459c57afdc6579fbd33fffa1f94a77c212b2a', fill: "#25f4ee" }, h("path", { key: 'b60ec5f75cb7dc305db878b178d9969df5c4ebd7', d: "M19.683 19.22v-1.756a13.62 13.62 0 0 0-1.839-.133c-7.523 0-13.644 6.121-13.644 13.645 0 4.617 2.306 8.702 5.825 11.171a13.59 13.59 0 0 1-3.664-9.291A13.66 13.66 0 0 1 19.684 19.22h-.001zm.322 19.868c3.357 0 6.095-2.671 6.219-5.997l.012-29.709h5.427a10.33 10.33 0 0 1-.175-1.882h-7.413l-.012 29.709c-.124 3.326-2.863 5.997-6.219 5.997a6.19 6.19 0 0 1-2.891-.716 6.22 6.22 0 0 0 5.051 2.597zm21.797-25.623v-1.651c-2.07 0-3.999-.615-5.617-1.671 1.44 1.654 3.397 2.847 5.617 3.322z" })), h("g", { key: 'f4d2b138a2e520bd0a7b5c5ad90de523a9022117', fill: "#fe2c55" }, h("path", { key: '931bbc5c4a7e15a6b72e3c27a567025703c09d9c', d: "M36.187 10.143c-1.578-1.812-2.536-4.176-2.536-6.762h-1.986c.523 2.824 2.199 5.248 4.522 6.762zm-18.343 14.6a6.24 6.24 0 0 0-6.232 6.232c0 2.393 1.358 4.472 3.341 5.515a6.19 6.19 0 0 1-1.18-3.635 6.24 6.24 0 0 1 6.232-6.232c.641 0 1.256.106 1.839.288v-7.568a13.62 13.62 0 0 0-1.839-.133l-.322.008v5.812c-.582-.182-1.198-.288-1.839-.288l-.001.001zm23.958-11.278v5.761a17.63 17.63 0 0 1-10.313-3.316v15.066c0 7.524-6.121 13.644-13.644 13.644-2.908 0-5.603-.917-7.82-2.473 2.492 2.676 6.043 4.354 9.98 4.354 7.524 0 13.644-6.121 13.644-13.644V17.791a17.63 17.63 0 0 0 10.313 3.316v-7.414c-.742 0-1.464-.08-2.16-.229z" })), h("path", { key: '121ee08850686ba8a5c61ed5813881e093f0772f', d: "M31.489 30.976V15.91a17.63 17.63 0 0 0 10.313 3.316v-5.761c-2.22-.475-4.176-1.667-5.617-3.322a10.33 10.33 0 0 1-4.522-6.762h-5.427l-.012 29.709c-.124 3.327-2.863 5.997-6.219 5.997a6.22 6.22 0 0 1-5.051-2.597c-1.983-1.044-3.341-3.123-3.341-5.515a6.24 6.24 0 0 1 6.232-6.232c.641 0 1.256.106 1.839.288v-5.812c-7.375.173-13.323 6.221-13.323 13.637a13.59 13.59 0 0 0 3.664 9.291c2.216 1.555 4.912 2.473 7.82 2.473 7.523 0 13.644-6.121 13.644-13.644v.001z", fill: "#000" })), h("defs", { key: 'b04470ff8d3cda8125c58c5cadb3d74259d60923' }, h("clipPath", { key: '58f0c794bce482afc8113477d94fe1b87b5c08a3', id: "A" }, h("path", { key: '019b222e8ef3b97ab9d3493979a95841a68725f7', fill: "#fff", transform: "translate(4.2 1.5)", d: "M0 0h39.764v45H0z" })))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-tiktok-black"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconTiktokBlack$1;},KsIconTiktokBlack$1 = GetKsIconTiktokBlack$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-tiktok-black"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-tiktok-black":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconTiktokBlack$1(transTagName));
        }
        break;
    }});
}

const KsIconTiktokBlack = KsIconTiktokBlack$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconTiktokBlack, defineCustomElement };
//# sourceMappingURL=ks-icon-tiktok-black.js.map
//# sourceMappingURL=ks-icon-tiktok-black.js.map