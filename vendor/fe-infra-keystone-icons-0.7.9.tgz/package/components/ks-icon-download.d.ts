import type { Components, JSX } from "../dist/types/components";

interface KsIconDownload extends Components.KsIconDownload, HTMLElement {}
export const KsIconDownload: {
    prototype: KsIconDownload;
    new (): KsIconDownload;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
