import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconApple$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconApple$1 =

    proxyCustomElement(class KsIconApple extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-apple';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '6b695506c2ef18e26ec9bc7a7df4e0a4a7bbee10', class: "ks-icon", "ks-icon": true }, h("svg", { key: '5a5442c256ee0d8fab02b96035713e5a94b1274d', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color }, h("path", { key: 'a7649120e3e751f82c8cc71e5df5044b815dbeaf', d: "M24.097 12.31c.082-2.231.713-4.192 1.876-5.83C27.142 4.833 29.074 3.663 31.72 3l.055.243v.424c0 .961-.234 2.064-.697 3.277-.485 1.174-1.243 2.279-2.249 3.277-.941.879-1.812 1.461-2.582 1.724-.254.075-.602.15-1.023.217l-1.126.149z", fill: icon.color }), h("path", { key: 'e91aeba1085b6638d92f14d2e6567528842ea247', d: "M24.537 15.621c-2.988 0-5.063-2.629-8.01-2.629s-9.02 2.695-9.02 12 5.392 15.3 5.996 16 1.998 2.5 4.159 2.5 4.527-1.709 6.876-1.709 5.306 1.709 7.237 1.709 2.724-.783 4.038-2.133 3.82-5.471 4.695-7.944c-1.441-.854-5.262-3.171-5.262-8.422 0-3.501 1.286-6.409 3.858-8.725-1.687-2.183-3.644-3.275-5.871-3.275-3.34 0-5.706 2.629-8.695 2.629z", "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-apple"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconApple$1;},KsIconApple$1 = GetKsIconApple$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-apple"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-apple":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconApple$1(transTagName));
        }
        break;
    }});
}

const KsIconApple = KsIconApple$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconApple, defineCustomElement };
//# sourceMappingURL=ks-icon-apple.js.map
//# sourceMappingURL=ks-icon-apple.js.map