import type { Components, JSX } from "../dist/types/components";

interface KsIconColoredExcel extends Components.KsIconColoredExcel, HTMLElement {}
export const KsIconColoredExcel: {
    prototype: KsIconColoredExcel;
    new (): KsIconColoredExcel;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
