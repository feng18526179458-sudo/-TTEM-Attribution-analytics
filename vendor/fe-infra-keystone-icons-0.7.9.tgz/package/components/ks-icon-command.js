import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconCommand$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconCommand$1 =

    proxyCustomElement(class KsIconCommand extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-command';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'a5a5c446a0105e47e861b25bda59f57467213998', class: "ks-icon", "ks-icon": true }, h("svg", { key: '66dc61a04de5d6634bf1ec8bf87b1b9e51118ee9', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '5c8cdf4c447ef49045d465ba79a4919db7d6e1ac', d: "M13.3239 13.3622H9.48575C7.366 13.3622 5.6476 11.6183 5.6476 9.46717C5.6476 7.31602 7.366 5.57216 9.48575 5.57216C11.6055 5.57216 13.3239 7.31601 13.3239 9.46716V13.3622ZM13.3239 13.3622H34.6023M13.3239 13.3622V34.7873M34.6023 13.3622H38.588C40.7485 13.3622 42.5 11.5848 42.5 9.39227C42.5 7.19975 40.7302 5.42236 38.5697 5.42236C36.3888 5.42236 34.6023 7.21652 34.6023 9.42972V13.3622ZM34.6023 13.3622V34.7873M34.6023 34.7873V38.6074C34.6023 40.7999 36.391 42.5773 38.5515 42.5773C40.6712 42.5773 42.4262 40.8335 42.4262 38.6823C42.4262 36.5312 40.7078 34.7873 38.588 34.7873H34.6023ZM34.6023 34.7873H13.3239M13.3239 34.7873H9.33815C7.21839 34.7873 5.5 36.5312 5.5 38.6823C5.5 40.8335 7.25495 42.5773 9.3747 42.5773C11.5352 42.5773 13.3239 40.7999 13.3239 38.6074V34.7873Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-command"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconCommand$1;},KsIconCommand$1 = GetKsIconCommand$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-command"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-command":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconCommand$1(transTagName));
        }
        break;
    }});
}

const KsIconCommand = KsIconCommand$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconCommand, defineCustomElement };
//# sourceMappingURL=ks-icon-command.js.map
//# sourceMappingURL=ks-icon-command.js.map