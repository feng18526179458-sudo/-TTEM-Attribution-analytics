import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconUndo$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconUndo$1 =

    proxyCustomElement(class KsIconUndo extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-undo';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'eb96ed87f890cd16ec7ea38dd65fac51601fe88b', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: '586796c1c6d58b603f995efe4b8ecdc526ddcfdf', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: '8e25f47eab2bbb742ff80770df9f5270bbd76809', d: "M9.985 18.828l-5.509-5.509m5.508-5.508L4.475 13.32m.821-.128h25.97A12 12 0 0 1 43.264 25.19h0a12 12 0 0 1-11.998 11.998H10.264" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-undo"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconUndo$1;},KsIconUndo$1 = GetKsIconUndo$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-undo"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-undo":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconUndo$1(transTagName));
        }
        break;
    }});
}

const KsIconUndo = KsIconUndo$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconUndo, defineCustomElement };
//# sourceMappingURL=ks-icon-undo.js.map
//# sourceMappingURL=ks-icon-undo.js.map