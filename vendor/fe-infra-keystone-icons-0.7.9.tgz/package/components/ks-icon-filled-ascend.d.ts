import type { Components, JSX } from "../dist/types/components";

interface KsIconFilledAscend extends Components.KsIconFilledAscend, HTMLElement {}
export const KsIconFilledAscend: {
    prototype: KsIconFilledAscend;
    new (): KsIconFilledAscend;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
