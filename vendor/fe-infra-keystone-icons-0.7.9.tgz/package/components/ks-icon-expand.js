import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconExpand$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconExpand$1 =

    proxyCustomElement(class KsIconExpand extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-expand';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '9d9fc5385f383c0284aed9d821f16d5d600d6e1a', class: "ks-icon", "ks-icon": true }, h("svg", { key: '9a7a7b57d34a981314c0b652d6891f10d0d5513b', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '1bf36f478a419323895f7298b16a986edcb1fa1e', d: "M8.571 16.906h8.698V8.814a3.43 3.43 0 0 1 3.429-3.429h18.731a3.43 3.43 0 0 1 3.428 3.429v18.609a3.43 3.43 0 0 1-3.428 3.429h-9.062v8.334a3.43 3.43 0 0 1-3.428 3.429H8.571a3.43 3.43 0 0 1-3.429-3.429V20.335a3.43 3.43 0 0 1 3.429-3.429z", stroke: icon.color, "stroke-width": icon.strokeWidth })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-expand"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconExpand$1;},KsIconExpand$1 = GetKsIconExpand$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-expand"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-expand":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconExpand$1(transTagName));
        }
        break;
    }});
}

const KsIconExpand = KsIconExpand$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconExpand, defineCustomElement };
//# sourceMappingURL=ks-icon-expand.js.map
//# sourceMappingURL=ks-icon-expand.js.map