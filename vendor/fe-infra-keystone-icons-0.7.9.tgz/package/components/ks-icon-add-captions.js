import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconAddCaptions$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconAddCaptions$1 =

    proxyCustomElement(class KsIconAddCaptions extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-add-captions';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '658548db5a0a8186599718c17a40114730de4915', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'e743de6b1dddeb04c46664adf267287f0b99e468', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'b14b4e8ac5c759f5d8bdec43cb4a7dac8d14f368', d: "M12.271 37.273l8.811-26.545h5.836l8.811 26.545h-3.577l-3.389-10.467h-9.526l-3.389 10.467h-3.577zm11.71-25.265L20.14 23.944h7.719l-3.878-11.936zM7.855 5.61c-.284 1.161-.633 2.587-1.547 3.465s-2.4 1.212-3.609 1.485c-1.1.248-1.971.444-1.971.95s.871.702 1.971.95c1.209.273 2.695.608 3.609 1.485s1.263 2.304 1.547 3.464c.258 1.056.463 1.892.99 1.892s.731-.836.99-1.892c.284-1.161.633-2.587 1.547-3.464s2.4-1.212 3.609-1.485c1.1-.248 1.971-.444 1.971-.95s-.871-.702-1.971-.95c-1.209-.273-2.695-.608-3.609-1.485S10.118 6.771 9.834 5.61c-.258-1.056-.463-1.892-.99-1.892s-.731.836-.99 1.892z", fill: icon.color }), h("path", { key: '6c4daf50e8a166f6c8180dce449176ca172f24f3', d: "M15.402 4.875h24.352a3.43 3.43 0 0 1 3.429 3.429v7.403M4.848 32.212v7.575a3.43 3.43 0 0 0 3.429 3.429h31.473a3.43 3.43 0 0 0 3.428-3.429v-7.312m.108-11.18v4.527M4.848 21.295v4.527", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-add-captions"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconAddCaptions$1;},KsIconAddCaptions$1 = GetKsIconAddCaptions$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-add-captions"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-add-captions":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconAddCaptions$1(transTagName));
        }
        break;
    }});
}

const KsIconAddCaptions = KsIconAddCaptions$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconAddCaptions, defineCustomElement };
//# sourceMappingURL=ks-icon-add-captions.js.map
//# sourceMappingURL=ks-icon-add-captions.js.map