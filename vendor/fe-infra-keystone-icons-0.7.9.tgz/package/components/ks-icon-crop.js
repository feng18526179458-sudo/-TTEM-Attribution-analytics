import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconCrop$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconCrop$1 =

    proxyCustomElement(class KsIconCrop extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-crop';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '166587e2d1c957cc77c35cc2289dd8be02792fe3', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'ec4fee841ad41ab8bc1e6677e14d7c02fe6bf348', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }, h("path", { key: '20b3236f0df55d1c843860e78f1e3f9a22c7b922', d: "M11.398 5.399v31.5h31.5" }), h("path", { key: 'bcf21289b0a3020271b42baf224984602cd7588d', d: "M36.897 42.899v-31.5h-31.5m6.001 25.5l30-30" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-crop"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconCrop$1;},KsIconCrop$1 = GetKsIconCrop$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-crop"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-crop":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconCrop$1(transTagName));
        }
        break;
    }});
}

const KsIconCrop = KsIconCrop$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconCrop, defineCustomElement };
//# sourceMappingURL=ks-icon-crop.js.map
//# sourceMappingURL=ks-icon-crop.js.map