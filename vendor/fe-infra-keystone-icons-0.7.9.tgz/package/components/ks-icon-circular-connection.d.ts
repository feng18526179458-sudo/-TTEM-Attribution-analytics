import type { Components, JSX } from "../dist/types/components";

interface KsIconCircularConnection extends Components.KsIconCircularConnection, HTMLElement {}
export const KsIconCircularConnection: {
    prototype: KsIconCircularConnection;
    new (): KsIconCircularConnection;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
