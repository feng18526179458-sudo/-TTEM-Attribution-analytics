import type { Components, JSX } from "../dist/types/components";

interface KsIconFilledCheck extends Components.KsIconFilledCheck, HTMLElement {}
export const KsIconFilledCheck: {
    prototype: KsIconFilledCheck;
    new (): KsIconFilledCheck;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
