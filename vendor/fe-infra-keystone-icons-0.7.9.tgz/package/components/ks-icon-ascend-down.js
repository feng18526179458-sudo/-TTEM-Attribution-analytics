import { proxyCustomElement, HTMLElement, createEvent, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconAscendDown$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconAscendDown$1 =

    proxyCustomElement(class KsIconAscendDown extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this.triangleUpClick = createEvent(this, "triangleUpClick", 7);
        this.triangleDownClick = createEvent(this, "triangleDownClick", 7);
        this['ks-icon-name'] = 'ks-icon-ascend-down';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'a0d48cc3bf622990c3e2a372657db029c58776fb', class: "ks-icon", "ks-icon": true }, h("svg", { key: '9849f8262ae5fa79674a1d8e5b96f7fe4791b85d', width: icon.width, height: icon.height, viewBox: "0 0 48 48", xmlns: "http://www.w3.org/2000/svg", "fill-rule": "evenodd", "clip-rule": "evenodd", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: 'b5f2ea00899c3a084b9eb6fbecf280f66cba24d4', part: "triangleUp", fill: "transparent", d: "M25.5589 6.42591C25.2287 6.07567 24.7688 5.8769 24.2875 5.87637C23.8061 5.87583 23.3458 6.07359 23.0149 6.4231L12.8771 17.1289C12.3963 17.6366 12.2639 18.3816 12.5402 19.0238C12.8165 19.6661 13.4486 20.0822 14.1477 20.0822H24.2631H34.3785C35.0769 20.0822 35.7085 19.6669 35.9852 19.0256C36.262 18.3843 36.1309 17.6399 35.6518 17.1317L25.5589 6.42591Z", onClick: () => this.triangleUpClick.emit() }), h("path", { key: '05cd8507864c99fc0c1c7f5b7e22c608a4322506', part: "triangleDown", fill: icon.color, d: "M34.3302 28.2853C35.0143 28.2853 35.633 28.6921 35.9041 29.3203C36.1752 29.9485 36.0468 30.6777 35.5775 31.1755L25.27 42.1088C24.9465 42.4519 24.4961 42.6466 24.0246 42.6471C23.5531 42.6477 23.1021 42.454 22.7779 42.1116L12.4246 31.1783C11.9537 30.681 11.824 29.9511 12.0947 29.3221C12.3653 28.693 12.9845 28.2853 13.6693 28.2853H23.9998H34.3302Z", onClick: () => this.triangleDownClick.emit() })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-ascend-down"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconAscendDown$1;},KsIconAscendDown$1 = GetKsIconAscendDown$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-ascend-down"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-ascend-down":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconAscendDown$1(transTagName));
        }
        break;
    }});
}

const KsIconAscendDown = KsIconAscendDown$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconAscendDown, defineCustomElement };
//# sourceMappingURL=ks-icon-ascend-down.js.map
//# sourceMappingURL=ks-icon-ascend-down.js.map