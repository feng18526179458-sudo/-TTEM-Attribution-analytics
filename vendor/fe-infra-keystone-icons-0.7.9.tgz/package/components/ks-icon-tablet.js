import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconTablet$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconTablet$1 =

    proxyCustomElement(class KsIconTablet extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-tablet';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '77ef7be65d15a8aca220bbea3fa249641ae8dc80', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'b4c00f3a43a70f7fbed991e4e6f94cc0ea619a4f', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", "stroke-width": icon.strokeWidth, stroke: icon.color }, h("rect", { key: 'ce653563b3284844060b94301092e86a3a105196', x: "43.5", y: "10.5", width: "27", height: "39", rx: "1.5", transform: "rotate(90 43.497 10.5)" }), h("path", { key: 'bcb5aa763081f0c42ba368dda696e6e6a4267a41', d: "M10.49 21.73v6", "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-tablet"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconTablet$1;},KsIconTablet$1 = GetKsIconTablet$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-tablet"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-tablet":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconTablet$1(transTagName));
        }
        break;
    }});
}

const KsIconTablet = KsIconTablet$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconTablet, defineCustomElement };
//# sourceMappingURL=ks-icon-tablet.js.map
//# sourceMappingURL=ks-icon-tablet.js.map