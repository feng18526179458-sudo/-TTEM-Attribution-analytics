import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconChevronRight$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconChevronRight$1 =

    proxyCustomElement(class KsIconChevronRight extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-chevron-right';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'efc3db696f3513bfc53f9a24fac4479d5ed05b70', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'af55df7c67b17a09121be6a9d6b6431bb32aebd7', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'dafc5487309088c773294f34a132b0a0e4f8bb99', d: "M15 6l16.939 16.939a1.5 1.5 0 0 1 0 2.121L15 42", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-chevron-right"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconChevronRight$1;},KsIconChevronRight$1 = GetKsIconChevronRight$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-chevron-right"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-chevron-right":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconChevronRight$1(transTagName));
        }
        break;
    }});
}

const KsIconChevronRight = KsIconChevronRight$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconChevronRight, defineCustomElement };
//# sourceMappingURL=ks-icon-chevron-right.js.map
//# sourceMappingURL=ks-icon-chevron-right.js.map