import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconArrowUp$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconArrowUp$1 =

    proxyCustomElement(class KsIconArrowUp extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-arrow-up';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '20c8b78b270595c7d9cede8db4496936ac3612a6', class: "ks-icon", "ks-icon": true }, h("svg", { key: '33ff9ef24b95af2abdda7300f561d0f7f1ba2d13', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }, h("path", { key: '94713efdfc478ba4f5de2e66a659bcf27d4e0b4f', d: "M11.998 12.929L22.964 2.485a1.5 1.5 0 0 1 2.069 0l10.965 10.443M23.986 4.5v39" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-arrow-up"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconArrowUp$1;},KsIconArrowUp$1 = GetKsIconArrowUp$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-arrow-up"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-arrow-up":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconArrowUp$1(transTagName));
        }
        break;
    }});
}

const KsIconArrowUp = KsIconArrowUp$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconArrowUp, defineCustomElement };
//# sourceMappingURL=ks-icon-arrow-up.js.map
//# sourceMappingURL=ks-icon-arrow-up.js.map