import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledVolumeUp$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledVolumeUp$1 =

    proxyCustomElement(class KsIconFilledVolumeUp extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-volume-up';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '71dc6530f02b3842b141141f52a54696fe98db10', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: 'efa5e345195c9afee3ffcca432d6649883861300', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'c5c1256b18771cd25157776021086555ae8e845b', d: "M10.12 15.972a2.96 2.96 0 0 0-2.958 2.958v11.01a2.96 2.96 0 0 0 2.958 2.958h4.143a1.97 1.97 0 0 1 1.441.626l8.751 9.362c1.222 1.307 3.413.443 3.413-1.346V6.491c0-1.828-2.272-2.672-3.466-1.287l-8.692 10.084a1.97 1.97 0 0 1-1.494.685H10.12z", fill: icon.color }), h("path", { key: 'b2004d078f0df201117b6569b4b7baa58e21077c', d: "M32.177 16.094c4.375 4.375 4.375 11.467 0 15.842m6.871-19.803c6.562 6.562 6.562 17.201 0 23.762", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-volume-up"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFilledVolumeUp$1;},KsIconFilledVolumeUp$1 = GetKsIconFilledVolumeUp$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-volume-up"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-volume-up":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledVolumeUp$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledVolumeUp = KsIconFilledVolumeUp$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledVolumeUp, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-volume-up.js.map
//# sourceMappingURL=ks-icon-filled-volume-up.js.map