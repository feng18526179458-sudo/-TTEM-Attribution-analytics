import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconTiktokLive$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconTiktokLive$1 =

    proxyCustomElement(class KsIconTiktokLive extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-tiktok-live';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '28640589a6d906baf8779506a68f21a0464c1632', class: "ks-icon", "ks-icon": true }, h("svg", { key: '40df87d3498858a37d0a3b3878815145058e7b78', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'fba37cc214ca437349599606b1cd5b438da5e5d9', d: "M7.88916 14.5216V13.0423C7.88916 11.3854 9.23231 10.0423 10.8892 10.0423H37.1112C38.7681 10.0423 40.1112 11.3854 40.1112 13.0423V14.5216", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: 'dcd131fa93ed8eafecfc17cfc6a0559b41c04257', d: "M7.88916 35.5207V37C7.88916 38.6569 9.23231 40 10.8892 40H37.1112C38.7681 40 40.1112 38.6569 40.1112 37V35.5207", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '2694f88e3ab5bbb55c08e00126069e26a5d33b42', d: "M5.57373 19.3127V28.6406C5.57373 29.1929 6.02145 29.6406 6.57373 29.6406H10.772M15.8999 18.9766L15.8999 29.9766M22.0486 19.3127L25.3036 29.693H27.6387L31.389 19.3127M42.4264 19.2878H38.1233C37.571 19.2878 37.1233 19.7355 37.1233 20.2878V24.4904M42.4264 29.6931H38.1233C37.571 29.6931 37.1233 29.2454 37.1233 28.6931V24.4904M37.1233 24.4904H42.4264", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: '986f7c98261e07adc1778b67644d4d91768d50fe', d: "M17.8132 3.60669L24.0001 9.79357L30.187 3.60669", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-tiktok-live"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconTiktokLive$1;},KsIconTiktokLive$1 = GetKsIconTiktokLive$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-tiktok-live"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-tiktok-live":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconTiktokLive$1(transTagName));
        }
        break;
    }});
}

const KsIconTiktokLive = KsIconTiktokLive$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconTiktokLive, defineCustomElement };
//# sourceMappingURL=ks-icon-tiktok-live.js.map
//# sourceMappingURL=ks-icon-tiktok-live.js.map