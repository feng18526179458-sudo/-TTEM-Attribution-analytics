import { proxyCustomElement, HTMLElement, createEvent, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledAscend$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledAscend$1 =

    proxyCustomElement(class KsIconFilledAscend extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this.triangleUpClick = createEvent(this, "triangleUpClick", 7);
        this.triangleDownClick = createEvent(this, "triangleDownClick", 7);
        this['ks-icon-name'] = 'ks-icon-filled-ascend';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '64c59694754aeaabab907e28a9af00d8d0cec578', class: "ks-icon", "ks-icon": true }, h("svg", { key: '6f38b9eebdba905b413ac749e6bbdc39e0d27f87', width: icon.width, height: icon.height, viewBox: "0 0 48 48", xmlns: "http://www.w3.org/2000/svg", fill: icon.color, stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" }, h("path", { key: '1b9ff4c2124774ef2dfd3e70abd32e754dd9d755', part: "triangleUp", d: "M34.3302 19.714C35.0143 19.714 35.633 19.3072 35.9041 18.6791C36.1752 18.0509 36.0468 17.3217 35.5775 16.8239L25.27 5.89054C24.9465 5.54746 24.4961 5.35275 24.0246 5.35223C23.5531 5.35171 23.1021 5.54542 22.7779 5.88778L12.4246 16.8211C11.9537 17.3184 11.824 18.0482 12.0947 18.6773C12.3653 19.3064 12.9845 19.714 13.6693 19.714H23.9998H34.3302Z", onClick: () => this.triangleUpClick.emit() }), h("path", { key: 'f0b278c838ca534c80929468dbe6e229253f866e', part: "triangleDown", d: "M34.3302 28.2853C35.0143 28.2853 35.633 28.6921 35.9041 29.3203C36.1752 29.9485 36.0468 30.6777 35.5775 31.1755L25.27 42.1088C24.9465 42.4519 24.4961 42.6466 24.0246 42.6471C23.5531 42.6477 23.1021 42.454 22.7779 42.1116L12.4246 31.1783C11.9537 30.681 11.824 29.9511 12.0947 29.3221C12.3653 28.693 12.9845 28.2853 13.6693 28.2853H23.9998H34.3302Z", onClick: () => this.triangleDownClick.emit() })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-ascend"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFilledAscend$1;},KsIconFilledAscend$1 = GetKsIconFilledAscend$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-ascend"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-ascend":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledAscend$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledAscend = KsIconFilledAscend$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledAscend, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-ascend.js.map
//# sourceMappingURL=ks-icon-filled-ascend.js.map