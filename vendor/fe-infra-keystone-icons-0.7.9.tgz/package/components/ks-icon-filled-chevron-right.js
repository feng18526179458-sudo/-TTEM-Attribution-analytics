import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledChevronRight$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledChevronRight$1 =

    proxyCustomElement(class KsIconFilledChevronRight extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-chevron-right';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '0843aaf2246eaaeea67b9a200e3b14cf2ab3cab6', class: "ks-icon", "ks-icon": true }, h("svg", { key: '7642ae0e3c48a66521a203050890ac49ab5b2b60', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'c4128756ae6511476accf0849f6f0d8525353ea8', d: "M34.0395 25.0581C34.6216 24.473 34.6216 23.5275 34.0395 22.9424L16.0874 4.89578C15.659 4.46516 15.0132 4.33538 14.4517 4.56709C13.8902 4.7988 13.5239 5.34625 13.5239 5.95366V42.0464C13.5239 42.6539 13.8902 43.2013 14.4517 43.433C15.0132 43.6647 15.659 43.535 16.0874 43.1043L34.0395 25.0581Z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-chevron-right"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFilledChevronRight$1;},KsIconFilledChevronRight$1 = GetKsIconFilledChevronRight$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-chevron-right"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-chevron-right":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledChevronRight$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledChevronRight = KsIconFilledChevronRight$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledChevronRight, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-chevron-right.js.map
//# sourceMappingURL=ks-icon-filled-chevron-right.js.map