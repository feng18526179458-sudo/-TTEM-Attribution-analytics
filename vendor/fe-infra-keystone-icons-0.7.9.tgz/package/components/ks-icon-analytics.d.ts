import type { Components, JSX } from "../dist/types/components";

interface KsIconAnalytics extends Components.KsIconAnalytics, HTMLElement {}
export const KsIconAnalytics: {
    prototype: KsIconAnalytics;
    new (): KsIconAnalytics;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
