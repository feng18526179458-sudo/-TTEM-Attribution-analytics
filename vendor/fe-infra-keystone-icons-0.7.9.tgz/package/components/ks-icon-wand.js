import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconWand$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconWand$1 =

    proxyCustomElement(class KsIconWand extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-wand';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '82c91c0c00d266762f75093ee3c7078a7f9b52d6', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: 'dcdc270c217065f8ff1ea5316845e874f7ee025b', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'a08853f48736543c9c0e357a71ed49ead657b796', d: "M35.1369 12.8635L32.0892 22.7192L38.0334 31.1508L27.7182 31.2978L21.5362 39.5565L18.2088 29.7916L8.44391 26.4643L16.7027 20.2822L16.8496 9.96707L25.2812 15.9113L35.1369 12.8635Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" }), h("path", { key: 'ca1f38b55e402c90f5a48be0f9c0bf73d77eac67', d: "M18.166 29.834L2.12488 45.8751", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '3632dbf4f8214bf3aa01b2a8d984417c88f212ab', d: "M39.7885 8.09527L42.2129 5.6709", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: 'f515c49aedf81b0ce85d833935372c86d42afa80', d: "M41.001 22.1553L44.4295 22.1553", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '702c84c161cca764a99e70685afc143bd81da9f5', d: "M25.458 7.3856L25.458 3.95703", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-wand"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconWand$1;},KsIconWand$1 = GetKsIconWand$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-wand"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-wand":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconWand$1(transTagName));
        }
        break;
    }});
}

const KsIconWand = KsIconWand$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconWand, defineCustomElement };
//# sourceMappingURL=ks-icon-wand.js.map
//# sourceMappingURL=ks-icon-wand.js.map