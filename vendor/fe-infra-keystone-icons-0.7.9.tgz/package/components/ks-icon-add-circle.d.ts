import type { Components, JSX } from "../dist/types/components";

interface KsIconAddCircle extends Components.KsIconAddCircle, HTMLElement {}
export const KsIconAddCircle: {
    prototype: KsIconAddCircle;
    new (): KsIconAddCircle;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
