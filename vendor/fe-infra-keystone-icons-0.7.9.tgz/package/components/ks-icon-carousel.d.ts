import type { Components, JSX } from "../dist/types/components";

interface KsIconCarousel extends Components.KsIconCarousel, HTMLElement {}
export const KsIconCarousel: {
    prototype: KsIconCarousel;
    new (): KsIconCarousel;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
