import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconPlusSmall$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconPlusSmall$1 =

    proxyCustomElement(class KsIconPlusSmall extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-plus-small';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '01b6111f750146034653ba0faa54b2f5858960f5', class: "ks-icon", "ks-icon": true }, h("svg", { key: '01e2a7ffa267b9f8966dd7863a5cda619e2479a3', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'e5cff8d1120a65464448890d804681b1368daea2', d: "M24 9.16308L24 38.8369M38.8369 24L9.16308 24", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-plus-small"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconPlusSmall$1;},KsIconPlusSmall$1 = GetKsIconPlusSmall$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-plus-small"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-plus-small":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconPlusSmall$1(transTagName));
        }
        break;
    }});
}

const KsIconPlusSmall = KsIconPlusSmall$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconPlusSmall, defineCustomElement };
//# sourceMappingURL=ks-icon-plus-small.js.map
//# sourceMappingURL=ks-icon-plus-small.js.map