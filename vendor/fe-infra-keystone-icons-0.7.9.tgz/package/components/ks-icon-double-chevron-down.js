import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconDoubleChevronDown$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconDoubleChevronDown$1 =

    proxyCustomElement(class KsIconDoubleChevronDown extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-double-chevron-down';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '3415ce8b498ebdbddcb28a87219bb74db0e3fd0d', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'e7e90486df9ff2dbe3ac03febd0df8d509b3108c', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }, h("path", { key: '9d2b28acf200e37362a3d920a3df59279390bcbb', d: "M8.997 24l15 12 15-12m-30-12l15 12 15-12" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-double-chevron-down"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconDoubleChevronDown$1;},KsIconDoubleChevronDown$1 = GetKsIconDoubleChevronDown$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-double-chevron-down"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-double-chevron-down":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconDoubleChevronDown$1(transTagName));
        }
        break;
    }});
}

const KsIconDoubleChevronDown = KsIconDoubleChevronDown$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconDoubleChevronDown, defineCustomElement };
//# sourceMappingURL=ks-icon-double-chevron-down.js.map
//# sourceMappingURL=ks-icon-double-chevron-down.js.map