import type { Components, JSX } from "../dist/types/components";

interface KsIconFilledFlag extends Components.KsIconFilledFlag, HTMLElement {}
export const KsIconFilledFlag: {
    prototype: KsIconFilledFlag;
    new (): KsIconFilledFlag;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
