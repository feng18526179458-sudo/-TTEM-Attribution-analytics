import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconContext$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconContext$1 =

    proxyCustomElement(class KsIconContext extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-context';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'ebcee76223997b496f46e59fd377b7e0d7e44a3f', class: "ks-icon", "ks-icon": true }, h("svg", { key: '7a1ebfc4704c4fbc97bbae0c34460810a5cdfe4f', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("g", { key: '925b43b777ec98010902d14cc5f8706bda3d6a60', "clip-path": "url(#A)", "fill-rule": "evenodd", fill: icon.color }, h("path", { key: '3b637dad36e3e9c44972a0ac00f2fbb979d948b0', d: "M24 44.571c11.361 0 20.571-9.21 20.571-20.571S35.361 3.429 24 3.429 3.429 12.639 3.429 24 12.639 44.571 24 44.571zM24 48c13.255 0 24-10.745 24-24S37.255 0 24 0 0 10.745 0 24s10.745 24 24 24zm-.012-39.67c.709-.005 1.349.428 1.608 1.088.933 2.377 1.808 4.052 2.907 5.585 1.109 1.548 2.488 3.009 4.503 4.935.506.484.667 1.227.407 1.877s-.891 1.076-1.591 1.076H30.35a14.41 14.41 0 0 0 1.185 2.285c.794 1.237 1.833 2.417 3.416 3.958.5.487.655 1.227.393 1.874s-.891 1.069-1.588 1.069H25.98v5.878c0 .947-.768 1.714-1.714 1.714s-1.714-.767-1.714-1.714v-5.878h-8.305c-.708 0-1.343-.435-1.598-1.095s-.08-1.409.443-1.886c1.696-1.547 2.771-2.721 3.548-3.933.441-.688.803-1.416 1.124-2.271h-1.316c-.705 0-1.338-.432-1.596-1.088a1.71 1.71 0 0 1 .431-1.883c2.042-1.893 3.373-3.371 4.409-4.915s1.822-3.219 2.705-5.564c.25-.664.883-1.105 1.592-1.11zm-3.48 11.187c.364.094.69.306.926.609.325.418.438.963.307 1.476-.542 2.122-1.19 3.811-2.215 5.411-.36.561-.759 1.101-1.204 1.636h11.5a18.42 18.42 0 0 1-1.172-1.62c-1.005-1.567-1.709-3.228-2.366-5.343-.162-.52-.066-1.086.257-1.525.285-.387.718-.634 1.19-.687a27.54 27.54 0 0 1-2.014-2.473 23.53 23.53 0 0 1-1.669-2.698 23.01 23.01 0 0 1-1.509 2.613c-.596.888-1.261 1.738-2.03 2.602z" })), h("defs", { key: 'f1b524a0db4a7b6938bc09eea644b6358c7464f0' }, h("clipPath", { key: '373ad52bfa97fd8b58de2ab57209d2e674451049', id: "A" }, h("path", { key: '7476e63de7d33080911a9bb97db110c8a2408ae3', fill: "#fff", d: "M0 0h48v48H0z" })))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-context"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconContext$1;},KsIconContext$1 = GetKsIconContext$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-context"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-context":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconContext$1(transTagName));
        }
        break;
    }});
}

const KsIconContext = KsIconContext$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconContext, defineCustomElement };
//# sourceMappingURL=ks-icon-context.js.map
//# sourceMappingURL=ks-icon-context.js.map