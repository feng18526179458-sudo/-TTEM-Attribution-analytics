import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconToggleOn$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconToggleOn$1 =

    proxyCustomElement(class KsIconToggleOn extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-toggle-on';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'b4f3cdb9341e5e05ff58e6e799668ca3874d5350', class: "ks-icon", "ks-icon": true }, h("svg", { key: '01e8f545f0d07e77fe8b596318be90dfecdcc903', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '2bcde558b030371f81c5432bfbaf37d93a4d074c', d: "M17.1424 11.7858H30.8573C37.6028 11.7858 43.0709 17.2541 43.0711 23.9996C43.0711 30.7454 37.603 36.2144 30.8573 36.2145H17.1424C10.3969 36.2142 4.92856 30.7453 4.92856 23.9996C4.92878 17.2542 10.397 11.786 17.1424 11.7858Z", stroke: icon.color, "stroke-width": icon.strokeWidth }), h("rect", { key: '811b9901515ea2132a35dbbac1b0303ac6891097', x: "24", y: "17.1429", width: "13.7143", height: "13.7143", rx: "6.85714", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-toggle-on"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconToggleOn$1;},KsIconToggleOn$1 = GetKsIconToggleOn$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-toggle-on"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-toggle-on":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconToggleOn$1(transTagName));
        }
        break;
    }});
}

const KsIconToggleOn = KsIconToggleOn$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconToggleOn, defineCustomElement };
//# sourceMappingURL=ks-icon-toggle-on.js.map
//# sourceMappingURL=ks-icon-toggle-on.js.map