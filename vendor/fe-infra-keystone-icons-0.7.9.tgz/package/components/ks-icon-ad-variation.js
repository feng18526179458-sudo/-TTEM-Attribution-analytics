import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconAdVariation$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconAdVariation$1 =

    proxyCustomElement(class KsIconAdVariation extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-ad-variation';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'f2a6165432816a167bc75cbc8db80b9b5c60a0c7', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'a47a69b730ab806a5e834914fb2895eadc626cc8', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: '49c35894f0fceb4e5a8a445548b2ad0c48a6868a', d: "M34.504 36.36v2.787a3.43 3.43 0 0 1-3.428 3.429H18.536a3.43 3.43 0 0 1-3.429-3.429V36.36m19.396 0h1.467a3.43 3.43 0 0 0 3.429-3.428v-4.255m-4.896 7.683H15.107M39.4 28.677h.549a3.43 3.43 0 0 0 3.429-3.429V8.853a3.43 3.43 0 0 0-3.428-3.429H7.623a3 3 0 0 0-3 3v16.824a3.43 3.43 0 0 0 3.429 3.429h.75m30.598 0H8.802m0 0v4.255a3.43 3.43 0 0 0 3.429 3.428h2.877", "stroke-linejoin": "round" }), h("path", { key: 'b5068f4b814035a9014d50b8cd7ce8f1bff7f49c', d: "M33.881 16.685h-5.8m8.801 5.611h-8.801m-16.406 0h10.096a.56.56 0 0 0 .56-.56V11.641a.56.56 0 0 0-.56-.56H11.675a.56.56 0 0 0-.56.56v10.096a.56.56 0 0 0 .56.56z", "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-ad-variation"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconAdVariation$1;},KsIconAdVariation$1 = GetKsIconAdVariation$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-ad-variation"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-ad-variation":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconAdVariation$1(transTagName));
        }
        break;
    }});
}

const KsIconAdVariation = KsIconAdVariation$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconAdVariation, defineCustomElement };
//# sourceMappingURL=ks-icon-ad-variation.js.map
//# sourceMappingURL=ks-icon-ad-variation.js.map