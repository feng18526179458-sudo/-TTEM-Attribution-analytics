import type { Components, JSX } from "../dist/types/components";

interface KsIconDropbox extends Components.KsIconDropbox, HTMLElement {}
export const KsIconDropbox: {
    prototype: KsIconDropbox;
    new (): KsIconDropbox;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
