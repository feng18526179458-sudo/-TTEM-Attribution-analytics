import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconSmartOptimization$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconSmartOptimization$1 =

    proxyCustomElement(class KsIconSmartOptimization extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-smart-optimization';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'e36596a18646ffc4fe83e63e261519d48099ab3f', class: "ks-icon", "ks-icon": true }, h("svg", { key: '00bc4f1b54ab505f585690344f7ea94944c72fe4', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", "stroke-width": icon.strokeWidth, stroke: icon.color }, h("ellipse", { key: 'a5a2fcd989df145ab5341c3641a18b53dfec3ef7', cx: "23.995", cy: "22.886", rx: "5.755", ry: "19.733", transform: "rotate(90 23.995 22.886)" }), h("ellipse", { key: 'a915416d7f9fc23e21d256d9d5085a15d0e250d5', cx: "5.755", cy: "19.733", rx: "5.755", ry: "19.733", transform: "matrix(.866023 .500001 -.499999 .866028 28.8794 2.91943)" }), h("ellipse", { key: 'ba2197d53d3826f256e9107069360eda43e7407f', cx: "5.755", cy: "19.733", rx: "5.755", ry: "19.733", transform: "matrix(.866024 -.500002 .499998 .866026 9.14386 8.67456)" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-smart-optimization"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconSmartOptimization$1;},KsIconSmartOptimization$1 = GetKsIconSmartOptimization$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-smart-optimization"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-smart-optimization":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconSmartOptimization$1(transTagName));
        }
        break;
    }});
}

const KsIconSmartOptimization = KsIconSmartOptimization$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconSmartOptimization, defineCustomElement };
//# sourceMappingURL=ks-icon-smart-optimization.js.map
//# sourceMappingURL=ks-icon-smart-optimization.js.map