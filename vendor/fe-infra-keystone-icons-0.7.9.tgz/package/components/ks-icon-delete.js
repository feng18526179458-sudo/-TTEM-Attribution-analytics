import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconDelete$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconDelete$1 =

    proxyCustomElement(class KsIconDelete extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-delete';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '0f9d032e6f0ce70e17342c8728a849b61f349552', class: "ks-icon", "ks-icon": true }, h("svg", { key: '473e218db090f978275bca8dce3cb7109668b649', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("g", { key: 'e2c5844f6d8d25cb399812ff899e6f489f8ea8d3', "stroke-linejoin": "round" }, h("path", { key: '0710cdefa02f93a504da2fe51f6acacfda6518d8', d: "M10.685 16.643a1.5 1.5 0 0 1 1.493-1.645h23.654a1.5 1.5 0 0 1 1.493 1.645l-2.544 26.259a1.5 1.5 0 0 1-1.493 1.355H14.722a1.5 1.5 0 0 1-1.493-1.355l-2.543-26.259z" }), h("path", { key: '9c3869e1889e53d181c3cfd61ece92ab3b4d871f', d: "M20.616 36.173v-12.8m6.899 12.8v-12.8", "stroke-linecap": "round" })), h("rect", { key: '159a859bfa8945c0a7b7bb134cc320e3b7b5b319', x: "6.76", y: "8.481", width: "34.496", height: "6.6", rx: "1.5" }), h("path", { key: '47fb22a476be4d133b42c598145f0dec96446dee', d: "M18.19 8.359l3-4.602h5.641l3 4.602", "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-delete"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconDelete$1;},KsIconDelete$1 = GetKsIconDelete$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-delete"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-delete":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconDelete$1(transTagName));
        }
        break;
    }});
}

const KsIconDelete = KsIconDelete$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconDelete, defineCustomElement };
//# sourceMappingURL=ks-icon-delete.js.map
//# sourceMappingURL=ks-icon-delete.js.map