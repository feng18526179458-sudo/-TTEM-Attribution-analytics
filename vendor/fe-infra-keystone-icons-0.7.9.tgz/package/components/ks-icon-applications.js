import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconApplications$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconApplications$1 =

    proxyCustomElement(class KsIconApplications extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-applications';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '31324b730712396bb92376841909165b81f8878f', class: "ks-icon", "ks-icon": true }, h("svg", { key: '197b920aea0f44cd79219d574ff81f8c3773602c', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("rect", { key: '167440207026c39540f43a6e308dee6e68060101', x: "6", y: "27", width: "15", height: "15", rx: "1.5" }), h("rect", { key: 'ad17d6d0b081b4e2d6e160c43fb328fe932a3f70', x: "27", y: "27", width: "15", height: "15", rx: "1.5" }), h("rect", { key: '7d17ab6d6c220d8ce7f0db499a91c5dae6051e7e', x: "6", y: "6", width: "15", height: "15", rx: "1.5" }), h("path", { key: '0a07b7bb23f1bfe15be88ca56f01a6ee6e5f0f79', d: "M27 6h7.5a7.5 7.5 0 0 1 7.5 7.5h0a7.5 7.5 0 0 1-7.5 7.5h0a7.5 7.5 0 0 1-7.5-7.5V6z" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-applications"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconApplications$1;},KsIconApplications$1 = GetKsIconApplications$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-applications"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-applications":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconApplications$1(transTagName));
        }
        break;
    }});
}

const KsIconApplications = KsIconApplications$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconApplications, defineCustomElement };
//# sourceMappingURL=ks-icon-applications.js.map
//# sourceMappingURL=ks-icon-applications.js.map