import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconHideTimeline$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconHideTimeline$1 =

    proxyCustomElement(class KsIconHideTimeline extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-hide-timeline';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '2d705038f352123ed8d0ecbb14c049cb0fa7d43d', class: "ks-icon", "ks-icon": true }, h("svg", { key: '364aab2b6dce3c92daa65b5576d8452837bc3166', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '5f1da4217e8e434b954a5ee252b71c2a25f829e4', d: "M5.143 19.6496H42.8569C43.922 19.6496 44.7856 20.5132 44.7856 21.5783V42.1496C44.7856 43.2147 43.922 44.0783 42.8569 44.0783H5.143C4.07788 44.0783 3.21429 43.2147 3.21429 42.1496V21.5783C3.21429 20.5797 3.9732 19.7581 4.94573 19.6594L5.143 19.6496Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: 'ab78cc4568705effe749689ed0d137d894bbd04e', d: "M35.0163 1.90857L24.0227 12.9021L13.0291 1.90857", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-hide-timeline"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconHideTimeline$1;},KsIconHideTimeline$1 = GetKsIconHideTimeline$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-hide-timeline"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-hide-timeline":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconHideTimeline$1(transTagName));
        }
        break;
    }});
}

const KsIconHideTimeline = KsIconHideTimeline$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconHideTimeline, defineCustomElement };
//# sourceMappingURL=ks-icon-hide-timeline.js.map
//# sourceMappingURL=ks-icon-hide-timeline.js.map