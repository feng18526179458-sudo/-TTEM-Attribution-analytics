import type { Components, JSX } from "../dist/types/components";

interface KsIconFilledLocationPin extends Components.KsIconFilledLocationPin, HTMLElement {}
export const KsIconFilledLocationPin: {
    prototype: KsIconFilledLocationPin;
    new (): KsIconFilledLocationPin;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
