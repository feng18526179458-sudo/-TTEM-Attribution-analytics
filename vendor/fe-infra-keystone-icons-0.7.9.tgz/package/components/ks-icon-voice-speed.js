import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconVoiceSpeed$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconVoiceSpeed$1 =

    proxyCustomElement(class KsIconVoiceSpeed extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-voice-speed';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '008e2e132bce1d7af2f7df77c63c7abfd0302846', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'c1e4ed983156486445d1b6df022feaadc1891386', width: icon.width, height: icon.height, viewBox: "0 0 49 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'de7f6dd2a950d5bde4e609d8514028ab0f596ae1', d: "M15.3294 7.00304C22.7843 2.7048 32.4749 3.74312 38.8498 10.118C46.465 17.7332 46.465 30.0799 38.8498 37.6952C31.2346 45.3104 18.8879 45.3104 11.2726 37.6952C6.11056 32.5331 4.44767 25.1969 6.28395 18.6341", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '8a459e1df17b1157852c2621aa094b3edec3f4c0', d: "M15.6877 14.6265L26.3423 25.2811", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-voice-speed"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconVoiceSpeed$1;},KsIconVoiceSpeed$1 = GetKsIconVoiceSpeed$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-voice-speed"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-voice-speed":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconVoiceSpeed$1(transTagName));
        }
        break;
    }});
}

const KsIconVoiceSpeed = KsIconVoiceSpeed$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconVoiceSpeed, defineCustomElement };
//# sourceMappingURL=ks-icon-voice-speed.js.map
//# sourceMappingURL=ks-icon-voice-speed.js.map