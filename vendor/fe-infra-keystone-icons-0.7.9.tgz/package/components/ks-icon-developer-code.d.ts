import type { Components, JSX } from "../dist/types/components";

interface KsIconDeveloperCode extends Components.KsIconDeveloperCode, HTMLElement {}
export const KsIconDeveloperCode: {
    prototype: KsIconDeveloperCode;
    new (): KsIconDeveloperCode;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
