import type { Components, JSX } from "../dist/types/components";

interface KsIconColoredSnapchat extends Components.KsIconColoredSnapchat, HTMLElement {}
export const KsIconColoredSnapchat: {
    prototype: KsIconColoredSnapchat;
    new (): KsIconColoredSnapchat;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
