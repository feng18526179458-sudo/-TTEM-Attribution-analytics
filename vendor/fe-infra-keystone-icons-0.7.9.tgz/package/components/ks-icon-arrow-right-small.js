import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconArrowRightSmall$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconArrowRightSmall$1 =

    proxyCustomElement(class KsIconArrowRightSmall extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-arrow-right-small';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'e893a98b5ab0a633c0749b798d9d9e6cb4d64cdc', class: "ks-icon", "ks-icon": true }, h("svg", { key: '1f2a0792a5c0d8d871639eeb03991bc06a0277fe', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: '277f8c00d5c6da1017a784c2e13bf1a81536cefc', d: "M30.002 8.25l14.015 14.715a1.5 1.5 0 0 1 0 2.069L30.002 39.75", "stroke-linejoin": "round" }), h("path", { key: '52a3b644a5554984b920e1f78d147910e2217ef9', d: "M42.001 24h-36" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-arrow-right-small"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconArrowRightSmall$1;},KsIconArrowRightSmall$1 = GetKsIconArrowRightSmall$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-arrow-right-small"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-arrow-right-small":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconArrowRightSmall$1(transTagName));
        }
        break;
    }});
}

const KsIconArrowRightSmall = KsIconArrowRightSmall$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconArrowRightSmall, defineCustomElement };
//# sourceMappingURL=ks-icon-arrow-right-small.js.map
//# sourceMappingURL=ks-icon-arrow-right-small.js.map