import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconBrush$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconBrush$1 =

    proxyCustomElement(class KsIconBrush extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-brush';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'b66f3598226fa6cf54eb9ae48f66f29252989265', class: "ks-icon", "ks-icon": true }, h("svg", { key: '95f2769142fcfdddda85284106a00b88b84fded5', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" }, h("path", { key: 'a77edd2444a8fb7277a5bb52851d0a6562069c08', d: "M16.394 40.984c6.214-.973 4.431-13.995 12.86-14.859 0 0 .193 1.698 1.63 2.639s3.762 1.463 3.762 1.463c-.993 8.411-5.391 10.632-18.251 10.757z" }), h("path", { key: '2fe98abd4c363227e57231d7030bedf97ef13436', d: "M35.117 29.873l7.277-13.677m-13.339 9.929l10.701-20.1M16.02 40.984H3.472", "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-brush"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconBrush$1;},KsIconBrush$1 = GetKsIconBrush$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-brush"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-brush":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconBrush$1(transTagName));
        }
        break;
    }});
}

const KsIconBrush = KsIconBrush$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconBrush, defineCustomElement };
//# sourceMappingURL=ks-icon-brush.js.map
//# sourceMappingURL=ks-icon-brush.js.map