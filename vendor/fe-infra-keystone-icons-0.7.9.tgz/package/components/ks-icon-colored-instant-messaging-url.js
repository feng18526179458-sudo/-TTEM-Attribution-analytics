import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconColoredInstantMessagingUrl$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconColoredInstantMessagingUrl$1 =

    proxyCustomElement(class KsIconColoredInstantMessagingUrl extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-colored-instant-messaging-url';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '72c53e553a78246a143aa71045dedd6c0386da87', class: "ks-icon", "ks-icon": true }, h("svg", { key: '92211cd3dab35b99449601aa56f2ab9468409b10', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("rect", { key: 'e0743583f54fc8902b84abb60ac99608aacd9659', width: "48", height: "48", rx: "8", fill: "#017976" }), h("path", { key: '6264956be88c443e0595d746d5af9d3af17534b3', d: "M24.8004 25.0183H24.991C27.7575 25.0183 30.0002 22.7756 30.0002 20.0091C30.0002 17.2426 27.7575 14.9999 24.991 14.9999L14.7368 14.9999C12.0207 14.9999 9.81892 17.2017 9.81892 19.9177L9.81892 20.0091C9.81892 22.7756 12.0616 25.0183 14.8281 25.0183H15.1821", stroke: "white", "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: 'ba6954e472a80337382e0cccb9c1b47baedbd7cd', d: "M32.8005 21.9811L32.9911 21.9811C35.7576 21.9811 38.0003 24.2238 38.0003 26.9903C38.0003 29.7568 35.7576 31.9995 32.9911 31.9995L22.7369 31.9995C20.0208 31.9995 17.819 29.7977 17.819 27.0816L17.819 26.9903C17.819 24.2238 20.0617 21.9811 22.8283 21.9811L23.1822 21.9811", stroke: "white", "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-colored-instant-messaging-url"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconColoredInstantMessagingUrl$1;},KsIconColoredInstantMessagingUrl$1 = GetKsIconColoredInstantMessagingUrl$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-colored-instant-messaging-url"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-colored-instant-messaging-url":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconColoredInstantMessagingUrl$1(transTagName));
        }
        break;
    }});
}

const KsIconColoredInstantMessagingUrl = KsIconColoredInstantMessagingUrl$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconColoredInstantMessagingUrl, defineCustomElement };
//# sourceMappingURL=ks-icon-colored-instant-messaging-url.js.map
//# sourceMappingURL=ks-icon-colored-instant-messaging-url.js.map