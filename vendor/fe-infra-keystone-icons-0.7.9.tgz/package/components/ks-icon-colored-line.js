import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconColoredLine$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconColoredLine$1 =

    proxyCustomElement(class KsIconColoredLine extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-colored-line';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '5d987ac33ab5ebaf634512d5020c2ba1ce65f613', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'e7c966dbd60d57c2b19f8b35355443cbb6a97662', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("rect", { key: '24f885ec19d480bd59f1608b3a89b4a0b40cf2c1', width: "48", height: "48", rx: "8", fill: "#06C755" }), h("path", { key: '034f0cfb57e36b8612620d3902e23c41452d00e4', d: "M37.2875 22.0719C37.2875 15.9668 31.1672 10.9999 23.6437 10.9999C16.1211 10.9999 10 15.9668 10 22.0719C10 27.5452 14.8539 32.1289 21.4105 32.9957C21.8549 33.0914 22.4596 33.2886 22.6126 33.6684C22.7502 34.0134 22.7026 34.5537 22.6566 34.9021C22.6566 34.9021 22.4965 35.8649 22.462 36.07C22.4026 36.415 22.1878 37.4191 23.6437 36.8054C25.1 36.1918 31.5012 32.1788 34.3637 28.8841C36.341 26.7158 37.2875 24.5154 37.2875 22.0719Z", fill: "white" }), h("path", { key: '111c86aadfe23763753e32c78c641d7e2eba3d3f', d: "M20.8715 19.1203H19.9144C19.7677 19.1203 19.6484 19.2393 19.6484 19.3855V25.3306C19.6484 25.4771 19.7677 25.5958 19.9144 25.5958H20.8715C21.0182 25.5958 21.1372 25.4771 21.1372 25.3306V19.3855C21.1372 19.2393 21.0182 19.1203 20.8715 19.1203Z", fill: "#00B900" }), h("path", { key: '3b1a95504059964de048e69f601e6906b65fd0b4', d: "M27.4595 19.1203H26.5024C26.3557 19.1203 26.2367 19.2393 26.2367 19.3855V22.9175L23.5124 19.2383C23.4638 19.1654 23.3785 19.1203 23.2911 19.1203H22.3343C22.1876 19.1203 22.0683 19.2393 22.0683 19.3855V25.3306C22.0683 25.4771 22.1876 25.5958 22.3343 25.5958H23.2911C23.4381 25.5958 23.5571 25.4771 23.5571 25.3306V21.7996L26.2848 25.4836C26.3338 25.553 26.4176 25.5958 26.5024 25.5958H27.4595C27.6065 25.5958 27.7252 25.4771 27.7252 25.3306V19.3855C27.7252 19.2393 27.6065 19.1203 27.4595 19.1203Z", fill: "#00B900" }), h("path", { key: '68e1a6e08e7d9a66d2c7225f19588249c403c5e0', d: "M18.5636 24.1084H15.9632V19.3871C15.9632 19.2404 15.8442 19.1214 15.6978 19.1214H14.7405C14.5937 19.1214 14.4747 19.2404 14.4747 19.3871V25.3312C14.4747 25.4767 14.5945 25.5972 14.7402 25.5972H18.5636C18.7103 25.5972 18.8288 25.4779 18.8288 25.3312V24.3741C18.8288 24.2274 18.7103 24.1084 18.5636 24.1084Z", fill: "#00B900" }), h("path", { key: '417efa528ee31455e75a9b7b821ebfe1809fd618', d: "M32.7425 20.6101C32.8892 20.6101 33.0077 20.4914 33.0077 20.3444V19.3874C33.0077 19.2406 32.8892 19.1214 32.7425 19.1214H28.9194C28.7739 19.1214 28.6536 19.2416 28.6536 19.3871V25.3314C28.6536 25.4766 28.7735 25.5972 28.9189 25.5972H32.7425C32.8892 25.5972 33.0077 25.4779 33.0077 25.3314V24.3741C33.0077 24.2277 32.8892 24.1084 32.7425 24.1084H30.1424V23.1035H32.7425C32.8892 23.1035 33.0077 22.9845 33.0077 22.8378V21.8807C33.0077 21.734 32.8892 21.6147 32.7425 21.6147H30.1424V20.6101H32.7425Z", fill: "#00B900" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-colored-line"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconColoredLine$1;},KsIconColoredLine$1 = GetKsIconColoredLine$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-colored-line"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-colored-line":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconColoredLine$1(transTagName));
        }
        break;
    }});
}

const KsIconColoredLine = KsIconColoredLine$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconColoredLine, defineCustomElement };
//# sourceMappingURL=ks-icon-colored-line.js.map
//# sourceMappingURL=ks-icon-colored-line.js.map