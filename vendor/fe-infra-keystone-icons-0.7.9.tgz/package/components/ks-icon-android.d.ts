import type { Components, JSX } from "../dist/types/components";

interface KsIconAndroid extends Components.KsIconAndroid, HTMLElement {}
export const KsIconAndroid: {
    prototype: KsIconAndroid;
    new (): KsIconAndroid;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
