import type { Components, JSX } from "../dist/types/components";

interface KsIconAdsManager extends Components.KsIconAdsManager, HTMLElement {}
export const KsIconAdsManager: {
    prototype: KsIconAdsManager;
    new (): KsIconAdsManager;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
