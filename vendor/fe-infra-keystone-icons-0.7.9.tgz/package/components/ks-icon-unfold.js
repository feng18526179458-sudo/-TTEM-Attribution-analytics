import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconUnfold$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconUnfold$1 =

    proxyCustomElement(class KsIconUnfold extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-unfold';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '24d462d55093caaadec84303867d8e1b9fdfc38b', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'ea6a495b40aa30c60a2f68fd154d710aad5ee0d7', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '789f976758d1447d8fb2252fad41f897af9bd995', d: "M6.006 39h36m-36-15.126h21m-21-15h21", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '947e0fd83dc9f7f92f37cb2ca55b896d6f6e2458', d: "M31.142 14.956l8.232-6.478c1.093-.86 2.638-.029 2.638 1.418v12.956c0 1.447-1.546 2.278-2.638 1.418l-8.232-6.478c-.895-.705-.895-2.131 0-2.836z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-unfold"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconUnfold$1;},KsIconUnfold$1 = GetKsIconUnfold$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-unfold"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-unfold":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconUnfold$1(transTagName));
        }
        break;
    }});
}

const KsIconUnfold = KsIconUnfold$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconUnfold, defineCustomElement };
//# sourceMappingURL=ks-icon-unfold.js.map
//# sourceMappingURL=ks-icon-unfold.js.map