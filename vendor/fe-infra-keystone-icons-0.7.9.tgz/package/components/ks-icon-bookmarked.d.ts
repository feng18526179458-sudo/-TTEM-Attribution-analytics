import type { Components, JSX } from "../dist/types/components";

interface KsIconBookmarked extends Components.KsIconBookmarked, HTMLElement {}
export const KsIconBookmarked: {
    prototype: KsIconBookmarked;
    new (): KsIconBookmarked;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
