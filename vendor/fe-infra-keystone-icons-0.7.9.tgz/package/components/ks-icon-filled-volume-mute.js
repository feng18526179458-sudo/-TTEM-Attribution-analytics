import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledVolumeMute$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledVolumeMute$1 =

    proxyCustomElement(class KsIconFilledVolumeMute extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-volume-mute';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '6211ec13e845a28c16ba284e2d1e17dbdae0b3ea', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: '109b3462555b1dae126e52e7b7897e1521f028ac', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '399530c63303c810ba1274c5c65f1da97446516a', d: "M10.12 15.472a2.96 2.96 0 0 0-2.958 2.958v11.01a2.96 2.96 0 0 0 2.958 2.958h4.143a1.97 1.97 0 0 1 1.441.625l8.751 9.362c1.222 1.307 3.413.443 3.413-1.346V5.991c0-1.828-2.272-2.672-3.466-1.287l-8.692 10.084a1.97 1.97 0 0 1-1.494.684H10.12z", fill: icon.color }), h("g", { key: '0997f85a17ee6e1a38580b7fd752e4b0d73d74bf', stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: '0dd4259771a6818d3af0692e45f9706c562aaaf0', d: "M31.756 17.574l12.882 12.882" }), h("path", { key: '999fc851a39d798daa20cec41e3276ad47c0498a', d: "M31.756 30.456l12.882-12.882" }))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-volume-mute"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFilledVolumeMute$1;},KsIconFilledVolumeMute$1 = GetKsIconFilledVolumeMute$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-volume-mute"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-volume-mute":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledVolumeMute$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledVolumeMute = KsIconFilledVolumeMute$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledVolumeMute, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-volume-mute.js.map
//# sourceMappingURL=ks-icon-filled-volume-mute.js.map