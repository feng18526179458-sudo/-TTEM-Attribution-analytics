import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledRocket$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledRocket$1 =

    proxyCustomElement(class KsIconFilledRocket extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-rocket';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '128f0b8bbd7b745e1a28bd847d782fe4597086cb', class: "ks-icon", "ks-icon": true }, h("svg", { key: '158082ff30389e1ec43c62de8a4d02e6c68f96aa', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'a6ee3106078d19363d2ffefef085d7287130b230', d: "M17.599 38.446h13.387c-1.259 3.019-3.674 5.435-6.693 6.693-3.019-1.259-5.434-3.674-6.693-6.693zm18.162-9.93l3.823 4.336v3.683H9.001v-3.683l3.823-4.336V17.421c0-6.658 4.787-12.322 11.468-14.421 6.682 2.099 11.468 7.763 11.468 14.421v11.095zm-11.468-7.272c2.111 0 3.823-1.712 3.823-3.823s-1.712-3.823-3.823-3.823-3.823 1.711-3.823 3.823 1.711 3.823 3.823 3.823z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-rocket"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFilledRocket$1;},KsIconFilledRocket$1 = GetKsIconFilledRocket$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-rocket"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-rocket":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledRocket$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledRocket = KsIconFilledRocket$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledRocket, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-rocket.js.map
//# sourceMappingURL=ks-icon-filled-rocket.js.map