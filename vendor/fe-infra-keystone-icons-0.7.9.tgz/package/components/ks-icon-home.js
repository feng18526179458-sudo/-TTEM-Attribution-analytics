import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconHome$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconHome$1 =

    proxyCustomElement(class KsIconHome extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-home';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '10ad0e78e207557e5e0ab144c3b92ed2851e76e6', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'ada776abfe28fb2706cff61a4ed9bdc6776b39e1', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }, h("path", { key: 'd9d1d497e2335131281a06e097126e3a5784c670', d: "M39.96 19.753a1.5 1.5 0 0 1 .54 1.152V40.5A1.5 1.5 0 0 1 39 42H9a1.5 1.5 0 0 1-1.5-1.5V20.905a1.5 1.5 0 0 1 .54-1.152l15-12.5a1.5 1.5 0 0 1 1.921 0l15 12.5z" }), h("path", { key: 'c5aeee46ab352cc168c35d4bf5fa27e6145f97bb', d: "M17.637 34.74h12.728" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-home"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconHome$1;},KsIconHome$1 = GetKsIconHome$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-home"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-home":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconHome$1(transTagName));
        }
        break;
    }});
}

const KsIconHome = KsIconHome$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconHome, defineCustomElement };
//# sourceMappingURL=ks-icon-home.js.map
//# sourceMappingURL=ks-icon-home.js.map