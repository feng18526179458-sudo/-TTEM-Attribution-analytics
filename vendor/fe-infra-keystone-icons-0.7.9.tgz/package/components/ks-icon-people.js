import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconPeople$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconPeople$1 =

    proxyCustomElement(class KsIconPeople extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-people';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'd43e3dc7a9fb84438e9411c7bbef2994ffacc780', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'a5b4600b64f4e072d2b8b46121b202b4e8186af6', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '2e18cccceac4425bb3f565da4fb3f61acfbed75f', d: "M35.9885 8.99815C37.8297 10.6461 38.9885 13.0409 38.9885 15.7063C38.9885 18.3717 37.8297 20.7666 35.9885 22.4145", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("ellipse", { key: '034df40128e3c4dc4e6f9a9b835f49803a7bf8ee', cx: "20.9714", cy: "14.9984", rx: "8.99986", ry: "8.99979", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: 'f573ca82ef05897391f3247519ebb75d302f4ff1', d: "M35.9884 38.9981C35.9884 30.714 29.2727 23.9984 20.9886 23.9984C12.7045 23.9984 5.98883 30.714 5.98883 38.9981", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: 'c669ab76d718db0c45fbc72e4c868b6076a46698', d: "M45.3587 36.4052C45.3587 30.1121 41.4831 24.7241 35.9885 22.4978", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-people"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconPeople$1;},KsIconPeople$1 = GetKsIconPeople$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-people"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-people":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconPeople$1(transTagName));
        }
        break;
    }});
}

const KsIconPeople = KsIconPeople$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconPeople, defineCustomElement };
//# sourceMappingURL=ks-icon-people.js.map
//# sourceMappingURL=ks-icon-people.js.map