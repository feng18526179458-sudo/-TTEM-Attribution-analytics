import type { Components, JSX } from "../dist/types/components";

interface KsIconFeelGood extends Components.KsIconFeelGood, HTMLElement {}
export const KsIconFeelGood: {
    prototype: KsIconFeelGood;
    new (): KsIconFeelGood;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
