import type { Components, JSX } from "../dist/types/components";

interface KsIconColoredInstagram extends Components.KsIconColoredInstagram, HTMLElement {}
export const KsIconColoredInstagram: {
    prototype: KsIconColoredInstagram;
    new (): KsIconColoredInstagram;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
