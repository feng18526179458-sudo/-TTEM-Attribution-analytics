import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconColoredPptx$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconColoredPptx$1 =

    proxyCustomElement(class KsIconColoredPptx extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-colored-pptx';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '86d377665a5529cb8fed9d3a84e9f5f4a9b0e0b7', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'ccbaedfd5abf12a00f8b71705c8863711ec4989c', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("rect", { key: '980b13d3fbee50c47e83f9ec5f903a5b8aadf45b', width: "48", height: "48", rx: "1.556", fill: "#ea4d1b" }), h("path", { key: '03299fd65cb21ec7a9cf3aee16ad9da414509f56', d: "M19.698 34.667c.161 0 .292-.131.292-.292v-7.324h5.44c4.608 0 7.168-3.136 7.168-6.848 0-3.744-2.528-6.88-7.168-6.88H16.32c-.483 0-.875.392-.875.875v20.177c0 .161.131.292.292.292h3.961zm5.092-11.616h-4.8v-5.728h4.8c1.792 0 3.168 1.088 3.168 2.88 0 1.76-1.376 2.848-3.168 2.848z", fill: "#fff" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-colored-pptx"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconColoredPptx$1;},KsIconColoredPptx$1 = GetKsIconColoredPptx$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-colored-pptx"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-colored-pptx":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconColoredPptx$1(transTagName));
        }
        break;
    }});
}

const KsIconColoredPptx = KsIconColoredPptx$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconColoredPptx, defineCustomElement };
//# sourceMappingURL=ks-icon-colored-pptx.js.map
//# sourceMappingURL=ks-icon-colored-pptx.js.map