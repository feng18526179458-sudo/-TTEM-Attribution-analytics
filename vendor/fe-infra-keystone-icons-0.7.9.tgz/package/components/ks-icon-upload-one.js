import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconUploadOne$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconUploadOne$1 =

    proxyCustomElement(class KsIconUploadOne extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-upload-one';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '0643c5e25fa6cdfa220a7f821c228d9ce03e558e', class: "ks-icon", "ks-icon": true }, h("svg", { key: '2e7ba1fa6a37295946b9b926f1e9d406d3a544a5', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: '8d4b03e6281a7ade78d817d1277a8b8c86fe3687', d: "M24.028 33.001V7.223m0 .033l-12 12" }), h("path", { key: '08706236f2c131c32891041009084e566ea98db6', d: "M23.995 7.257l12 12M7.501 33.001v6h33v-6" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-upload-one"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconUploadOne$1;},KsIconUploadOne$1 = GetKsIconUploadOne$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-upload-one"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-upload-one":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconUploadOne$1(transTagName));
        }
        break;
    }});
}

const KsIconUploadOne = KsIconUploadOne$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconUploadOne, defineCustomElement };
//# sourceMappingURL=ks-icon-upload-one.js.map
//# sourceMappingURL=ks-icon-upload-one.js.map