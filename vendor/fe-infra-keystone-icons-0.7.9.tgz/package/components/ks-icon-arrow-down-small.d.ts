import type { Components, JSX } from "../dist/types/components";

interface KsIconArrowDownSmall extends Components.KsIconArrowDownSmall, HTMLElement {}
export const KsIconArrowDownSmall: {
    prototype: KsIconArrowDownSmall;
    new (): KsIconArrowDownSmall;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
