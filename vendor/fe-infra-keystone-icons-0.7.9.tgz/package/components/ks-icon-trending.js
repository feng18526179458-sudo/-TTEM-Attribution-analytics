import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconTrending$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconTrending$1 =

    proxyCustomElement(class KsIconTrending extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-trending';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '6327998535a6d200b32397a8d4d6a8c477f86ed7', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'd597a55496aee14f713d11657c608927a2811e0f', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '248216c028963797aeee0f65ad73bddcfcb2f82b', d: "M3.429 35.018l14.235-14.235 9.554 9.554 17.354-17.354m0 0h-14.77m14.77 0v14.792", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-trending"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconTrending$1;},KsIconTrending$1 = GetKsIconTrending$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-trending"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-trending":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconTrending$1(transTagName));
        }
        break;
    }});
}

const KsIconTrending = KsIconTrending$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconTrending, defineCustomElement };
//# sourceMappingURL=ks-icon-trending.js.map
//# sourceMappingURL=ks-icon-trending.js.map