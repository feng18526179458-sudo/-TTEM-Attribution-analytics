import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconDragItem$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconDragItem$1 =

    proxyCustomElement(class KsIconDragItem extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-drag-item';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'a3455c2fee37cfd8ee83fad69baf0946a7fab09d', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'ab65b243e08cc236f05311b2b3af374c06eee439', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: icon.color }, h("circle", { key: 'fb3d0956a823b45a3cff14713dc453dede2f05de', cx: "16.509", cy: "24.008", r: "3" }), h("circle", { key: '52e483a5609e7cf350b8cd164f6a2ad15b01f083', cx: "16.509", cy: "37.902", r: "3" }), h("circle", { key: '727269959549440a8ae43967306448fb0e3d35dc', cx: "16.509", cy: "10.127", r: "3" }), h("circle", { key: '1e9f2465262d3abbde72d69c5ad19a818d6b8c25', cx: "31.508", cy: "24.007", r: "3" }), h("circle", { key: '0dd95c665561a6cffe90c4a5ce33f785ad4f83cd', cx: "31.508", cy: "37.902", r: "3" }), h("circle", { key: 'd37d730b4b0772ffb89947d4c6dd20198418ac6c', cx: "31.508", cy: "10.127", r: "3" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-drag-item"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconDragItem$1;},KsIconDragItem$1 = GetKsIconDragItem$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-drag-item"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-drag-item":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconDragItem$1(transTagName));
        }
        break;
    }});
}

const KsIconDragItem = KsIconDragItem$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconDragItem, defineCustomElement };
//# sourceMappingURL=ks-icon-drag-item.js.map
//# sourceMappingURL=ks-icon-drag-item.js.map