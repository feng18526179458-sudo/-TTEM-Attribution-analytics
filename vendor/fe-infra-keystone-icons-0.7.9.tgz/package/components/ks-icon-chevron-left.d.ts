import type { Components, JSX } from "../dist/types/components";

interface KsIconChevronLeft extends Components.KsIconChevronLeft, HTMLElement {}
export const KsIconChevronLeft: {
    prototype: KsIconChevronLeft;
    new (): KsIconChevronLeft;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
