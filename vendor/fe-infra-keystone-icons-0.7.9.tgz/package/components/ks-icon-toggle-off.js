import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconToggleOff$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconToggleOff$1 =

    proxyCustomElement(class KsIconToggleOff extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-toggle-off';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'b6729b73480083ba112e2aa08245e5cfbdc18d68', class: "ks-icon", "ks-icon": true }, h("svg", { key: '9ba411dcbde07e59f9bb8b61088e30247f174079', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'ee7da46c20507b963dd463c4f08b92bf6a502f0a', d: "M17.1424 11.7858H30.8573C37.6028 11.7858 43.0709 17.2541 43.0711 23.9996C43.0711 30.7454 37.603 36.2144 30.8573 36.2145H17.1424C10.3969 36.2142 4.92856 30.7453 4.92856 23.9996C4.92878 17.2542 10.397 11.786 17.1424 11.7858Z", stroke: icon.color, "stroke-width": icon.strokeWidth }), h("rect", { key: '9492fd426a18d6a1ee8ab8ff96a1eba33d569679', x: "10.2857", y: "17.1429", width: "13.7143", height: "13.7143", rx: "6.85714", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-toggle-off"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconToggleOff$1;},KsIconToggleOff$1 = GetKsIconToggleOff$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-toggle-off"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-toggle-off":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconToggleOff$1(transTagName));
        }
        break;
    }});
}

const KsIconToggleOff = KsIconToggleOff$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconToggleOff, defineCustomElement };
//# sourceMappingURL=ks-icon-toggle-off.js.map
//# sourceMappingURL=ks-icon-toggle-off.js.map