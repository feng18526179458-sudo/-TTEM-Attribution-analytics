import type { Components, JSX } from "../dist/types/components";

interface KsIconErase extends Components.KsIconErase, HTMLElement {}
export const KsIconErase: {
    prototype: KsIconErase;
    new (): KsIconErase;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
