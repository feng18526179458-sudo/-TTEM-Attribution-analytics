import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFlight$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFlight$1 =

    proxyCustomElement(class KsIconFlight extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-flight';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '660e9286ba0c2cd00ed241b998e04c1ae145d297', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'de1447fe29bc68aa93a8e8954be36dfb2408450e', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '3f7beb9391c4487be953bd29101e6bf6ca11c1c0', d: "M32.6104 8.18115C34.772 6.72391 37.6242 5.48123 40.2744 6.71533L40.5303 6.84229L40.625 6.89697C40.8407 7.03219 41.0192 7.22074 41.1426 7.44482C42.6397 10.165 41.3504 13.1479 39.8408 15.3784C38.4152 17.4847 36.4403 19.4511 34.8721 20.895L34.875 38.5513C34.875 38.951 34.7153 39.3341 34.4316 39.6157L33.4492 40.5913C33.1011 40.9368 32.6056 41.0905 32.123 41.0024C31.6407 40.9144 31.2321 40.5958 31.0283 40.1499L25.8867 28.8882L20.0801 34.0454L20.1709 40.6694C20.1764 41.0755 20.0174 41.4669 19.7295 41.7534L18.7002 42.7778C18.3516 43.1247 17.8548 43.2787 17.3711 43.1899C16.8874 43.1011 16.4781 42.7805 16.2754 42.3325L14.3154 37.9995L11.1016 39.8042C10.5626 40.1067 9.89371 40.0479 9.41602 39.6558C8.93837 39.2635 8.7495 38.6183 8.94141 38.0308L10.3115 33.8394L5.59082 31.6606C5.14546 31.4552 4.82834 31.0449 4.74219 30.562C4.65609 30.0792 4.81142 29.5846 5.1582 29.2378L6.21973 28.1763C6.50857 27.8874 6.90312 27.7284 7.31152 27.7368L13.9873 27.8735L19.1025 22.1138L7.81836 17.0083C7.37091 16.8058 7.05016 16.3975 6.96094 15.9146C6.87177 15.4317 7.02461 14.9354 7.37012 14.5864L8.37988 13.5669C8.6616 13.2824 9.04593 13.1226 9.44629 13.1226H27.1045C28.5461 11.5586 30.5068 9.59926 32.6104 8.18115Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-flight"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFlight$1;},KsIconFlight$1 = GetKsIconFlight$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-flight"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-flight":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFlight$1(transTagName));
        }
        break;
    }});
}

const KsIconFlight = KsIconFlight$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFlight, defineCustomElement };
//# sourceMappingURL=ks-icon-flight.js.map
//# sourceMappingURL=ks-icon-flight.js.map