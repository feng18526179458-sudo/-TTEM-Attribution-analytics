import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledHeart$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledHeart$1 =

    proxyCustomElement(class KsIconFilledHeart extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-heart';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '16baa029b84d68c5376324bda193c1c3fa59f08a', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'd13974f798430c4e88a01f0233c3b59f9aed053f', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '0afd2a90efbde54e89bce48e5e60cb8b2b228387', d: "M24.003 8.529c4.933-4.428 12.555-4.281 17.306.481a12.6 12.6 0 0 1 .496 17.294L26.123 42.009a3 3 0 0 1-4.246 0L6.196 26.303c-4.419-4.947-4.254-12.545.496-17.294 4.755-4.755 12.364-4.915 17.311-.481z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-heart"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFilledHeart$1;},KsIconFilledHeart$1 = GetKsIconFilledHeart$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-heart"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-heart":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledHeart$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledHeart = KsIconFilledHeart$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledHeart, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-heart.js.map
//# sourceMappingURL=ks-icon-filled-heart.js.map