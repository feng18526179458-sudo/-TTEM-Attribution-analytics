import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconMarkedFlag$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconMarkedFlag$1 =

    proxyCustomElement(class KsIconMarkedFlag extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-marked-flag';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '7e871f79440a243a58a9cc4a6a533558f7281d6e', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: 'afd1f4ac8428cf7ca4801645073d3353c642a94f', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: 'd27a807e18116f4bdc4ab4b9abc0b8fba32fc284', d: "M9 3v42", "stroke-linecap": "round" }), h("path", { key: '4107de72545ddb220145757620ee1e352a450567', d: "M9 4.5h33.555l-10.047 8.931.996 1.121-.996-1.121a2.1 2.1 0 0 0 0 3.139l10.047 8.93H9v-21z" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-marked-flag"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconMarkedFlag$1;},KsIconMarkedFlag$1 = GetKsIconMarkedFlag$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-marked-flag"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-marked-flag":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconMarkedFlag$1(transTagName));
        }
        break;
    }});
}

const KsIconMarkedFlag = KsIconMarkedFlag$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconMarkedFlag, defineCustomElement };
//# sourceMappingURL=ks-icon-marked-flag.js.map
//# sourceMappingURL=ks-icon-marked-flag.js.map