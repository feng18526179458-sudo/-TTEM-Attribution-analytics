import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconPercent$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconPercent$1 =

    proxyCustomElement(class KsIconPercent extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-percent';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'e8d482df2f852954100e2e30f8b4963d4240135a', class: "ks-icon", "ks-icon": true }, h("svg", { key: '450ee1aff5fd467774237fd7bc48dee773b33559', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '66378191cd71417762f49cb4bf4a506eed5e60f6', d: "M13.2702 34.7115L34.6919 13.2899M15.3306 15.7226V15.7367M32.6315 32.2614V32.2755", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-percent"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconPercent$1;},KsIconPercent$1 = GetKsIconPercent$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-percent"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-percent":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconPercent$1(transTagName));
        }
        break;
    }});
}

const KsIconPercent = KsIconPercent$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconPercent, defineCustomElement };
//# sourceMappingURL=ks-icon-percent.js.map
//# sourceMappingURL=ks-icon-percent.js.map