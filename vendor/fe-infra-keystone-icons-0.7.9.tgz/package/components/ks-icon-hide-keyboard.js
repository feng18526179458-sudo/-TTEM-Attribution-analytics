import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconHideKeyboard$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconHideKeyboard$1 =

    proxyCustomElement(class KsIconHideKeyboard extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-hide-keyboard';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '1dd908f8d2cf1f45e4f4e07c3d0e09aab3ea92bb', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'a4ae0fdfe5bb38b53b12a1418dee076c11f3ff2b', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("g", { key: 'f3732216395b80cd1c805fc89b12a6dead95e637', "clip-path": "url(#A)" }, h("g", { key: 'a290f3723fc8c8c851b8c8bc63b61996f97deb0f', "fill-rule": "evenodd", fill: icon.color }, h("use", { key: 'c93145ec11e18ba74893a781659cea00e0a54eff', href: "#B" }), h("use", { key: 'c35633ebf66e7afadbefd888567c33bfd5b93592', href: "#C" }), h("path", { key: '92432bcc22d2cdaee91263c65c2f15376a749ad9', d: "M12.823 25.88c0-.947.768-1.714 1.714-1.714h.999c.947 0 1.714.767 1.714 1.714s-.768 1.714-1.714 1.714h-.999c-.947 0-1.714-.768-1.714-1.714zm0 6.857c0-.947.768-1.714 1.714-1.714h.999c.947 0 1.714.768 1.714 1.714s-.768 1.714-1.714 1.714h-.999c-.947 0-1.714-.767-1.714-1.714zm5.921-6.857c0-.947.768-1.714 1.714-1.714h.999c.947 0 1.714.767 1.714 1.714s-.768 1.714-1.714 1.714h-.999c-.947 0-1.714-.768-1.714-1.714zm0 6.857c0-.947.768-1.714 1.714-1.714h.999c.947 0 1.714.768 1.714 1.714s-.768 1.714-1.714 1.714h-.999c-.947 0-1.714-.767-1.714-1.714z" }), h("use", { key: '4f33da6465c86d33c91b528844253579ac32d7e5', href: "#D" }), h("use", { key: '1587fe72c8f6489b4cc46633e2c24f9287098522', href: "#E" }), h("path", { key: '5cac3d5ba6f0b5ef43577350af6652703bdea4e7', d: "M30.587 25.88c0-.947.767-1.714 1.714-1.714h.999c.947 0 1.714.767 1.714 1.714s-.767 1.714-1.714 1.714h-.999c-.947 0-1.714-.768-1.714-1.714zm0 6.857c0-.947.767-1.714 1.714-1.714h.999c.947 0 1.714.768 1.714 1.714s-.767 1.714-1.714 1.714h-.999c-.947 0-1.714-.767-1.714-1.714zm5.921-6.857c0-.947.767-1.714 1.714-1.714h.999c.947 0 1.714.767 1.714 1.714s-.768 1.714-1.714 1.714h-.999c-.947 0-1.714-.768-1.714-1.714zm0 6.857c0-.947.767-1.714 1.714-1.714h.999c.947 0 1.714.768 1.714 1.714s-.768 1.714-1.714 1.714h-.999c-.947 0-1.714-.767-1.714-1.714z" })), h("g", { key: 'b789b1d54d2b2cf6aac2ee20d1dc5abe7f63356e', stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: 'ef08d95360077e2d5833a721d805e728b533518a', d: "M15.429 38.382h17.143M5.143 45.578h37.714a3.43 3.43 0 0 0 3.429-3.429V21.578a3.43 3.43 0 0 0-3.429-3.429H5.143a3.43 3.43 0 0 0-3.429 3.429v20.571a3.43 3.43 0 0 0 3.429 3.429z" }), h("path", { key: 'c8bfbe6b67384710a1123c13a1e336a6e1b751d3', d: "M35.017 1.908L24.023 12.902 13.029 1.908", "stroke-linejoin": "round" }))), h("defs", { key: 'bf0783cb5836240b4c4987cb8f7cfe9cc67d106a' }, h("clipPath", { key: 'ec5ffc4248ce8b4b051e2ca20766e76add7dddb3', id: "A" }, h("path", { key: '04ed3c1f8d9861cb72b9c195d9a898f05409552a', fill: "#fff", d: "M0 0h48v48H0z" })), h("path", { key: '472f105b997cbf97c85f42160f7de5af46da241b', id: "B", d: "M6.902 25.88c0-.947.768-1.714 1.714-1.714h.999c.947 0 1.714.767 1.714 1.714s-.768 1.714-1.714 1.714h-.999c-.947 0-1.714-.768-1.714-1.714z" }), h("path", { key: '4e31f385f5cea90d6015ccf250e4e3304478d505', id: "C", d: "M6.902 32.737c0-.947.768-1.714 1.714-1.714h.999c.947 0 1.714.768 1.714 1.714s-.768 1.714-1.714 1.714h-.999c-.947 0-1.714-.767-1.714-1.714z" }), h("path", { key: 'bf754708b036ed93a0eca70e58e383314f95e09b', id: "D", d: "M24.666 25.88c0-.947.767-1.714 1.714-1.714h.999c.947 0 1.714.767 1.714 1.714s-.767 1.714-1.714 1.714h-.999c-.947 0-1.714-.768-1.714-1.714z" }), h("path", { key: '9b8b4e3a54519183bf769d2867cb5d076b6bcc08', id: "E", d: "M24.666 32.737c0-.947.767-1.714 1.714-1.714h.999c.947 0 1.714.768 1.714 1.714s-.767 1.714-1.714 1.714h-.999c-.947 0-1.714-.767-1.714-1.714z" }))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-hide-keyboard"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconHideKeyboard$1;},KsIconHideKeyboard$1 = GetKsIconHideKeyboard$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-hide-keyboard"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-hide-keyboard":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconHideKeyboard$1(transTagName));
        }
        break;
    }});
}

const KsIconHideKeyboard = KsIconHideKeyboard$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconHideKeyboard, defineCustomElement };
//# sourceMappingURL=ks-icon-hide-keyboard.js.map
//# sourceMappingURL=ks-icon-hide-keyboard.js.map