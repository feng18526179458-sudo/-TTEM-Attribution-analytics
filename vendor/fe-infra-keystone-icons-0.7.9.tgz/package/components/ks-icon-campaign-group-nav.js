import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconCampaignGroupNav$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconCampaignGroupNav$1 =

    proxyCustomElement(class KsIconCampaignGroupNav extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-campaign-group-nav';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '8e203dfe448339d2ceaf19263b9b8a86dc6a3c21', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'bb55325df1a414a62d1bfe5a0ae11869a6a7b753', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'faedfd4bfcfcdedac7aa4f3aa4fb54e1b367c838', d: "M6.49805 11.4961C6.49805 9.83924 7.84119 8.49609 9.49805 8.49609H19.8339C21.0665 8.49609 22.1737 9.25006 22.6253 10.397L23.1284 11.6746C23.58 12.8215 24.6871 13.5754 25.9198 13.5754H38.498C40.1549 13.5754 41.498 14.9186 41.498 16.5754V36.4961C41.498 38.153 40.1549 39.4961 38.498 39.4961H9.49805C7.84119 39.4961 6.49805 38.153 6.49805 36.4961V11.4961Z", stroke: icon.color, "stroke-width": icon.strokeWidth }), h("path", { key: '5bcac60da293cc9bb027c524198aeb23b78afbcf', d: "M7.31616 21.9375L39.9161 21.9375", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-campaign-group-nav"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconCampaignGroupNav$1;},KsIconCampaignGroupNav$1 = GetKsIconCampaignGroupNav$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-campaign-group-nav"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-campaign-group-nav":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconCampaignGroupNav$1(transTagName));
        }
        break;
    }});
}

const KsIconCampaignGroupNav = KsIconCampaignGroupNav$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconCampaignGroupNav, defineCustomElement };
//# sourceMappingURL=ks-icon-campaign-group-nav.js.map
//# sourceMappingURL=ks-icon-campaign-group-nav.js.map