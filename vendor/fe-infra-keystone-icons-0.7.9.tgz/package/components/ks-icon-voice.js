import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconVoice$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconVoice$1 =

    proxyCustomElement(class KsIconVoice extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-voice';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'db37ff80ef10321cb999660e6941bd72a7ff93aa', class: "ks-icon", "ks-icon": true }, h("svg", { key: '6359df4e5d3d5b7cc401d4fca1aed98c26dede85', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '453a3238089a221f14d3745d588070007037cd2d', d: "M8.71 17.274v14.69m19.757-11.696v8.701m9.878-4.054v13.088M18.588 7.128V42.11", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '3157f632a1de5a2812503f40a806fea449ccbaca', d: "M37.623 4.082zm.722 2.249c.342 1.059.873 2.348 1.838 3.31s2.252 1.496 3.31 1.838c-1.059.342-2.348.873-3.31 1.838s-1.496 2.252-1.838 3.31c-.342-1.059-.873-2.348-1.838-3.31s-2.252-1.496-3.31-1.838c1.059-.342 2.348-.873 3.31-1.838s1.496-2.252 1.838-3.31zm-7.397 4.426zm.002 1.442zm6.673 6.677zm1.442-.002zm6.677-6.673zm-.002-1.442zm-6.675-6.675z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-voice"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconVoice$1;},KsIconVoice$1 = GetKsIconVoice$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-voice"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-voice":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconVoice$1(transTagName));
        }
        break;
    }});
}

const KsIconVoice = KsIconVoice$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconVoice, defineCustomElement };
//# sourceMappingURL=ks-icon-voice.js.map
//# sourceMappingURL=ks-icon-voice.js.map