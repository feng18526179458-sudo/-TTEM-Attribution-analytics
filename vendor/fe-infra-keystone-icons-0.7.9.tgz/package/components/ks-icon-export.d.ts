import type { Components, JSX } from "../dist/types/components";

interface KsIconExport extends Components.KsIconExport, HTMLElement {}
export const KsIconExport: {
    prototype: KsIconExport;
    new (): KsIconExport;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
