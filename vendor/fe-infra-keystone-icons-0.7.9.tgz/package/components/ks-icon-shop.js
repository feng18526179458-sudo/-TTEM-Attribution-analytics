import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconShop$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconShop$1 =

    proxyCustomElement(class KsIconShop extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-shop';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '7b18d5bd081d8a4584b82190275eb22bc0fe4e06', class: "ks-icon", "ks-icon": true }, h("svg", { key: '9e393aa696c7cae829144b6660d051ced217edef', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: '7a3a0a50a91c24fe4d56e45f9995d14e50d29ee5', d: "M7.852 17.502V42a1.5 1.5 0 0 0 1.5 1.5H38.66a1.5 1.5 0 0 0 1.5-1.5V17.502" }), h("path", { key: 'a9334f395933c7c2856630328ee0bb7719945f28', d: "M7.854 27.251h11.423a1.5 1.5 0 0 1 1.5 1.5v3.5a1.5 1.5 0 0 1-1.5 1.5H7.854M5.735 5.662A1.5 1.5 0 0 1 7.197 4.5H40.81a1.5 1.5 0 0 1 1.462 1.163l2.308 9.999a1.5 1.5 0 0 1-1.462 1.837H4.889a1.5 1.5 0 0 1-1.462-1.837l2.308-9.999z" }), h("path", { key: '534e5a35866f45a58c9ae5f0af779d243d35b142', d: "M30.466 19.012v24.373", "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-shop"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconShop$1;},KsIconShop$1 = GetKsIconShop$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-shop"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-shop":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconShop$1(transTagName));
        }
        break;
    }});
}

const KsIconShop = KsIconShop$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconShop, defineCustomElement };
//# sourceMappingURL=ks-icon-shop.js.map
//# sourceMappingURL=ks-icon-shop.js.map