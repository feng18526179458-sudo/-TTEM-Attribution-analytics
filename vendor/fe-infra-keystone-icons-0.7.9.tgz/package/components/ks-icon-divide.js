import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconDivide$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconDivide$1 =

    proxyCustomElement(class KsIconDivide extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-divide';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'bad53631db5e63d188dd300074acd9232963b605', class: "ks-icon", "ks-icon": true }, h("svg", { key: '41a6a94495d54778c49f47b1b059c390bb1882af', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'e821b1d49018df5234988189537f1169db09f784', d: "M5.25757 24.0002H42.7439", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: 'b89cd886760dc5c8369ebc425b8ba95336184087', d: "M26.0007 40.0002C26.0007 41.1048 25.1053 42.0002 24.0007 42.0002C22.8961 42.0002 22.0007 41.1048 22.0007 40.0002C22.0007 38.8957 22.8961 38.0002 24.0007 38.0002C25.1053 38.0002 26.0007 38.8957 26.0007 40.0002Z", fill: icon.color, stroke: icon.color, "stroke-width": icon.strokeWidth }), h("path", { key: 'a49a16ef751415fb84ae9d69329eb213ca03f08c', d: "M26.0007 10.0002C26.0007 11.1048 25.1053 12.0002 24.0007 12.0002C22.8961 12.0002 22.0007 11.1048 22.0007 10.0002C22.0007 8.89567 22.8961 8.00024 24.0007 8.00024C25.1053 8.00024 26.0007 8.89567 26.0007 10.0002Z", fill: icon.color, stroke: icon.color, "stroke-width": icon.strokeWidth })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-divide"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconDivide$1;},KsIconDivide$1 = GetKsIconDivide$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-divide"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-divide":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconDivide$1(transTagName));
        }
        break;
    }});
}

const KsIconDivide = KsIconDivide$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconDivide, defineCustomElement };
//# sourceMappingURL=ks-icon-divide.js.map
//# sourceMappingURL=ks-icon-divide.js.map