import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconBreakdown$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconBreakdown$1 =

    proxyCustomElement(class KsIconBreakdown extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-breakdown';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '86a38dccf4e9dfbabefbd733baba5e7a94a98db3', class: "ks-icon", "ks-icon": true }, h("svg", { key: '1dff364e97777e30d49a487986bb37612849fed7', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'c27c7125330364cc174471fef52469c1df43e2cb', d: "M5 9.92188C5 8.81731 5.89543 7.92188 7 7.92188H41C42.1046 7.92188 43 8.81731 43 9.92188V17.9219C43 19.0264 42.1046 19.9219 41 19.9219H7C5.89543 19.9219 5 19.0264 5 17.9219V9.92188Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: 'c2e8155fa96fcd7215c7a0a9fbc2c3115dcffdca', d: "M10 30.0781H38", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '70d214f0b858c4c9d4354aa6f054774a2a7fd553', d: "M10 40.0781H38", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-breakdown"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconBreakdown$1;},KsIconBreakdown$1 = GetKsIconBreakdown$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-breakdown"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-breakdown":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconBreakdown$1(transTagName));
        }
        break;
    }});
}

const KsIconBreakdown = KsIconBreakdown$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconBreakdown, defineCustomElement };
//# sourceMappingURL=ks-icon-breakdown.js.map
//# sourceMappingURL=ks-icon-breakdown.js.map