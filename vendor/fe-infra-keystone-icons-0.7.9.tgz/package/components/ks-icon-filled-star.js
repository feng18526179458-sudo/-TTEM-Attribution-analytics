import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledStar$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledStar$1 =

    proxyCustomElement(class KsIconFilledStar extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-star';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '34178912a4fcd4585a35775c316bff57f91b59cf', class: "ks-icon", "ks-icon": true }, h("svg", { key: '325fb772ff28ff099198c2f5a330f06ec3dd4cee', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '91c8e50c476fcd9af4687b1565cb67ed80fcc4ca', d: "M21.488 4.618c1.037-2.158 3.986-2.158 5.023 0l4.372 9.098c.409.851 1.188 1.442 2.089 1.585l9.637 1.531c2.286.363 3.197 3.292 1.552 4.989l-6.934 7.154c-.649.669-.946 1.625-.798 2.564l1.584 10.044c.376 2.382-2.011 4.192-4.064 3.083l-8.658-4.676c-.81-.437-1.772-.437-2.582 0l-8.658 4.676c-2.053 1.109-4.439-.701-4.064-3.083l1.583-10.044c.148-.939-.149-1.895-.798-2.564l-6.934-7.154c-1.645-1.697-.733-4.626 1.552-4.989l9.637-1.531c.901-.143 1.68-.734 2.089-1.585l4.372-9.098z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-star"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFilledStar$1;},KsIconFilledStar$1 = GetKsIconFilledStar$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-star"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-star":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledStar$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledStar = KsIconFilledStar$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledStar, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-star.js.map
//# sourceMappingURL=ks-icon-filled-star.js.map