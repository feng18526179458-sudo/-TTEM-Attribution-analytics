import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconRefresh$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconRefresh$1 =

    proxyCustomElement(class KsIconRefresh extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-refresh';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'd7696d0d4bef768e6844d0c3ecfbe677bdbd3d5d', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: '2a1204468f36e7fe8c04c1d2b4d342d8f9de35b6', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: '539d2473fff6ce2de2803d7700c06d8de56d1b0c', d: "M43.5 24a19.44 19.44 0 0 1-5.711 13.789A19.44 19.44 0 0 1 24 43.5a19.44 19.44 0 0 1-13.788-5.711A19.44 19.44 0 0 1 4.5 24a19.44 19.44 0 0 1 5.711-13.789A19.44 19.44 0 0 1 24 4.5a19.44 19.44 0 0 1 13.789 5.711 19.62 19.62 0 0 1 1.963 2.29" }), h("path", { key: 'd08bcce0ed42006dbbf7fc8a10b373c1931e873a', d: "M32.241 12.817h7.79m0-7.79v7.791" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-refresh"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconRefresh$1;},KsIconRefresh$1 = GetKsIconRefresh$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-refresh"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-refresh":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconRefresh$1(transTagName));
        }
        break;
    }});
}

const KsIconRefresh = KsIconRefresh$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconRefresh, defineCustomElement };
//# sourceMappingURL=ks-icon-refresh.js.map
//# sourceMappingURL=ks-icon-refresh.js.map