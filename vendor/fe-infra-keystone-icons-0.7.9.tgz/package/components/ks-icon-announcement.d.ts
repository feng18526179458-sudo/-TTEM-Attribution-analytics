import type { Components, JSX } from "../dist/types/components";

interface KsIconAnnouncement extends Components.KsIconAnnouncement, HTMLElement {}
export const KsIconAnnouncement: {
    prototype: KsIconAnnouncement;
    new (): KsIconAnnouncement;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
