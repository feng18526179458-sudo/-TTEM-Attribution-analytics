import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconUnderline$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconUnderline$1 =

    proxyCustomElement(class KsIconUnderline extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-underline';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '9cff4e4cc484a886a7729e8cba67cfcc59bb611d', class: "ks-icon", "ks-icon": true }, h("svg", { key: '6a6451c1f0383334605a13e784d3ac7d2c48d15d', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: 'acb1102f6d7d156283b3082998c4d2ffd629fecb', d: "M14.175 6.923v19.763a9.79 9.79 0 0 0 9.789 9.789 9.79 9.79 0 0 0 9.789-9.789V6.923M8.571 40.938h30.857" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-underline"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconUnderline$1;},KsIconUnderline$1 = GetKsIconUnderline$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-underline"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-underline":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconUnderline$1(transTagName));
        }
        break;
    }});
}

const KsIconUnderline = KsIconUnderline$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconUnderline, defineCustomElement };
//# sourceMappingURL=ks-icon-underline.js.map
//# sourceMappingURL=ks-icon-underline.js.map