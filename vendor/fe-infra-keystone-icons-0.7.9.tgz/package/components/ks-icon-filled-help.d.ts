import type { Components, JSX } from "../dist/types/components";

interface KsIconFilledHelp extends Components.KsIconFilledHelp, HTMLElement {}
export const KsIconFilledHelp: {
    prototype: KsIconFilledHelp;
    new (): KsIconFilledHelp;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
