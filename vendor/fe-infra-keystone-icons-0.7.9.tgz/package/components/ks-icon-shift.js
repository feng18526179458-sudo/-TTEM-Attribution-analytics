import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconShift$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconShift$1 =

    proxyCustomElement(class KsIconShift extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-shift';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '57d2182d396524661e55d9cee611d4671165d3b1', class: "ks-icon", "ks-icon": true }, h("svg", { key: '8081158b1989d6ffbec966eaae1b1b1f7153e2e0', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '13f7fc0d417d474f449a5ba9489c72df56dd715c', d: "M23.9892 6.87598L41.0147 24.9911H32.0049L32.0361 41.124L15.9438 41.0805L16.0103 25.0138L6.98438 25.0054L23.9892 6.87598Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-shift"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconShift$1;},KsIconShift$1 = GetKsIconShift$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-shift"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-shift":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconShift$1(transTagName));
        }
        break;
    }});
}

const KsIconShift = KsIconShift$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconShift, defineCustomElement };
//# sourceMappingURL=ks-icon-shift.js.map
//# sourceMappingURL=ks-icon-shift.js.map