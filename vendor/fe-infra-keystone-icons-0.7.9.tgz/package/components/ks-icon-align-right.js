import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconAlignRight$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconAlignRight$1 =

    proxyCustomElement(class KsIconAlignRight extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-align-right';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'c350398243125a6a59799bb199e5f4d4c978fe02', class: "ks-icon", "ks-icon": true }, h("svg", { key: '8ad1348d2b7f66d70e2763f5488f26e8809eee8c', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '7af13e46f5e777ee4b5627e63b59742671c95dbf', d: "M42.4541 39.0528H24.3055M42.4541 18.4813L24.3055 18.4813M42.4541 28.7668L11.9556 28.7668M42.4539 8.19531L6.47783 8.19531", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-align-right"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconAlignRight$1;},KsIconAlignRight$1 = GetKsIconAlignRight$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-align-right"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-align-right":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconAlignRight$1(transTagName));
        }
        break;
    }});
}

const KsIconAlignRight = KsIconAlignRight$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconAlignRight, defineCustomElement };
//# sourceMappingURL=ks-icon-align-right.js.map
//# sourceMappingURL=ks-icon-align-right.js.map