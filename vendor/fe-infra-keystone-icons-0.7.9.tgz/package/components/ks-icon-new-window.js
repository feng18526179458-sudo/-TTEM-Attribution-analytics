import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconNewWindow$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconNewWindow$1 =

    proxyCustomElement(class KsIconNewWindow extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-new-window';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '82207ffdc3f9f8b85148b14310d3a4866fc92492', class: "ks-icon", "ks-icon": true }, h("svg", { key: '8a5c3279d359762c1c0ae1ee582e5b02453b8f76', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: 'e39a89e0b50a55e941ae9fff7b63fe5f7f0634c6', d: "M16.478 5.952H7.411a1.5 1.5 0 0 0-1.5 1.5v32.611a1.5 1.5 0 0 0 1.5 1.5h32.758a1.5 1.5 0 0 0 1.5-1.5v-9.21M24.82 5.951h17m-.011 16.464V6.001", "stroke-linejoin": "round" }), h("path", { key: 'a29ca76e808bc607ef856efaeefdb604fa6ca499', d: "M23.667 23.999L41.665 6.002" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-new-window"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconNewWindow$1;},KsIconNewWindow$1 = GetKsIconNewWindow$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-new-window"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-new-window":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconNewWindow$1(transTagName));
        }
        break;
    }});
}

const KsIconNewWindow = KsIconNewWindow$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconNewWindow, defineCustomElement };
//# sourceMappingURL=ks-icon-new-window.js.map
//# sourceMappingURL=ks-icon-new-window.js.map