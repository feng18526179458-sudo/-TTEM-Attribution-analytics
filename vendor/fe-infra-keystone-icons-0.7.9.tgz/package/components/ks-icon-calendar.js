import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconCalendar$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconCalendar$1 =

    proxyCustomElement(class KsIconCalendar extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-calendar';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '448b3ac77154b541d73587f9244c2bd23270b53a', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: '3a7ca36265477f65900b54127f7a1f4ad8296348', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("rect", { key: 'b73f850a76216c859e12164d44bec47dfaa5fca0', x: "4.502", y: "9.003", width: "39", height: "33", rx: "1.5" }), h("path", { key: 'e239fa5a3c3b11d33e8c222619ca52f24c40b289', d: "M15.001 5.257v7.517m18.007-7.517v7.517", "stroke-linecap": "round" }), h("path", { key: '1df09e68942345abd1556fe48146951102424acd', d: "M4.507 19.503h39" }), h("path", { key: '6853ecee15281c1f156a9c39fa5ef9a6e70e50f3', d: "M12.007 27.207h12m-12 7.533h21", "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-calendar"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconCalendar$1;},KsIconCalendar$1 = GetKsIconCalendar$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-calendar"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-calendar":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconCalendar$1(transTagName));
        }
        break;
    }});
}

const KsIconCalendar = KsIconCalendar$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconCalendar, defineCustomElement };
//# sourceMappingURL=ks-icon-calendar.js.map
//# sourceMappingURL=ks-icon-calendar.js.map