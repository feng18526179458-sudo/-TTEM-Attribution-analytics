import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledDisapproval$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledDisapproval$1 =

    proxyCustomElement(class KsIconFilledDisapproval extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-disapproval';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '21308e23f0c191b6b5a7866e4ce5bafd86300588', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'd117bcc8f72bfe470c6113b7745044653a1d4c67', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '13ed3ce5a347b6bcb402d242efb1ff3dcbc87185', d: "M4.50104 23.9999C4.50104 13.2304 13.2315 4.5 24.001 4.5C34.7706 4.5 43.501 13.2304 43.501 23.9999C43.501 34.7693 34.7706 43.4997 24.001 43.4997C13.2315 43.4997 4.50104 34.7693 4.50104 23.9999Z", fill: "#FFC6BD" }), h("path", { key: 'd88475f68c8955d3eac3dc21295f9df41306ac26', d: "M15.7833 15.7817L32.2188 32.2173", stroke: "#4E0C0B", "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-disapproval"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFilledDisapproval$1;},KsIconFilledDisapproval$1 = GetKsIconFilledDisapproval$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-disapproval"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-disapproval":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledDisapproval$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledDisapproval = KsIconFilledDisapproval$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledDisapproval, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-disapproval.js.map
//# sourceMappingURL=ks-icon-filled-disapproval.js.map