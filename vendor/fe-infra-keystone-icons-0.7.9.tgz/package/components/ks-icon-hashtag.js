import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconHashtag$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconHashtag$1 =

    proxyCustomElement(class KsIconHashtag extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-hashtag';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '738c171ae7d8b2589d264f8f456088584954cfcc', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'b1c91515c499955178bc008bfec934b1c77cee62', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: '6cd73c7c932382e47ecf3213715f5cffde50d322', d: "M6.989 16.275h34.295M6.988 31.753h34.295" }), h("path", { key: 'd4fd43a87e2cd133a7a78e636f26ddc26ca32b70', d: "M28.895 40.901L34.85 7.127M13.418 40.901l5.955-33.774" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-hashtag"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconHashtag$1;},KsIconHashtag$1 = GetKsIconHashtag$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-hashtag"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-hashtag":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconHashtag$1(transTagName));
        }
        break;
    }});
}

const KsIconHashtag = KsIconHashtag$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconHashtag, defineCustomElement };
//# sourceMappingURL=ks-icon-hashtag.js.map
//# sourceMappingURL=ks-icon-hashtag.js.map