import type { Components, JSX } from "../dist/types/components";

interface KsIconCreditCard extends Components.KsIconCreditCard, HTMLElement {}
export const KsIconCreditCard: {
    prototype: KsIconCreditCard;
    new (): KsIconCreditCard;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
