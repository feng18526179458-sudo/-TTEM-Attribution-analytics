import type { Components, JSX } from "../dist/types/components";

interface KsIconClock extends Components.KsIconClock, HTMLElement {}
export const KsIconClock: {
    prototype: KsIconClock;
    new (): KsIconClock;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
