import type { Components, JSX } from "../dist/types/components";

interface KsIconColoredUnknown extends Components.KsIconColoredUnknown, HTMLElement {}
export const KsIconColoredUnknown: {
    prototype: KsIconColoredUnknown;
    new (): KsIconColoredUnknown;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
