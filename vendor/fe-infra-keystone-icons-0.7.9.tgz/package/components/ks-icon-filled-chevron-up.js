import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledChevronUp$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledChevronUp$1 =

    proxyCustomElement(class KsIconFilledChevronUp extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-chevron-up';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '0dfab334230e440b4e3def9c6dca7f1b5e5bfbc3', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'af5d1ae79fc4c8f8d33bf2ee304f2e4f54bdfcdd', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'c6cf8d9d1397d7aa45747266706af4a915531f51', d: "M25.0583 13.9605C24.4731 13.3784 23.5276 13.3784 22.9425 13.9605L4.89591 31.9126C4.46528 32.341 4.3355 32.9868 4.56721 33.5483C4.79892 34.1098 5.34637 34.4761 5.95378 34.4761H42.0466C42.654 34.4761 43.2014 34.1098 43.4331 33.5483C43.6648 32.9868 43.5351 32.341 43.1045 31.9126L25.0583 13.9605Z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-chevron-up"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFilledChevronUp$1;},KsIconFilledChevronUp$1 = GetKsIconFilledChevronUp$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-chevron-up"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-chevron-up":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledChevronUp$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledChevronUp = KsIconFilledChevronUp$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledChevronUp, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-chevron-up.js.map
//# sourceMappingURL=ks-icon-filled-chevron-up.js.map