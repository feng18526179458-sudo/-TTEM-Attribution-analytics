import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconLocationPin$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconLocationPin$1 =

    proxyCustomElement(class KsIconLocationPin extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-location-pin';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'c57e675d0bb70da641f22601ff4599e5336a860a', class: "ks-icon", "ks-icon": true }, h("svg", { key: '1377d6da1bfe1c2011b71d14a700ef0e8ad65649', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '6bb5c1aa6a55624163eef8e7355a2d807cbced44', "fill-rule": "evenodd", "clip-rule": "evenodd", d: "M23.9211 41.9634L13.2275 29.6015C8.33471 23.9454 8.63922 15.4666 13.9246 10.1768C19.4893 4.6074 28.5105 4.6074 34.0752 10.1768C39.3606 15.4666 39.6651 23.9454 34.7724 29.6015L24.0787 41.9634C24.0625 41.9822 24.0515 41.9881 24.0444 41.9912C24.0343 41.9957 24.019 41.9998 23.9999 41.9998C23.9808 41.9998 23.9655 41.9957 23.9554 41.9912C23.9484 41.9881 23.9374 41.9822 23.9211 41.9634ZM11.8024 8.05634C18.5389 1.31423 29.4609 1.31423 36.1974 8.05634C42.5943 14.4585 42.9626 24.7191 37.0413 31.5642L26.3476 43.9261C25.1093 45.3576 22.8906 45.3576 21.6522 43.9261L10.9586 31.5642C5.03725 24.7191 5.40556 14.4585 11.8024 8.05634Z", fill: icon.color }), h("path", { key: '6cbc2947436600fcdbff07f7438cd3449f4af69e', "fill-rule": "evenodd", "clip-rule": "evenodd", d: "M24.006 24.2012C21.6323 24.2012 19.7037 22.2746 19.7037 19.8928C19.7037 17.511 21.6323 15.5845 24.006 15.5845C26.3797 15.5845 28.3083 17.511 28.3083 19.8928C28.3083 22.2746 26.3797 24.2012 24.006 24.2012ZM24.006 27.2012C19.9731 27.2012 16.7037 23.9291 16.7037 19.8928C16.7037 15.8565 19.9731 12.5845 24.006 12.5845C28.0389 12.5845 31.3083 15.8565 31.3083 19.8928C31.3083 23.9291 28.0389 27.2012 24.006 27.2012Z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-location-pin"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconLocationPin$1;},KsIconLocationPin$1 = GetKsIconLocationPin$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-location-pin"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-location-pin":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconLocationPin$1(transTagName));
        }
        break;
    }});
}

const KsIconLocationPin = KsIconLocationPin$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconLocationPin, defineCustomElement };
//# sourceMappingURL=ks-icon-location-pin.js.map
//# sourceMappingURL=ks-icon-location-pin.js.map