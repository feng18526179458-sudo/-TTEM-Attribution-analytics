import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconBold$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconBold$1 =

    proxyCustomElement(class KsIconBold extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-bold';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'b4cb147a03c241ef5d55a1f4194827682ac0d839', class: "ks-icon", "ks-icon": true }, h("svg", { key: '12cd00cb756ac6a82d3fd44472176d85950a7919', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '092a170295c2e9d3c176471c8a376f5292079ad6', d: "M12.013 22.977h13.295a7.95 7.95 0 0 0 7.946-7.946 7.95 7.95 0 0 0-7.946-7.946H12.013v15.892zm0 0h15.006a8.97 8.97 0 0 1 8.968 8.968 8.97 8.97 0 0 1-8.968 8.968H12.013V22.977z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-bold"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconBold$1;},KsIconBold$1 = GetKsIconBold$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-bold"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-bold":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconBold$1(transTagName));
        }
        break;
    }});
}

const KsIconBold = KsIconBold$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconBold, defineCustomElement };
//# sourceMappingURL=ks-icon-bold.js.map
//# sourceMappingURL=ks-icon-bold.js.map