import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledPause$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledPause$1 =

    proxyCustomElement(class KsIconFilledPause extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-pause';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'dda4896f8de2bfd5a20dc433b4e103d19b1d4954', class: "ks-icon", "ks-icon": true }, h("svg", { key: '4a3c695d51f4afa62910d88932859f16d38f26ef', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '6604a6ba528bfbb786d307611c8369c80671ad79', d: "M12.2556 39.4995V8.50126C12.2556 7.39669 13.151 6.50126 14.2556 6.50126H18.5638C19.6684 6.50126 20.5638 7.39669 20.5638 8.50126V39.4995C20.5638 40.6041 19.6684 41.4995 18.5638 41.4995H14.2556C13.151 41.4995 12.2556 40.6041 12.2556 39.4995Z", fill: "#262627" }), h("path", { key: '2a26d46feced44fc9024c39852583531816181af', d: "M27.4358 39.4995V8.49951C27.4358 7.39494 28.3312 6.49951 29.4358 6.49951H33.7439C34.8485 6.49951 35.7439 7.39494 35.7439 8.49951V39.4995C35.7439 40.6041 34.8485 41.4995 33.7439 41.4995H29.4358C28.3312 41.4995 27.4358 40.6041 27.4358 39.4995Z", fill: "#262627" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-pause"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFilledPause$1;},KsIconFilledPause$1 = GetKsIconFilledPause$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-pause"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-pause":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledPause$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledPause = KsIconFilledPause$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledPause, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-pause.js.map
//# sourceMappingURL=ks-icon-filled-pause.js.map