import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconAlignLeft$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconAlignLeft$1 =

    proxyCustomElement(class KsIconAlignLeft extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-align-left';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '6af57c1ced3d150dcf4f1a1bd602380103e9c1c7', class: "ks-icon", "ks-icon": true }, h("svg", { key: '3c2bdc49c2c17ef43443433fbc30c5275ce9ee12', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'e8f207dee571d4ce4ebbf16dc0d1e60dee96a526', d: "M6.47796 39.8051H24.6265M6.47796 19.2337H24.6265M6.47796 29.5194L36.9764 29.5194M6.47796 8.94794L42.454 8.94794", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-align-left"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconAlignLeft$1;},KsIconAlignLeft$1 = GetKsIconAlignLeft$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-align-left"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-align-left":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconAlignLeft$1(transTagName));
        }
        break;
    }});
}

const KsIconAlignLeft = KsIconAlignLeft$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconAlignLeft, defineCustomElement };
//# sourceMappingURL=ks-icon-align-left.js.map
//# sourceMappingURL=ks-icon-align-left.js.map