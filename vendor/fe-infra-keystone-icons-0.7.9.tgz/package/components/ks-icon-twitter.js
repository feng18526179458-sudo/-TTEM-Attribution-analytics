import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconTwitter$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconTwitter$1 =

    proxyCustomElement(class KsIconTwitter extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-twitter';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'fb8229644e269a569e759634f5628c8900966ed6', class: "ks-icon", "ks-icon": true }, h("svg", { key: '3a46a38ff2cab108f2e81d5fa9fb03a5b57fb397', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '5fb40c87d9e39ae468feadbe7d91981fba6d087c', d: "M35.534 6h6.107L28.298 21.249 43.995 42h-12.29l-9.626-12.585L11.064 42H4.953l14.271-16.311L4.167 6h12.602l8.701 11.503L35.534 6zM33.39 38.345h3.384L14.93 9.463h-3.631L33.39 38.345z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-twitter"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconTwitter$1;},KsIconTwitter$1 = GetKsIconTwitter$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-twitter"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-twitter":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconTwitter$1(transTagName));
        }
        break;
    }});
}

const KsIconTwitter = KsIconTwitter$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconTwitter, defineCustomElement };
//# sourceMappingURL=ks-icon-twitter.js.map
//# sourceMappingURL=ks-icon-twitter.js.map