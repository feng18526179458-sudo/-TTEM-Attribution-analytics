import type { Components, JSX } from "../dist/types/components";

interface KsIconColoredCompressedFile extends Components.KsIconColoredCompressedFile, HTMLElement {}
export const KsIconColoredCompressedFile: {
    prototype: KsIconColoredCompressedFile;
    new (): KsIconColoredCompressedFile;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
