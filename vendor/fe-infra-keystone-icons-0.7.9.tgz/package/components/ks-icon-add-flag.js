import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconAddFlag$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconAddFlag$1 =

    proxyCustomElement(class KsIconAddFlag extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-add-flag';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '9ee82883b12491ec64eec51b22aacd57d9ffcf43', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: '072ab5a22537d9e1eb1a4d8713d3c419467d5eac', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: '38342333efeaef6f0ec8fc6804cfd92e552aef20', d: "M10.5 20.308V6A1.5 1.5 0 0 1 12 4.5h5.153a13.55 13.55 0 0 1 6.502 1.662 16.55 16.55 0 0 0 7.942 2.03H36a1.5 1.5 0 0 1 1.5 1.5V24a1.5 1.5 0 0 1-1.5 1.5h-4.403a13.55 13.55 0 0 1-6.502-1.662 16.55 16.55 0 0 0-7.942-2.03H12a1.5 1.5 0 0 1-1.5-1.5z" }), h("path", { key: '0e7631b2a9951b3dbb1bbd8ad734dd7d70450cd5', d: "M10.501 12v31.5", "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-add-flag"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconAddFlag$1;},KsIconAddFlag$1 = GetKsIconAddFlag$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-add-flag"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-add-flag":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconAddFlag$1(transTagName));
        }
        break;
    }});
}

const KsIconAddFlag = KsIconAddFlag$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconAddFlag, defineCustomElement };
//# sourceMappingURL=ks-icon-add-flag.js.map
//# sourceMappingURL=ks-icon-add-flag.js.map