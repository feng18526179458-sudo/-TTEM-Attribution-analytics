import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconCoin$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconCoin$1 =

    proxyCustomElement(class KsIconCoin extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-coin';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'ec33d04b547520d191e5b3500c9039f1257dd070', class: "ks-icon", "ks-icon": true }, h("svg", { key: '83bc203f30af2f0624e045f091c95f01fb2c20a7', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '652395658957eaa0962760f1ef1e41db69c5b951', d: "M24 21.3999C31.1797 21.3999 37 18.4898 37 14.8999C37 11.3101 31.1797 8.3999 24 8.3999C16.8203 8.3999 11 11.3101 11 14.8999C11 18.4898 16.8203 21.3999 24 21.3999Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: '4a163d38687d34efed336df2cfb6cf712aa1a16a', d: "M11 14.8999C11 14.8999 11 20.4101 11 23.9999C11 27.5897 16.8204 30.4999 24 30.4999C31.1796 30.4999 37 27.5897 37 23.9999C37 21.8736 37 14.8999 37 14.8999", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: '369bc97dbf45ee7d63c043fa99171c258ba0d031', d: "M11 24C11 24 11 29.5102 11 33.1C11 36.6898 16.8204 39.6 24 39.6C31.1796 39.6 37 36.6898 37 33.1C37 30.9737 37 24 37 24", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-coin"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconCoin$1;},KsIconCoin$1 = GetKsIconCoin$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-coin"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-coin":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconCoin$1(transTagName));
        }
        break;
    }});
}

const KsIconCoin = KsIconCoin$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconCoin, defineCustomElement };
//# sourceMappingURL=ks-icon-coin.js.map
//# sourceMappingURL=ks-icon-coin.js.map