import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconLipsync$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconLipsync$1 =

    proxyCustomElement(class KsIconLipsync extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-lipsync';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '1ffea43903532dd2608e15b6f685406de0173768', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'e3f7f8c8e385110f41b2d6b4fcb7f2e3bccc37ec', width: icon.width, height: icon.height, viewBox: "0 0 49 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'f5714867469e8fa4488a551f711bf0ece79e8425', d: "M13.5861 23.4725C22.2509 25.6141 26.8809 25.5637 34.8517 23.3953", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: '8eead8c40f9f01e66d8248679e704bdde96758fd', "fill-rule": "evenodd", "clip-rule": "evenodd", d: "M35.7929 40.6672C35.5305 39.55 35.208 38.1765 34.3637 37.3322C33.5195 36.488 32.1459 36.1654 31.0287 35.903C30.012 35.6643 29.2075 35.4754 29.2075 34.9884C29.2075 34.5015 30.012 34.3125 31.0287 34.0738C32.1459 33.8114 33.5194 33.4888 34.3637 32.6446C35.208 31.8003 35.5305 30.4268 35.7929 29.3096C36.0316 28.2929 36.2206 27.4884 36.7075 27.4884C37.1945 27.4884 37.3834 28.2929 37.6222 29.3096C37.8845 30.4268 38.2071 31.8003 39.0513 32.6446C39.8956 33.4888 41.2691 33.8114 42.3863 34.0738C43.4031 34.3125 44.2075 34.5015 44.2075 34.9884C44.2075 35.4754 43.4031 35.6643 42.3863 35.903C41.2691 36.1654 39.8956 36.488 39.0513 37.3322C38.2071 38.1765 37.8845 39.55 37.6222 40.6672C37.3834 41.6839 37.1945 42.4884 36.7075 42.4884C36.2206 42.4884 36.0316 41.6839 35.7929 40.6672Z", fill: icon.color }), h("path", { key: '0df87d87aeebb89ac827ea8f3f4d4c50c64ae65f', d: "M26.7922 36.2686H24.219C15.4621 36.2686 7.81852 30.3341 5.64841 21.8503L5.59588 21.645L13.9586 13.2647C14.9381 12.2831 16.2679 11.7314 17.6546 11.7314C18.8871 11.7314 20.0799 12.1674 21.0219 12.9623L22.8643 14.5168C23.6467 15.1771 24.7912 15.1771 25.5737 14.5168L27.4161 12.9623C28.358 12.1674 29.5508 11.7314 30.7833 11.7314C32.1701 11.7314 33.4999 12.2831 34.4794 13.2647L42.8421 21.645L42.4673 23.4763C42.0942 25.2998 41.4195 26.9974 40.5016 28.5214", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-lipsync"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconLipsync$1;},KsIconLipsync$1 = GetKsIconLipsync$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-lipsync"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-lipsync":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconLipsync$1(transTagName));
        }
        break;
    }});
}

const KsIconLipsync = KsIconLipsync$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconLipsync, defineCustomElement };
//# sourceMappingURL=ks-icon-lipsync.js.map
//# sourceMappingURL=ks-icon-lipsync.js.map