import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconGear$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconGear$1 =

    proxyCustomElement(class KsIconGear extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-gear';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'bba68e50791ad3d1f05a63e649fd3416c41a40ab', class: "ks-icon", "ks-icon": true }, h("svg", { key: '10c77bc819ccb00e8dc0bf9c4bb09a6f6d2f46bd', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'ec258c0be30497574f3a38fe5008726ebeb96d66', "fill-rule": "evenodd", "clip-rule": "evenodd", d: "M28.5831 28.5959C27.3724 29.8066 25.7338 30.4997 23.987 30.4997C22.2401 30.4997 20.6016 29.8066 19.3908 28.5959C18.1801 27.3852 17.4871 25.7467 17.4871 23.9998C17.4871 22.253 18.1801 20.6145 19.3908 19.4037C20.6016 18.193 22.2401 17.5 23.987 17.5C25.7338 17.5 27.3724 18.193 28.5831 19.4037C29.7938 20.6145 30.4868 22.253 30.4868 23.9998C30.4868 25.7467 29.7938 27.3852 28.5831 28.5959Z", stroke: icon.color, "stroke-width": icon.strokeWidth }), h("path", { key: 'cb05aa0d62a5208f080824f7470f68d31d9f4005', d: "M21.0256 5.75432C21.1462 5.03105 21.7719 4.50095 22.5052 4.50095H26.4637C27.197 4.50095 27.8228 5.03105 27.9433 5.75432L28.1907 7.23868C28.2851 7.80519 28.6969 8.26235 29.2374 8.45669C30.1202 8.77413 30.9724 9.16746 31.7855 9.6319C32.324 9.93951 32.9952 9.93268 33.4999 9.57222L34.2484 9.03752C34.8451 8.61133 35.6624 8.67897 36.1809 9.19745L38.98 11.9966C39.4985 12.515 39.5662 13.3324 39.14 13.929L38.4206 14.9361C38.0807 15.412 38.054 16.0395 38.3129 16.564C38.7913 17.5332 39.1726 18.5508 39.4496 19.6031C39.6088 20.2081 40.0907 20.685 40.7077 20.7878L42.2308 21.0417C42.9541 21.1622 43.4842 21.788 43.4842 22.5212V26.4798C43.4842 27.213 42.9541 27.8388 42.2308 27.9593L40.2145 28.2954C39.651 28.3893 39.1954 28.7973 38.9992 29.3338C38.7339 30.0597 38.4171 30.7647 38.0515 31.4439C37.7646 31.9769 37.7801 32.6298 38.1319 33.1224L38.9476 34.2644C39.3738 34.861 39.3061 35.6783 38.7877 36.1968L35.9885 38.9959C35.4701 39.5144 34.6527 39.5821 34.0561 39.1559L32.8413 38.2882C32.3567 37.9421 31.716 37.9211 31.1869 38.1945C30.5824 38.5069 29.9582 38.781 29.3178 39.0151C28.7813 39.2113 28.3733 39.6668 28.2794 40.2303L27.9433 42.2467C27.8228 42.9699 27.197 43.5 26.4637 43.5H22.5052C21.7719 43.5 21.1462 42.9699 21.0256 42.2467L20.7718 40.7236C20.6689 40.1065 20.192 39.6246 19.5871 39.4654C18.5347 39.1885 17.5172 38.8071 16.5479 38.3288C16.0234 38.0699 15.396 38.0966 14.9201 38.4365L13.913 39.1559C13.3163 39.5821 12.499 39.5144 11.9805 38.9959L9.18135 36.1968C8.66287 35.6783 8.59522 34.861 9.02141 34.2644L9.55613 33.5158C9.91659 33.0111 9.92342 32.3399 9.61581 31.8014C9.15138 30.9884 8.75805 30.1361 8.44062 29.2533C8.24628 28.7129 7.78912 28.3011 7.2226 28.2067L5.73821 27.9593C5.01494 27.8388 4.48483 27.213 4.48483 26.4798V22.5212C4.48483 21.788 5.01494 21.1622 5.73821 21.0417L6.7388 20.8749C7.35878 20.7716 7.84202 20.2908 7.99889 19.6822C8.31225 18.4664 8.76476 17.2966 9.34509 16.1933C9.62432 15.6624 9.60575 15.0164 9.25711 14.5283L8.82903 13.929C8.40284 13.3324 8.47048 12.515 8.98897 11.9966L11.7881 9.19745C12.3066 8.67897 13.1239 8.61133 13.7206 9.03752L14.2491 9.41503C14.7452 9.76936 15.4033 9.78238 15.938 9.48958C17.1109 8.84728 18.3621 8.3511 19.6661 8.015C20.2747 7.85812 20.7555 7.37489 20.8589 6.75491L21.0256 5.75432Z", stroke: icon.color, "stroke-width": icon.strokeWidth })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-gear"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconGear$1;},KsIconGear$1 = GetKsIconGear$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-gear"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-gear":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconGear$1(transTagName));
        }
        break;
    }});
}

const KsIconGear = KsIconGear$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconGear, defineCustomElement };
//# sourceMappingURL=ks-icon-gear.js.map
//# sourceMappingURL=ks-icon-gear.js.map