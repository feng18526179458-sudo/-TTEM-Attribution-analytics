import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconLeadGeneration$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconLeadGeneration$1 =

    proxyCustomElement(class KsIconLeadGeneration extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-lead-generation';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '67b8369cb1ca96cc960e42b2ccb350b274fde2f5', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: 'd4f21e3c03f1d5842ee4677b809d870055410971', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: 'b7a64ac088c40a64c2a4357c1ae2a9094662295b', d: "M13.375 41.089c-7.396-4.27-9.93-13.727-5.66-21.122l9.092-15.748a1.5 1.5 0 0 1 2.049-.549l4.707 2.718a1.5 1.5 0 0 1 .549 2.049l-9.092 15.748a7.03 7.03 0 0 0 2.572 9.6 7.03 7.03 0 0 0 9.599-2.572l9.092-15.748a1.5 1.5 0 0 1 2.049-.549l4.707 2.718a1.5 1.5 0 0 1 .549 2.049l-9.092 15.748c-4.27 7.396-13.727 9.93-21.122 5.66z" }), h("path", { key: '983aa60ceb3c72e902f8bfd39a0e9e25c305d342', d: "M21.295 13.844l-7.553-4.361m27.465 15.858l-7.553-4.361" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-lead-generation"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconLeadGeneration$1;},KsIconLeadGeneration$1 = GetKsIconLeadGeneration$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-lead-generation"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-lead-generation":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconLeadGeneration$1(transTagName));
        }
        break;
    }});
}

const KsIconLeadGeneration = KsIconLeadGeneration$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconLeadGeneration, defineCustomElement };
//# sourceMappingURL=ks-icon-lead-generation.js.map
//# sourceMappingURL=ks-icon-lead-generation.js.map