import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconSelectDirectional$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconSelectDirectional$1 =

    proxyCustomElement(class KsIconSelectDirectional extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-select-directional';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '2a261fc0e6634bd341fd21ddcbf406bae689210d', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'c74566109dc0d37379e3c874a9d115b0e0c0355c', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'dedd5ee486e9fd6e4196b79e43a68e6e113b019d', d: "M42.0742 35.3853L34.1231 42.08L26.044 35.3853M34.123 40.6155L34.123 23.0402M6.18848 12.4559L14.1396 5.76123L22.2187 12.4559M14.1396 7.22575L14.1396 24.801", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-select-directional"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconSelectDirectional$1;},KsIconSelectDirectional$1 = GetKsIconSelectDirectional$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-select-directional"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-select-directional":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconSelectDirectional$1(transTagName));
        }
        break;
    }});
}

const KsIconSelectDirectional = KsIconSelectDirectional$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconSelectDirectional, defineCustomElement };
//# sourceMappingURL=ks-icon-select-directional.js.map
//# sourceMappingURL=ks-icon-select-directional.js.map