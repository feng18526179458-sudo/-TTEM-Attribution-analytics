import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconSmartPlus$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconSmartPlus$1 =

    proxyCustomElement(class KsIconSmartPlus extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-smart-plus';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '9793addd9d5de96d3242f548ea3a79c9d39852b1', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'c756d6671388c44104298a571e26bd5f18f9262c', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("g", { key: '347b98a6de03e7e966a4388fda8b5a379e3d2dd2', "clip-path": "url(#A)", fill: icon.color }, h("path", { key: 'a34d597a4568dbf8d3a0d8c1d2f7d661b86c0de2', d: "M24.003 10.271c1.868 0 1.561 6.276 4.5 9.225 2.945 2.942 9.215 2.635 9.215 4.505s-6.269 1.563-9.215 4.505c-2.939 2.949-2.632 9.225-4.5 9.225s-1.561-6.276-4.5-9.225c-2.945-2.942-9.215-2.635-9.215-4.504s6.269-1.563 9.215-4.504c2.939-2.949 2.632-9.225 4.5-9.225z" }), h("g", { key: '8f9364546ec46491f85742d7598110b609a919ec', "fill-rule": "evenodd" }, h("path", { key: 'a793bd2130750e98134246520e37d9c1e250c570', d: "M24.001 3.427c6.794 0 12.821 3.28 16.587 8.349.564.76 1.638.919 2.398.354s.919-1.638.354-2.398C38.956 3.829 31.925-.001 24.001-.001S9.046 3.829 4.661 9.732c-.565.76-.406 1.834.354 2.398s1.834.406 2.398-.354C11.178 6.706 17.206 3.427 24 3.427zm0 41.146c6.794 0 12.821-3.279 16.587-8.349.564-.76 1.638-.919 2.398-.354s.919 1.638.354 2.398c-4.385 5.903-11.415 9.734-19.339 9.734s-14.955-3.83-19.339-9.733c-.565-.76-.406-1.834.354-2.398s1.834-.406 2.398.354c3.765 5.07 9.793 8.349 16.587 8.349z" }))), h("defs", { key: '5c2221e1c5021c3dd529cb4d671dcc595fa6e6e0' }, h("clipPath", { key: '509f45d0d702816ce0212c86243ebfeaef372636', id: "A" }, h("path", { key: '9dcf71610da8fa29d9b7a875a492e2a86f0c8263', fill: "#fff", d: "M0 0h48v48H0z" })))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-smart-plus"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconSmartPlus$1;},KsIconSmartPlus$1 = GetKsIconSmartPlus$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-smart-plus"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-smart-plus":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconSmartPlus$1(transTagName));
        }
        break;
    }});
}

const KsIconSmartPlus = KsIconSmartPlus$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconSmartPlus, defineCustomElement };
//# sourceMappingURL=ks-icon-smart-plus.js.map
//# sourceMappingURL=ks-icon-smart-plus.js.map