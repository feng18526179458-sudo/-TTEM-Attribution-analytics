import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconAddressSymbol$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconAddressSymbol$1 =

    proxyCustomElement(class KsIconAddressSymbol extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-address-symbol';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'eb41a22d8845b99fc32b7c64522e56b52b0dbd5b', class: "ks-icon", "ks-icon": true }, h("svg", { key: '433c7889c6068b3ea7f5355e567cca6d52f43ede', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '66922580dfe78c27246140b9f8748be66721cde0', d: "M30.91 28.316a8.52 8.52 0 0 0 1.483-4.815c0-4.758-3.89-8.615-8.689-8.615s-8.689 3.857-8.689 8.615 3.89 8.615 8.689 8.615a8.7 8.7 0 0 0 7.206-3.8zm0 0c.521.796 1.483 1.621 1.483 1.621m0 13.647h-6.965c-11.141 0-20.172-8.954-20.172-20v-1.162c0-10.404 8.507-18.838 19-18.838s19 8.511 19 18.915c0 3.776-1.124 8.189-4.909 8.615-1.812.204-4.275-.188-5.954-1.176m0 0V14.887", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-address-symbol"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconAddressSymbol$1;},KsIconAddressSymbol$1 = GetKsIconAddressSymbol$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-address-symbol"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-address-symbol":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconAddressSymbol$1(transTagName));
        }
        break;
    }});
}

const KsIconAddressSymbol = KsIconAddressSymbol$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconAddressSymbol, defineCustomElement };
//# sourceMappingURL=ks-icon-address-symbol.js.map
//# sourceMappingURL=ks-icon-address-symbol.js.map