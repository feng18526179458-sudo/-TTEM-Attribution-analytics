import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconViewReport$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconViewReport$1 =

    proxyCustomElement(class KsIconViewReport extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-view-report';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '32a9907612a72f7a25f57f8c6a8e5daef371a29a', class: "ks-icon", "ks-icon": true }, h("svg", { key: '12333afc43fa258fe246432873a1618b3f56b280', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'f864aa9bf0c3856992acbd4e665603c991027cef', d: "M16.3532 39.9683H24.0032H39.3032C40.7943 39.9683 42.0032 38.6846 42.0032 37.1012V10.3419C42.0032 8.75842 40.7943 7.47479 39.3032 7.47479H8.70317C7.212 7.47479 6.00317 8.75842 6.00317 10.3419V23.7215V30.4114", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '655b2fcb45327e7949ff0cf302accd207ebdb52e', d: "M31.9851 23.7216L25.0271 30.6796L21.6178 27.4252L8.51781 40.5252", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("line", { key: '4efd8dca5d41d1a5346e86f3032c0b8c7a789315', x1: "6.69019", y1: "18.1671", x2: "41.3098", y2: "18.1671", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-view-report"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconViewReport$1;},KsIconViewReport$1 = GetKsIconViewReport$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-view-report"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-view-report":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconViewReport$1(transTagName));
        }
        break;
    }});
}

const KsIconViewReport = KsIconViewReport$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconViewReport, defineCustomElement };
//# sourceMappingURL=ks-icon-view-report.js.map
//# sourceMappingURL=ks-icon-view-report.js.map