import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconAddSection$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconAddSection$1 =

    proxyCustomElement(class KsIconAddSection extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-add-section';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '07c723307e72aaeffcea81d611f714dde9ef1633', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'f70f145cf590f700f26b34a8592c946819e4c01d', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("g", { key: '5912aaca13e7bfd9c2f559d8eb18fa66e36b8c68', "stroke-linecap": "round", "stroke-linejoin": "round" }, h("path", { key: '02cc063c0eb776aabf5f2550b70ec63f13d419da', d: "M12.185 23.999h24" }), h("path", { key: 'e1cd5e3f953ce674492bef66a0bd463ebc7b72a7', d: "M24.187 12v24" })), h("rect", { key: 'e7214fa9f7d39e28e3e7f6939778cf52e65dcd32', x: "4.687", y: "4.514", width: "39", height: "39", rx: "1.5" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-add-section"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconAddSection$1;},KsIconAddSection$1 = GetKsIconAddSection$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-add-section"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-add-section":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconAddSection$1(transTagName));
        }
        break;
    }});
}

const KsIconAddSection = KsIconAddSection$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconAddSection, defineCustomElement };
//# sourceMappingURL=ks-icon-add-section.js.map
//# sourceMappingURL=ks-icon-add-section.js.map