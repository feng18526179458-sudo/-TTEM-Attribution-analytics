import type { Components, JSX } from "../dist/types/components";

interface KsIconColoredSamsung extends Components.KsIconColoredSamsung, HTMLElement {}
export const KsIconColoredSamsung: {
    prototype: KsIconColoredSamsung;
    new (): KsIconColoredSamsung;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
