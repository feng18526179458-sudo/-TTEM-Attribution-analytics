import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconColoredWord$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconColoredWord$1 =

    proxyCustomElement(class KsIconColoredWord extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-colored-word';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '60f473a4c0befaa9332c316fe9c98832f21f2443', class: "ks-icon", "ks-icon": true }, h("svg", { key: '8a4c954ad65b40f5dbd8ca1a70aa64c04448f29f', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("rect", { key: 'becb0a7fc34d7f24e970878768da42bdffb85e04', width: "48", height: "48", rx: "1.556", fill: "#224bdd" }), h("path", { key: '2fe0f26b08cec0dc0bc2953bcc9636790a1d9e75', d: "M31.69 34.667c.13 0 .245-.087.281-.212l5.914-20.761c.053-.186-.087-.371-.281-.371h-4.472c-.135 0-.252.092-.283.223l-3.69 15.201-3.975-15.206c-.034-.128-.149-.218-.282-.218h-3.102c-.132 0-.248.089-.282.217L17.51 28.747l-3.69-15.201c-.032-.131-.149-.223-.284-.223H9.065c-.194 0-.334.186-.28.372l5.945 20.761c.036.125.15.211.28.211h4.385c.134 0 .25-.091.283-.22l3.656-14.436 3.688 14.437c.033.129.149.219.283.219h4.385z", fill: "#fff" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-colored-word"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconColoredWord$1;},KsIconColoredWord$1 = GetKsIconColoredWord$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-colored-word"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-colored-word":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconColoredWord$1(transTagName));
        }
        break;
    }});
}

const KsIconColoredWord = KsIconColoredWord$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconColoredWord, defineCustomElement };
//# sourceMappingURL=ks-icon-colored-word.js.map
//# sourceMappingURL=ks-icon-colored-word.js.map