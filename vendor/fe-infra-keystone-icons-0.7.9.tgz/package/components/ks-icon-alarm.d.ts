import type { Components, JSX } from "../dist/types/components";

interface KsIconAlarm extends Components.KsIconAlarm, HTMLElement {}
export const KsIconAlarm: {
    prototype: KsIconAlarm;
    new (): KsIconAlarm;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
