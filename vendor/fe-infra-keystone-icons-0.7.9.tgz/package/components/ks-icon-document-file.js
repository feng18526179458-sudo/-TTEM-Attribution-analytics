import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconDocumentFile$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconDocumentFile$1 =

    proxyCustomElement(class KsIconDocumentFile extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-document-file';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '59351eb5d9ca189b3f26d6dfad89c897bcae714b', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: '7a2904d0efa78dcc5fc8628223a8e1dceabdd840', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("g", { key: 'e1fc1c4ffd012b2d94b6ce4356b4d64966bee850', stroke: icon.color, "stroke-width": icon.strokeWidth }, h("rect", { key: 'ee4a3ea3fd44789d4bf263e329bf96e63b5a3475', x: "6.719", y: "7.515", width: "9", height: "33", rx: "1.5" }), h("rect", { key: '40f527042eb8dc9c669dc8585787ab4daf218e02', x: "15.719", y: "7.515", width: "9", height: "33", rx: "1.5" }), h("path", { key: 'a87548be44690fbf1019fffd1c26dc5488bd8d9b', d: "M27.77 10.69a1.5 1.5 0 0 1 1.061-1.837L34.627 7.3a1.5 1.5 0 0 1 1.837 1.061l7.765 28.978a1.5 1.5 0 0 1-1.061 1.837l-5.795 1.553a1.5 1.5 0 0 1-1.837-1.061L27.77 10.69z" })), h("g", { key: 'af529652c691ed1f8955a210d2592bec12e920be', fill: icon.color }, h("circle", { key: '03126cba90b0e4f92209a47dad29d9f3b2d664ff', cx: "11.219", cy: "16.515", r: "1.5" }), h("circle", { key: 'a6012c26467dea0176fdbbd863aae1358f33b6e9', cx: "20.219", cy: "16.515", r: "1.5" }), h("circle", { key: '2ac730b67f1c41f061ad3f9922c0dae020230403', cx: "33.973", cy: "16.515", r: "1.5" }))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-document-file"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconDocumentFile$1;},KsIconDocumentFile$1 = GetKsIconDocumentFile$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-document-file"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-document-file":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconDocumentFile$1(transTagName));
        }
        break;
    }});
}

const KsIconDocumentFile = KsIconDocumentFile$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconDocumentFile, defineCustomElement };
//# sourceMappingURL=ks-icon-document-file.js.map
//# sourceMappingURL=ks-icon-document-file.js.map