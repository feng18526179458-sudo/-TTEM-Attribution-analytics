import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconColoredCode$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconColoredCode$1 =

    proxyCustomElement(class KsIconColoredCode extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-colored-code';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'f5fc99b5d56ef5fe6fcffdb10d4c6fb788b139e8', class: "ks-icon", "ks-icon": true }, h("svg", { key: '1c527a8b1e74de6ff359e5d3a6849bc390db28c2', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("rect", { key: '7a02bb26ffc58f2db7544f33628b97c287495798', width: "48", height: "48", rx: "1.556", fill: "#464f6f" }), h("path", { key: 'e020acc76054e9ea31e2dfc811eedb2da01fca76', "fill-rule": "evenodd", d: "M22.7 34.953c.153.051.318-.032.369-.184l6.482-19.447c.051-.153-.032-.318-.184-.369l-3.241-1.081c-.153-.051-.318.032-.369.184l-6.482 19.447c-.051.153.032.318.184.369l3.241 1.08zm17.381-9.539l-6.46 6.46c-.114.114-.299.114-.413 0l-2.416-2.416c-.114-.114-.114-.299 0-.413L35.839 24l-5.046-5.046c-.114-.114-.114-.299 0-.412l2.416-2.416c.114-.114.299-.114.413 0l6.46 6.461.795.796c.342.342.342.896 0 1.237l-.795.796zM7.919 22.586l6.46-6.46c.114-.114.299-.114.413 0l2.416 2.416c.114.114.114.299 0 .412L12.162 24l5.046 5.046c.114.114.114.299 0 .413l-2.416 2.416c-.114.114-.299.114-.413 0l-6.46-6.46-.795-.796c-.342-.342-.342-.896 0-1.237l.795-.796z", fill: "#fff" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-colored-code"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconColoredCode$1;},KsIconColoredCode$1 = GetKsIconColoredCode$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-colored-code"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-colored-code":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconColoredCode$1(transTagName));
        }
        break;
    }});
}

const KsIconColoredCode = KsIconColoredCode$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconColoredCode, defineCustomElement };
//# sourceMappingURL=ks-icon-colored-code.js.map
//# sourceMappingURL=ks-icon-colored-code.js.map