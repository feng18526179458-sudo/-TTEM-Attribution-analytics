import type { Components, JSX } from "../dist/types/components";

interface KsIconCar extends Components.KsIconCar, HTMLElement {}
export const KsIconCar: {
    prototype: KsIconCar;
    new (): KsIconCar;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
