import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconCheckMark$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconCheckMark$1 =

    proxyCustomElement(class KsIconCheckMark extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-check-mark';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'fb1d4b291685162e49921b05095229c81c9ae260', class: "ks-icon", "ks-icon": true }, h("svg", { key: '7892bd526148e42ef06d28a635e5688993ebe0db', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '2f734941b02fe204dcee2a4a11134b026acc5910', d: "M6 25.667L17.077 39 42 9", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-check-mark"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconCheckMark$1;},KsIconCheckMark$1 = GetKsIconCheckMark$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-check-mark"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-check-mark":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconCheckMark$1(transTagName));
        }
        break;
    }});
}

const KsIconCheckMark = KsIconCheckMark$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconCheckMark, defineCustomElement };
//# sourceMappingURL=ks-icon-check-mark.js.map
//# sourceMappingURL=ks-icon-check-mark.js.map