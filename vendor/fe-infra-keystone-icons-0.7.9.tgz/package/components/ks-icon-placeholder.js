import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconPlaceholder$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconPlaceholder$1 =

    proxyCustomElement(class KsIconPlaceholder extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-placeholder';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '678d153becd570d42f88eae4285562822807c324', class: "ks-icon", "ks-icon": true }, h("svg", { key: '28c5138d4b0c32bf4388741bda3651c4db457a66', width: icon.width, height: icon.height, viewBox: "0 0 49 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("rect", { key: '01b7a698ece78fbb19aae6b93dc4e15e8eec1828', x: "5.718", y: "5.5", width: "37", height: "37", rx: "3", stroke: icon.color, "stroke-width": icon.strokeWidth }), h("path", { key: 'bff09f9b0a9a7ba6d27a98ffbd337ffae8dac6c1', d: "M7.71962 7.11621L40.717 40.8838", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: 'aa611bdba093115bcf9334fcca3f775152e4caa4', d: "M41.1018 7.50113L7.3342 40.4986", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-placeholder"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconPlaceholder$1;},KsIconPlaceholder$1 = GetKsIconPlaceholder$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-placeholder"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-placeholder":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconPlaceholder$1(transTagName));
        }
        break;
    }});
}

const KsIconPlaceholder = KsIconPlaceholder$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconPlaceholder, defineCustomElement };
//# sourceMappingURL=ks-icon-placeholder.js.map
//# sourceMappingURL=ks-icon-placeholder.js.map