import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconAllApps$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconAllApps$1 =

    proxyCustomElement(class KsIconAllApps extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-all-apps';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'e087fb469db80c84181da8888ba0eb00dadfa032', class: "ks-icon", "ks-icon": true }, h("svg", { key: '0bd287f4c0ee60120b8a31da1a8532b0557d7c60', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'c585fc7c10a36a4429fbd4fcc63f2c28563938a3', d: "M23.5386 4.50336L40.9351 12.5268L23.5386 20.5502C23.5342 20.5522 23.5266 20.5541 23.5171 20.5541C23.5075 20.5541 23.5 20.5522 23.4956 20.5502L6.09912 12.5268L23.4956 4.50336C23.4999 4.50136 23.5074 4.49947 23.5171 4.49945C23.5267 4.49945 23.5342 4.50138 23.5386 4.50336Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" }), h("path", { key: 'eb888e799b9ea80a493e37b7b6a1c93df6fbc983', d: "M5.98767 18.0003C5.98984 18.0007 5.99515 18.0013 6.0033 18.0052L20.9818 25.1927V43.265C20.9799 43.265 20.9779 43.2653 20.976 43.265C20.9735 43.2645 20.9685 43.2628 20.9603 43.2591L5.98181 36.4827V17.9993C5.98389 17.9993 5.9857 17.9999 5.98767 18.0003Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" }), h("path", { key: 'e4b5cde0beb39c83c073bb25cb0dae5204f4f9fc', d: "M41.981 36.4828L27.0024 43.2592C26.9941 43.263 26.9882 43.2647 26.9858 43.2651C26.9842 43.2653 26.9826 43.2651 26.981 43.2651V25.1928L41.9585 18.0053C41.9664 18.0015 41.9717 18.0009 41.9741 18.0004C41.9763 18 41.9787 17.9994 41.981 17.9995V36.4828Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-all-apps"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconAllApps$1;},KsIconAllApps$1 = GetKsIconAllApps$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-all-apps"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-all-apps":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconAllApps$1(transTagName));
        }
        break;
    }});
}

const KsIconAllApps = KsIconAllApps$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconAllApps, defineCustomElement };
//# sourceMappingURL=ks-icon-all-apps.js.map
//# sourceMappingURL=ks-icon-all-apps.js.map