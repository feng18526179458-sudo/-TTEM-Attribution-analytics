import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconImageCollection$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconImageCollection$1 =

    proxyCustomElement(class KsIconImageCollection extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-image-collection';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '61251109936fc7114ca4e78ce431133a8b542141', class: "ks-icon", "ks-icon": true }, h("svg", { key: '14c23f7e4d1c1f1cf85c809fe09e7281f1338731', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("rect", { key: '6b7095bf7b5043c1520c44b3ed4a482521aa4395', x: "3.49937", y: "7.50049", width: "35.0009", height: "26.8388", rx: "1.5", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: '4cd8c0f4ee3e08de5c032be6d599cf28b80fd35b', d: "M4.70895 33.1456L22.3306 15.4951C23.4575 14.3664 25.3099 14.4479 26.3333 15.6712L37.6552 29.205", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("circle", { key: '86ff79c39dd75cd4c39fe920d2a1a7a6fec8030f', cx: "11.4907", cy: "14.4719", r: "2.71435", fill: icon.color }), h("path", { key: '34406ac99c79533f5130d62df94697261d2a5d26', d: "M17.0664 40.5009H41.8464C43.4156 40.5009 44.6878 39.2288 44.6878 37.6595V20.2595", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-image-collection"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconImageCollection$1;},KsIconImageCollection$1 = GetKsIconImageCollection$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-image-collection"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-image-collection":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconImageCollection$1(transTagName));
        }
        break;
    }});
}

const KsIconImageCollection = KsIconImageCollection$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconImageCollection, defineCustomElement };
//# sourceMappingURL=ks-icon-image-collection.js.map
//# sourceMappingURL=ks-icon-image-collection.js.map