import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconAccountHealth$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconAccountHealth$1 =

    proxyCustomElement(class KsIconAccountHealth extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-account-health';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'e3683b1f683869e2779626a0917c5bab1d6f0454', class: "ks-icon", "ks-icon": true }, h("svg", { key: '55d949f7c9d78e7bf0123415adcfac1193c488ac', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: '96884523ed39de13b6c89230c949d37f7fdd5618', d: "M22.839 10.513l1.169 1.048 1.168-1.049c4.246-3.811 10.81-3.683 14.898.414h0a10.85 10.85 0 0 1 .46 14.856l-15.645 15.67a1.25 1.25 0 0 1-1.769 0L7.475 25.783a10.85 10.85 0 0 1 15.364-15.27z" }), h("path", { key: 'ea3c02c924123ce7e0b3557670ed96d6e067b738', d: "M14.766 24.561h5.419l3.663-5.657 2.351 8.707 2.147-3.731h4.481", "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-account-health"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconAccountHealth$1;},KsIconAccountHealth$1 = GetKsIconAccountHealth$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-account-health"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-account-health":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconAccountHealth$1(transTagName));
        }
        break;
    }});
}

const KsIconAccountHealth = KsIconAccountHealth$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconAccountHealth, defineCustomElement };
//# sourceMappingURL=ks-icon-account-health.js.map
//# sourceMappingURL=ks-icon-account-health.js.map