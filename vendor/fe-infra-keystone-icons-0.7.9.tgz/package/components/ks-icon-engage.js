import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconEngage$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconEngage$1 =

    proxyCustomElement(class KsIconEngage extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-engage';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '73ed8d7ce363878b87b54cfddc1444723c4009db', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: 'be2987476320ad5b9231ffc6c7921ee4765c7c4c', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: '670c021c6a7f0e1fcd6e75f96301f8a894f12e9c', d: "M21.097 7.518a17.09 17.09 0 0 0-2.582.483 16.93 16.93 0 0 0-10.311 7.912 17.25 17.25 0 0 0-.381.696m10.648-2.692l3.895-6.747m-6.745-3.896l6.747 3.895m6.034 31.813c.864-.094 1.727-.254 2.582-.483a16.93 16.93 0 0 0 10.311-7.912 17.16 17.16 0 0 0 .381-.696M31.03 32.584l-3.895 6.747m6.747 3.894l-6.747-3.895", "stroke-linecap": "round" }), h("circle", { key: 'cea0856855ac135735436b2a46506c1ab14f42c8', cx: "35.319", cy: "10.991", r: "4.991" }), h("path", { key: '2f98349ad77bed42600448e94b28922daf1325cb', d: "M43.638 24.3a8.32 8.32 0 0 0-8.318-8.318 8.32 8.32 0 0 0-8.318 8.318", "stroke-linecap": "round" }), h("circle", { key: '50c7ce3bf82eac96eedf08af62dbb5df9d401e36', cx: "11.313", cy: "28.991", r: "4.991" }), h("path", { key: 'd94850073e4714b25f354928866efbe01a5e2ccd', d: "M19.633 42.3a8.32 8.32 0 0 0-8.318-8.318A8.32 8.32 0 0 0 2.996 42.3", "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-engage"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconEngage$1;},KsIconEngage$1 = GetKsIconEngage$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-engage"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-engage":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconEngage$1(transTagName));
        }
        break;
    }});
}

const KsIconEngage = KsIconEngage$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconEngage, defineCustomElement };
//# sourceMappingURL=ks-icon-engage.js.map
//# sourceMappingURL=ks-icon-engage.js.map