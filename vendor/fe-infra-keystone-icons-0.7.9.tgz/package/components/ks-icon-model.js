import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconModel$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconModel$1 =

    proxyCustomElement(class KsIconModel extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-model';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '0ce776b15f0c9af430d7009a7beb0c2b6e7ead14', class: "ks-icon", "ks-icon": true }, h("svg", { key: '0ecb84da89085c6c7ec96adf3310168e12f747c4', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("g", { key: 'b7fd9042e3d904018a8bdbb9a583efe895ef9358', "clip-path": "url(#A)" }, h("circle", { key: 'e99f6d0fbbbb7b2b33742a97597f66729a7b5eb1', cx: "24", cy: "24", r: "22.5", stroke: icon.color, "stroke-width": icon.strokeWidth }), h("g", { key: 'c8623553ed6e97b90d4b7ca57edd4f19b8bc86e0', fill: icon.color }, h("path", { key: '7486904fc521a02e165aa486bc3e50ddff2f7dc6', "fill-rule": "evenodd", d: "M21.643 10.415c-4.155 0-7.524 3.368-7.524 7.524 0 2.153.905 4.095 2.354 5.466-3.721 1.888-6.273 5.751-6.273 10.211 0 .908.736 1.645 1.645 1.645s1.645-.736 1.645-1.645c0-4.503 3.65-8.153 8.153-8.153s8.153 3.65 8.153 8.153c0 .908.736 1.645 1.645 1.645s1.645-.736 1.645-1.645c0-4.46-2.552-8.323-6.273-10.211 1.449-1.371 2.354-3.313 2.354-5.466 0-4.155-3.368-7.524-7.523-7.524zm-4.234 7.524c0-2.339 1.896-4.234 4.234-4.234s4.234 1.896 4.234 4.234-1.896 4.234-4.234 4.234-4.234-1.896-4.234-4.234z" }), h("path", { key: '163f1b2d08a57f97c8f489471c1e8cf334f0d2df', d: "M32.271 11.836c-.654-.63-1.695-.611-2.326.043s-.611 1.695.043 2.326c.88.848 1.456 2.104 1.456 3.534 0 1.419-.568 2.668-1.437 3.516a1.64 1.64 0 0 0-.228.264l-.032.047c-.23.356-.309.78-.237 1.182.041.229.13.45.269.649a1.64 1.64 0 0 0 .411.411c.097.068.2.124.307.168 2.948 1.299 5.108 4.47 5.108 8.263 0 .908.736 1.645 1.645 1.645s1.645-.736 1.645-1.645c0-4.288-2.084-8.106-5.294-10.288.722-1.229 1.133-2.675 1.133-4.212 0-2.32-.937-4.432-2.463-5.902z" }))), h("defs", { key: '68f5fddbb2541b2582453460826992b81b02186e' }, h("clipPath", { key: '6d6f27692fcecefe4c36ccec55fbf14f3edabef2', id: "A" }, h("path", { key: '479c5b80fe9b225734790e017f2cb0b5cee828a3', fill: "#fff", d: "M0 0h48v48H0z" })))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-model"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconModel$1;},KsIconModel$1 = GetKsIconModel$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-model"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-model":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconModel$1(transTagName));
        }
        break;
    }});
}

const KsIconModel = KsIconModel$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconModel, defineCustomElement };
//# sourceMappingURL=ks-icon-model.js.map
//# sourceMappingURL=ks-icon-model.js.map