import type { Components, JSX } from "../dist/types/components";

interface KsIconCaseSensitive extends Components.KsIconCaseSensitive, HTMLElement {}
export const KsIconCaseSensitive: {
    prototype: KsIconCaseSensitive;
    new (): KsIconCaseSensitive;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
