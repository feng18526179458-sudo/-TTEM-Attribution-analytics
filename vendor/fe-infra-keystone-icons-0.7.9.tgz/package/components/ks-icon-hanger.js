import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconHanger$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconHanger$1 =

    proxyCustomElement(class KsIconHanger extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-hanger';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'cfde43154e569b0819f02feafc063b515e3be613', class: "ks-icon", "ks-icon": true }, h("svg", { key: '20bdd007f157c1cdb0e8245fa10421fb35221c34', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'bfd203d1ac407d73712c1b64645ab060e6fbe042', d: "M16.48 14.215c0-8.333 14.529-8.367 14.529 0v1.854a5.97 5.97 0 0 1-2.841 5.084l-1.655 1.018c-1.522.937-2.448 2.596-2.448 4.383m0 0L3.398 42.73h41.483L24.064 26.554z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: 'ec07ec86ec85a97abdb56136a0a5b88bcb9269a8', d: "M40.203 2.365c-.276-.955-.491-1.704-.971-1.704s-.695.749-.971 1.704c-.296 1.026-.661 2.291-1.495 3.122s-2.096 1.199-3.122 1.495c-.955.275-1.704.491-1.704.971s.749.695 1.704.971c1.026.296 2.291.661 3.122 1.495s1.199 2.096 1.495 3.122c.276.955.491 1.704.971 1.704s.695-.748.971-1.704c.296-1.026.661-2.291 1.495-3.122s2.096-1.199 3.122-1.495c.955-.275 1.704-.491 1.704-.971s-.748-.695-1.704-.971c-1.026-.296-2.291-.661-3.122-1.495s-1.199-2.096-1.495-3.122z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-hanger"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconHanger$1;},KsIconHanger$1 = GetKsIconHanger$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-hanger"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-hanger":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconHanger$1(transTagName));
        }
        break;
    }});
}

const KsIconHanger = KsIconHanger$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconHanger, defineCustomElement };
//# sourceMappingURL=ks-icon-hanger.js.map
//# sourceMappingURL=ks-icon-hanger.js.map