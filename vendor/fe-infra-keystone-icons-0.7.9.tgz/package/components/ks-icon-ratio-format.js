import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconRatioFormat$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconRatioFormat$1 =

    proxyCustomElement(class KsIconRatioFormat extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-ratio-format';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'a6d483824ab225313bb0f1030d4b51e34955149c', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'ae41f258a3d51fd33a123955dd0d7a6dcdab3b82', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("rect", { key: '58da4b8170957accaae5245832058e3b37ee2a46', x: "4", y: "9.02496", width: "40", height: "29.9501", rx: "3", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '3b44b9f4f7c7b079b216a42819a3d90055fc2347', d: "M25.0826 18.6082C25.0826 19.2295 24.579 19.7332 23.9576 19.7332C23.3363 19.7332 22.8326 19.2295 22.8326 18.6082C22.8326 17.9868 23.3363 17.4832 23.9576 17.4832C24.579 17.4832 25.0826 17.9868 25.0826 18.6082Z", fill: icon.color, stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '1c9a1c6af78b46cb3d4b4776a64b8bb6d5fc173d', d: "M25.0826 29.8582C25.0826 30.4795 24.579 30.9832 23.9576 30.9832C23.3363 30.9832 22.8326 30.4795 22.8326 29.8582C22.8326 29.2368 23.3363 28.7332 23.9576 28.7332C24.579 28.7332 25.0826 29.2368 25.0826 29.8582Z", fill: icon.color, stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '8d4b9206a6c8e7edf89575d6fb6ff8247c6d4bd2', d: "M13.6274 31.7975L13.6274 16.2024L10.0613 19.2719", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: 'd13b99206627ce7362a844711a40583279e0d5e6', d: "M36.748 31.7975L36.748 16.2024L33.1819 19.2719", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-ratio-format"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconRatioFormat$1;},KsIconRatioFormat$1 = GetKsIconRatioFormat$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-ratio-format"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-ratio-format":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconRatioFormat$1(transTagName));
        }
        break;
    }});
}

const KsIconRatioFormat = KsIconRatioFormat$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconRatioFormat, defineCustomElement };
//# sourceMappingURL=ks-icon-ratio-format.js.map
//# sourceMappingURL=ks-icon-ratio-format.js.map