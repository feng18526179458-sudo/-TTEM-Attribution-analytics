import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconColoredWhatsapp$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconColoredWhatsapp$1 =

    proxyCustomElement(class KsIconColoredWhatsapp extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-colored-whatsapp';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '5b62dd48b98aba09e4c2824c432fb4f86e5a6578', class: "ks-icon", "ks-icon": true }, h("svg", { key: '2388ebc22db3750539d9f319101f405158921908', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("rect", { key: 'c35839a5d16cb12ba6d376cf5cfbae0034c8494f', width: "48", height: "48", rx: "8", fill: "#25D366" }), h("path", { key: '5ee651c9da4760f3abdab389d444cc34e5088bd3', "fill-rule": "evenodd", "clip-rule": "evenodd", d: "M29.9564 26.5807C29.6329 26.4195 28.0426 25.6409 27.7461 25.5333C27.4497 25.4259 27.234 25.3722 27.0184 25.6944C26.8027 26.0166 26.1828 26.7418 25.9941 26.9567C25.8055 27.1715 25.6168 27.1985 25.2933 27.0372C24.9698 26.8761 23.9276 26.5362 22.6921 25.4394C21.7305 24.5858 21.0813 23.5317 20.8927 23.2094C20.7039 22.8871 20.8725 22.7129 21.0344 22.5524C21.18 22.4081 21.358 22.1763 21.5197 21.9883C21.6814 21.8004 21.7353 21.666 21.8431 21.4513C21.9509 21.2364 21.897 21.0485 21.8161 20.8874C21.7353 20.7262 21.0884 19.1416 20.8188 18.497C20.5563 17.8694 20.2896 17.9544 20.091 17.9444C19.9026 17.9351 19.6867 17.9331 19.4711 17.9331C19.2555 17.9331 18.905 18.0137 18.6084 18.3359C18.312 18.6582 17.4764 19.4371 17.4764 21.0215C17.4764 22.6061 18.6354 24.1368 18.7972 24.3516C18.959 24.5666 21.078 27.8181 24.323 29.2125C25.0947 29.5443 25.6972 29.7423 26.167 29.8906C26.9418 30.1357 27.647 30.1011 28.2044 30.0182C28.8258 29.9258 30.1181 29.2395 30.3877 28.4876C30.6572 27.7355 30.6572 27.0909 30.5763 26.9567C30.4955 26.8224 30.2799 26.7418 29.9564 26.5807ZM24.0544 34.6007C21.9388 34.6007 19.9845 33.9417 18.1806 32.876L14.1082 33.9392L15.1952 29.9876C14.0225 28.1299 13.2933 26.1052 13.2943 23.8836C13.2966 17.9795 18.1236 13.176 24.0587 13.176C29.9041 13.1781 34.8165 18.0327 34.8143 23.8922C34.8118 29.7969 29.985 34.6007 24.0544 34.6007ZM24.0543 11C16.9188 11 11.1114 16.7793 11.1085 23.8828C11.1075 26.1535 11.7036 28.3699 12.8365 30.3238L11 37L17.8626 35.2084C19.7536 36.2348 21.8825 36.7758 24.0491 36.7765C31.0974 36.7765 36.9971 30.9083 37 23.8931C37.0027 16.8392 31.0891 11.0028 24.0543 11Z", fill: "white" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-colored-whatsapp"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconColoredWhatsapp$1;},KsIconColoredWhatsapp$1 = GetKsIconColoredWhatsapp$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-colored-whatsapp"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-colored-whatsapp":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconColoredWhatsapp$1(transTagName));
        }
        break;
    }});
}

const KsIconColoredWhatsapp = KsIconColoredWhatsapp$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconColoredWhatsapp, defineCustomElement };
//# sourceMappingURL=ks-icon-colored-whatsapp.js.map
//# sourceMappingURL=ks-icon-colored-whatsapp.js.map