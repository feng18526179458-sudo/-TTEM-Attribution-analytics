import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconDoubleChevronLeft$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconDoubleChevronLeft$1 =

    proxyCustomElement(class KsIconDoubleChevronLeft extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-double-chevron-left';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'dc8699a15d80df10ba3d34cb845a0630036a4620', class: "ks-icon", "ks-icon": true }, h("svg", { key: '19f16faa959e21904d44753d6d32c99a15ad735c', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }, h("path", { key: '193febb9749170c328b7a998991498ab5d694743', d: "M23.996 9.014l-12 15 12 15m12.003-30l-12 15 12 15" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-double-chevron-left"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconDoubleChevronLeft$1;},KsIconDoubleChevronLeft$1 = GetKsIconDoubleChevronLeft$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-double-chevron-left"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-double-chevron-left":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconDoubleChevronLeft$1(transTagName));
        }
        break;
    }});
}

const KsIconDoubleChevronLeft = KsIconDoubleChevronLeft$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconDoubleChevronLeft, defineCustomElement };
//# sourceMappingURL=ks-icon-double-chevron-left.js.map
//# sourceMappingURL=ks-icon-double-chevron-left.js.map