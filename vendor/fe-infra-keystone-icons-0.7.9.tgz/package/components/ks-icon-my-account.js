import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconMyAccount$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconMyAccount$1 =

    proxyCustomElement(class KsIconMyAccount extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-my-account';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '05ca864fcf228cea279372d3f495cb37d2109937', class: "ks-icon", "ks-icon": true }, h("svg", { key: '73c27f37573472497eebdef01f5a595f37f1f214', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("rect", { key: '9fd2c863323a426abdd30e538fcde59bb4f948f8', x: "4.5", y: "9.24341", width: "39", height: "29.5135", rx: "3", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '0473454f22f40dd09695384fa02681449c47df40', d: "M16.6406 24.6596C18.6184 24.6596 20.2218 23.0562 20.2218 21.0784C20.2218 19.1005 18.6184 17.4972 16.6406 17.4972C14.6627 17.4972 13.0593 19.1005 13.0593 21.0784C13.0593 23.0562 14.6627 24.6596 16.6406 24.6596ZM16.6406 24.6596C13.4132 24.6596 10.7969 27.2759 10.7969 30.5032M16.6406 24.6596C19.8679 24.6596 22.4841 27.2759 22.4841 30.5032", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("line", { key: '9b825e45a6c77893f898ce074139bde67611f49e', x1: "37.0156", y1: "20.3868", x2: "30.0156", y2: "20.3868", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("line", { key: 'e49118e7682d972a864c2f7a5a8d0dfda04f519a', x1: "37.0156", y1: "28.8195", x2: "30.0156", y2: "28.8195", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-my-account"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconMyAccount$1;},KsIconMyAccount$1 = GetKsIconMyAccount$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-my-account"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-my-account":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconMyAccount$1(transTagName));
        }
        break;
    }});
}

const KsIconMyAccount = KsIconMyAccount$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconMyAccount, defineCustomElement };
//# sourceMappingURL=ks-icon-my-account.js.map
//# sourceMappingURL=ks-icon-my-account.js.map