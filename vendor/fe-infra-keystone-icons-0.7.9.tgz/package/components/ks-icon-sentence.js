import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconSentence$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconSentence$1 =

    proxyCustomElement(class KsIconSentence extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-sentence';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'c2f719440d7bd82a280b3ec26ee4fa46d96bc302', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'e6974d017a721cd22424f0fad75402a0982b15cf', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '9f3eb063663b3c634ff8993cd34b89ab74bcd645', d: "M24.1527 36.4402L13.6247 11.3351L4.31152 36.4402M20.3745 27.4307H7.65377", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: '354257452824dee9e737c74b7d0db932368117bf', d: "M38.2371 26.9559H44.3115V30.0095C44.3115 33.6852 41.3093 36.6649 37.606 36.6649H36.6716C33.4843 36.6649 30.9004 34.1004 30.9005 30.9369L30.9005 24.8271C30.9005 18.4604 39.0948 15.795 42.8915 20.9268", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-sentence"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconSentence$1;},KsIconSentence$1 = GetKsIconSentence$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-sentence"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-sentence":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconSentence$1(transTagName));
        }
        break;
    }});
}

const KsIconSentence = KsIconSentence$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconSentence, defineCustomElement };
//# sourceMappingURL=ks-icon-sentence.js.map
//# sourceMappingURL=ks-icon-sentence.js.map