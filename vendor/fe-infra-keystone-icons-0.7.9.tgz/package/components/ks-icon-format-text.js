import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFormatText$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFormatText$1 =

    proxyCustomElement(class KsIconFormatText extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-format-text';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'e52dc6e61d71ada8fbc87ea995709933d3da6ead', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: '070a76aa3410a38cd5a124d6cfcb46bfb6362363', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("g", { key: '076746850486ee94e428af4df3055e3ea7fc37c3', "stroke-linecap": "round", "stroke-linejoin": "round" }, h("path", { key: 'e80217b6f9fb0b458840fa02fd7d96fd50043314', d: "M17.223 21.266V18.74h13.474v2.526m-8.421 12.632h3.369" }), h("path", { key: '85fefc18f13296445af0a3ff9bcbf522c8656da1', d: "M23.96 20.424v13.474" })), h("path", { key: 'f1fed5f7e7575c5e186c955b901ab25624f21e84', d: "M9 5.25a1.5 1.5 0 0 1 1.5-1.5h19.412a1.5 1.5 0 0 1 1.04.419l7.588 7.299a1.5 1.5 0 0 1 .46 1.081V41.25a1.5 1.5 0 0 1-1.5 1.5h-27a1.5 1.5 0 0 1-1.5-1.5v-36z" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-format-text"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFormatText$1;},KsIconFormatText$1 = GetKsIconFormatText$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-format-text"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-format-text":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFormatText$1(transTagName));
        }
        break;
    }});
}

const KsIconFormatText = KsIconFormatText$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFormatText, defineCustomElement };
//# sourceMappingURL=ks-icon-format-text.js.map
//# sourceMappingURL=ks-icon-format-text.js.map