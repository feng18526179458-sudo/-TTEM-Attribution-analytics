import type { Components, JSX } from "../dist/types/components";

interface KsIconApple extends Components.KsIconApple, HTMLElement {}
export const KsIconApple: {
    prototype: KsIconApple;
    new (): KsIconApple;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
