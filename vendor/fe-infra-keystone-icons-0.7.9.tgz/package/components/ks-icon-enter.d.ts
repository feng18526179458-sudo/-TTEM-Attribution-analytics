import type { Components, JSX } from "../dist/types/components";

interface KsIconEnter extends Components.KsIconEnter, HTMLElement {}
export const KsIconEnter: {
    prototype: KsIconEnter;
    new (): KsIconEnter;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
