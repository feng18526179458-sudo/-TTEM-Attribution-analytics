import type { Components, JSX } from "../dist/types/components";

interface KsIconAddressSymbol extends Components.KsIconAddressSymbol, HTMLElement {}
export const KsIconAddressSymbol: {
    prototype: KsIconAddressSymbol;
    new (): KsIconAddressSymbol;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
