import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconDoubleChevronRight$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconDoubleChevronRight$1 =

    proxyCustomElement(class KsIconDoubleChevronRight extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-double-chevron-right';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'd69ab403a1e22ecbc18b47ff66dfe329846041b0', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'a2c822a2684e76b5dee56cc8e7aae5aef44c02d7', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }, h("path", { key: '7091a8899ef635509cf4a56a02cf51756c61082e', d: "M23.997 39.015l12-15-12-15m-12 30l12-15-12-15" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-double-chevron-right"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconDoubleChevronRight$1;},KsIconDoubleChevronRight$1 = GetKsIconDoubleChevronRight$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-double-chevron-right"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-double-chevron-right":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconDoubleChevronRight$1(transTagName));
        }
        break;
    }});
}

const KsIconDoubleChevronRight = KsIconDoubleChevronRight$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconDoubleChevronRight, defineCustomElement };
//# sourceMappingURL=ks-icon-double-chevron-right.js.map
//# sourceMappingURL=ks-icon-double-chevron-right.js.map