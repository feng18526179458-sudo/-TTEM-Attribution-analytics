import type { Components, JSX } from "../dist/types/components";

interface KsIconCoupon extends Components.KsIconCoupon, HTMLElement {}
export const KsIconCoupon: {
    prototype: KsIconCoupon;
    new (): KsIconCoupon;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
