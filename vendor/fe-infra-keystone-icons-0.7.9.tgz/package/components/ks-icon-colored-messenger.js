import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconColoredMessenger$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconColoredMessenger$1 =

    proxyCustomElement(class KsIconColoredMessenger extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-colored-messenger';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'd805fb3c30959539eb32624fa391c83cfbac7fb1', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'ed86d0b1ca3e1e37c7eaa7adeca79d3f251b168e', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("rect", { key: 'd7dec59961fa801320eaec24019a08688aafc8df', width: "48", height: "48", rx: "8", fill: "url(#paint0_radial_2_155)" }), h("path", { key: 'a694477f7f5220e76231e8b1778ea47adff67a86', "fill-rule": "evenodd", "clip-rule": "evenodd", d: "M11 23.6089C11 16.3653 16.6778 11 24 11C31.3222 11 37 16.3685 37 23.6121C37 30.8557 31.3222 36.221 24 36.221C22.6837 36.221 21.4228 36.0455 20.2365 35.7206C20.0057 35.6588 19.7587 35.6751 19.541 35.7726L16.9605 36.91C16.2845 37.2089 15.524 36.728 15.5013 35.9903L15.4297 33.6765C15.4232 33.3905 15.2932 33.124 15.082 32.9356C12.5535 30.6738 11 27.398 11 23.6089ZM19.7573 21.5169L15.6954 26.9683C15.3047 27.4918 16.0653 28.0796 16.646 27.7053L21.0088 24.9035C21.3026 24.7134 21.7106 24.7134 22.0079 24.9006L25.2402 26.9507C26.2116 27.5649 27.5944 27.3514 28.2408 26.4828L32.3063 21.0343C32.6935 20.5108 31.9329 19.9201 31.3521 20.2944L26.9894 23.0961C26.6956 23.2862 26.2876 23.2862 25.9903 23.0991L22.758 21.049C21.7866 20.4348 20.4038 20.6483 19.7573 21.5169Z", fill: "white" }), h("defs", { key: '2b51dee65f44f7824f022e420cc09bf4a7bd1359' }, h("radialGradient", { key: 'effc9486bb783aaeb4bec55b5a34a9269b3e03d4', id: "paint0_radial_2_155", cx: "0", cy: "0", r: "1", gradientUnits: "userSpaceOnUse", gradientTransform: "translate(9.24 47.7344) scale(52.3008 52.2961)" }, h("stop", { key: '5ef98702befba45e9fcebe956963fe46e657efb9', "stop-color": "#0099FF" }), h("stop", { key: '53853c5380dd4853d34192c5f178e4b4762eaefa', offset: "0.6098", "stop-color": "#A033FF" }), h("stop", { key: '5444d414ff0c4e47c711a4643987eb7796c7a03f', offset: "0.9348", "stop-color": "#FF5280" }), h("stop", { key: '34bbe2eac5ed2fdabe03185004dcb74adaca7410', offset: "1", "stop-color": "#FF7061" })))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-colored-messenger"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconColoredMessenger$1;},KsIconColoredMessenger$1 = GetKsIconColoredMessenger$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-colored-messenger"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-colored-messenger":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconColoredMessenger$1(transTagName));
        }
        break;
    }});
}

const KsIconColoredMessenger = KsIconColoredMessenger$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconColoredMessenger, defineCustomElement };
//# sourceMappingURL=ks-icon-colored-messenger.js.map
//# sourceMappingURL=ks-icon-colored-messenger.js.map