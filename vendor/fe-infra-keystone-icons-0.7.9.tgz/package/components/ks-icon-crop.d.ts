import type { Components, JSX } from "../dist/types/components";

interface KsIconCrop extends Components.KsIconCrop, HTMLElement {}
export const KsIconCrop: {
    prototype: KsIconCrop;
    new (): KsIconCrop;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
