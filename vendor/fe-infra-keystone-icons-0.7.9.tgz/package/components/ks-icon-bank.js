import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconBank$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconBank$1 =

    proxyCustomElement(class KsIconBank extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-bank';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '664e5c5ff2c0bb79cb1f6c86291714021667882b', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'ba8b00955016e6a33b6ec16bb7f267a173375163', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '00d3d097aaabb3e5fbd96d557782c20cef7c4e8c', d: "M12 26.0625L12 34.0938", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: 'f79a961ca619c4d812352ab5979bb313abb81c29', d: "M24.0312 26.0625L24.0313 34.0938", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: '3c3cac6c696cbd174ed3637acec04f08283d8887', d: "M36.0625 26.0625L36.0625 34.0938", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: 'fc4dac40c10b9dcdf06cdd2c119c04714f91b35c', d: "M8 40.0625H39.875", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: 'f93ee780f1eeeaf445adfc85e10b4d042c107259', d: "M24 6.64844L40.0156 20.0078L8 20L24 6.64844Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-bank"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconBank$1;},KsIconBank$1 = GetKsIconBank$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-bank"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-bank":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconBank$1(transTagName));
        }
        break;
    }});
}

const KsIconBank = KsIconBank$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconBank, defineCustomElement };
//# sourceMappingURL=ks-icon-bank.js.map
//# sourceMappingURL=ks-icon-bank.js.map