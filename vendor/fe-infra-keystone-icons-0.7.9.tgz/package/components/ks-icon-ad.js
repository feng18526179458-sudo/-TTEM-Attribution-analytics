import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconAd$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconAd$1 =

    proxyCustomElement(class KsIconAd extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-ad';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '0263616a0eaa6c23872a044a5182116528309c81', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'e45c5512b42056ab5638202f9368a91694bbbd42', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'b5b2891a09542c0d849b03393cb84b046acb76d3', d: "M27.43 31.5c-.795 0-1.407-.193-1.835-.58-.413-.401-.619-.974-.619-1.719V17.879c0-.745.206-1.311.619-1.697.428-.401 1.04-.601 1.835-.601h.619V31.5h-.619zm.321-2.793h2.936c1.162 0 2.125-.215 2.89-.645.78-.43 1.353-1.031 1.72-1.805.382-.773.573-1.676.573-2.707 0-1.06-.184-1.976-.55-2.75a3.85 3.85 0 0 0-1.72-1.783c-.764-.43-1.735-.644-2.913-.644h-2.936V15.58h2.936c1.728 0 3.211.365 4.449 1.096 1.254.73 2.202 1.704 2.844 2.922s.963 2.535.963 3.953c0 1.389-.321 2.693-.963 3.91s-1.59 2.199-2.844 2.943c-1.238.73-2.722 1.096-4.449 1.096h-2.936v-2.793zm-5.091 1.096c.168.444.138.838-.092 1.182s-.596.516-1.101.516h-.092c-.505 0-.91-.136-1.216-.408-.29-.287-.535-.702-.734-1.246l-4.449-11.473h1.284l-4.449 11.473c-.214.544-.466.96-.757 1.246-.29.272-.688.408-1.193.408h-.092c-.505 0-.872-.172-1.101-.516s-.26-.738-.092-1.182l5.046-12.976c.336-.831.994-1.246 1.972-1.246h.046c.979 0 1.636.415 1.972 1.246l5.046 12.976zm-3.257-5.178v2.793h-7.568v-2.793h7.568z", fill: icon.color }), h("path", { key: '09bc1230ec91663c761957ed50dafaeb2d2aece7', d: "M6.002 12.041C10.077 6.555 16.606 3 23.965 3s13.888 3.555 17.963 9.041M6.002 35.959C10.077 41.445 16.606 45 23.965 45s13.888-3.555 17.963-9.041", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-ad"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconAd$1;},KsIconAd$1 = GetKsIconAd$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-ad"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-ad":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconAd$1(transTagName));
        }
        break;
    }});
}

const KsIconAd = KsIconAd$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconAd, defineCustomElement };
//# sourceMappingURL=ks-icon-ad.js.map
//# sourceMappingURL=ks-icon-ad.js.map