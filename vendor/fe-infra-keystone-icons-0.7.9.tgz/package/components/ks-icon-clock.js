import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconClock$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconClock$1 =

    proxyCustomElement(class KsIconClock extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-clock';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'f05dcea93d620fc1c51efe7cf7e4a03fd815a505', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'ed222eb9cd2f9f09e642b3e3ed492acf63101fc2', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("circle", { key: '1ad661be7705bcdeeaa81d9bf0ce53426d0e962d', cx: "24", cy: "24", r: "19.5" }), h("path", { key: 'c058021e3381bb5b45360858b3ca025a9cc05b70', d: "M24 12v12l6 6", "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-clock"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconClock$1;},KsIconClock$1 = GetKsIconClock$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-clock"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-clock":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconClock$1(transTagName));
        }
        break;
    }});
}

const KsIconClock = KsIconClock$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconClock, defineCustomElement };
//# sourceMappingURL=ks-icon-clock.js.map
//# sourceMappingURL=ks-icon-clock.js.map