import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconAdsManager$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconAdsManager$1 =

    proxyCustomElement(class KsIconAdsManager extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-ads-manager';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '69b4d006ba2bed3f0104359ecb50a2a07bfa7b11', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'dcb4dd62780b2bad98917a1aed2b0d2038949d3b', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '1cc7e9eaec9586543aa97298fbd9bd03ce1e37a6', d: "M35.822 34.5097V8.88295C35.822 8.18821 35.0559 7.75033 34.435 8.09078C27.3324 11.9854 25.0114 13.6017 18.1567 13.6017V28.2164C24.0455 28.2164 31.1302 32.9508 34.2343 35.2591C34.8698 35.7316 35.822 35.2891 35.822 34.5097Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: 'ba8e853143baf4fc8c74e5b7d82324e8569721b2', d: "M12.822 13.6045H18.1571V28.2134H12.822C8.6861 28.2134 5.33325 24.9431 5.33325 20.909C5.33325 16.8748 8.6861 13.6045 12.822 13.6045Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: 'beae30a303af3d2a829d39130fd86cb7f9c34eb0', d: "M18.4918 28.3416V36.441C18.4918 38.2101 16.897 39.6328 14.9592 39.5924C13.4259 39.5603 12.0993 38.6091 11.7023 37.2569L8.8302 27.4739", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: 'd677e14912bef98bbf7cacd6b50346041452a2e9', d: "M36.1125 27.9339C39.5481 27.9339 42.3332 25.1488 42.3332 21.7132C42.3332 18.2777 39.5481 15.4926 36.1125 15.4926", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-ads-manager"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconAdsManager$1;},KsIconAdsManager$1 = GetKsIconAdsManager$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-ads-manager"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-ads-manager":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconAdsManager$1(transTagName));
        }
        break;
    }});
}

const KsIconAdsManager = KsIconAdsManager$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconAdsManager, defineCustomElement };
//# sourceMappingURL=ks-icon-ads-manager.js.map
//# sourceMappingURL=ks-icon-ads-manager.js.map