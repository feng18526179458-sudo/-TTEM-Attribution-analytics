import type { Components, JSX } from "../dist/types/components";

interface KsIconCoin extends Components.KsIconCoin, HTMLElement {}
export const KsIconCoin: {
    prototype: KsIconCoin;
    new (): KsIconCoin;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
