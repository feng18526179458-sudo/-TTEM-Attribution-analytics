import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconUnlink$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconUnlink$1 =

    proxyCustomElement(class KsIconUnlink extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-unlink';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '74a73fa92a8de8bf700a7e461cdd47b54045a4fe', class: "ks-icon", "ks-icon": true }, h("svg", { key: '38086e7df09b605273cb53df3523e50b3bb51675', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'dfac000a8ea368783b6f01c233c863dc1bc0dc9d', d: "M25.1993 25.5274H25.4853C29.635 25.5274 32.999 22.1634 32.999 18.0137C32.999 13.864 29.635 10.5 25.4853 10.5L10.1042 10.5C6.03019 10.5 2.72754 13.8027 2.72754 17.8767L2.72754 18.0137C2.72754 22.1634 6.09154 25.5274 10.2412 25.5274H10.7722", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: '1fcefa11fdcaff3c25c9d3be3fdba7af20588773', d: "M37.1993 20.9717L37.4853 20.9717C41.635 20.9717 44.999 24.3357 44.999 28.4854C44.999 32.6351 41.635 35.9991 37.4853 35.9991L22.1042 35.9991C18.0302 35.9991 14.7275 32.6964 14.7275 28.6224L14.7275 28.4854C14.7275 24.3357 18.0915 20.9717 22.2412 20.9717L22.7722 20.9717", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: 'dd7646539075b4baa0a49c616c589bd34ade5847', d: "M9.08105 37.3911L39.4121 7.06055", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-unlink"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconUnlink$1;},KsIconUnlink$1 = GetKsIconUnlink$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-unlink"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-unlink":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconUnlink$1(transTagName));
        }
        break;
    }});
}

const KsIconUnlink = KsIconUnlink$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconUnlink, defineCustomElement };
//# sourceMappingURL=ks-icon-unlink.js.map
//# sourceMappingURL=ks-icon-unlink.js.map