import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconChangeUser$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconChangeUser$1 =

    proxyCustomElement(class KsIconChangeUser extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-change-user';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '1f61bd8e1590c6e424b77b84abc629faa8415abc', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: '784aee09f76749742366d8af1675cac7b0c40d8a', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("g", { key: 'f1f864d694ef214c55554fa7e8bfc8ac0146fad4', stroke: icon.color, "stroke-width": icon.strokeWidth }, h("circle", { key: '9989fb98d61ca81bd9cdecf4dd3c19bd30da85aa', cx: "24", cy: "15", r: "9" }), h("path", { key: 'c6e2d2b446e0fa50951d77b74e892ffbd9503b1c', d: "M6 42c0-9.941 8.059-18 18-18", "stroke-linecap": "round" })), h("path", { key: 'a99d58851f3b97361c390602eceb733aa7fef01f', d: "M24.006 27.936a1.5 1.5 0 1 0 0 3v-3zm0 3H42.56v-3H24.006v3z", fill: icon.color }), h("path", { key: 'f2cb3a44dfc01dd0de3144816f1195330db958b3', d: "M38.426 25.501l3.934 3.934", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '8e7c202373f901a3c596b24566bf175b69907d94', d: "M42.373 40.303a1.5 1.5 0 1 0 0-3v3zm0-3H23.98v3h18.393v-3z", fill: icon.color }), h("path", { key: '22622c39daae9ad1f9e44a2d027b5b20df8cb891', d: "M27.686 42.477l-3.673-3.673", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-change-user"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconChangeUser$1;},KsIconChangeUser$1 = GetKsIconChangeUser$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-change-user"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-change-user":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconChangeUser$1(transTagName));
        }
        break;
    }});
}

const KsIconChangeUser = KsIconChangeUser$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconChangeUser, defineCustomElement };
//# sourceMappingURL=ks-icon-change-user.js.map
//# sourceMappingURL=ks-icon-change-user.js.map