import { proxyCustomElement, HTMLElement, createEvent, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconAscendUp$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconAscendUp$1 =

    proxyCustomElement(class KsIconAscendUp extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this.triangleUpClick = createEvent(this, "triangleUpClick", 7);
        this.triangleDownClick = createEvent(this, "triangleDownClick", 7);
        this['ks-icon-name'] = 'ks-icon-ascend-up';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '1f47432baf6f4c63f8e7dc34b3282f55b3da9ffd', class: "ks-icon", "ks-icon": true }, h("svg", { key: '6ca68a7050a6c76bcf922aa4b29e837c319a6cac', width: icon.width, height: icon.height, viewBox: "0 0 48 48", xmlns: "http://www.w3.org/2000/svg", "fill-rule": "evenodd", "clip-rule": "evenodd", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: '5b637ed47b2811a721bcb0d2142690542253af4d', part: "triangleUp", fill: icon.color, d: "M34.3302 19.714C35.0143 19.714 35.633 19.3072 35.9041 18.6791C36.1752 18.0509 36.0468 17.3217 35.5775 16.8239L25.27 5.89054C24.9465 5.54746 24.4961 5.35275 24.0246 5.35223C23.5531 5.35171 23.1021 5.54542 22.7779 5.88778L12.4246 16.8211C11.9537 17.3184 11.824 18.0482 12.0947 18.6773C12.3653 19.3064 12.9845 19.714 13.6693 19.714H23.9998H34.3302Z", onClick: () => this.triangleUpClick.emit() }), h("path", { key: '743cd519503a530e3b909111eb5671590380a20a', part: "triangleDown", fill: "transparent", d: "M25.559 41.9887C25.2288 42.339 24.7689 42.5377 24.2876 42.5383C23.8062 42.5388 23.3459 42.3411 23.015 41.9915L12.8772 31.2857C12.3964 30.7781 12.264 30.033 12.5403 29.3908C12.8167 28.7486 13.4487 28.3325 14.1478 28.3325H24.2632H34.3786C35.077 28.3325 35.7086 28.7478 35.9853 29.389C36.2621 30.0303 36.131 30.7747 35.6519 31.2829L25.559 41.9887Z", onClick: () => this.triangleDownClick.emit() })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-ascend-up"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconAscendUp$1;},KsIconAscendUp$1 = GetKsIconAscendUp$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-ascend-up"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-ascend-up":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconAscendUp$1(transTagName));
        }
        break;
    }});
}

const KsIconAscendUp = KsIconAscendUp$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconAscendUp, defineCustomElement };
//# sourceMappingURL=ks-icon-ascend-up.js.map
//# sourceMappingURL=ks-icon-ascend-up.js.map