import type { Components, JSX } from "../dist/types/components";

interface KsIconCommand extends Components.KsIconCommand, HTMLElement {}
export const KsIconCommand: {
    prototype: KsIconCommand;
    new (): KsIconCommand;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
