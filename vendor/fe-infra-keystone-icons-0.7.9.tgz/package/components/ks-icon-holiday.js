import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconHoliday$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconHoliday$1 =

    proxyCustomElement(class KsIconHoliday extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-holiday';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'fbd36bdcfe00a2976b102d3e823d949b5c0d01e8', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'f1c569e75095e9dbf64038675e616f3dfc89e2cb', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'e85d6655ca6115d5ae5b13297a658ab0977ebaf3', d: "M40.3008 27.7847C40.3008 36.6835 33.0868 43.8975 24.188 43.8975C15.2891 43.8975 8.0752 36.6835 8.0752 27.7847C8.0752 18.8858 15.2891 11.6719 24.188 11.6719C33.0868 11.6719 40.3008 18.8858 40.3008 27.7847Z", stroke: icon.color, "stroke-width": icon.strokeWidth }), h("path", { key: 'b1d591e1858e261c3936ed183ab1a23768de3854', d: "M22.6914 12.0391C12.4973 20.1138 13.9111 38.8369 23.2472 43.5303", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '6848900bfd2b13af25f5bd2801bcb367969ea35d', d: "M25.6699 12.0391C35.864 20.1138 34.4502 38.8369 25.1141 43.5303", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '0adf9646b782d06df2adb4f90611f9871ab45b79', d: "M9.06543 22.9258H38.8916", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '4a5fcc5e5fb92d8403af6bbf2b695975fb48a403', d: "M24.2061 43.0703L24.2061 2.83984", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: 'ff7c0b36151356fc23958256709a53445d4d57e2', d: "M9.06543 32.5146H38.8916", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: 'e8bc75780209e669c6fef6c2d953febe856d599e', d: "M21.7578 9.2998H26.6279", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: 'e994639fac64394b3fef46674863ff2de01496fa', d: "M39.6807 4.70606C39.8819 4.30631 40.5059 4.30631 40.707 4.70606C41.1052 5.49711 41.6954 6.5303 42.335 7.16993C42.9745 7.80951 44.0078 8.3997 44.7988 8.79786C45.1986 8.99905 45.1986 9.62304 44.7988 9.82423C44.0078 10.2224 42.9746 10.8126 42.335 11.4522C41.6953 12.0919 41.1052 13.1259 40.707 13.917C40.5058 14.3166 39.8819 14.3165 39.6807 13.917C39.2825 13.1259 38.6925 12.0919 38.0527 11.4522C37.4131 10.8126 36.3799 10.2224 35.5889 9.82423C35.1891 9.62304 35.1891 8.99905 35.5889 8.79786C36.3799 8.3997 37.4132 7.80949 38.0527 7.16993C38.6923 6.53028 39.2825 5.4971 39.6807 4.70606Z", fill: icon.color }), h("path", { key: '664e908847e6f53f584c1e6e1ceb57511269a894', d: "M6.53227 39.6586C6.6813 39.3625 7.1429 39.3626 7.29204 39.6586C7.587 40.2446 8.02516 41.0098 8.49907 41.4838C8.97299 41.9577 9.73816 42.3958 10.3243 42.6908C10.6204 42.8399 10.6204 43.3015 10.3243 43.4506C9.73827 43.7455 8.97297 44.1828 8.49907 44.6566C8.02512 45.1306 7.58702 45.8967 7.29204 46.4828C7.1428 46.7786 6.68131 46.7787 6.53227 46.4828C6.23729 45.8967 5.80016 45.1306 5.32622 44.6566C4.85226 44.1827 4.08612 43.7455 3.50005 43.4506C3.20437 43.3014 3.20445 42.84 3.50005 42.6908C4.08616 42.3958 4.85227 41.9577 5.32622 41.4838C5.80003 41.0098 6.23734 40.2446 6.53227 39.6586Z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-holiday"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconHoliday$1;},KsIconHoliday$1 = GetKsIconHoliday$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-holiday"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-holiday":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconHoliday$1(transTagName));
        }
        break;
    }});
}

const KsIconHoliday = KsIconHoliday$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconHoliday, defineCustomElement };
//# sourceMappingURL=ks-icon-holiday.js.map
//# sourceMappingURL=ks-icon-holiday.js.map