import type { Components, JSX } from "../dist/types/components";

interface KsIconColoredX extends Components.KsIconColoredX, HTMLElement {}
export const KsIconColoredX: {
    prototype: KsIconColoredX;
    new (): KsIconColoredX;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
