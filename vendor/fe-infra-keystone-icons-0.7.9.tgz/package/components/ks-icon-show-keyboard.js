import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconShowKeyboard$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconShowKeyboard$1 =

    proxyCustomElement(class KsIconShowKeyboard extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-show-keyboard';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '336d6ad79b542da2025ffec8765cc060b7acbc03', class: "ks-icon", "ks-icon": true }, h("svg", { key: '2d20be407c2d5b25b6b9c72d99073f6b5fdc4342', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("g", { key: 'ab7ce7f9c5524657c25c697bf4595a9d701e1b56', "clip-path": "url(#A)" }, h("g", { key: 'e30b984af4f2755db3db5926243828f3473da632', "fill-rule": "evenodd", fill: icon.color }, h("use", { key: '3e349b78664e55c52f97ac3cb9beddd81d2665bc', href: "#B" }), h("use", { key: 'aca0f5928e5e5e73689d111e57de4e5e5c9552ad', href: "#C" }), h("path", { key: 'd89874d83907a1e9e675bc90fb741182e77f3530', d: "M12.823 25.88c0-.947.768-1.714 1.714-1.714h.999c.947 0 1.714.767 1.714 1.714s-.768 1.714-1.714 1.714h-.999c-.947 0-1.714-.768-1.714-1.714zm0 6.857c0-.947.768-1.714 1.714-1.714h.999c.947 0 1.714.768 1.714 1.714s-.768 1.714-1.714 1.714h-.999c-.947 0-1.714-.768-1.714-1.714zm5.921-6.857c0-.947.768-1.714 1.714-1.714h.999c.947 0 1.714.767 1.714 1.714s-.768 1.714-1.714 1.714h-.999c-.947 0-1.714-.768-1.714-1.714zm0 6.857c0-.947.768-1.714 1.714-1.714h.999c.947 0 1.714.768 1.714 1.714s-.768 1.714-1.714 1.714h-.999c-.947 0-1.714-.768-1.714-1.714z" }), h("use", { key: 'b701fcfaf30909b40692602bad33e664efc687e0', href: "#D" }), h("use", { key: '3d68319fc4b4d1abe6a3cc13261bf2b4d7dfd7bd', href: "#E" }), h("path", { key: '0591fb9ac7916a07ff6cc2f0e7aaf0594294e512', d: "M30.587 25.88c0-.947.767-1.714 1.714-1.714h.999c.947 0 1.714.767 1.714 1.714s-.767 1.714-1.714 1.714h-.999c-.947 0-1.714-.768-1.714-1.714zm0 6.857c0-.947.767-1.714 1.714-1.714h.999c.947 0 1.714.768 1.714 1.714s-.767 1.714-1.714 1.714h-.999c-.947 0-1.714-.768-1.714-1.714zm5.921-6.857c0-.947.767-1.714 1.714-1.714h.999c.947 0 1.714.767 1.714 1.714s-.768 1.714-1.714 1.714h-.999c-.947 0-1.714-.768-1.714-1.714zm0 6.857c0-.947.767-1.714 1.714-1.714h.999c.947 0 1.714.768 1.714 1.714s-.768 1.714-1.714 1.714h-.999c-.947 0-1.714-.768-1.714-1.714z" })), h("g", { key: 'db240acd804198221b1659c07bb8e09860ba1e26', stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: '74212ef745b4fb1def6639502300c0765407da13', d: "M15.429 38.382h17.143M5.143 45.578h37.714a3.43 3.43 0 0 0 3.429-3.429V21.578a3.43 3.43 0 0 0-3.429-3.429H5.143a3.43 3.43 0 0 0-3.429 3.429v20.571a3.43 3.43 0 0 0 3.429 3.429z" }), h("path", { key: 'f2f6beff7db9631669accc072c1c053451a32b25', d: "M13.029 12.902L24.023 1.909l10.994 10.994", "stroke-linejoin": "round" }))), h("defs", { key: '6cb19b1776ee9cc95c7f855427dbb80530c60603' }, h("clipPath", { key: '9a8e67032eb5e6c819c18e3f146c0dce55f46958', id: "A" }, h("path", { key: 'caf326f936e1ae2271e81162a38b76373886e00b', fill: "#fff", d: "M0 0h48v48H0z" })), h("path", { key: '74e99d9495d6477e3c3436cf6b45b17f8aac0b9d', id: "B", d: "M6.902 25.88c0-.947.768-1.714 1.714-1.714h.999c.947 0 1.714.767 1.714 1.714s-.768 1.714-1.714 1.714h-.999c-.947 0-1.714-.768-1.714-1.714z" }), h("path", { key: 'e6ae1ada70dd2f6646a1afa4a8490d9ff77bf8d4', id: "C", d: "M6.902 32.737c0-.947.768-1.714 1.714-1.714h.999c.947 0 1.714.768 1.714 1.714s-.768 1.714-1.714 1.714h-.999c-.947 0-1.714-.768-1.714-1.714z" }), h("path", { key: '2dc7d50039ddc223206df0fca41283749afe6a77', id: "D", d: "M24.666 25.88c0-.947.767-1.714 1.714-1.714h.999c.947 0 1.714.767 1.714 1.714s-.767 1.714-1.714 1.714h-.999c-.947 0-1.714-.768-1.714-1.714z" }), h("path", { key: 'e9cd82769137a753191299311af40ef6b370194c', id: "E", d: "M24.666 32.737c0-.947.767-1.714 1.714-1.714h.999c.947 0 1.714.768 1.714 1.714s-.767 1.714-1.714 1.714h-.999c-.947 0-1.714-.768-1.714-1.714z" }))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-show-keyboard"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconShowKeyboard$1;},KsIconShowKeyboard$1 = GetKsIconShowKeyboard$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-show-keyboard"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-show-keyboard":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconShowKeyboard$1(transTagName));
        }
        break;
    }});
}

const KsIconShowKeyboard = KsIconShowKeyboard$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconShowKeyboard, defineCustomElement };
//# sourceMappingURL=ks-icon-show-keyboard.js.map
//# sourceMappingURL=ks-icon-show-keyboard.js.map