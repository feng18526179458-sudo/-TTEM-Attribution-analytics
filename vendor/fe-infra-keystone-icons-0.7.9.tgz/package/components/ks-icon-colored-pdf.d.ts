import type { Components, JSX } from "../dist/types/components";

interface KsIconColoredPdf extends Components.KsIconColoredPdf, HTMLElement {}
export const KsIconColoredPdf: {
    prototype: KsIconColoredPdf;
    new (): KsIconColoredPdf;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
