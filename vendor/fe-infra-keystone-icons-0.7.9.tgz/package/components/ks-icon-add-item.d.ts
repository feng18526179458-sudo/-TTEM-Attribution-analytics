import type { Components, JSX } from "../dist/types/components";

interface KsIconAddItem extends Components.KsIconAddItem, HTMLElement {}
export const KsIconAddItem: {
    prototype: KsIconAddItem;
    new (): KsIconAddItem;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
