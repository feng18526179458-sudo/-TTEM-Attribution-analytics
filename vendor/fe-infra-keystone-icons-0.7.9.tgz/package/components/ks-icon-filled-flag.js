import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledFlag$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledFlag$1 =

    proxyCustomElement(class KsIconFilledFlag extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-flag';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '8f133cb44beeb86769fbd60c3fcff80eb9a26ee8', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'eea683a3998b9458adb236373fa485b236171aa8', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '9719defcf8183ae76980e26729dc23c5128ffc9f', d: "M40.955 16.584c1.339.469 1.339 2.363 0 2.832l-23.959 8.386A1.5 1.5 0 0 1 15 26.386V9.614a1.5 1.5 0 0 1 1.995-1.416l23.959 8.386z", fill: icon.color }), h("path", { key: '9d922818d4f6b0dd6d7f07983d9d4fb08f6020da', d: "M15 6v34.5m-4.5.363h9", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-flag"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFilledFlag$1;},KsIconFilledFlag$1 = GetKsIconFilledFlag$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-flag"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-flag":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledFlag$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledFlag = KsIconFilledFlag$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledFlag, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-flag.js.map
//# sourceMappingURL=ks-icon-filled-flag.js.map