import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconConnect$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconConnect$1 =

    proxyCustomElement(class KsIconConnect extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-connect';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '58c6b4bbffb155708a4c0fdca939402ef244f5ff', class: "ks-icon", "ks-icon": true }, h("svg", { key: '1174d3604091dd760380d61167337b9d2d6f6bd7', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: '00175707af40b6e62afaa72ecfda6df042a3c9e4', d: "M24.144 10.664a9.37 9.37 0 0 1 13.25 0 9.37 9.37 0 0 1 0 13.25l-3.643 3.643a1.5 1.5 0 0 1-2.121 0L20.501 16.428a1.5 1.5 0 0 1 0-2.121l3.643-3.643zM10.691 24.116a9.37 9.37 0 0 0 0 13.25 9.37 9.37 0 0 0 13.249 0l3.643-3.643a1.5 1.5 0 0 0 0-2.121L16.455 20.473a1.5 1.5 0 0 0-2.121 0l-3.643 3.643z" }), h("path", { key: 'fb20bb9380e1b87b2af40bdfe71e5d520c9b89d0', d: "M22.595 18.729l-2.885 2.885m9.611 3.839l-2.885 2.885m11.057-17.775l4.803-4.803M10.592 37.465l-4.803 4.803", "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-connect"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconConnect$1;},KsIconConnect$1 = GetKsIconConnect$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-connect"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-connect":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconConnect$1(transTagName));
        }
        break;
    }});
}

const KsIconConnect = KsIconConnect$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconConnect, defineCustomElement };
//# sourceMappingURL=ks-icon-connect.js.map
//# sourceMappingURL=ks-icon-connect.js.map