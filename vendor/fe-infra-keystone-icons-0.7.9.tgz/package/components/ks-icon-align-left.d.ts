import type { Components, JSX } from "../dist/types/components";

interface KsIconAlignLeft extends Components.KsIconAlignLeft, HTMLElement {}
export const KsIconAlignLeft: {
    prototype: KsIconAlignLeft;
    new (): KsIconAlignLeft;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
