import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconTiktokWhite$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconTiktokWhite$1 =

    proxyCustomElement(class KsIconTiktokWhite extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-tiktok-white';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '5201fec8fad41dd1397ecd285089616ac4c026ae', class: "ks-icon", "ks-icon": true }, h("svg", { key: '567606d3da2461089335cbeafc51ce9cc828b5fa', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'd4b5152a1d164dd79ea524a261bcea585fd6e954', d: "M19.666 20.541v-1.756a13.62 13.62 0 0 0-1.839-.133c-7.523 0-13.644 6.121-13.644 13.646 0 4.617 2.306 8.701 5.825 11.171a13.59 13.59 0 0 1-3.664-9.291 13.66 13.66 0 0 1 13.323-13.636h-.001zm-.146 18.555c3.357 0 6.095-2.671 6.219-5.997l.012-29.709h5.427a10.33 10.33 0 0 1-.175-1.882h-7.412l-.012 29.709c-.124 3.326-2.863 5.997-6.219 5.997-1.043 0-2.026-.261-2.891-.716a6.22 6.22 0 0 0 5.051 2.597zm21.137-23.98v-1.651c-2.07 0-3.999-.615-5.617-1.671a10.32 10.32 0 0 0 5.617 3.322z", fill: "#25f4ee" }), h("path", { key: 'fc78c417609f0fe264ca536341de858a42768f81', d: "M36.133 11.7c-1.578-1.812-2.536-4.176-2.536-6.762h-1.986c.523 2.824 2.199 5.248 4.522 6.762zM17.272 24.185a6.24 6.24 0 0 0-6.232 6.232c0 2.393 1.358 4.472 3.341 5.515a6.19 6.19 0 0 1-1.18-3.634 6.24 6.24 0 0 1 6.232-6.232c.641 0 1.256.106 1.839.288v-7.568a13.62 13.62 0 0 0-1.839-.133l-.322.008v5.812c-.582-.182-1.198-.288-1.839-.288l-.001.001zm25.546-12.391v5.761a17.63 17.63 0 0 1-10.313-3.316v15.066c0 7.524-6.121 13.644-13.644 13.644a13.56 13.56 0 0 1-7.82-2.473c2.492 2.676 6.043 4.354 9.981 4.354 7.524 0 13.644-6.121 13.644-13.644V16.121a17.63 17.63 0 0 0 10.313 3.316v-7.414c-.742 0-1.464-.08-2.16-.229z", fill: "#fe2c55" }), h("path", { key: '994e71ec7d11942d0069194636f7d906029b89ec', d: "M32.74 32.532V17.466a17.63 17.63 0 0 0 10.313 3.316v-5.761c-2.22-.475-4.176-1.667-5.617-3.322a10.33 10.33 0 0 1-4.522-6.762h-5.427l-.012 29.709c-.124 3.326-2.863 5.997-6.219 5.997a6.22 6.22 0 0 1-5.051-2.597c-1.983-1.044-3.341-3.123-3.341-5.515a6.24 6.24 0 0 1 6.232-6.232c.641 0 1.256.106 1.839.288v-5.812c-7.375.173-13.323 6.221-13.323 13.636a13.59 13.59 0 0 0 3.664 9.291c2.216 1.555 4.912 2.473 7.82 2.473 7.523 0 13.644-6.121 13.644-13.644v.001z", fill: "#fff" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-tiktok-white"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconTiktokWhite$1;},KsIconTiktokWhite$1 = GetKsIconTiktokWhite$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-tiktok-white"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-tiktok-white":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconTiktokWhite$1(transTagName));
        }
        break;
    }});
}

const KsIconTiktokWhite = KsIconTiktokWhite$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconTiktokWhite, defineCustomElement };
//# sourceMappingURL=ks-icon-tiktok-white.js.map
//# sourceMappingURL=ks-icon-tiktok-white.js.map