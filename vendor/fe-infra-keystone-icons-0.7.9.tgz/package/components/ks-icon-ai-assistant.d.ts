import type { Components, JSX } from "../dist/types/components";

interface KsIconAiAssistant extends Components.KsIconAiAssistant, HTMLElement {}
export const KsIconAiAssistant: {
    prototype: KsIconAiAssistant;
    new (): KsIconAiAssistant;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
