import type { Components, JSX } from "../dist/types/components";

interface KsIconAuto extends Components.KsIconAuto, HTMLElement {}
export const KsIconAuto: {
    prototype: KsIconAuto;
    new (): KsIconAuto;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
