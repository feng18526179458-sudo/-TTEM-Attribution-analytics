import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledTips$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledTips$1 =

    proxyCustomElement(class KsIconFilledTips extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-tips';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
        this.innerColor = '#fff';
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '1007f0b462c75bfc5ef184583a6fc9077a7e37af', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'c5580b0ff4c36fa3ad36269dceabac37f70830f6', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '48e56d531929ae10719fd5922ffd9dac391e87f3', d: "M24.0093 3.99979C35.0545 4.00021 44.0092 12.9544 44.0093 23.9998C44.0093 35.0452 35.0546 43.9994 24.0093 43.9998C12.9637 43.9997 4.00928 35.0454 4.00928 23.9998C4.00935 12.9542 12.9637 3.99984 24.0093 3.99979Z", fill: icon.color }), h("path", { key: '4108366e08eb2227eb21f351365c2154a7e6d868', d: "M24.0083 24.4542V21.0962M24.0083 21.0962L21.0884 18.177M24.0083 21.0962L26.9276 18.1765", stroke: this.innerColor, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '27c73d5ed4fd1a1a1c32236482400fca702bb700', d: "M20.8318 37.685H27.1848", stroke: this.innerColor, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '3d9abde10c30c25bfc32fd2a5b149bfe231313b7', d: "M24.0093 10.3142L24.0093 8.81424H24.0093V10.3142ZM35.0083 19.949L36.5083 19.949V19.949H35.0083ZM29.1167 28.4803L28.4896 27.1176C27.9576 27.3625 27.6167 27.8946 27.6167 28.4803H29.1167ZM29.1167 32.3152V33.8152C29.9451 33.8152 30.6167 33.1436 30.6167 32.3152H29.1167ZM18.8999 32.3152H17.3999C17.3999 33.1436 18.0715 33.8152 18.8999 33.8152V32.3152ZM18.8999 28.4793H20.3999C20.3999 27.8937 20.0591 27.3616 19.5271 27.1167L18.8999 28.4793ZM13.0093 19.949H11.5093V19.949L13.0093 19.949ZM24.0093 10.3142L24.0092 11.8142C29.4484 11.8144 33.5083 15.6372 33.5083 19.949H35.0083H36.5083C36.5083 13.6195 30.7198 8.81446 24.0093 8.81424L24.0093 10.3142ZM35.0083 19.949L33.5083 19.949C33.5082 22.9671 31.5587 25.7053 28.4896 27.1176L29.1167 28.4803L29.7438 29.8429C33.679 28.032 36.5082 24.3418 36.5083 19.949L35.0083 19.949ZM29.1167 28.4803H27.6167V32.3152H29.1167H30.6167V28.4803H29.1167ZM29.1167 32.3152V30.8152H18.8999V32.3152V33.8152H29.1167V32.3152ZM18.8999 32.3152H20.3999V28.4793H18.8999H17.3999V32.3152H18.8999ZM18.8999 28.4793L19.5271 27.1167C16.4586 25.7042 14.5094 22.9666 14.5093 19.949L13.0093 19.949L11.5093 19.949C11.5094 24.3414 14.3383 28.0308 18.2727 29.8418L18.8999 28.4793ZM13.0093 19.949H14.5093C14.5093 15.6372 18.5698 11.8142 24.0093 11.8142V10.3142V8.81424C17.2987 8.81424 11.5093 13.6193 11.5093 19.949H13.0093Z", fill: this.innerColor })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-tips"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"],
      "innerColor": [1, "inner-color"]
    }]);return innerKsIconFilledTips$1;},KsIconFilledTips$1 = GetKsIconFilledTips$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-tips"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-tips":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledTips$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledTips = KsIconFilledTips$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledTips, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-tips.js.map
//# sourceMappingURL=ks-icon-filled-tips.js.map