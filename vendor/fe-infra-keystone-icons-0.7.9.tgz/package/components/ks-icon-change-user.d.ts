import type { Components, JSX } from "../dist/types/components";

interface KsIconChangeUser extends Components.KsIconChangeUser, HTMLElement {}
export const KsIconChangeUser: {
    prototype: KsIconChangeUser;
    new (): KsIconChangeUser;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
