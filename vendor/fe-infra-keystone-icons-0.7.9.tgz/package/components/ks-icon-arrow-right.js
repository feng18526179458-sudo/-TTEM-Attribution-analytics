import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconArrowRight$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconArrowRight$1 =

    proxyCustomElement(class KsIconArrowRight extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-arrow-right';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '405ddc7654458a48b5c8382b7fe7362ed092a464', class: "ks-icon", "ks-icon": true }, h("svg", { key: '1c1c00f47f24608b329b3c06fa3036e115ded3f4', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }, h("path", { key: 'cd87a3f47a11593225d10294f9260a76a2f3c51f', d: "M35.074 12l10.443 10.965a1.5 1.5 0 0 1 0 2.069L35.074 36M43.5 23.985h-39" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-arrow-right"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconArrowRight$1;},KsIconArrowRight$1 = GetKsIconArrowRight$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-arrow-right"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-arrow-right":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconArrowRight$1(transTagName));
        }
        break;
    }});
}

const KsIconArrowRight = KsIconArrowRight$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconArrowRight, defineCustomElement };
//# sourceMappingURL=ks-icon-arrow-right.js.map
//# sourceMappingURL=ks-icon-arrow-right.js.map