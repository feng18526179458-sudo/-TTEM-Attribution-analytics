import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledLimitedApproval$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledLimitedApproval$1 =

    proxyCustomElement(class KsIconFilledLimitedApproval extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-limited-approval';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'fbd83d027f6ed42f7edaa342ab85c969f003e895', class: "ks-icon", "ks-icon": true }, h("svg", { key: '15d803e4e5d7fbef03d24be729aa10c53a4a264f', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '1ded12393217f92121be1263ade0d042f5aae0e5', d: "M4.50018 23.9999C4.50018 13.2304 13.2306 4.5 24.0002 4.5C34.7697 4.5 43.5002 13.2304 43.5002 23.9999C43.5002 34.7693 34.7697 43.4997 24.0002 43.4997C13.2306 43.4997 4.50018 34.7693 4.50018 23.9999Z", fill: "#FAD253" }), h("path", { key: 'b295e73de0cf0f1e40a28e12f7efa90ea71b1c6d', d: "M15.7824 15.7817L32.218 32.2173", stroke: "#342209", "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-limited-approval"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFilledLimitedApproval$1;},KsIconFilledLimitedApproval$1 = GetKsIconFilledLimitedApproval$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-limited-approval"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-limited-approval":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledLimitedApproval$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledLimitedApproval = KsIconFilledLimitedApproval$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledLimitedApproval, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-limited-approval.js.map
//# sourceMappingURL=ks-icon-filled-limited-approval.js.map