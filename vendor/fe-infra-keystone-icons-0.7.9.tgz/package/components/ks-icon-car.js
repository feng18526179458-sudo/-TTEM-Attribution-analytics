import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconCar$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconCar$1 =

    proxyCustomElement(class KsIconCar extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-car';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '0f927e14f9c0cef83b617b987145a4084c8cd129', class: "ks-icon", "ks-icon": true }, h("svg", { key: '6a529c200164990b5a694956102341fb4e9b37df', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '3503f1f38236884555dc396d29df846486bab9f5', d: "M6.40625 38.0691L6.45775 23.9805L41.5938 24.0155L41.5842 38.0691H6.40625Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" }), h("path", { key: '7d7bd5027aa4654ec7f075f53a624a5136729dbb', d: "M11.0819 11.9383L6.45801 23.9807L41.594 24.0157L37.878 12.1192C37.4868 10.8666 36.3268 10.0137 35.0145 10.0137H13.8826C12.6406 10.0137 11.5271 10.7789 11.0819 11.9383Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" }), h("path", { key: '5461373a411b73568aaddbdb040b4ac15291ea98', d: "M36.7477 41.234V36.8836H43.0755V41.234C43.0755 42.9814 41.659 44.3979 39.9116 44.3979C38.1642 44.3979 36.7477 42.9814 36.7477 41.234Z", fill: icon.color }), h("path", { key: '03e1c003c6cb63efac1e265e2579860f7f9e2ef3', d: "M4.88477 41.2403L4.89692 36.8689L11.2126 36.89V41.2403C11.2126 42.9877 9.79607 44.4043 8.04869 44.4043C6.3013 44.4043 4.88477 42.9877 4.88477 41.2403Z", fill: icon.color }), h("path", { key: 'b03c04d55fe9d7e07f7c88f62ac59dcd785fc518', d: "M18.1267 31.0215C18.1267 32.6783 16.7835 34.0215 15.1267 34.0215C13.4698 34.0215 12.1267 32.6783 12.1267 31.0215C12.1267 29.3646 13.4698 28.0215 15.1267 28.0215C16.7835 28.0215 18.1267 29.3646 18.1267 31.0215Z", fill: icon.color }), h("path", { key: '87f20897115a30fdc31b58a0bf1746c7fed0fc84', d: "M36.1892 31.0215C36.1892 32.6783 34.846 34.0215 33.1892 34.0215C31.5323 34.0215 30.1892 32.6783 30.1892 31.0215C30.1892 29.3646 31.5323 28.0215 33.1892 28.0215C34.846 28.0215 36.1892 29.3646 36.1892 31.0215Z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-car"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconCar$1;},KsIconCar$1 = GetKsIconCar$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-car"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-car":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconCar$1(transTagName));
        }
        break;
    }});
}

const KsIconCar = KsIconCar$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconCar, defineCustomElement };
//# sourceMappingURL=ks-icon-car.js.map
//# sourceMappingURL=ks-icon-car.js.map