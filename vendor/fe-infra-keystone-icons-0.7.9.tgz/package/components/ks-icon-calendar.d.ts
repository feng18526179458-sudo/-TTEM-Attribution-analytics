import type { Components, JSX } from "../dist/types/components";

interface KsIconCalendar extends Components.KsIconCalendar, HTMLElement {}
export const KsIconCalendar: {
    prototype: KsIconCalendar;
    new (): KsIconCalendar;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
