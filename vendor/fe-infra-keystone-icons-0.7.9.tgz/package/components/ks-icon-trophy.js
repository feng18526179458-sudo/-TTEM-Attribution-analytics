import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconTrophy$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconTrophy$1 =

    proxyCustomElement(class KsIconTrophy extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-trophy';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '8ed3a9ee85ac66ba457a279c87d440d783204af4', class: "ks-icon", "ks-icon": true }, h("svg", { key: '9f37e834714936755beafad0f4c6fe71cbd08af5', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("g", { key: 'd3100b404a8455f27068b9f6d0c0e5e2aa8cb968', "stroke-linecap": "round" }, h("path", { key: 'a60ebfb3e7370d154577b2ee43ef2b2aebef5c72', d: "M13.5 42h21" }), h("path", { key: '9cf26ed1879f76e5f2f92b596f5e32dd07931a9c', d: "M24 42v-6" })), h("path", { key: '5c9c80053274ded049d1ffe176d25254df6250dd', d: "M10.5 7.5h27V21c0 7.456-6.044 13.5-13.5 13.5S10.5 28.456 10.5 21V7.5z" }), h("path", { key: '474a14e996589b3582351997b41778c91b737ad9', d: "M42 10.5V18M6 10.5V18", "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-trophy"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconTrophy$1;},KsIconTrophy$1 = GetKsIconTrophy$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-trophy"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-trophy":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconTrophy$1(transTagName));
        }
        break;
    }});
}

const KsIconTrophy = KsIconTrophy$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconTrophy, defineCustomElement };
//# sourceMappingURL=ks-icon-trophy.js.map
//# sourceMappingURL=ks-icon-trophy.js.map