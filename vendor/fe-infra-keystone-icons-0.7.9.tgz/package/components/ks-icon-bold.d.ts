import type { Components, JSX } from "../dist/types/components";

interface KsIconBold extends Components.KsIconBold, HTMLElement {}
export const KsIconBold: {
    prototype: KsIconBold;
    new (): KsIconBold;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
