import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledChevronDown$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledChevronDown$1 =

    proxyCustomElement(class KsIconFilledChevronDown extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-chevron-down';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '1960fea7c077c9f375c5e3e45e853ae7c5c30926', class: "ks-icon", "ks-icon": true }, h("svg", { key: '3ab2d27d7a3ce01bd5ffc0f7b0fc4c7ce546c91e', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '6668e185fd60e445ad0b99f9d416b2aed544bcb0', d: "M25.0581 34.0395C24.473 34.6216 23.5275 34.6216 22.9424 34.0395L4.89578 16.0874C4.46516 15.659 4.33538 15.0132 4.56709 14.4517C4.7988 13.8902 5.34625 13.5239 5.95366 13.5239H42.0464C42.6539 13.5239 43.2013 13.8902 43.433 14.4517C43.6647 15.0132 43.535 15.659 43.1043 16.0874L25.0581 34.0395Z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-chevron-down"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFilledChevronDown$1;},KsIconFilledChevronDown$1 = GetKsIconFilledChevronDown$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-chevron-down"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-chevron-down":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledChevronDown$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledChevronDown = KsIconFilledChevronDown$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledChevronDown, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-chevron-down.js.map
//# sourceMappingURL=ks-icon-filled-chevron-down.js.map