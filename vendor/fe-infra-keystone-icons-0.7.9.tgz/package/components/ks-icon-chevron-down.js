import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconChevronDown$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconChevronDown$1 =

    proxyCustomElement(class KsIconChevronDown extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-chevron-down';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'fa59f5e5688367349615c61cdc8616d70db78d30', class: "ks-icon", "ks-icon": true }, h("svg", { key: '421741ea8db1b07b0f1a9a1b9f5e15021c7433c4', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '9a212421cb7aff1290486fad6ac43ecf95684b00', d: "M6 15l16.939 16.939a1.5 1.5 0 0 0 2.121 0L42 15", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-chevron-down"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconChevronDown$1;},KsIconChevronDown$1 = GetKsIconChevronDown$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-chevron-down"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-chevron-down":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconChevronDown$1(transTagName));
        }
        break;
    }});
}

const KsIconChevronDown = KsIconChevronDown$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconChevronDown, defineCustomElement };
//# sourceMappingURL=ks-icon-chevron-down.js.map
//# sourceMappingURL=ks-icon-chevron-down.js.map