import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconOffScreen$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconOffScreen$1 =

    proxyCustomElement(class KsIconOffScreen extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-off-screen';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '60e8ef7f6cf4b3160026c79576b10dddee1a2397', class: "ks-icon", "ks-icon": true }, h("svg", { key: '8cbf24d63f8557953c0192793910a322f9261188', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: '5581735edb6e859ce039f5bd8b8a51db5ffa99ea', d: "M6.002 18h9a1.5 1.5 0 0 0 1.5-1.5V6m25.5 12h-9a1.5 1.5 0 0 1-1.5-1.5V6m10.5 24h-9a1.5 1.5 0 0 0-1.5 1.5V42m-25.5-12h9a1.5 1.5 0 0 1 1.5 1.5V42" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-off-screen"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconOffScreen$1;},KsIconOffScreen$1 = GetKsIconOffScreen$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-off-screen"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-off-screen":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconOffScreen$1(transTagName));
        }
        break;
    }});
}

const KsIconOffScreen = KsIconOffScreen$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconOffScreen, defineCustomElement };
//# sourceMappingURL=ks-icon-off-screen.js.map
//# sourceMappingURL=ks-icon-off-screen.js.map