import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconMoveOne$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconMoveOne$1 =

    proxyCustomElement(class KsIconMoveOne extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-move-one';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'd8503d8488d9166d3430ccc95d9cc291951b4e9b', class: "ks-icon", "ks-icon": true }, h("svg", { key: '7f1c9f25be1989ebd4b42186766548fee0a02da6', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'c2ecba1f6857da04a6579e0110583c5bd1e6c5c0', d: "M9.147 7.192c-.289-1.305 1.143-2.308 2.27-1.59l30.116 19.185c1.24.79.722 2.706-.747 2.764l-14.309.56a1.5 1.5 0 0 0-1.33.931l-5.42 13.254c-.556 1.361-2.535 1.192-2.853-.243L9.147 7.192z", stroke: icon.color, "stroke-width": icon.strokeWidth })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-move-one"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconMoveOne$1;},KsIconMoveOne$1 = GetKsIconMoveOne$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-move-one"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-move-one":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconMoveOne$1(transTagName));
        }
        break;
    }});
}

const KsIconMoveOne = KsIconMoveOne$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconMoveOne, defineCustomElement };
//# sourceMappingURL=ks-icon-move-one.js.map
//# sourceMappingURL=ks-icon-move-one.js.map