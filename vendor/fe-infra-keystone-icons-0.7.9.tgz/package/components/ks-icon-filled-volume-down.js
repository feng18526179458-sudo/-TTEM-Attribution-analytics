import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledVolumeDown$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledVolumeDown$1 =

    proxyCustomElement(class KsIconFilledVolumeDown extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-volume-down';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'c8230c81d4f141d1b1e7e47024d6acebae1e998b', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: 'b4dec46af8f093ecf094b702e27b73ea96bcb310', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '84f3544d7d9b125b631e3080d52c639308dd6e14', d: "M10.12 15.972a2.96 2.96 0 0 0-2.958 2.958v11.01a2.96 2.96 0 0 0 2.958 2.958h4.143a1.97 1.97 0 0 1 1.441.625l8.751 9.362c1.222 1.307 3.413.443 3.413-1.346V6.491c0-1.828-2.272-2.672-3.466-1.287l-8.692 10.084a1.97 1.97 0 0 1-1.494.684H10.12z", fill: icon.color }), h("path", { key: 'f58e1bd9b23d8d31b0075db405983e84dae442a6', d: "M32.177 17.289c4.375 4.374 4.375 11.467 0 15.842", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-volume-down"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFilledVolumeDown$1;},KsIconFilledVolumeDown$1 = GetKsIconFilledVolumeDown$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-volume-down"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-volume-down":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledVolumeDown$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledVolumeDown = KsIconFilledVolumeDown$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledVolumeDown, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-volume-down.js.map
//# sourceMappingURL=ks-icon-filled-volume-down.js.map