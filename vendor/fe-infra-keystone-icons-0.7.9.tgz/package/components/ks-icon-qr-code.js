import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconQrCode$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconQrCode$1 =

    proxyCustomElement(class KsIconQrCode extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-qr-code';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '5dbfb095de20068e61c04996f4cb4ade348dd90e', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'fe2433537422c04aa8736fe1043e2f441f876841', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("rect", { key: 'c9a0496389a3c7f597e2615f40754a8f64867b94', x: "5.5007", y: "27.5968", width: "14.9035", height: "14.9035", rx: "1.5", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" }), h("rect", { key: '1e9f3e8f0433f670c6debc1229d7f9b5f15e92bc', x: "15.4524", y: "32.5485", width: "5", height: "5", rx: "0.277778", transform: "rotate(90 15.4524 32.5485)", fill: icon.color }), h("rect", { key: '0b06374d35e4175ceffc8a5d382b7c606ea9de65', x: "5.5007", y: "5.50024", width: "15", height: "15", rx: "1.51618", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" }), h("rect", { key: '313c0ddcfae8054a07c8727f303bf458f03a07fd', x: "15.3158", y: "10.41", width: "5.02696", height: "5.02696", rx: "0.279276", transform: "rotate(90 15.3158 10.41)", fill: icon.color }), h("rect", { key: '87c188dc1afe5847c3a2fb9454046ef85192e1b3', x: "27.5007", y: "5.50024", width: "15", height: "15", rx: "1.51618", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" }), h("rect", { key: '6afe5e0b1498dbde722cb38265beb98f9ae47a93', x: "37.5142", y: "10.4868", width: "5.02696", height: "5.02696", rx: "0.279276", transform: "rotate(90 37.5142 10.4868)", fill: icon.color }), h("path", { key: '96f7982695ed19a4277c201c69b54ec1b1d680a3', d: "M29.9821 31.9856H35.987L35.9861 35.9866H31.9851V39.9954H35.987L35.9861 44.0002H28.0085V39.9954H24.032V35.9866H29.032V31.9856H25.9734V26.051H29.9821V31.9856Z", fill: icon.color }), h("path", { key: '2b56f5649968d1d1f8955877e0ba441631313c78', d: "M44.0007 44.0002H39.9958V39.9954H44.0007V44.0002Z", fill: icon.color }), h("path", { key: '7932eb604426db345221e0d2006382e501d4c73f', d: "M39.9958 39.9954H35.987L35.9861 35.9866H39.9958V39.9954Z", fill: icon.color }), h("path", { key: 'f390d4e389ccdcdc3787a58a27dc57b2623e613e', d: "M44.0007 35.9866H39.9958V31.9807H35.987V28.0159H32.0632V24.0071H40.0007V31.9807H44.0007V35.9866Z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-qr-code"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconQrCode$1;},KsIconQrCode$1 = GetKsIconQrCode$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-qr-code"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-qr-code":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconQrCode$1(transTagName));
        }
        break;
    }});
}

const KsIconQrCode = KsIconQrCode$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconQrCode, defineCustomElement };
//# sourceMappingURL=ks-icon-qr-code.js.map
//# sourceMappingURL=ks-icon-qr-code.js.map