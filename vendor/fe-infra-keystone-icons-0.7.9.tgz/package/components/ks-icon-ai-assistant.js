import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconAiAssistant$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconAiAssistant$1 =

    proxyCustomElement(class KsIconAiAssistant extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-ai-assistant';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '31644b3faa547e60bef337f75517e7aefb9dd921', class: "ks-icon", "ks-icon": true }, h("svg", { key: '9581df78dbe1fb1d5e204b74d04beb9d83f7e3a7', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("g", { key: '522993593feaa13ef280b63f8b0380777e2d3f1c', "clip-path": "url(#clip0_18_325)" }, h("path", { key: '4b71550ef4110180a37bf6af99be3cc7580fe822', d: "M24.3385 4.00933L24.3381 4.0109L17.5109 29.671C17.5108 29.6711 17.5108 29.6713 17.5107 29.6714C17.466 29.8403 17.5088 29.9892 17.6119 30.1064C17.7332 30.2443 17.905 30.3036 18.0925 30.2543L18.0926 30.2543L43.8121 23.4995L46.269 22.7839C46.3826 22.7417 46.4278 22.6902 46.4491 22.6591C46.4772 22.6181 46.5005 22.5556 46.5 22.4719C46.4989 22.3093 46.4095 22.1129 46.1495 22.0046L46.1153 21.9904L46.0819 21.9745L46.726 20.6198C46.0819 21.9745 46.0818 21.9744 46.0817 21.9744L46.0812 21.9742L46.0796 21.9734L46.0735 21.9705L46.0502 21.9594L45.9607 21.9166C45.8825 21.8792 45.7682 21.8243 45.6223 21.7539C45.3304 21.613 44.9119 21.4099 44.4036 21.16C43.3878 20.6604 42.0099 19.9721 40.5656 19.2189C39.1241 18.4672 37.6027 17.6436 36.3045 16.8743C35.0558 16.1341 33.8641 15.3589 33.2024 14.7032L24.3385 4.00933ZM24.3385 4.00933L24.8631 2.02908C24.9276 1.85591 25.0932 1.71693 25.3676 1.7058C25.6305 1.69513 25.8728 1.81357 26.0063 2.1182L26.0155 2.13934M24.3385 4.00933L26.0155 2.13934M26.0155 2.13934L26.0254 2.16018M26.0155 2.13934L26.0254 2.16018M26.0254 2.16018L27.3801 1.51608M26.0254 2.16018L27.3801 1.51608M27.3801 1.51608C26.0254 2.16018 26.0255 2.16028 26.0256 2.16042M27.3801 1.51608L26.0256 2.16042M26.0256 2.16042L26.0258 2.16088M26.0256 2.16042L26.0258 2.16088M26.0258 2.16088L26.0265 2.1625M26.0258 2.16088L26.0265 2.1625M26.0265 2.1625L26.0294 2.16844M26.0265 2.1625L26.0294 2.16844M26.0294 2.16844L26.0401 2.191M26.0294 2.16844L26.0401 2.191M26.0401 2.191L26.0815 2.27743M26.0401 2.191L26.0815 2.27743M26.0815 2.27743C26.1176 2.35285 26.1706 2.46317 26.2387 2.60399M26.0815 2.27743L26.2387 2.60399M26.2387 2.60399C26.3748 2.88559 26.5711 3.28937 26.8133 3.78012M26.2387 2.60399L26.8133 3.78012M26.8133 3.78012C27.2971 4.76088 27.9654 6.09244 28.7012 7.49192M26.8133 3.78012L28.7012 7.49192M28.7012 7.49192C29.4355 8.88858 30.2446 10.3672 31.0096 11.6369M28.7012 7.49192L31.0096 11.6369M31.0096 11.6369C31.7472 12.8612 32.526 14.033 33.2024 14.7032L31.0096 11.6369ZM23.3056 42.0874C22.504 39.9921 21.5157 37.5042 20.9273 36.4392L20.9419 36.4352L32.1597 33.3411C31.293 34.7352 29.6267 37.8642 28.1896 40.616C27.4357 42.0594 26.7318 43.4245 26.2165 44.4284C25.9588 44.9305 25.7482 45.3425 25.6019 45.6291L25.4328 45.9607L25.3885 46.0477L25.3772 46.07L25.3757 46.0729C25.3754 46.0735 25.3751 46.0741 25.3748 46.0747C25.3172 46.1862 25.256 46.2345 25.2141 46.2582C25.1663 46.2853 25.1094 46.2992 25.049 46.2966C24.9872 46.294 24.935 46.2746 24.8986 46.2498C24.8695 46.23 24.8412 46.2013 24.8188 46.1492L24.7961 46.0865L24.7058 45.8382C24.6276 45.6237 24.5149 45.3157 24.3764 44.9403C24.0996 44.1898 23.7192 43.1687 23.3056 42.0874ZM11.381 26.5696L11.3771 26.5842C10.3099 26.0008 7.81709 25.0235 5.71771 24.2312C4.63451 23.8224 3.61155 23.4466 2.85983 23.1731C2.48379 23.0363 2.17521 22.925 1.96039 22.8478L1.71167 22.7586L1.64897 22.7362C1.59666 22.7139 1.56779 22.6857 1.54785 22.6567C1.5229 22.6204 1.5033 22.5684 1.50037 22.5067C1.4975 22.4464 1.51119 22.3895 1.53804 22.3417C1.56169 22.2995 1.61004 22.2376 1.72273 22.1791L1.72545 22.1778L1.74776 22.1663L1.83457 22.1216L2.16536 21.9511C2.45134 21.8036 2.86241 21.5911 3.36336 21.3312C4.36505 20.8115 5.72703 20.1016 7.16716 19.3414C9.913 17.892 13.0351 16.2119 14.4253 15.3393L11.381 26.5696Z", fill: icon.color, stroke: icon.color, "stroke-width": icon.strokeWidth })), h("defs", { key: 'a01f962f513ad38ca949cb62e1f547f54585d81e' }, h("clipPath", { key: '1f1dec611e33d2ba08c9f437c8d5493b1920f509', id: "clip0_18_325" }, h("rect", { key: 'f736980b8c9ebeab58d46669364d3488953b992a', width: "48", height: "48", fill: "white" })))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-ai-assistant"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconAiAssistant$1;},KsIconAiAssistant$1 = GetKsIconAiAssistant$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-ai-assistant"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-ai-assistant":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconAiAssistant$1(transTagName));
        }
        break;
    }});
}

const KsIconAiAssistant = KsIconAiAssistant$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconAiAssistant, defineCustomElement };
//# sourceMappingURL=ks-icon-ai-assistant.js.map
//# sourceMappingURL=ks-icon-ai-assistant.js.map