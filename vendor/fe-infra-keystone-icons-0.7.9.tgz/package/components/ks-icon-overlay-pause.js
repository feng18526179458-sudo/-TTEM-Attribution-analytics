import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconOverlayPause$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconOverlayPause$1 =

    proxyCustomElement(class KsIconOverlayPause extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-overlay-pause';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'd2d67771564f66366c19146a8a18ce2421a28a95', class: "ks-icon", "ks-icon": true }, h("svg", { key: '9106638fc34b4d04a133563541a77a94524a6250', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'e5264ba1b73d1a5536d409c28980ab79eca881fe', "fill-rule": "evenodd", "clip-rule": "evenodd", d: "M24.001 4.5C34.77 4.50022 43.4998 13.2301 43.5 23.999C43.5 34.7682 34.7702 43.4988 24.001 43.499C13.2316 43.499 4.50098 34.7683 4.50098 23.999C4.50122 13.2299 13.2317 4.5 24.001 4.5Z", fill: "#262627", "fill-opacity": "0.7" }), h("path", { key: 'd9ac0f61e4e413beaa27c90b414a6ddb3c1a9fcb', d: "M18.3282 31.6517V16.3482C18.3282 15.9064 18.6864 15.5482 19.1282 15.5482H21.5409C21.9827 15.5482 22.3409 15.9064 22.3409 16.3482V31.6517C22.3409 32.0935 21.9827 32.4517 21.5409 32.4517H19.1282C18.6864 32.4517 18.3282 32.0935 18.3282 31.6517Z", fill: "white" }), h("path", { key: '3d39aa4c81434e8b99bdd8839900d7f375c6fe16', d: "M25.6599 31.6517V16.3474C25.6599 15.9055 26.0181 15.5474 26.4599 15.5474H28.8726C29.3144 15.5474 29.6726 15.9055 29.6726 16.3474V31.6517C29.6726 32.0935 29.3144 32.4517 28.8726 32.4517H26.4599C26.0181 32.4517 25.6599 32.0935 25.6599 31.6517Z", fill: "white" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-overlay-pause"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconOverlayPause$1;},KsIconOverlayPause$1 = GetKsIconOverlayPause$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-overlay-pause"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-overlay-pause":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconOverlayPause$1(transTagName));
        }
        break;
    }});
}

const KsIconOverlayPause = KsIconOverlayPause$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconOverlayPause, defineCustomElement };
//# sourceMappingURL=ks-icon-overlay-pause.js.map
//# sourceMappingURL=ks-icon-overlay-pause.js.map