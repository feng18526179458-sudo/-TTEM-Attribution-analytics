import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconReceipt$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconReceipt$1 =

    proxyCustomElement(class KsIconReceipt extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-receipt';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '2cfb8e7ede6f7c36b2dd5cb2ba4b1c0475047839', class: "ks-icon", "ks-icon": true }, h("svg", { key: '510ed759a28f31a46d873a9cedeebf71d19470c3', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '2ce3f8b1919d9c14c7ed830b0dd819833b0cdb4b', d: "M38.4687 39.7236C38.4687 41.9045 35.8712 43.0397 34.2705 41.5586L30.8242 38.3691C30.6326 38.1919 30.3362 38.1919 30.1445 38.3691L25.6982 42.4844C24.74 43.3711 23.26 43.3711 22.3018 42.4844L17.8555 38.3691C17.6638 38.1919 17.3674 38.1919 17.1758 38.3691L13.7295 41.5586C12.1288 43.0397 9.53125 41.9044 9.53125 39.7236L9.53125 7.98828C9.53125 6.05528 11.0983 4.48828 13.0313 4.48828L34.9688 4.48828C36.9017 4.48828 38.4687 6.05528 38.4687 7.98828L38.4687 39.7236Z", stroke: icon.color, "stroke-width": icon.strokeWidth }), h("path", { key: '1498d85090d661c05b49a87892e94a7e8732ead9', d: "M18.2168 20.1924L22.4638 24.0001L31.9692 14.4946", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: 'e693b531744c08793e41a248dbde922dc6c8c62f', d: "M16.3438 32H31.9688", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-receipt"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconReceipt$1;},KsIconReceipt$1 = GetKsIconReceipt$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-receipt"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-receipt":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconReceipt$1(transTagName));
        }
        break;
    }});
}

const KsIconReceipt = KsIconReceipt$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconReceipt, defineCustomElement };
//# sourceMappingURL=ks-icon-receipt.js.map
//# sourceMappingURL=ks-icon-receipt.js.map