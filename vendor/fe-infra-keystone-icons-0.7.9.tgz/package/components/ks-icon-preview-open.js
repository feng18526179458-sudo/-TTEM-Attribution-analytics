import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconPreviewOpen$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconPreviewOpen$1 =

    proxyCustomElement(class KsIconPreviewOpen extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-preview-open';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '03a8b17eb8d1085aeee11c9c39e2e7f756050990', class: "ks-icon", "ks-icon": true }, h("svg", { key: '32ecd9ea2c0c5bb167576ecc33150d4d62b5c7be', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'f33c2c92f59bacfcf38d36c6ae47c3506c65e23f', d: "M5.999 23.729C8.901 16.848 15.867 12 23.999 12s15.098 4.847 18 11.729m-36 0c2.74 7.17 9.765 12.271 18 12.271s15.26-5.101 18-12.271", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("circle", { key: '129fee58404b6ee2277065af59cdc13da073d0a1', cx: "24", cy: "24", fill: icon.color, r: "7" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-preview-open"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconPreviewOpen$1;},KsIconPreviewOpen$1 = GetKsIconPreviewOpen$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-preview-open"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-preview-open":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconPreviewOpen$1(transTagName));
        }
        break;
    }});
}

const KsIconPreviewOpen = KsIconPreviewOpen$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconPreviewOpen, defineCustomElement };
//# sourceMappingURL=ks-icon-preview-open.js.map
//# sourceMappingURL=ks-icon-preview-open.js.map