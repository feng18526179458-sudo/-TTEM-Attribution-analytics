import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconClose$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconClose$1 =

    proxyCustomElement(class KsIconClose extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-close';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '06c3c95461899c241f5a7136a5d6bfc2838cc2ce', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'e1666cd7b1ff74e1485d2b6c5cdf6e79a74a1af9', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: '667d29ac1d4c870ef73e2bcebf703fe27fce6af4', d: "M9.001 9l30 30" }), h("path", { key: '0c0d199805e83a587b54cc23ed6da4ae4ed4689f', d: "M9.001 39l30-30" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-close"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconClose$1;},KsIconClose$1 = GetKsIconClose$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-close"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-close":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconClose$1(transTagName));
        }
        break;
    }});
}

const KsIconClose = KsIconClose$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconClose, defineCustomElement };
//# sourceMappingURL=ks-icon-close.js.map
//# sourceMappingURL=ks-icon-close.js.map