import type { Components, JSX } from "../dist/types/components";

interface KsIconFilledInfo extends Components.KsIconFilledInfo, HTMLElement {}
export const KsIconFilledInfo: {
    prototype: KsIconFilledInfo;
    new (): KsIconFilledInfo;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
