import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconTips$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconTips$1 =

    proxyCustomElement(class KsIconTips extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-tips';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'f9da71d65bbda221b85f14e70c9076ce62178747', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'ea712b757247486c8a76183495cb9497a6064c2c', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '3aeb8488b68011e2e93e4390c5f022d912f341aa', d: "M24.4468 23.9858V19.712M24.4468 19.712L20.7305 15.9966M24.4468 19.712L28.1622 15.996", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '2ae299c373b758f2aec699471178a281eeabd9ed', d: "M20.4034 40.8251H28.489", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '614ff623d072de1626de562295e88143f6231ea6', d: "M24.4463 5.99088C32.1781 5.99088 38.4463 11.4807 38.4463 18.2526C38.4461 22.9682 35.405 27.0588 30.9482 29.11V33.9909H17.9443V29.11C13.4877 27.0587 10.4465 22.9681 10.4463 18.2526C10.4463 11.4808 16.7145 5.99094 24.4463 5.99088Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-tips"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconTips$1;},KsIconTips$1 = GetKsIconTips$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-tips"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-tips":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconTips$1(transTagName));
        }
        break;
    }});
}

const KsIconTips = KsIconTips$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconTips, defineCustomElement };
//# sourceMappingURL=ks-icon-tips.js.map
//# sourceMappingURL=ks-icon-tips.js.map