import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledInProgress$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledInProgress$1 =

    proxyCustomElement(class KsIconFilledInProgress extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-in-progress';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
        this.innerColor = '#fff';
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'f4bb853d81ee2d3c5f12641aceb4a167926d6eab', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'dabf32b4fc4c0c8749b485ec7725043bda663949', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'a25d849e597e8d29ded10bc1159520719cc24e62', d: "M43.5 24C43.5 34.77 34.77 43.5 24 43.5C13.23 43.5 4.5 34.77 4.5 24C4.5 13.23 13.23 4.5 24 4.5C34.77 4.5 43.5 13.23 43.5 24Z", fill: icon.color }), h("path", { key: '45ba000072df074a2b6371ba5ed882fbeaaf24df', d: "M24 14V24L32 28", stroke: this.innerColor, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-in-progress"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"],
      "innerColor": [1, "inner-color"]
    }]);return innerKsIconFilledInProgress$1;},KsIconFilledInProgress$1 = GetKsIconFilledInProgress$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-in-progress"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-in-progress":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledInProgress$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledInProgress = KsIconFilledInProgress$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledInProgress, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-in-progress.js.map
//# sourceMappingURL=ks-icon-filled-in-progress.js.map