import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconPreviewClose$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconPreviewClose$1 =

    proxyCustomElement(class KsIconPreviewClose extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-preview-close';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'cbe9d37c3ba1494956d6822c5e3a693094f663a9', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'e4c8e9ff514468f19156a0893692e63b0bea2518', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: icon.color, "fill-rule": "evenodd" }, h("path", { key: '7bc8742bf52521c8caa625aafef8965aa52d8938', d: "M5.072 18.254a1.5 1.5 0 0 1 2.081.411c3.903 5.825 9.989 9.494 16.752 9.494s12.851-3.671 16.756-9.494a1.5 1.5 0 0 1 2.492 1.671c-4.376 6.525-11.335 10.823-19.248 10.823S9.035 26.863 4.661 20.335a1.5 1.5 0 0 1 .411-2.081z" }), h("path", { key: '8d23e84a3faefce9469b362e538de3e65f1d4c2b', d: "M22.456 36.503v-6.132h3v6.132a1.5 1.5 0 1 1-3 0zM6.494 32.415l5.888-5.888 2.121 2.121-5.888 5.888a1.5 1.5 0 0 1-2.121-2.121zm32.869 2.122l-5.888-5.888 2.121-2.121 5.888 5.888a1.5 1.5 0 1 1-2.121 2.121z" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-preview-close"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconPreviewClose$1;},KsIconPreviewClose$1 = GetKsIconPreviewClose$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-preview-close"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-preview-close":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconPreviewClose$1(transTagName));
        }
        break;
    }});
}

const KsIconPreviewClose = KsIconPreviewClose$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconPreviewClose, defineCustomElement };
//# sourceMappingURL=ks-icon-preview-close.js.map
//# sourceMappingURL=ks-icon-preview-close.js.map