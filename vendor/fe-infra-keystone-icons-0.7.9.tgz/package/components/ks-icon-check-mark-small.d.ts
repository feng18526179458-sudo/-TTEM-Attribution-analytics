import type { Components, JSX } from "../dist/types/components";

interface KsIconCheckMarkSmall extends Components.KsIconCheckMarkSmall, HTMLElement {}
export const KsIconCheckMarkSmall: {
    prototype: KsIconCheckMarkSmall;
    new (): KsIconCheckMarkSmall;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
