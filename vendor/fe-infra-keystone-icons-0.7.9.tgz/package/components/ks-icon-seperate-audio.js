import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconSeperateAudio$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconSeperateAudio$1 =

    proxyCustomElement(class KsIconSeperateAudio extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-seperate-audio';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '335eeb26ebe5b6af97103a0b0548888d4274cf1d', class: "ks-icon", "ks-icon": true }, h("svg", { key: '9757c3ac798cf17ef32834f30dad35f07734bde4', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: 'e958a1b783520a9202d208ddb4aacb319d35abde', d: "M39.655 8.331H3.947m23.288 10.264H3.947m13.985 11.366H3.947", "stroke-linejoin": "round" }), h("path", { key: '4e2772317158cdc151dfd969fb2720f504586383', d: "M32.408 38.753c.944-4.852 1.932-13.574 2.358-17.54a2.31 2.31 0 0 1 2.296-2.065l6.991-.002M32.408 38.36c0 2.929-2.374 5.304-5.303 5.304s-5.303-2.374-5.303-5.303 2.374-5.303 5.304-5.303 5.303 2.374 5.303 5.304z" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-seperate-audio"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconSeperateAudio$1;},KsIconSeperateAudio$1 = GetKsIconSeperateAudio$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-seperate-audio"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-seperate-audio":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconSeperateAudio$1(transTagName));
        }
        break;
    }});
}

const KsIconSeperateAudio = KsIconSeperateAudio$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconSeperateAudio, defineCustomElement };
//# sourceMappingURL=ks-icon-seperate-audio.js.map
//# sourceMappingURL=ks-icon-seperate-audio.js.map