import type { Components, JSX } from "../dist/types/components";

interface KsIconBag extends Components.KsIconBag, HTMLElement {}
export const KsIconBag: {
    prototype: KsIconBag;
    new (): KsIconBag;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
