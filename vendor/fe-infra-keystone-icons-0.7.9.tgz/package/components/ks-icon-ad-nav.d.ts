import type { Components, JSX } from "../dist/types/components";

interface KsIconAdNav extends Components.KsIconAdNav, HTMLElement {}
export const KsIconAdNav: {
    prototype: KsIconAdNav;
    new (): KsIconAdNav;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
