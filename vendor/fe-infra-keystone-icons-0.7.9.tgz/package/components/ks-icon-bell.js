import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconBell$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconBell$1 =

    proxyCustomElement(class KsIconBell extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-bell';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '5f1b4b00aaac3b68837c57b0c5604ebe6e75216f', class: "ks-icon", "ks-icon": true }, h("svg", { key: '8158904cd6b080b7b566b9c9f1721611ed4e3d5a', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: 'b819f820e67aa85b7b6d6e306b176a8c18dabecc', d: "M10.871 28.875l-2.754 2.754c-1.89 1.89-.551 5.121 2.121 5.121h27.515c2.673 0 4.011-3.231 2.121-5.121l-2.754-2.754" }), h("path", { key: '76d3ae04351a5ce8383c01709be0f0bb4b68f022', d: "M29.192 36.75a5.25 5.25 0 1 1-10.5 0" }), h("path", { key: '6e102669e3e7938356122780f7dd166941cc4822', d: "M10.871 28.875h26.25", "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: '940774c4b96bb05b587eaaecb9d5596388ecadce', d: "M36 30V18c0-6.627-5.372-12-12-12h0c-6.627 0-12 5.373-12 12v12" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-bell"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconBell$1;},KsIconBell$1 = GetKsIconBell$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-bell"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-bell":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconBell$1(transTagName));
        }
        break;
    }});
}

const KsIconBell = KsIconBell$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconBell, defineCustomElement };
//# sourceMappingURL=ks-icon-bell.js.map
//# sourceMappingURL=ks-icon-bell.js.map