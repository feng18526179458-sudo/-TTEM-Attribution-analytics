import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconTitlecase$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconTitlecase$1 =

    proxyCustomElement(class KsIconTitlecase extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-titlecase';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'd88e8f81ec5a27841adae794e6ebe123ae3495ae', class: "ks-icon", "ks-icon": true }, h("svg", { key: '112b67ff994b356b6cd2a56efbda2a6b0a53abab', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'd5d8847195e1c23fb351bc2f6d4ff882581e777c', d: "M23.9765 32.2002L20.5958 24.1386M20.5958 24.1386L14.5562 9.73642L9.21343 24.1386M20.5958 24.1386H9.21343M9.21343 24.1386L6.22284 32.2002", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: '61ddb6673f0c4178c7dd0a3cf99d51fe53f00e1d', d: "M41.7772 16.268V32.9165C41.7772 38.2282 34.0152 40.0642 30.361 36.2092M41.7772 22.768C41.7772 26.3578 38.867 29.268 35.2772 29.268C31.6873 29.268 28.7772 26.3578 28.7772 22.768C28.7772 19.1781 31.6873 16.268 35.2772 16.268C38.867 16.268 41.7772 19.1781 41.7772 22.768Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-titlecase"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconTitlecase$1;},KsIconTitlecase$1 = GetKsIconTitlecase$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-titlecase"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-titlecase":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconTitlecase$1(transTagName));
        }
        break;
    }});
}

const KsIconTitlecase = KsIconTitlecase$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconTitlecase, defineCustomElement };
//# sourceMappingURL=ks-icon-titlecase.js.map
//# sourceMappingURL=ks-icon-titlecase.js.map