import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconChevronLeft$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconChevronLeft$1 =

    proxyCustomElement(class KsIconChevronLeft extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-chevron-left';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'e91e41b32782a30b7c2d26a33cbad2e7363648ad', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'f11664f72bb30f419674d4f2914853da19969cab', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'a3d4ea7d24910d43b9d8ff4bf14495da4d817122', d: "M33 6L16.061 22.939a1.5 1.5 0 0 0 0 2.121L33 42", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-chevron-left"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconChevronLeft$1;},KsIconChevronLeft$1 = GetKsIconChevronLeft$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-chevron-left"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-chevron-left":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconChevronLeft$1(transTagName));
        }
        break;
    }});
}

const KsIconChevronLeft = KsIconChevronLeft$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconChevronLeft, defineCustomElement };
//# sourceMappingURL=ks-icon-chevron-left.js.map
//# sourceMappingURL=ks-icon-chevron-left.js.map