import type { Components, JSX } from "../dist/types/components";

interface KsIconFilledPlay extends Components.KsIconFilledPlay, HTMLElement {}
export const KsIconFilledPlay: {
    prototype: KsIconFilledPlay;
    new (): KsIconFilledPlay;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
