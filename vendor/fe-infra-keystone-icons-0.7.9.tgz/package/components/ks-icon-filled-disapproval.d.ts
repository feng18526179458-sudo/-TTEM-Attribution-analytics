import type { Components, JSX } from "../dist/types/components";

interface KsIconFilledDisapproval extends Components.KsIconFilledDisapproval, HTMLElement {}
export const KsIconFilledDisapproval: {
    prototype: KsIconFilledDisapproval;
    new (): KsIconFilledDisapproval;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
