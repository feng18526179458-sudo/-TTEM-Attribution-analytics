import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconArrowDownSmall$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconArrowDownSmall$1 =

    proxyCustomElement(class KsIconArrowDownSmall extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-arrow-down-small';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'b9804e1a0c8476ab81a040ad89e764d700b15321', class: "ks-icon", "ks-icon": true }, h("svg", { key: '22f65acc159ebe0d1b66174c63cbf45e9e255862', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: 'b394079480172d9331ad4c63fb6acd90c0f34bc1', d: "M39.748 30L25.033 44.014a1.5 1.5 0 0 1-2.069 0L8.249 30", "stroke-linejoin": "round" }), h("path", { key: '75bac30a95ea6d2f48c0e86ad5d329961f386a73', d: "M23.999 42V6" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-arrow-down-small"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconArrowDownSmall$1;},KsIconArrowDownSmall$1 = GetKsIconArrowDownSmall$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-arrow-down-small"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-arrow-down-small":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconArrowDownSmall$1(transTagName));
        }
        break;
    }});
}

const KsIconArrowDownSmall = KsIconArrowDownSmall$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconArrowDownSmall, defineCustomElement };
//# sourceMappingURL=ks-icon-arrow-down-small.js.map
//# sourceMappingURL=ks-icon-arrow-down-small.js.map