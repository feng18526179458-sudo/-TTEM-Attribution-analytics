import type { Components, JSX } from "../dist/types/components";

interface KsIconAscendUp extends Components.KsIconAscendUp, HTMLElement {}
export const KsIconAscendUp: {
    prototype: KsIconAscendUp;
    new (): KsIconAscendUp;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
