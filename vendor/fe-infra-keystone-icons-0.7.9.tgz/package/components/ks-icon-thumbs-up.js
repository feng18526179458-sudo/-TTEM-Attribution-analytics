import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconThumbsUp$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconThumbsUp$1 =

    proxyCustomElement(class KsIconThumbsUp extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-thumbs-up';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '80c845aface7c1fccfe61d96e11760c6e941861c', class: "ks-icon", "ks-icon": true }, h("svg", { key: '673ccb865e2c14cfb7e082a07a96ee4408d831f6', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: '176fa2ab7f0a39167f2a115f1a0929ecdc8ade8c', d: "M13.502 18l6.506-10.121c.152-.236.413-.379.694-.379h0a3.3 3.3 0 0 1 3.3 3.3V18h14.511a1.5 1.5 0 0 1 1.442 1.912l-5.143 18A1.5 1.5 0 0 1 33.37 39H13.502V18z" }), h("path", { key: '3a51676bf02ef7f13f36cd0d50d06c71ba97746c', d: "M7.502 19.5a1.5 1.5 0 0 1 1.5-1.5h4.5v21h-4.5a1.5 1.5 0 0 1-1.5-1.5v-18z" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-thumbs-up"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconThumbsUp$1;},KsIconThumbsUp$1 = GetKsIconThumbsUp$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-thumbs-up"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-thumbs-up":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconThumbsUp$1(transTagName));
        }
        break;
    }});
}

const KsIconThumbsUp = KsIconThumbsUp$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconThumbsUp, defineCustomElement };
//# sourceMappingURL=ks-icon-thumbs-up.js.map
//# sourceMappingURL=ks-icon-thumbs-up.js.map