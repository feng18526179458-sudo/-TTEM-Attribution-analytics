import type { Components, JSX } from "../dist/types/components";

interface KsIconAddLink extends Components.KsIconAddLink, HTMLElement {}
export const KsIconAddLink: {
    prototype: KsIconAddLink;
    new (): KsIconAddLink;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
