import type { Components, JSX } from "../dist/types/components";

interface KsIconBriefcase extends Components.KsIconBriefcase, HTMLElement {}
export const KsIconBriefcase: {
    prototype: KsIconBriefcase;
    new (): KsIconBriefcase;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
