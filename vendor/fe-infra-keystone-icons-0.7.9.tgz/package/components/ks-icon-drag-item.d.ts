import type { Components, JSX } from "../dist/types/components";

interface KsIconDragItem extends Components.KsIconDragItem, HTMLElement {}
export const KsIconDragItem: {
    prototype: KsIconDragItem;
    new (): KsIconDragItem;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
