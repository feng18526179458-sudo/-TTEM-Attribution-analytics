import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconColoredFacebook$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconColoredFacebook$1 =

    proxyCustomElement(class KsIconColoredFacebook extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-colored-facebook';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '1a7e7eb2049ac0f071cabde1441d1b34fec61085', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'e7c754c02b90c1dbcf4e89e69c162ab9d299023d', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("rect", { key: 'a7f74bd19863490e3492d672f19e238febfe5db1', width: "48", height: "48", rx: "8", fill: "#0075FA" }), h("path", { key: 'b2c5150e0f20701512829994abc52191015eb06b', d: "M26.0303 36.8425C32.2457 35.8677 37 30.4891 37 24.0001C37 16.8204 31.1797 11.0001 24 11.0001C16.8203 11.0001 11 16.8204 11 24.0001C11 30.4856 15.7491 35.8618 21.9594 36.8409V27.8686H18.6374V24.0847H21.9594C21.9594 24.0847 21.9441 21.9313 21.9594 20.9725C21.9747 20.0137 22.1632 19.0908 22.6574 18.25C23.4166 16.9477 24.5986 16.3119 26.0507 16.1324C27.2826 15.9788 28.5848 16.1184 29.8007 16.3478C29.8007 16.3478 29.798 18.5032 29.8007 19.5779C29.6904 19.5759 29.5661 19.5722 29.4327 19.5682C28.8817 19.5515 28.1765 19.5303 27.676 19.6087C26.6468 19.7676 26.0558 20.429 26.0354 21.4699C26.015 22.28 26.0252 24.0847 26.0252 24.0847H29.6478L29.0619 27.8686H26.0303V36.8425Z", fill: "white" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-colored-facebook"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconColoredFacebook$1;},KsIconColoredFacebook$1 = GetKsIconColoredFacebook$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-colored-facebook"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-colored-facebook":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconColoredFacebook$1(transTagName));
        }
        break;
    }});
}

const KsIconColoredFacebook = KsIconColoredFacebook$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconColoredFacebook, defineCustomElement };
//# sourceMappingURL=ks-icon-colored-facebook.js.map
//# sourceMappingURL=ks-icon-colored-facebook.js.map