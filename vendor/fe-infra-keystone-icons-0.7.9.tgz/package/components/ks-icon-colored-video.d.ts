import type { Components, JSX } from "../dist/types/components";

interface KsIconColoredVideo extends Components.KsIconColoredVideo, HTMLElement {}
export const KsIconColoredVideo: {
    prototype: KsIconColoredVideo;
    new (): KsIconColoredVideo;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
