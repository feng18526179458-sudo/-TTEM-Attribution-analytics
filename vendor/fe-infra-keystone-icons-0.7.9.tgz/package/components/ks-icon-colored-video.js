import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconColoredVideo$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconColoredVideo$1 =

    proxyCustomElement(class KsIconColoredVideo extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-colored-video';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '0f67d75c523b2477e8d24ad27b563112c84e2b4d', class: "ks-icon", "ks-icon": true }, h("svg", { key: '641da03ea3d93b3f87f2a9515d61484e13f3f5d0', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("rect", { key: '2a1bd221592f9a188c2af5d5bb6cfe3aff1f2572', width: "48", height: "48", rx: "1.556", fill: "#f6861e" }), h("path", { key: 'cf1b2198881546b25839e16c06690a676ee04e07', "fill-rule": "evenodd", d: "M31.989 21.171a3.27 3.27 0 0 1 0 5.658l-12.174 7.028a3.27 3.27 0 0 1-4.9-2.829V16.971a3.27 3.27 0 0 1 4.9-2.829l12.174 7.028zM27.822 24l-8.374-4.835v9.669L27.822 24z", fill: "#fff" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-colored-video"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconColoredVideo$1;},KsIconColoredVideo$1 = GetKsIconColoredVideo$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-colored-video"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-colored-video":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconColoredVideo$1(transTagName));
        }
        break;
    }});
}

const KsIconColoredVideo = KsIconColoredVideo$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconColoredVideo, defineCustomElement };
//# sourceMappingURL=ks-icon-colored-video.js.map
//# sourceMappingURL=ks-icon-colored-video.js.map