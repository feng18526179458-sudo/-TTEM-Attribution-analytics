import type { Components, JSX } from "../dist/types/components";

interface KsIconCopyContent extends Components.KsIconCopyContent, HTMLElement {}
export const KsIconCopyContent: {
    prototype: KsIconCopyContent;
    new (): KsIconCopyContent;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
