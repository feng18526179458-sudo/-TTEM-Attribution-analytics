import type { Components, JSX } from "../dist/types/components";

interface KsIconBlockNone extends Components.KsIconBlockNone, HTMLElement {}
export const KsIconBlockNone: {
    prototype: KsIconBlockNone;
    new (): KsIconBlockNone;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
