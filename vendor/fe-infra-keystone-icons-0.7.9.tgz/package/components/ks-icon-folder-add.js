import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFolderAdd$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFolderAdd$1 =

    proxyCustomElement(class KsIconFolderAdd extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-folder-add';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '29c051720863a4de94ca606287750fc5f75aa187', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: 'd0517575cde874d212040e325c4b888f64bcab9a', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("g", { key: '3f9f466c7ac75c2d6e1bcd3dbb78a934b7319547', stroke: icon.color, "stroke-width": icon.strokeWidth }, h("rect", { key: '86c2e5a3a3ac423e04943bbf99c3a74d0fa254aa', x: "4.638", y: "14.22", width: "39", height: "27", rx: "1.5" }), h("g", { key: 'bfbfd8ef8583a4c9321a592579f79fb7e798ee6c', "stroke-linecap": "round" }, h("path", { key: 'f98812c71c3402a043fdd571abacbc0375e5a85b', d: "M15.709 27.719h16.5" }), h("path", { key: 'aa0d380e70be9ec855753830f1503844635537fd', d: "M23.959 19.469v16.5" }))), h("mask", { key: '928c1c2262a559fcc6215c48e94f547e0130eb9e', id: "A", fill: "#fff" }, h("path", { key: '36b1c2a4d8a1a71415e7631342e6df311836b11b', d: "M3.131 8.218a3 3 0 0 1 3-3h19.657a3 3 0 0 1 2.466 1.292l6.377 9.208h-31.5v-7.5z" })), h("path", { key: 'fc90d7c613ef7d4d165e3dca747b1f7149f5044b', d: "M34.631 15.719v3h5.727l-3.261-4.708-2.466 1.708zm-31.5 0h-3v3h3v-3zM28.254 6.51l2.466-1.708-2.466 1.708zM6.131 8.218h19.657v-6H6.131v6zm19.657 0l6.377 9.208 4.932-3.416-6.377-9.208-4.933 3.416zm8.843 4.5h-31.5v6h31.5v-6zm-28.5 3v-7.5h-6v7.5h6zm19.657-7.5h0l4.933-3.416a6 6 0 0 0-4.933-2.584v6zm-19.657-6a6 6 0 0 0-6 6h6 0v-6z", fill: icon.color, mask: "url(#A)" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-folder-add"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFolderAdd$1;},KsIconFolderAdd$1 = GetKsIconFolderAdd$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-folder-add"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-folder-add":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFolderAdd$1(transTagName));
        }
        break;
    }});
}

const KsIconFolderAdd = KsIconFolderAdd$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFolderAdd, defineCustomElement };
//# sourceMappingURL=ks-icon-folder-add.js.map
//# sourceMappingURL=ks-icon-folder-add.js.map