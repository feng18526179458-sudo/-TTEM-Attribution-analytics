import type { Components, JSX } from "../dist/types/components";

interface KsIconArrowRight extends Components.KsIconArrowRight, HTMLElement {}
export const KsIconArrowRight: {
    prototype: KsIconArrowRight;
    new (): KsIconArrowRight;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
