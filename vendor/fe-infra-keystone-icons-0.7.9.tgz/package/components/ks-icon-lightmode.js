import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconLightmode$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconLightmode$1 =

    proxyCustomElement(class KsIconLightmode extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-lightmode';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '95f2cf6a8eeaf9eefb9b59c1a7780bc5e0c35604', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'e676b8e955963fb97f3186f8dc2c9eec6a7f0ebf', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '7354e7fa8c34c7ef826543c2c1f1cde90667fbe2', d: "M23.9528 7.54535V3.54535", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: 'b68afa5ca034eb96dd36781cdce5fe30499304e7', d: "M23.9528 44.5336V40.5336", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '74cda195083caab3320a958d4b25fa553041a981', d: "M35.6174 12.3728L38.4458 9.54437", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '647aec221c7942c2d98efb359db506d3eaccbbde', d: "M9.46277 38.5275L12.2912 35.699", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: 'f4a87cf42a056a4654a81156acce5d5b5c85db63', d: "M40.4484 24.0359L44.4484 24.0359", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: 'ccc706fdc68e6ced4dfd1e8cda597102e03f9eb5', d: "M3.4602 24.0359L7.46021 24.0359", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: 'bd619dd851fddb6018d648bcfcfeab23bed75db7', d: "M35.6209 35.7005L38.4493 38.5289", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: 'b99ee9ab4ecca453b9de8d7e80ffc1008b228d6e', d: "M9.46631 9.54584L12.2947 12.3743", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("circle", { key: '8cc0f950c07a29c7e9bf3b5f561034a0b9944e26', cx: "24", cy: "24", r: "10.3639", stroke: icon.color, "stroke-width": icon.strokeWidth })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-lightmode"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconLightmode$1;},KsIconLightmode$1 = GetKsIconLightmode$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-lightmode"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-lightmode":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconLightmode$1(transTagName));
        }
        break;
    }});
}

const KsIconLightmode = KsIconLightmode$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconLightmode, defineCustomElement };
//# sourceMappingURL=ks-icon-lightmode.js.map
//# sourceMappingURL=ks-icon-lightmode.js.map