import type { Components, JSX } from "../dist/types/components";

interface KsIconColoredMessenger extends Components.KsIconColoredMessenger, HTMLElement {}
export const KsIconColoredMessenger: {
    prototype: KsIconColoredMessenger;
    new (): KsIconColoredMessenger;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
