import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconColoredPicture$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconColoredPicture$1 =

    proxyCustomElement(class KsIconColoredPicture extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-colored-picture';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'caa39955cf8fa50652ee9c2803ff21b025889877', class: "ks-icon", "ks-icon": true }, h("svg", { key: '6d9d2a3ec43fed8e599c46de14b5f3d993771059', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("rect", { key: 'feee94ddefabf8b25e9cb5dc51079207f737aa9e', width: "48", height: "48", rx: "1.556", fill: "#1bc0e4" }), h("path", { key: '21976dfd5de4a60d56ff8fd5e857798598c42105', "fill-rule": "evenodd", d: "M14.667 17.696a1.33 1.33 0 1 1 2.662 0 1.33 1.33 0 1 1-2.662 0zm1.331-5.331a5.33 5.33 0 1 0 0 10.662 5.33 5.33 0 1 0 0-10.662zm20.162 21.984c-.135.087-.316.048-.403-.087l-4.512-7-6.367 4.713c-1.104.817-2.644.678-3.584-.323l-1.558-1.659-6.037 4.528c-.129.097-.312.071-.408-.058l-2.37-3.16c-.097-.129-.07-.312.058-.408l7.345-5.509c1.104-.828 2.653-.693 3.597.313l1.565 1.667 6.627-4.905a2.71 2.71 0 0 1 3.885.709l5.567 8.639c.087.135.048.316-.087.403l-3.32 2.14z", fill: "#fff" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-colored-picture"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconColoredPicture$1;},KsIconColoredPicture$1 = GetKsIconColoredPicture$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-colored-picture"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-colored-picture":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconColoredPicture$1(transTagName));
        }
        break;
    }});
}

const KsIconColoredPicture = KsIconColoredPicture$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconColoredPicture, defineCustomElement };
//# sourceMappingURL=ks-icon-colored-picture.js.map
//# sourceMappingURL=ks-icon-colored-picture.js.map