import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconPendingConversion$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconPendingConversion$1 =

    proxyCustomElement(class KsIconPendingConversion extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-pending-conversion';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '9ef6fea1efd24cb7557c715317a5b869db94a648', class: "ks-icon", "ks-icon": true }, h("svg", { key: '44034dc22a5743d630282446cb569f6996e0a1a7', width: icon.width, height: icon.height, viewBox: "0 0 49 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'e433b51290656cbf516fed6f2c0ca86ab1420dc6', d: "M24.0027 3.11133C24.2196 3.0625 24.445 3.06252 24.6619 3.11133L41.1619 6.82617C41.8461 6.98029 42.3318 7.58864 42.3318 8.29004V27.9814C42.3317 31.4551 40.4609 34.7486 37.2615 36.7295L25.1219 44.2461C24.6381 44.5455 24.0264 44.5456 23.5428 44.2461L11.4031 36.7295C8.2037 34.7486 6.33292 31.4551 6.33279 27.9814V8.29004L6.33865 8.15918C6.39464 7.51394 6.8622 6.97059 7.50369 6.82617L24.0027 3.11133Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: '19ce539979343bb50196dedd28c8791f8013e2ec', d: "M22.5739 13.9919V25.9877L28.5718 31.9856", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-pending-conversion"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconPendingConversion$1;},KsIconPendingConversion$1 = GetKsIconPendingConversion$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-pending-conversion"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-pending-conversion":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconPendingConversion$1(transTagName));
        }
        break;
    }});
}

const KsIconPendingConversion = KsIconPendingConversion$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconPendingConversion, defineCustomElement };
//# sourceMappingURL=ks-icon-pending-conversion.js.map
//# sourceMappingURL=ks-icon-pending-conversion.js.map