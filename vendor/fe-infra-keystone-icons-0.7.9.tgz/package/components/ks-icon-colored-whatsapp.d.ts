import type { Components, JSX } from "../dist/types/components";

interface KsIconColoredWhatsapp extends Components.KsIconColoredWhatsapp, HTMLElement {}
export const KsIconColoredWhatsapp: {
    prototype: KsIconColoredWhatsapp;
    new (): KsIconColoredWhatsapp;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
