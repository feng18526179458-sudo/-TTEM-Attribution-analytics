import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilterApply$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilterApply$1 =

    proxyCustomElement(class KsIconFilterApply extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filter-apply';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'b492ad47836ae262eee8e99903b7f71dd17a95a9', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'f1796ad75c4419fc51bb203193102d39492e8541', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '4808fba47d98ed5b111e84402312ffb6d6d70faf', d: "M4.232 10.927l1.172-1.3h0l-1.172 1.3zM6.413 5.25V3.5v1.75zm35.189 0V7 5.25zm2.181 5.677l1.172 1.3h0l-1.172-1.3zM23.557 42.502l.662-1.62h0l-.662 1.62zm-1.45-.593l-.662 1.62h0l.662-1.62zm7.017-17.768l-1.172-1.3 1.172 1.3zm-10.117.104l1.172-1.3-1.172 1.3zm1.172-1.3L5.403 9.627l-2.343 2.6 14.775 13.319 2.344-2.6zM5.403 9.627C4.378 8.702 5.032 7 6.413 7V3.5c-4.587 0-6.76 5.655-3.353 8.727l2.343-2.6zM6.413 7h35.189V3.5H6.413V7zm35.189 0c1.381 0 2.035 1.702 1.009 2.627l2.343 2.6C48.362 9.155 46.189 3.5 41.602 3.5V7zm1.009 2.627L27.952 22.842l2.343 2.6 14.659-13.214-2.343-2.6zM26.298 26.561v12.926h3.5V26.561h-3.5zm0 12.926a1.51 1.51 0 0 1-2.078 1.395l-1.325 3.239a5.01 5.01 0 0 0 6.903-4.635h-3.5zm-2.078 1.395l-1.45-.593-1.325 3.239 1.45.593 1.325-3.239zm-1.45-.593a1.51 1.51 0 0 1-.937-1.395h-3.5a5.01 5.01 0 0 0 3.112 4.635l1.325-3.239zm-.937-1.395V26.665h-3.5v12.229h3.5zm6.119-16.052a5.01 5.01 0 0 0-1.655 3.719h3.5c0-.427.181-.834.498-1.12l-2.343-2.6zm-10.118 2.704a1.51 1.51 0 0 1 .498 1.12h3.5c0-1.418-.601-2.77-1.655-3.719l-2.344 2.6z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filter-apply"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFilterApply$1;},KsIconFilterApply$1 = GetKsIconFilterApply$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filter-apply"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filter-apply":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilterApply$1(transTagName));
        }
        break;
    }});
}

const KsIconFilterApply = KsIconFilterApply$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilterApply, defineCustomElement };
//# sourceMappingURL=ks-icon-filter-apply.js.map
//# sourceMappingURL=ks-icon-filter-apply.js.map