import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFollowers$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFollowers$1 =

    proxyCustomElement(class KsIconFollowers extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-followers';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '5be17dd637afffc535248d2c1f664019a9056152', class: "ks-icon", "ks-icon": true }, h("svg", { key: '076178e8f1d5bb3d33af18db117419a05d1c7400', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("circle", { key: '9f9f11c707824a215e303a7ba0cf5384bef58da1', cx: "21.334", cy: "15.117", r: "10.66" }), h("g", { key: 'a03d31d2fc40fe0110218385ebf9ecdda7756e67', "stroke-linecap": "round" }, h("path", { key: 'edb3568e8cc04876337c12445b2d9e64c16a3105', d: "M3.568 43.544a17.77 17.77 0 0 1 17.766-17.766c3.816 0 7.351 1.203 10.246 3.25" }), h("path", { key: 'fa48399ebddce473a884364d149b1f3c6b709b36', d: "M37.138 27.429v17.143M45.709 36H28.566", "stroke-linejoin": "round" }))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-followers"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFollowers$1;},KsIconFollowers$1 = GetKsIconFollowers$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-followers"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-followers":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFollowers$1(transTagName));
        }
        break;
    }});
}

const KsIconFollowers = KsIconFollowers$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFollowers, defineCustomElement };
//# sourceMappingURL=ks-icon-followers.js.map
//# sourceMappingURL=ks-icon-followers.js.map