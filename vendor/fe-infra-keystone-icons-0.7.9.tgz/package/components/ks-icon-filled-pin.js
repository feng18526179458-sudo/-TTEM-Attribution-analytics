import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledPin$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledPin$1 =

    proxyCustomElement(class KsIconFilledPin extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-pin';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'f4620e3cb9b2223b3f457cc10e2ad16081903cb9', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'c6db9cc9ed7f9ec6f8c5baa29260fa4e77ae477d', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '4aa861da985e7806ec0b76dce2beb594f278b99b', d: "M30.0504 24.0076L34 27.9853V31.8387H14L14 27.9708L18.0536 24.1151V11.979H30.0504V24.0076Z", fill: icon.color, stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" }), h("path", { key: '9de189409bc7c838c121e8850af2ffa40ba10684', d: "M25.98 39.8035V30.575H22.0244V39.8105L24.016 41.9543L25.98 39.8035Z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-pin"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFilledPin$1;},KsIconFilledPin$1 = GetKsIconFilledPin$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-pin"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-pin":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledPin$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledPin = KsIconFilledPin$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledPin, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-pin.js.map
//# sourceMappingURL=ks-icon-filled-pin.js.map