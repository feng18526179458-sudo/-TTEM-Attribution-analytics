import type { Components, JSX } from "../dist/types/components";

interface KsIconFilledLightbulb extends Components.KsIconFilledLightbulb, HTMLElement {}
export const KsIconFilledLightbulb: {
    prototype: KsIconFilledLightbulb;
    new (): KsIconFilledLightbulb;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
