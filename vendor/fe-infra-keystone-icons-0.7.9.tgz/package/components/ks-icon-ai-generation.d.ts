import type { Components, JSX } from "../dist/types/components";

interface KsIconAiGeneration extends Components.KsIconAiGeneration, HTMLElement {}
export const KsIconAiGeneration: {
    prototype: KsIconAiGeneration;
    new (): KsIconAiGeneration;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
