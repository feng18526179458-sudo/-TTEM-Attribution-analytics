import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconTiktokUi$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconTiktokUi$1 =

    proxyCustomElement(class KsIconTiktokUi extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-tiktok-ui';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'd9d327e8ea1a9fcf4e08e8839efc96b6988b9b67', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'cb50ae7230f1be69a613adc5e97755fb26c57753', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("rect", { key: 'e86896b574f82c09fcaab19e879965ca8b722430', x: "10.459", y: "2.974", width: "27.083", height: "42.052", rx: "4.929", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" }), h("path", { key: '5a7901216b9d4374e7ad6c14a6691aac5858e70a', d: "M27.692 14.624c0 2.589 2.125 4.688 4.747 4.688v3.125a7.94 7.94 0 0 1-4.747-1.562v6.511c0 3.308-2.716 5.99-6.065 5.99s-6.065-2.682-6.065-5.99 2.716-5.99 6.065-5.99c.268 0 .532.017.791.051v3.182l-.107-.028c-.218-.052-.447-.08-.684-.08-1.602 0-2.901 1.283-2.901 2.865s1.299 2.865 2.901 2.865 2.901-1.283 2.901-2.865V14.624h3.165z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-tiktok-ui"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconTiktokUi$1;},KsIconTiktokUi$1 = GetKsIconTiktokUi$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-tiktok-ui"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-tiktok-ui":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconTiktokUi$1(transTagName));
        }
        break;
    }});
}

const KsIconTiktokUi = KsIconTiktokUi$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconTiktokUi, defineCustomElement };
//# sourceMappingURL=ks-icon-tiktok-ui.js.map
//# sourceMappingURL=ks-icon-tiktok-ui.js.map