import type { Components, JSX } from "../dist/types/components";

interface KsIconFilledPause extends Components.KsIconFilledPause, HTMLElement {}
export const KsIconFilledPause: {
    prototype: KsIconFilledPause;
    new (): KsIconFilledPause;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
