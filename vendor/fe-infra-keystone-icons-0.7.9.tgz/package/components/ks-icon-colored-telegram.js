import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconColoredTelegram$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconColoredTelegram$1 =

    proxyCustomElement(class KsIconColoredTelegram extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-colored-telegram';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '69691c8db5355b7952b478ab1dee449f4237ab59', class: "ks-icon", "ks-icon": true }, h("svg", { key: '23e3363f1ec275ae1384ce57dbd2a8c4b2fb739c', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("rect", { key: '0562e44c3303a174c968bd79f45fcefc4efd7b36', width: "48", height: "48", rx: "8", fill: "#249BCE" }), h("path", { key: 'b57d5c597c22be766edb5a397314810ca767455c', d: "M13.0327 22.9892L27.9243 16.8626C29.3943 16.2244 34.3795 14.1822 34.3795 14.1822C34.3795 14.1822 36.6804 13.2888 36.4886 15.4586C36.4247 16.3521 35.9134 19.4792 35.4021 22.8616L33.8043 32.8811C33.8043 32.8811 33.6765 34.349 32.59 34.6043C31.5035 34.8595 29.7139 33.7108 29.3943 33.4555C29.1387 33.2641 24.6009 30.3922 22.9392 28.9882C22.4918 28.6053 21.9805 27.8395 23.0031 26.946C25.3039 24.84 28.0522 22.2234 29.7139 20.5641C30.4809 19.7983 31.2478 18.0114 28.0522 20.1812L19.0405 26.244C19.0405 26.244 18.0179 26.8822 16.1005 26.3078C14.1831 25.7334 11.9462 24.9676 11.9462 24.9676C11.9462 24.9676 10.4123 24.0103 13.0327 22.9892Z", fill: "white" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-colored-telegram"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconColoredTelegram$1;},KsIconColoredTelegram$1 = GetKsIconColoredTelegram$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-colored-telegram"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-colored-telegram":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconColoredTelegram$1(transTagName));
        }
        break;
    }});
}

const KsIconColoredTelegram = KsIconColoredTelegram$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconColoredTelegram, defineCustomElement };
//# sourceMappingURL=ks-icon-colored-telegram.js.map
//# sourceMappingURL=ks-icon-colored-telegram.js.map