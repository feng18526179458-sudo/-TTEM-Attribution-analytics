import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledCaution$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledCaution$1 =

    proxyCustomElement(class KsIconFilledCaution extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-caution';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
        this.innerColor = '#fff';
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '60699aa903433725fd95e7ce639334a3cc8e6f45', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'fd3ad29babedd53bbc6e7ecc31eb419486481078', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'dfdcc96b1a2b3851c984c57d79eca3ec055e9ead', part: "outer", d: "M21.0814 6.3623C22.2126 4.3623 25.0404 4.3623 26.1715 6.3623L43.9869 37.8623C45.1181 39.8623 43.7041 42.3623 41.4419 42.3623H5.81108C3.5488 42.3623 2.13489 39.8623 3.26603 37.8623L21.0814 6.3623Z", fill: icon.color }), h("path", { key: 'ef368407eb97d59c37d5db08c27a9acd6148f25e', d: "M20.9318 17.4525C20.8004 15.8432 22.0445 14.4629 23.6265 14.4629C25.2085 14.4629 26.4525 15.8432 26.3212 17.4525L25.2179 30.9681C25.1489 31.813 24.457 32.4629 23.6265 32.4629C22.7959 32.4629 22.104 31.813 22.0351 30.9681L20.9318 17.4525Z", fill: this.innerColor }), h("path", { key: '6c5987264a4c27e0a4c231606d8395dfb9601bcd', d: "M23.6265 36.9629C24.438 36.9629 25.0959 36.2913 25.0959 35.4629C25.0959 34.6345 24.438 33.9629 23.6265 33.9629C22.815 33.9629 22.1571 34.6345 22.1571 35.4629C22.1571 36.2913 22.815 36.9629 23.6265 36.9629Z", fill: this.innerColor })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-caution"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"],
      "innerColor": [1, "inner-color"]
    }]);return innerKsIconFilledCaution$1;},KsIconFilledCaution$1 = GetKsIconFilledCaution$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-caution"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-caution":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledCaution$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledCaution = KsIconFilledCaution$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledCaution, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-caution.js.map
//# sourceMappingURL=ks-icon-filled-caution.js.map