import type { Components, JSX } from "../dist/types/components";

interface KsIconContext extends Components.KsIconContext, HTMLElement {}
export const KsIconContext: {
    prototype: KsIconContext;
    new (): KsIconContext;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
