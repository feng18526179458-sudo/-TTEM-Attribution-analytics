import type { Components, JSX } from "../dist/types/components";

interface KsIconBulletedList extends Components.KsIconBulletedList, HTMLElement {}
export const KsIconBulletedList: {
    prototype: KsIconBulletedList;
    new (): KsIconBulletedList;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
