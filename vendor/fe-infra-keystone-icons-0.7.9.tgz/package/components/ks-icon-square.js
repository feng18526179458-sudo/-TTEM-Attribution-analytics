import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconSquare$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconSquare$1 =

    proxyCustomElement(class KsIconSquare extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-square';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '938d3c8c9f2ffc514a8af57cc9b91b68a9f196e3', class: "ks-icon", "ks-icon": true }, h("svg", { key: '701c32ac85a7f773c7a77bbadb7c2244fb94cf02', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("rect", { key: '00abf2ae5bcd49ddd741499d9e9c820b36ee5fe6', x: "-1.5", y: "1.5", width: "39", height: "39", rx: "1.5", transform: "matrix(-1 0 0 1 42.0001 2.99986)", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-square"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconSquare$1;},KsIconSquare$1 = GetKsIconSquare$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-square"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-square":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconSquare$1(transTagName));
        }
        break;
    }});
}

const KsIconSquare = KsIconSquare$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconSquare, defineCustomElement };
//# sourceMappingURL=ks-icon-square.js.map
//# sourceMappingURL=ks-icon-square.js.map