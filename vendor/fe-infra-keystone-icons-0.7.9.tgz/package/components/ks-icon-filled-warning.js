import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledWarning$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledWarning$1 =

    proxyCustomElement(class KsIconFilledWarning extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-warning';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
        this.innerColor = '#fff';
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '18afe129042852db22395a7d59520e540c842108', class: "ks-icon", "ks-icon": true }, h("svg", { key: '79f538a95ab3e082d2cd5cd2310d948f29274008', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("ellipse", { key: '413dfcfabf64f20cdcd645490b8b6374552b3496', cx: "24", cy: "24", rx: "19.5", ry: "19.5", fill: icon.color }), h("path", { key: '8441b686d5ee841037ee0889d90e0b5dec8d4445', d: "M20.777 13.6083C20.6205 11.73 22.1028 10.119 23.9877 10.119V10.119C25.8726 10.119 27.3549 11.73 27.1984 13.6083L25.8838 29.383C25.8016 30.3692 24.9773 31.1277 23.9877 31.1277V31.1277C22.9981 31.1277 22.1738 30.3692 22.0916 29.383L20.777 13.6083Z", fill: this.innerColor }), h("ellipse", { key: 'da8adb9cb46204bc7dbb7dea5ad4bb71d4a6cb52', cx: "24", cy: "34.6288", rx: "1.75", ry: "1.75", fill: this.innerColor })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-warning"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"],
      "innerColor": [1, "inner-color"]
    }]);return innerKsIconFilledWarning$1;},KsIconFilledWarning$1 = GetKsIconFilledWarning$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-warning"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-warning":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledWarning$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledWarning = KsIconFilledWarning$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledWarning, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-warning.js.map
//# sourceMappingURL=ks-icon-filled-warning.js.map