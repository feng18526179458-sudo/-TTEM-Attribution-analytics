import type { Components, JSX } from "../dist/types/components";

interface KsIconColoredWord extends Components.KsIconColoredWord, HTMLElement {}
export const KsIconColoredWord: {
    prototype: KsIconColoredWord;
    new (): KsIconColoredWord;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
