import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconInvalidConversion$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconInvalidConversion$1 =

    proxyCustomElement(class KsIconInvalidConversion extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-invalid-conversion';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '4b402355b34eb86a70235eda2e905ea77f2bba2b', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'a4e2d8855969b5a1ec8356cdcd1cb0ebc13a578d', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'dd71ae5eef84231fe55897f0f99f65d8abc924b3', d: "M23.6699 3.11133C23.8868 3.0625 24.1122 3.06252 24.3291 3.11133L40.8291 6.82617C41.5133 6.98029 41.999 7.58864 41.999 8.29004V27.9814C41.9989 31.4551 40.1281 34.7486 36.9287 36.7295L24.7891 44.2461C24.3053 44.5455 23.6937 44.5456 23.21 44.2461L11.0703 36.7295C7.8709 34.7486 6.00013 31.4551 6 27.9814V8.29004L6.00586 8.15918C6.06184 7.51394 6.52941 6.97059 7.1709 6.82617L23.6699 3.11133Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: 'ecc169a12e5f98769069e6ee35797b8415719a49', d: "M18.6191 18.6191L29.3801 29.3801M18.6191 29.3798L29.3801 18.6188", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-invalid-conversion"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconInvalidConversion$1;},KsIconInvalidConversion$1 = GetKsIconInvalidConversion$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-invalid-conversion"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-invalid-conversion":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconInvalidConversion$1(transTagName));
        }
        break;
    }});
}

const KsIconInvalidConversion = KsIconInvalidConversion$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconInvalidConversion, defineCustomElement };
//# sourceMappingURL=ks-icon-invalid-conversion.js.map
//# sourceMappingURL=ks-icon-invalid-conversion.js.map