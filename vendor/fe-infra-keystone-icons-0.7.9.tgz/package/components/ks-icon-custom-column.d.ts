import type { Components, JSX } from "../dist/types/components";

interface KsIconCustomColumn extends Components.KsIconCustomColumn, HTMLElement {}
export const KsIconCustomColumn: {
    prototype: KsIconCustomColumn;
    new (): KsIconCustomColumn;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
