import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledTiktokUi$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledTiktokUi$1 =

    proxyCustomElement(class KsIconFilledTiktokUi extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-tiktok-ui';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '9110658be510ecdb5c8dfd3bfe57b52a6a855496', class: "ks-icon", "ks-icon": true }, h("svg", { key: '666b117b2b43351363729ad262671c05037aae5d', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("rect", { key: '5afc24ef3d723bd8d2116e1864f0fc97b08ea6f3', x: "10.459", y: "2.974", width: "27.083", height: "42.052", rx: "4.929", fill: icon.color, stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" }), h("path", { key: 'afb876f388a4032d95282d118169967eab6c2400', d: "M27.692 14.624c0 2.589 2.125 4.688 4.747 4.688v3.125a7.94 7.94 0 0 1-4.747-1.562v6.511c0 3.308-2.716 5.99-6.065 5.99s-6.065-2.682-6.065-5.99 2.716-5.99 6.065-5.99c.268 0 .532.017.791.051v3.182l-.107-.028a2.95 2.95 0 0 0-.684-.08c-1.602 0-2.901 1.283-2.901 2.865s1.299 2.865 2.901 2.865 2.901-1.283 2.901-2.865V14.624h3.165z", fill: "#fff" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-tiktok-ui"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFilledTiktokUi$1;},KsIconFilledTiktokUi$1 = GetKsIconFilledTiktokUi$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-tiktok-ui"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-tiktok-ui":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledTiktokUi$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledTiktokUi = KsIconFilledTiktokUi$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledTiktokUi, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-tiktok-ui.js.map
//# sourceMappingURL=ks-icon-filled-tiktok-ui.js.map