import type { Components, JSX } from "../dist/types/components";

interface KsIconFilledLock extends Components.KsIconFilledLock, HTMLElement {}
export const KsIconFilledLock: {
    prototype: KsIconFilledLock;
    new (): KsIconFilledLock;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
