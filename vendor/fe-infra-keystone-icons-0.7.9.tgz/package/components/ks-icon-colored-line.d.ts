import type { Components, JSX } from "../dist/types/components";

interface KsIconColoredLine extends Components.KsIconColoredLine, HTMLElement {}
export const KsIconColoredLine: {
    prototype: KsIconColoredLine;
    new (): KsIconColoredLine;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
