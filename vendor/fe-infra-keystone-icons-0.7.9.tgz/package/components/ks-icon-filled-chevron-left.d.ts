import type { Components, JSX } from "../dist/types/components";

interface KsIconFilledChevronLeft extends Components.KsIconFilledChevronLeft, HTMLElement {}
export const KsIconFilledChevronLeft: {
    prototype: KsIconFilledChevronLeft;
    new (): KsIconFilledChevronLeft;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
