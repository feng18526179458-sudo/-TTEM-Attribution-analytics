import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconAnalytics$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconAnalytics$1 =

    proxyCustomElement(class KsIconAnalytics extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-analytics';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'c5a542b60d11f3c0ccbfa24e86e47984c160ef9f', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'abd95d3802f1e2f348c5c22888d87f01fb282ce2', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: '0c9075805edf38556e46657a6f0e5c0736c48ece', d: "M22.058 7.462h0c-10.206 0-18.48 8.274-18.48 18.48h0c0 10.206 8.274 18.48 18.48 18.48h0c10.206 0 18.48-8.274 18.48-18.48h0M23.558 3.973c10.966.738 19.732 9.504 20.47 20.47h-20.47V3.973z" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-analytics"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconAnalytics$1;},KsIconAnalytics$1 = GetKsIconAnalytics$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-analytics"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-analytics":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconAnalytics$1(transTagName));
        }
        break;
    }});
}

const KsIconAnalytics = KsIconAnalytics$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconAnalytics, defineCustomElement };
//# sourceMappingURL=ks-icon-analytics.js.map
//# sourceMappingURL=ks-icon-analytics.js.map