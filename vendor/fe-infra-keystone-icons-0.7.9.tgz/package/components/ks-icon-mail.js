import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconMail$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconMail$1 =

    proxyCustomElement(class KsIconMail extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-mail';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'b5e91c1131951808e89a4012d37c37b67a79a0ee', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'bf02ec1a06bb76699fa765cd60e69130db76dc76', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("rect", { key: '54f210aa5b846d97f4b2dc3b317203062cdaa05a', x: "4.5", y: "10.5", width: "39", height: "27", rx: "1.5" }), h("path", { key: 'db1222f2f0cc4d8316955196685e27c41de536d1', d: "M10.5 18l12.891 5.729a1.5 1.5 0 0 0 1.218 0L37.5 18", "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-mail"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconMail$1;},KsIconMail$1 = GetKsIconMail$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-mail"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-mail":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconMail$1(transTagName));
        }
        break;
    }});
}

const KsIconMail = KsIconMail$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconMail, defineCustomElement };
//# sourceMappingURL=ks-icon-mail.js.map
//# sourceMappingURL=ks-icon-mail.js.map