import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconPenTool$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconPenTool$1 =

    proxyCustomElement(class KsIconPenTool extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-pen-tool';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '4e5afbeee1a6e2fe9c305550e920b99146071ec8', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'b627415bbfd7a2958394d687d66f3113fbd94cc7', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '0d97a6012298ecbd0f4a094b3e9fc07a437909ad', d: "M21.6133 19.0723L21.834 19.1006C24.8701 19.6698 28.9696 20.5383 32.6943 21.6573C34.5572 22.2169 36.2976 22.8311 37.7519 23.4893C39.2323 24.1593 40.3018 24.8253 40.9199 25.4434C43.0248 27.5483 44.0423 30.327 43.9707 33.088L43.9424 33.6397C43.908 34.0772 44.0667 34.5081 44.3769 34.8184C44.9056 35.3472 44.9057 36.2047 44.3769 36.7335L37.4639 43.6465C36.9351 44.1753 36.0776 44.1752 35.5488 43.6465C35.2774 43.3751 34.9138 43.2197 34.5342 43.2081L34.3701 43.212C31.4309 43.4432 28.419 42.4347 26.1738 40.1895C25.5557 39.5714 24.8897 38.5019 24.2197 37.0215C23.5615 35.5672 22.9473 33.8268 22.3877 31.9639C21.4086 28.7048 20.6214 25.1586 20.0586 22.2891L19.831 21.1036C19.7247 20.5364 19.8846 20.0289 20.1973 19.6612L20.3408 19.5118C20.6644 19.2139 21.1079 19.0371 21.6133 19.0723Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" }), h("path", { key: '6f3e8ab5f5537256f6b579927c90c652c57a2eae', d: "M20.0022 19.4176L33.6923 33.1077", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" }), h("path", { key: 'd4dd621cc6ab412dbcd66c2ca88d500d78caa3dd', d: "M31.5374 30.807C32.291 30.0534 33.5122 30.0535 34.2659 30.807C35.0195 31.5606 35.0195 32.7818 34.2659 33.5355C33.5123 34.2891 32.291 34.2891 31.5374 33.5355C30.7839 32.7818 30.7838 31.5606 31.5374 30.807Z", fill: icon.color, stroke: icon.color, "stroke-width": icon.strokeWidth }), h("path", { key: '25ad21c5a1bb95b9ff8d9b3bbd2d2451a34bd48d', d: "M6.38047 34.4469C5.81635 19.1354 18.3808 6.57091 33.6923 7.13502", stroke: icon.color, "stroke-width": icon.strokeWidth }), h("path", { key: '8e703350af270c7ae88180f9dfaca1c7ca202a18', d: "M35.0315 5.36854C36.2866 4.11338 38.322 4.11288 39.5772 5.36784C40.8325 6.6231 40.8325 8.65906 39.5772 9.91432C38.322 11.1693 36.2866 11.1688 35.0315 9.91363C33.7766 8.65845 33.7766 6.62372 35.0315 5.36854Z", fill: icon.color, stroke: icon.color, "stroke-width": icon.strokeWidth }), h("path", { key: '0ef85ee25c0b6e49302b5388d3781c5bfadf8106', d: "M4.40777 35.7618C5.66293 34.5067 7.69828 34.5062 8.95356 35.7612C10.2088 37.0164 10.2088 39.0524 8.95356 40.3076C7.69828 41.5626 5.66293 41.5621 4.40777 40.3069C3.15291 39.0518 3.15291 37.017 4.40777 35.7618Z", fill: icon.color, stroke: icon.color, "stroke-width": icon.strokeWidth })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-pen-tool"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconPenTool$1;},KsIconPenTool$1 = GetKsIconPenTool$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-pen-tool"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-pen-tool":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconPenTool$1(transTagName));
        }
        break;
    }});
}

const KsIconPenTool = KsIconPenTool$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconPenTool, defineCustomElement };
//# sourceMappingURL=ks-icon-pen-tool.js.map
//# sourceMappingURL=ks-icon-pen-tool.js.map