import type { Components, JSX } from "../dist/types/components";

interface KsIconEngage extends Components.KsIconEngage, HTMLElement {}
export const KsIconEngage: {
    prototype: KsIconEngage;
    new (): KsIconEngage;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
