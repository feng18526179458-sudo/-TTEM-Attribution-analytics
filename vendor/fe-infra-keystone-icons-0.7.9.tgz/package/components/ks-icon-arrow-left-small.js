import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconArrowLeftSmall$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconArrowLeftSmall$1 =

    proxyCustomElement(class KsIconArrowLeftSmall extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-arrow-left-small';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'c9289e2768aaa595aac7ba89b9804724b32944a2', class: "ks-icon", "ks-icon": true }, h("svg", { key: '1f821b0d5f833a2767010fcf1afbba2ee7ab255d', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: '63bf5b6730b60d30c1b549f1eb783cf45e0dc8df', d: "M17.999 39.75L3.985 25.034a1.5 1.5 0 0 1 0-2.069L17.999 8.25", "stroke-linejoin": "round" }), h("path", { key: '3fb36cddc4225a760f7b2b1867fdc91dc98a11c3', d: "M5.998 24h36" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-arrow-left-small"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconArrowLeftSmall$1;},KsIconArrowLeftSmall$1 = GetKsIconArrowLeftSmall$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-arrow-left-small"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-arrow-left-small":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconArrowLeftSmall$1(transTagName));
        }
        break;
    }});
}

const KsIconArrowLeftSmall = KsIconArrowLeftSmall$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconArrowLeftSmall, defineCustomElement };
//# sourceMappingURL=ks-icon-arrow-left-small.js.map
//# sourceMappingURL=ks-icon-arrow-left-small.js.map