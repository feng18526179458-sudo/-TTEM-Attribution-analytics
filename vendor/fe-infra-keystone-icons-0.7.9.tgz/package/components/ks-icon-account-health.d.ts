import type { Components, JSX } from "../dist/types/components";

interface KsIconAccountHealth extends Components.KsIconAccountHealth, HTMLElement {}
export const KsIconAccountHealth: {
    prototype: KsIconAccountHealth;
    new (): KsIconAccountHealth;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
