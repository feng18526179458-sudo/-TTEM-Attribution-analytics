import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFold$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFold$1 =

    proxyCustomElement(class KsIconFold extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-fold';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '4385d9200ad752cf6a3d881533df788c4f8efbc5', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'f3bf80f88a7d48c815418bd2d08dbf3aad4c88d5', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'd3b744ed54c2331a53e9d1a130679a58a16ed625', d: "M5.995 39h36m-21-15.126h21m-21-15h21", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '0a943e117f133ae0ffba82c8e43a5c29d745235c', d: "M16.866 14.956L8.634 8.478c-1.092-.86-2.638-.029-2.638 1.418v12.956c0 1.447 1.546 2.278 2.638 1.418l8.232-6.478c.895-.705.895-2.131 0-2.836z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-fold"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFold$1;},KsIconFold$1 = GetKsIconFold$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-fold"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-fold":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFold$1(transTagName));
        }
        break;
    }});
}

const KsIconFold = KsIconFold$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFold, defineCustomElement };
//# sourceMappingURL=ks-icon-fold.js.map
//# sourceMappingURL=ks-icon-fold.js.map