import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledPlay$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledPlay$1 =

    proxyCustomElement(class KsIconFilledPlay extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-play';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'e4904b74716f4c166780f5bbb9565b2286e4df74', class: "ks-icon", "ks-icon": true }, h("svg", { key: '3259e8256de029985297776df39836292db2a411', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '254d0d152f995fe5f832f9c1fbd389e8ccf19115', d: "M13.3796 10.0664C13.38 8.16632 15.5432 7.0755 17.0715 8.20462L35.9302 22.1369C37.1829 23.0623 37.1827 24.9363 35.9302 25.8619L17.0715 39.7941C15.543 40.9234 13.3796 39.8327 13.3796 37.9324V10.0664Z", fill: "#262627" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-play"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFilledPlay$1;},KsIconFilledPlay$1 = GetKsIconFilledPlay$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-play"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-play":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledPlay$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledPlay = KsIconFilledPlay$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledPlay, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-play.js.map
//# sourceMappingURL=ks-icon-filled-play.js.map