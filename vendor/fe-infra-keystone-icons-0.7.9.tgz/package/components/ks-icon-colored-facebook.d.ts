import type { Components, JSX } from "../dist/types/components";

interface KsIconColoredFacebook extends Components.KsIconColoredFacebook, HTMLElement {}
export const KsIconColoredFacebook: {
    prototype: KsIconColoredFacebook;
    new (): KsIconColoredFacebook;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
