import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconVolumeMute$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconVolumeMute$1 =

    proxyCustomElement(class KsIconVolumeMute extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-volume-mute';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'ba988faac720cec3b0fb30edcc67d45427d5d6ea', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: 'f743f3c5d802e75bbee07107b8a1923d8fbbcf25', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: 'e5caa943be261eb3ab3a0da26101741ebf83bff9', d: "M10.46 15.957a2.96 2.96 0 0 0-2.958 2.958v11.01a2.96 2.96 0 0 0 2.958 2.958h4.143a1.97 1.97 0 0 1 1.441.625l8.751 9.363c1.222 1.307 3.413.443 3.413-1.347V6.476c0-1.828-2.272-2.672-3.466-1.287l-8.692 10.084a1.97 1.97 0 0 1-1.494.684H10.46z" }), h("g", { key: '0a7222a5818385fafa0ec8a0b90ab246f3e80eaf', "stroke-linecap": "round" }, h("path", { key: '371d8f383e8ae1f76312f8e79d2e4477effa80ed', d: "M35.327 19.5l9 9" }), h("path", { key: 'faac15944265e4fc562e18999e1818ab4e9436bf', d: "M35.287 28.5l9-9" }))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-volume-mute"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconVolumeMute$1;},KsIconVolumeMute$1 = GetKsIconVolumeMute$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-volume-mute"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-volume-mute":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconVolumeMute$1(transTagName));
        }
        break;
    }});
}

const KsIconVolumeMute = KsIconVolumeMute$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconVolumeMute, defineCustomElement };
//# sourceMappingURL=ks-icon-volume-mute.js.map
//# sourceMappingURL=ks-icon-volume-mute.js.map