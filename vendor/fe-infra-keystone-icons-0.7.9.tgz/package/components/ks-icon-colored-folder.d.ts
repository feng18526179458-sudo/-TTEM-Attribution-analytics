import type { Components, JSX } from "../dist/types/components";

interface KsIconColoredFolder extends Components.KsIconColoredFolder, HTMLElement {}
export const KsIconColoredFolder: {
    prototype: KsIconColoredFolder;
    new (): KsIconColoredFolder;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
