import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconMoreHorizontal$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconMoreHorizontal$1 =

    proxyCustomElement(class KsIconMoreHorizontal extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-more-horizontal';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '46372852f42fad42f7c808b71bcb530588095a1b', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'fcbc7c46860e718c9ef1fa1912f300aad88af3a9', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: icon.color }, h("circle", { key: 'b23a06129595ebbadba60c39b118545dc957170d', cx: "24.011", cy: "24", r: "3" }), h("circle", { key: '94f25990bc54f15c8aabd3f979ecbd8cba4747ce', cx: "34.513", cy: "24", r: "3" }), h("circle", { key: '1d0a8a9e2fa47ca39d76165bc191fbbab547404b', cx: "13.509", cy: "24", r: "3" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-more-horizontal"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconMoreHorizontal$1;},KsIconMoreHorizontal$1 = GetKsIconMoreHorizontal$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-more-horizontal"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-more-horizontal":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconMoreHorizontal$1(transTagName));
        }
        break;
    }});
}

const KsIconMoreHorizontal = KsIconMoreHorizontal$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconMoreHorizontal, defineCustomElement };
//# sourceMappingURL=ks-icon-more-horizontal.js.map
//# sourceMappingURL=ks-icon-more-horizontal.js.map