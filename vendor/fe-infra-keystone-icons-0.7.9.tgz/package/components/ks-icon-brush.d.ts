import type { Components, JSX } from "../dist/types/components";

interface KsIconBrush extends Components.KsIconBrush, HTMLElement {}
export const KsIconBrush: {
    prototype: KsIconBrush;
    new (): KsIconBrush;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
