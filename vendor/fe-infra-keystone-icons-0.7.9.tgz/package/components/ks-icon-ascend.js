import { proxyCustomElement, HTMLElement, createEvent, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconAscend$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconAscend$1 =

    proxyCustomElement(class KsIconAscend extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this.triangleUpClick = createEvent(this, "triangleUpClick", 7);
        this.triangleDownClick = createEvent(this, "triangleDownClick", 7);
        this['ks-icon-name'] = 'ks-icon-ascend';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'ab3cd0619d88dffe4ffa00dabfef4bee6cb9d426', class: "ks-icon", "ks-icon": true }, h("svg", { key: '79904ae4ffbca953ba4f17b5f17126e997471428', width: icon.width, height: icon.height, viewBox: "0 0 48 48", xmlns: "http://www.w3.org/2000/svg", "stroke-width": icon.strokeWidth, "stroke-linejoin": "round", stroke: icon.color }, h("path", { key: '746a3413d7cf4760230a580e0c721dc51b97b2dd', part: "triangleUp", fill: "transparent", d: "M25.5589 6.42591C25.2287 6.07567 24.7688 5.8769 24.2875 5.87637C23.8061 5.87583 23.3458 6.07359 23.0149 6.4231L12.8771 17.1289C12.3963 17.6366 12.2639 18.3816 12.5402 19.0238C12.8165 19.6661 13.4486 20.0822 14.1477 20.0822H24.2631H34.3785C35.0769 20.0822 35.7085 19.6669 35.9852 19.0256C36.262 18.3843 36.1309 17.6399 35.6518 17.1317L25.5589 6.42591Z", onClick: () => this.triangleUpClick.emit() }), h("path", { key: 'b7e4a64bce7b251bc9aa22b77b1f43e09998d973', part: "triangleDown", fill: "transparent", d: "M25.559 41.9887C25.2288 42.339 24.7689 42.5377 24.2876 42.5383C23.8062 42.5388 23.3459 42.3411 23.015 41.9915L12.8772 31.2857C12.3964 30.7781 12.264 30.033 12.5403 29.3908C12.8167 28.7486 13.4487 28.3325 14.1478 28.3325H24.2632H34.3786C35.077 28.3325 35.7086 28.7478 35.9853 29.389C36.2621 30.0303 36.131 30.7747 35.6519 31.2829L25.559 41.9887Z", onClick: () => this.triangleDownClick.emit() })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-ascend"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconAscend$1;},KsIconAscend$1 = GetKsIconAscend$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-ascend"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-ascend":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconAscend$1(transTagName));
        }
        break;
    }});
}

const KsIconAscend = KsIconAscend$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconAscend, defineCustomElement };
//# sourceMappingURL=ks-icon-ascend.js.map
//# sourceMappingURL=ks-icon-ascend.js.map