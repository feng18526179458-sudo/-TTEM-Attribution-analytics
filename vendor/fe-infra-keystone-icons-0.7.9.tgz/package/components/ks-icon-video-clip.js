import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconVideoClip$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconVideoClip$1 =

    proxyCustomElement(class KsIconVideoClip extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-video-clip';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '6a75c9ff686be893d73087abf6c68d7df0b77fcf', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'f0ff3cd31fd35e7ec350579ae66f1adf9d34e985', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '5d634ac1a06fe86feade0a84cd1ef66747a7607c', d: "M29.636 25.709l-7.461-5.512c-.99-.732-2.391-.025-2.391 1.206v11.024c0 1.231 1.401 1.938 2.391 1.206l7.461-5.512a1.5 1.5 0 0 0 0-2.413z", fill: icon.color }), h("g", { key: '07bfb2342e280b3a039cb85c977653b476f8af9d', stroke: icon.color, "stroke-width": icon.strokeWidth }, h("rect", { key: '21b28d8c1b2a134b86d8e474b159e630d3baa716', x: "4.5", y: "8.27", width: "39", height: "30", rx: "1.5" }), h("path", { key: 'f419068ce4d26f5f81c779b1631061aa9c290694', d: "M4.5 15.77h39m-29.994 0l7.5-7.5" }), h("path", { key: '09483a82aa9fe998209cbba09bbf53f1057e6f54', d: "M28.501 15.77l7.5-7.5" }))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-video-clip"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconVideoClip$1;},KsIconVideoClip$1 = GetKsIconVideoClip$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-video-clip"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-video-clip":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconVideoClip$1(transTagName));
        }
        break;
    }});
}

const KsIconVideoClip = KsIconVideoClip$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconVideoClip, defineCustomElement };
//# sourceMappingURL=ks-icon-video-clip.js.map
//# sourceMappingURL=ks-icon-video-clip.js.map