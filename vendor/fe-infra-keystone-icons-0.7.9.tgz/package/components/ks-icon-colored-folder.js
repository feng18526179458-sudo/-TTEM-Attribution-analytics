import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconColoredFolder$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconColoredFolder$1 =

    proxyCustomElement(class KsIconColoredFolder extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-colored-folder';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '1d5968044dfd3b1c52ea57ace92fdf11ac315933', class: "ks-icon", "ks-icon": true }, h("svg", { key: '639fd54b0925c29b53f135471ac97a03f789db97', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("rect", { key: '82faff9f102a7f940628d1550b5dfeefdd22c5f9', width: "48", height: "48", rx: "1.556", fill: "#f6ba1e" }), h("g", { key: 'bae7c34c2ebcca83fea787f4fb48bd21b4ad746e', "fill-rule": "evenodd", fill: "#fff" }, h("path", { key: '7641b9ea51527637f3e70a12aadee862e1225493', d: "M8.4 20.333c0-1.804 1.463-3.267 3.267-3.267h24.667c1.804 0 3.267 1.462 3.267 3.267v14a3.27 3.27 0 0 1-3.267 3.267H11.667A3.27 3.27 0 0 1 8.4 34.333v-14zm4.533 1.267v11.467h22.133V21.6H12.933z" }), h("path", { key: 'f7e7d01be83a8ae22e6f9ea7b6f4ea0c8c4c14cc', opacity: ".55", d: "M8.4 13.666c0-1.804 1.463-3.267 3.267-3.267h11.171c1.256 0 2.401.72 2.945 1.853l4.487 9.347H8.4v-7.933zm4.533 1.267v2.133h10.131l-1.024-2.133h-9.107z" }))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-colored-folder"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconColoredFolder$1;},KsIconColoredFolder$1 = GetKsIconColoredFolder$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-colored-folder"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-colored-folder":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconColoredFolder$1(transTagName));
        }
        break;
    }});
}

const KsIconColoredFolder = KsIconColoredFolder$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconColoredFolder, defineCustomElement };
//# sourceMappingURL=ks-icon-colored-folder.js.map
//# sourceMappingURL=ks-icon-colored-folder.js.map