import type { Components, JSX } from "../dist/types/components";

interface KsIconFilledCamera extends Components.KsIconFilledCamera, HTMLElement {}
export const KsIconFilledCamera: {
    prototype: KsIconFilledCamera;
    new (): KsIconFilledCamera;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
