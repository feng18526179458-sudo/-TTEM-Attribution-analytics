import type { Components, JSX } from "../dist/types/components";

interface KsIconCompare extends Components.KsIconCompare, HTMLElement {}
export const KsIconCompare: {
    prototype: KsIconCompare;
    new (): KsIconCompare;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
