import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconEdit$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconEdit$1 =

    proxyCustomElement(class KsIconEdit extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-edit';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '28d5046fc57fcae4a22bd9c6389742d78b098ddc', class: "ks-icon", "ks-icon": true }, h("svg", { key: '5cf99235fccb2896b44cc9a2ce53f2feaf7248ff', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("g", { key: '0ac8a6d7a5fe0c47715dc9bbb916bd477e64d4b2', "stroke-linejoin": "round" }, h("path", { key: 'e673cd5dc5cce97f9a3c49c6eb8914aca9dbbca7', d: "M10.386 36.577l.001-6.967L30.476 9.543c2.243-2.24 5.877-2.239 8.118.002s2.242 5.878 0 8.12L18.511 37.749l-6.86.078a1.25 1.25 0 0 1-1.264-1.25z" }), h("path", { key: 'b54222ff6ce6c735e5a09d5f911ee6cb56c61fe5', d: "M36.038 19.5l-7.659-7.659", "stroke-linecap": "round" })), h("path", { key: 'f03b9268ff8610e7548c448134274b1370a41894', d: "M7.558 43.5h33", "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-edit"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconEdit$1;},KsIconEdit$1 = GetKsIconEdit$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-edit"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-edit":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconEdit$1(transTagName));
        }
        break;
    }});
}

const KsIconEdit = KsIconEdit$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconEdit, defineCustomElement };
//# sourceMappingURL=ks-icon-edit.js.map
//# sourceMappingURL=ks-icon-edit.js.map