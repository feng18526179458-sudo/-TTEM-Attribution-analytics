import type { Components, JSX } from "../dist/types/components";

interface KsIconDoubleChevronLeft extends Components.KsIconDoubleChevronLeft, HTMLElement {}
export const KsIconDoubleChevronLeft: {
    prototype: KsIconDoubleChevronLeft;
    new (): KsIconDoubleChevronLeft;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
