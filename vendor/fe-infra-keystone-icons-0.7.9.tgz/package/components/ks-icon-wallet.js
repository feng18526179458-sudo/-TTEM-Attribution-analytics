import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconWallet$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconWallet$1 =

    proxyCustomElement(class KsIconWallet extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-wallet';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '68b011345598b000d3356f90272e106f7b410d41', class: "ks-icon", "ks-icon": true }, h("svg", { key: '9ab86bbdb38125a0107aeb4a4da75419552d58f2', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'c75ae6d2e74c4a0582cbcb1d16adfc26657679a9', d: "M4.62891 15.3234H39.3714C41.5806 15.3234 43.3714 17.1142 43.3714 19.3234V38.671C43.3714 40.8802 41.5806 42.671 39.3714 42.671H8.6289C6.41976 42.671 4.62891 40.8802 4.62891 38.671V15.3234Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" }), h("path", { key: '78704b4237d3e8a6c157c4464efbd6d54ad03fa9', d: "M4.62891 15.3234C11.7417 12.6829 25.0496 8.16863 32.4215 5.68865C35.0088 4.81824 37.674 6.74707 37.674 9.4769V14.058", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("circle", { key: '864d2770f95d96812478fef26bd2613f5d962111', cx: "33.2303", cy: "27.0335", r: "1.54953", fill: icon.color, stroke: icon.color, "stroke-width": icon.strokeWidth }), h("line", { key: '85514d01de5f6201d1f4f2c419d4e498331aefa8', x1: "12.7408", y1: "35.3365", x2: "28.5037", y2: "35.3365", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-wallet"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconWallet$1;},KsIconWallet$1 = GetKsIconWallet$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-wallet"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-wallet":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconWallet$1(transTagName));
        }
        break;
    }});
}

const KsIconWallet = KsIconWallet$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconWallet, defineCustomElement };
//# sourceMappingURL=ks-icon-wallet.js.map
//# sourceMappingURL=ks-icon-wallet.js.map