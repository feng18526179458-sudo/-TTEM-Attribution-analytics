import type { Components, JSX } from "../dist/types/components";

interface KsIconChart extends Components.KsIconChart, HTMLElement {}
export const KsIconChart: {
    prototype: KsIconChart;
    new (): KsIconChart;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
