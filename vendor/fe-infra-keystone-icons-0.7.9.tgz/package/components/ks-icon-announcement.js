import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconAnnouncement$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconAnnouncement$1 =

    proxyCustomElement(class KsIconAnnouncement extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-announcement';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'b8eda4dce22cb8a35ec5fcc66b9bb178ffeced03', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: '4b4544540777e24b2e4ead9b11e6baaa28c7829b', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: '6c49bfad11a8d33e85d2d4c22a476d85853dd132', d: "M5.998 38.87c-1.182-1.791-.896-4.174.675-5.636l23.03-21.42a.23.23 0 0 1 .255-.04l.55.258c6.862 3.222 10.891 10.49 10.005 18.02h0c-.011.093-.074.171-.161.202L11.131 40.592c-1.903.673-4.021-.037-5.133-1.723h0z" }), h("path", { key: 'fdb6e786d14c33ce9944c3a31432b3ed6042e665', d: "M24.869 36.928a5.21 5.21 0 0 1-3.266 6.603A5.21 5.21 0 0 1 15 40.266m0-24.903l-6-1.5m13.5-4.5l-1.5-4.5m15 4.5l3-4.5", "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-announcement"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconAnnouncement$1;},KsIconAnnouncement$1 = GetKsIconAnnouncement$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-announcement"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-announcement":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconAnnouncement$1(transTagName));
        }
        break;
    }});
}

const KsIconAnnouncement = KsIconAnnouncement$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconAnnouncement, defineCustomElement };
//# sourceMappingURL=ks-icon-announcement.js.map
//# sourceMappingURL=ks-icon-announcement.js.map