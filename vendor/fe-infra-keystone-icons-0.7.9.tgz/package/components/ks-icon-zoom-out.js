import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconZoomOut$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconZoomOut$1 =

    proxyCustomElement(class KsIconZoomOut extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-zoom-out';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '212ed440a372b67825d7f8fe7003bd1cbe33d8f9', class: "ks-icon", "ks-icon": true }, h("svg", { key: '1219eda3c879565b486cebe9a6b3a78f4a2bf997', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'a12122fd24051ee2549f8d327a078991157b2139', d: "M37.5 21c0 9.113-7.387 16.5-16.5 16.5S4.5 30.113 4.5 21 11.887 4.5 21 4.5 37.5 11.887 37.5 21z", stroke: icon.color, "stroke-width": icon.strokeWidth }), h("path", { key: 'afe2a5a2e52ee80a85183863b7fe81ea42213580', d: "M34.061 31.939L33 30.879 30.879 33l1.061 1.061 2.121-2.121zm9.879 14.121a1.5 1.5 0 0 0 2.121-2.121l-2.121 2.121zm-12-12l12 12 2.121-2.121-12-12-2.121 2.121z", fill: icon.color }), h("path", { key: '9f8630efa828efafa920f7f796a82641dbb86128', d: "M13.506 21h15", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-zoom-out"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconZoomOut$1;},KsIconZoomOut$1 = GetKsIconZoomOut$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-zoom-out"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-zoom-out":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconZoomOut$1(transTagName));
        }
        break;
    }});
}

const KsIconZoomOut = KsIconZoomOut$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconZoomOut, defineCustomElement };
//# sourceMappingURL=ks-icon-zoom-out.js.map
//# sourceMappingURL=ks-icon-zoom-out.js.map