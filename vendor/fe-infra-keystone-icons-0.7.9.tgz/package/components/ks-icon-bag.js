import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconBag$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconBag$1 =

    proxyCustomElement(class KsIconBag extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-bag';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'e847d4af5477e93d6ffee64dbd11af09ba98bd5f', class: "ks-icon", "ks-icon": true }, h("svg", { key: '8a40dcc66f64fe3fce41967ed6c86f73ba31efe8', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: 'ad1c195f84236fb1391d4a8ba824f098cb0f3b50', d: "M8.921 16.417A1.5 1.5 0 0 1 10.419 15h27.162a1.5 1.5 0 0 1 1.498 1.417l1.333 24A1.5 1.5 0 0 1 38.914 42H9.086a1.5 1.5 0 0 1-1.498-1.583l1.333-24z" }), h("path", { key: '522c4b94066e67d5c0f2a12e9e6c0a04f91e4689', d: "M33 15a9 9 0 0 0-18 0m0 4.5a9 9 0 0 0 18 0" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-bag"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconBag$1;},KsIconBag$1 = GetKsIconBag$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-bag"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-bag":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconBag$1(transTagName));
        }
        break;
    }});
}

const KsIconBag = KsIconBag$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconBag, defineCustomElement };
//# sourceMappingURL=ks-icon-bag.js.map
//# sourceMappingURL=ks-icon-bag.js.map