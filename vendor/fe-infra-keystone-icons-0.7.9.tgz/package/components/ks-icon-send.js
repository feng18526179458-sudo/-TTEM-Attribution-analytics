import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconSend$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconSend$1 =

    proxyCustomElement(class KsIconSend extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-send';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '936ba7a9a0812d40083049b4005a05c77f609c31', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'e67da8023c4048e873b74452e74d04bfeb0ff135', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '9b1b37286c058836750db4e2d09f1c99966094e5', d: "M43.8705 1.73122C45.438 1.11986 46.9857 2.59712 46.5092 4.16188L46.4565 4.31325L30.6 45.1404C29.9436 46.8301 27.5867 46.823 26.9057 45.2058L26.8451 45.0447L21.9487 30.24C21.4664 28.7824 20.3321 27.6328 18.8813 27.1306L2.7426 21.5457C1.04351 20.9574 0.945556 18.6273 2.51311 17.8689L2.67033 17.8006L43.8705 1.73122Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: 'd9aee01669468f9ee0004a40714dd74fbe879850', d: "M20.7997 27.6391L32.3741 16.0647", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-send"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconSend$1;},KsIconSend$1 = GetKsIconSend$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-send"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-send":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconSend$1(transTagName));
        }
        break;
    }});
}

const KsIconSend = KsIconSend$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconSend, defineCustomElement };
//# sourceMappingURL=ks-icon-send.js.map
//# sourceMappingURL=ks-icon-send.js.map