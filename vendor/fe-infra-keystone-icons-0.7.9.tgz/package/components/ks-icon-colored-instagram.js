import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconColoredInstagram$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconColoredInstagram$1 =

    proxyCustomElement(class KsIconColoredInstagram extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-colored-instagram';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'ae02ff3c7271e68b38f1891c19b0458d2790b0e0', class: "ks-icon", "ks-icon": true }, h("svg", { key: '9d1c003009cc2a24629bf6e932c0baa224c17673', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("rect", { key: 'e2a33ec9a63dc4a53834356d54befb08cd827384', width: "48", height: "48", rx: "8", fill: "url(#paint0_radial_2_167)" }), h("rect", { key: '847a6cc6951674f95626d7045420629265f44ad2', width: "48", height: "48", rx: "8", fill: "url(#paint1_radial_2_167)" }), h("path", { key: 'b63fed7719c5beac516280d915a986c5fd3a1239', d: "M24.0009 11.005C20.4703 11.005 20.0272 11.0204 18.6406 11.0835C17.2566 11.1469 16.3119 11.3659 15.4853 11.6874C14.6303 12.0193 13.905 12.4634 13.1824 13.1861C12.4593 13.9086 12.0151 14.6337 11.682 15.4883C11.3597 16.315 11.1403 17.2598 11.078 18.6429C11.0163 20.0294 11 20.4726 11 24.0026C11 27.5325 11.0157 27.9741 11.0785 29.3605C11.1422 30.7442 11.3613 31.6887 11.6825 32.5151C12.0148 33.37 12.459 34.0952 13.1819 34.8176C13.9042 35.5406 14.6295 35.9858 15.484 36.3178C16.3111 36.6392 17.256 36.8582 18.6397 36.9216C20.0264 36.9847 20.4692 37.0001 23.9996 37.0001C27.5305 37.0001 27.9722 36.9847 29.3589 36.9216C30.7429 36.8582 31.6886 36.6392 32.5158 36.3178C33.3705 35.9858 34.0947 35.5406 34.8171 34.8176C35.5402 34.0952 35.9844 33.37 36.3175 32.5154C36.6371 31.6887 36.8565 30.744 36.9215 29.3608C36.9837 27.9744 37 27.5325 37 24.0026C37 20.4726 36.9837 20.0296 36.9215 18.6432C36.8565 17.2595 36.6371 16.315 36.3175 15.4886C35.9844 14.6337 35.5402 13.9086 34.8171 13.1861C34.0939 12.4631 33.3708 12.0191 32.515 11.6874C31.6862 11.3659 30.741 11.1469 29.357 11.0835C26.881 10.9709 23.9942 11.005 24.0009 11.005ZM24.0009 13.3473C27.472 13.3473 27.8834 13.3597 29.2541 13.422C30.5216 13.4799 31.2095 13.6917 31.6678 13.8696C32.2744 14.1052 32.707 14.3868 33.1617 14.8417C33.6167 15.2966 33.8984 15.7299 34.1346 16.3364C34.3125 16.794 34.5246 17.4818 34.5822 18.7491C34.6445 20.1193 34.6581 20.5308 34.6581 23.9996C34.6581 27.4683 34.6445 27.8799 34.5822 29.25C34.5243 30.5173 34.3125 31.2051 34.1346 31.6627C33.8989 32.2693 33.6167 32.7012 33.1617 33.1558C32.7067 33.6107 32.2747 33.8923 31.6678 34.1279C31.2101 34.3066 30.5216 34.5179 29.2541 34.5758C27.8837 34.6381 27.472 34.6516 24.0009 34.6516C20.5296 34.6516 20.1182 34.6381 18.7478 34.5758C17.4803 34.5173 16.7924 34.3056 16.3338 34.1277C15.7272 33.8921 15.2938 33.6105 14.8388 33.1555C14.3838 32.7006 14.1022 32.2685 13.866 31.6616C13.688 31.204 13.476 30.5162 13.4183 29.249C13.356 27.8788 13.3435 27.4672 13.3435 23.9963C13.3435 20.5254 13.356 20.116 13.4183 18.7458C13.4763 17.4786 13.688 16.7908 13.866 16.3326C14.1016 15.7261 14.3838 15.2928 14.8388 14.8379C15.2938 14.383 15.7272 14.1014 16.3338 13.8653C16.7921 13.6865 17.4803 13.4753 18.7478 13.4171C19.9471 13.363 20.4118 13.3467 22.8347 13.344C22.8347 13.3495 23.9083 13.3473 24.0009 13.3473ZM30.9403 15.5054C30.6317 15.5054 30.3301 15.5969 30.0736 15.7683C29.817 15.9397 29.617 16.1833 29.499 16.4683C29.3809 16.7534 29.3501 17.067 29.4103 17.3696C29.4705 17.6721 29.6192 17.9501 29.8374 18.1682C30.0556 18.3863 30.3336 18.5348 30.6363 18.5949C30.9389 18.655 31.2526 18.6241 31.5377 18.5059C31.8227 18.3878 32.0663 18.1878 32.2377 17.9312C32.409 17.6747 32.5004 17.3731 32.5003 17.0646C32.5003 16.2035 31.8016 15.5054 30.9403 15.5054ZM24.0009 17.3278C20.3141 17.3278 17.3248 20.3164 17.3248 24.0026C17.3248 27.6887 20.3141 30.676 24.0009 30.676C27.6878 30.676 30.6762 27.6887 30.6762 24.0026C30.6762 20.3164 27.6878 17.3278 24.0009 17.3278ZM24.0009 19.67C26.3941 19.67 28.3343 21.6096 28.3343 24.0026C28.3343 26.3952 26.3941 28.3351 24.0009 28.3351C21.6076 28.3351 19.6676 26.3952 19.6676 24.0026C19.6676 21.6096 21.6076 19.67 24.0009 19.67Z", fill: "white" }), h("defs", { key: 'e1fed5ad92474000876aeab895d7aea562ff49ad' }, h("radialGradient", { key: '60cefaadc13470bcf2a8b0d87f17ff179be49d7a', id: "paint0_radial_2_167", cx: "0", cy: "0", r: "1", gradientUnits: "userSpaceOnUse", gradientTransform: "translate(12.7501 51.697) rotate(-90) scale(47.5715 44.2453)" }, h("stop", { key: '60a3075f85a9e748f754e9874811a643d812741b', "stop-color": "#FFDD55" }), h("stop", { key: 'd3e95dfbdcb9b6774d67d151251b2334078ed030', offset: "0.1", "stop-color": "#FFDD55" }), h("stop", { key: '50d6318fb07c68955b78c6e70b3da320dd46cece', offset: "0.5", "stop-color": "#FF543E" }), h("stop", { key: 'a20b7124a03945057a14bdf87dd11a0d3bbb1c11', offset: "1", "stop-color": "#C837AB" })), h("radialGradient", { key: 'dea99c0b876626da6d8fdfa580bf39e29c2b5360', id: "paint1_radial_2_167", cx: "0", cy: "0", r: "1", gradientUnits: "userSpaceOnUse", gradientTransform: "translate(-8.04025 3.45784) rotate(78.6806) scale(21.2647 87.6539)" }, h("stop", { key: '793a1b04fdcb33e397c69c962e89ee859de8a269', "stop-color": "#3771C8" }), h("stop", { key: '83936a1f4ecdc178a95015c7f6c61ddccc5c44dc', offset: "0.128", "stop-color": "#3771C8" }), h("stop", { key: '1c32bc0ce13cdc7a0203499fec87fb4c8c47209e', offset: "1", "stop-color": "#6600FF", "stop-opacity": "0" })))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-colored-instagram"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconColoredInstagram$1;},KsIconColoredInstagram$1 = GetKsIconColoredInstagram$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-colored-instagram"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-colored-instagram":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconColoredInstagram$1(transTagName));
        }
        break;
    }});
}

const KsIconColoredInstagram = KsIconColoredInstagram$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconColoredInstagram, defineCustomElement };
//# sourceMappingURL=ks-icon-colored-instagram.js.map
//# sourceMappingURL=ks-icon-colored-instagram.js.map