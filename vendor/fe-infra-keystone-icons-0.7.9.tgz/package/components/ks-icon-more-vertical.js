import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconMoreVertical$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconMoreVertical$1 =

    proxyCustomElement(class KsIconMoreVertical extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-more-vertical';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'b607133f3a692bb8cec0de85979480713bf6608f', class: "ks-icon", "ks-icon": true }, h("svg", { key: '0bfb4f909d0a8b2161bfd95b0ec0d1b7a7f24f30', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: icon.color }, h("circle", { key: 'a42add124bad5d6451c7e1856f2d9d5051063ae4', cx: "24", cy: "24", r: "3" }), h("circle", { key: 'be1cb5c4883428ab4731c848c2684b87e84e625f', cx: "24", cy: "34.5", r: "3" }), h("circle", { key: 'c4ddd62db785d01561f901f0e6eb83896df609ec', cx: "24", cy: "13.5", r: "3" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-more-vertical"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconMoreVertical$1;},KsIconMoreVertical$1 = GetKsIconMoreVertical$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-more-vertical"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-more-vertical":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconMoreVertical$1(transTagName));
        }
        break;
    }});
}

const KsIconMoreVertical = KsIconMoreVertical$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconMoreVertical, defineCustomElement };
//# sourceMappingURL=ks-icon-more-vertical.js.map
//# sourceMappingURL=ks-icon-more-vertical.js.map