import type { Components, JSX } from "../dist/types/components";

interface KsIconFilledPin extends Components.KsIconFilledPin, HTMLElement {}
export const KsIconFilledPin: {
    prototype: KsIconFilledPin;
    new (): KsIconFilledPin;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
