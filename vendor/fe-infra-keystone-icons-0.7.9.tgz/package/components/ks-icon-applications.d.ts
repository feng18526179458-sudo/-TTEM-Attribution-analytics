import type { Components, JSX } from "../dist/types/components";

interface KsIconApplications extends Components.KsIconApplications, HTMLElement {}
export const KsIconApplications: {
    prototype: KsIconApplications;
    new (): KsIconApplications;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
