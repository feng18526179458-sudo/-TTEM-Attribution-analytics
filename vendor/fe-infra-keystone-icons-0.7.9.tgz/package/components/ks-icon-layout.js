import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconLayout$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconLayout$1 =

    proxyCustomElement(class KsIconLayout extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-layout';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '810493e4fa6abce91b176120c6a6fdf238332266', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: '66647033877b45f3920f2cd98ac532d364eb09fa', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: '441a64a34a57d4d264495b597f8de798fb25cb1d', d: "M4.498 39a3 3 0 0 0 3 3h33a3 3 0 0 0 3-3V12a3 3 0 0 0-3-3h-33a3 3 0 0 0-3 3v27z" }), h("g", { key: '9330fe757957531324ba911a2703432ef76381b0', "stroke-linecap": "round" }, h("path", { key: '8facad5f2356ad602a63f8a374c1a1ba729b67c5', d: "M25.492 27h16.5m-16.5 15V9" }), h("path", { key: '783361d8bcc24dc0c7becb4fd7d262266cdc79da', d: "M25.492 42l-19.5-31.5" }))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-layout"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconLayout$1;},KsIconLayout$1 = GetKsIconLayout$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-layout"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-layout":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconLayout$1(transTagName));
        }
        break;
    }});
}

const KsIconLayout = KsIconLayout$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconLayout, defineCustomElement };
//# sourceMappingURL=ks-icon-layout.js.map
//# sourceMappingURL=ks-icon-layout.js.map