import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFullSelect$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFullSelect$1 =

    proxyCustomElement(class KsIconFullSelect extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-full-select';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'b3a8819bb28281ee5a2ac38cd431e349f6364ddb', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'ae6f13acf5076560e737292692bab79c9a3f4372', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("rect", { key: '4432f38a58233900e662b50f9294ae0e12d91ecb', x: "5", y: "5", width: "39", height: "39", rx: "1.5" }), h("path", { key: 'e7dad6b92ecfe361bfd36b34bcc5a39a5bfb4c13', d: "M14.215 24.75l6 6 13.5-13.5", "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-full-select"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFullSelect$1;},KsIconFullSelect$1 = GetKsIconFullSelect$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-full-select"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-full-select":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFullSelect$1(transTagName));
        }
        break;
    }});
}

const KsIconFullSelect = KsIconFullSelect$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFullSelect, defineCustomElement };
//# sourceMappingURL=ks-icon-full-select.js.map
//# sourceMappingURL=ks-icon-full-select.js.map