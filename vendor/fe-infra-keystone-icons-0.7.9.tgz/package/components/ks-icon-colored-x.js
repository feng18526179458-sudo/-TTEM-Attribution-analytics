import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconColoredX$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconColoredX$1 =

    proxyCustomElement(class KsIconColoredX extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-colored-x';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '564992a8acc24f8463156e645660b863a0de68d6', class: "ks-icon", "ks-icon": true }, h("svg", { key: '251de579430b3872f9f09ac8d203b053010e7d39', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("rect", { key: 'afa37c44b7c81de7fbf2ff00c8ecf84747fcae06', width: "48", height: "48", rx: "8", fill: "#262627" }), h("path", { key: '95b498bb7c95c6a0984061945843bd295986f7f0', d: "M30.4258 14H33.8187L26.4063 22.4718L35.1264 34H28.2986L22.9508 27.0082L16.8318 34H13.4369L21.3652 24.9385L13 14H20.0011L24.835 20.3908L30.4258 14ZM29.235 31.9692H31.115L18.9795 15.9241H16.9621L29.235 31.9692Z", fill: "white" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-colored-x"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconColoredX$1;},KsIconColoredX$1 = GetKsIconColoredX$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-colored-x"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-colored-x":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconColoredX$1(transTagName));
        }
        break;
    }});
}

const KsIconColoredX = KsIconColoredX$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconColoredX, defineCustomElement };
//# sourceMappingURL=ks-icon-colored-x.js.map
//# sourceMappingURL=ks-icon-colored-x.js.map