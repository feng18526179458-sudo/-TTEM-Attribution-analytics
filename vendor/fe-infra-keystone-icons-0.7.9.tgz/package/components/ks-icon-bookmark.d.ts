import type { Components, JSX } from "../dist/types/components";

interface KsIconBookmark extends Components.KsIconBookmark, HTMLElement {}
export const KsIconBookmark: {
    prototype: KsIconBookmark;
    new (): KsIconBookmark;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
