import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconColoredAudio$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconColoredAudio$1 =

    proxyCustomElement(class KsIconColoredAudio extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-colored-audio';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '45f76d8862e4aedbb977ceebf58bf78e1ac06589', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'b21bf41c66f48074f46ca24bcf462ad96feceec1', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("rect", { key: 'f199c8f0e550ab4c9818a48cc57889052325f5be', width: "48", height: "48", rx: "1.556", fill: "#f6ba1e" }), h("path", { key: 'b607bfb5b2892636579e36237f4770e4b4b61bad', "fill-rule": "evenodd", d: "M18.934 14.72c-.405 0-.733.328-.733.733v18h-.01l.002.132a5.24 5.24 0 0 1-5.239 5.239 5.24 5.24 0 0 1-5.238-5.239 5.24 5.24 0 0 1 5.238-5.239c.242 0 .48.016.713.048V15.454a5.27 5.27 0 0 1 5.267-5.267h12.6a5.27 5.27 0 0 1 5.267 5.267v15.402h-.013l.013.378a5.24 5.24 0 0 1-5.239 5.238 5.24 5.24 0 0 1-5.239-5.238 5.24 5.24 0 0 1 5.239-5.239 5.29 5.29 0 0 1 .705.047V15.454c0-.405-.328-.733-.733-.733h-12.6z", fill: "#fff" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-colored-audio"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconColoredAudio$1;},KsIconColoredAudio$1 = GetKsIconColoredAudio$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-colored-audio"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-colored-audio":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconColoredAudio$1(transTagName));
        }
        break;
    }});
}

const KsIconColoredAudio = KsIconColoredAudio$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconColoredAudio, defineCustomElement };
//# sourceMappingURL=ks-icon-colored-audio.js.map
//# sourceMappingURL=ks-icon-colored-audio.js.map