import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconMinus$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconMinus$1 =

    proxyCustomElement(class KsIconMinus extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-minus';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '8bf59713a7cbcf95b64a14770d11e51e425418cd', class: "ks-icon", "ks-icon": true }, h("svg", { key: '7a7790b6cb82550da4baa37fe1971e235cc4bbc9', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '9bdadb1c60a97400934a7104917b09be3ee95b22', d: "M4.908 24h38.184", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-minus"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconMinus$1;},KsIconMinus$1 = GetKsIconMinus$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-minus"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-minus":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconMinus$1(transTagName));
        }
        break;
    }});
}

const KsIconMinus = KsIconMinus$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconMinus, defineCustomElement };
//# sourceMappingURL=ks-icon-minus.js.map
//# sourceMappingURL=ks-icon-minus.js.map