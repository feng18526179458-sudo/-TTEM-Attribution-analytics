import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconPhone$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconPhone$1 =

    proxyCustomElement(class KsIconPhone extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-phone';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '5a5caf2bb0ac262d6077ed86089c9323dcf8c763', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'ca379f1c04d2f1a41aa69c768a7a9d6fbb5339d4', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("rect", { key: '1299040ebc4971199c56c61f75676155536b84fe', x: "12", y: "4.5", width: "24", height: "39", rx: "1.5" }), h("path", { key: '6b8a15a1094a018ebfe5fbdaa433d93f46ed5bec', d: "M20.996 37.5h6m-15.004-6h24", "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-phone"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconPhone$1;},KsIconPhone$1 = GetKsIconPhone$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-phone"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-phone":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconPhone$1(transTagName));
        }
        break;
    }});
}

const KsIconPhone = KsIconPhone$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconPhone, defineCustomElement };
//# sourceMappingURL=ks-icon-phone.js.map
//# sourceMappingURL=ks-icon-phone.js.map