import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFolderMinus$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFolderMinus$1 =

    proxyCustomElement(class KsIconFolderMinus extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-folder-minus';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '4376bf7db0e4426abc6ba2f89782b5051dfa4163', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'cd8712672d19837a2c6953bc0900282d4b6480de', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("g", { key: 'a6f4915c85292fb3742ac0f5bb31bdea1e5420ea', stroke: icon.color, "stroke-width": icon.strokeWidth }, h("rect", { key: 'b876cfc877dd36fee579a1343f54db1624f5b1c7', x: "4.638", y: "14.22", width: "39", height: "27", rx: "1.5" }), h("path", { key: 'bdef4b246cb7cc6869598102a6b664e452b068b6', d: "M13.5 27h21", "stroke-linecap": "round" })), h("mask", { key: 'a68b0f31d73c92ba122610b1bcba981171b7f4b5', id: "A", fill: "#fff" }, h("path", { key: 'd9ffeec8a592e4345c897ba0c06f98afd760a72c', d: "M3.141 8.208a3 3 0 0 1 3-3h19.657A3 3 0 0 1 28.264 6.5l6.377 9.208h-31.5v-7.5z" })), h("path", { key: '77483965db8c985977ef229f511664332cd0d019', d: "M34.641 15.708v3h5.727L37.107 14l-2.466 1.708zm-31.5 0h-3v3h3v-3zM28.264 6.5l2.466-1.708L28.264 6.5zM6.141 8.208h19.657v-6H6.141v6zm19.657 0l6.377 9.208L37.107 14 30.73 4.792l-4.933 3.416zm8.843 4.5h-31.5v6h31.5v-6zm-28.5 3v-7.5h-6v7.5h6zm19.657-7.5h0l4.933-3.416a6 6 0 0 0-4.933-2.584v6zm-19.657-6a6 6 0 0 0-6 6h6 0v-6z", fill: icon.color, mask: "url(#A)" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-folder-minus"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFolderMinus$1;},KsIconFolderMinus$1 = GetKsIconFolderMinus$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-folder-minus"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-folder-minus":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFolderMinus$1(transTagName));
        }
        break;
    }});
}

const KsIconFolderMinus = KsIconFolderMinus$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFolderMinus, defineCustomElement };
//# sourceMappingURL=ks-icon-folder-minus.js.map
//# sourceMappingURL=ks-icon-folder-minus.js.map