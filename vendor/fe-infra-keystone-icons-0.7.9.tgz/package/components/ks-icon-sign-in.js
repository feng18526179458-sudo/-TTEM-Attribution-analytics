import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconSignIn$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconSignIn$1 =

    proxyCustomElement(class KsIconSignIn extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-sign-in';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'd8794b02f8d616319d0e2219a5d1ccdd9ae211af', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: '2ab373cf14c877dfa4977dee7644d8af783508e8', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: '1ede080d6e47bf2088f01f0492334acfeead267f', d: "M9 8.897v-3a1.5 1.5 0 0 1 1.5-1.5h7.027H37.5a1.5 1.5 0 0 1 1.5 1.5v36a1.5 1.5 0 0 1-1.5 1.5h-27a1.5 1.5 0 0 1-1.5-1.5v-3" }), h("path", { key: 'f62216035e07c22652d03fc12bae1dced53be63f', d: "M33.002 23.897H8.999m24.002 0l-6.001-6.001m6.001 6.001l-6.001 6.001", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-sign-in"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconSignIn$1;},KsIconSignIn$1 = GetKsIconSignIn$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-sign-in"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-sign-in":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconSignIn$1(transTagName));
        }
        break;
    }});
}

const KsIconSignIn = KsIconSignIn$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconSignIn, defineCustomElement };
//# sourceMappingURL=ks-icon-sign-in.js.map
//# sourceMappingURL=ks-icon-sign-in.js.map