import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconToTop$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconToTop$1 =

    proxyCustomElement(class KsIconToTop extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-to-top';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '081cd81a8a3d38641dab9a26fe5e251361ae0511', class: "ks-icon", "ks-icon": true }, h("svg", { key: '34cc850c3d2a868b0e06450bdb4224cddd775a91', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: '0d48a9c010097d2fb3dafe93d00b7e8b031091ed', d: "M9.253 22.523L22.967 9.462a1.5 1.5 0 0 1 2.069 0l13.715 13.062", "stroke-linejoin": "round" }), h("path", { key: '39d0bad3c7ca2d5d60225e1005fc5cf98d85c93d', d: "M23.998 11.286v33.712" }), h("path", { key: '88db3897ef974107a62bcc18eea446a72760209c', d: "M7.51 3.001h33", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-to-top"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconToTop$1;},KsIconToTop$1 = GetKsIconToTop$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-to-top"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-to-top":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconToTop$1(transTagName));
        }
        break;
    }});
}

const KsIconToTop = KsIconToTop$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconToTop, defineCustomElement };
//# sourceMappingURL=ks-icon-to-top.js.map
//# sourceMappingURL=ks-icon-to-top.js.map