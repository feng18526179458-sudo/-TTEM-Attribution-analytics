import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconSound$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconSound$1 =

    proxyCustomElement(class KsIconSound extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-sound';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '9a5e35346ace267aa84d28b481bbd62d1a8afacd', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'd785065445cc6a9ce33bd084df6019d76633051e', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: '5f06cf9f46a560c204e8bbdce63d1d6361a55372', d: "M25.495 36a9 9 0 0 1-18 0 9 9 0 0 1 18 0z" }), h("path", { key: '56ddb6949b2020cc617fa1c92fef4773c8d00b24', d: "M25.498 34.5l2.73-27.299A3 3 0 0 1 31.213 4.5h12.285", "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-sound"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconSound$1;},KsIconSound$1 = GetKsIconSound$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-sound"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-sound":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconSound$1(transTagName));
        }
        break;
    }});
}

const KsIconSound = KsIconSound$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconSound, defineCustomElement };
//# sourceMappingURL=ks-icon-sound.js.map
//# sourceMappingURL=ks-icon-sound.js.map