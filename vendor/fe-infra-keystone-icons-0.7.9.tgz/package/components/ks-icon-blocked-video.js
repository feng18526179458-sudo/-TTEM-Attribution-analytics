import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconBlockedVideo$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconBlockedVideo$1 =

    proxyCustomElement(class KsIconBlockedVideo extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-blocked-video';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'f1feca9fb18af115f9458f7f1a66b33fc1bbc67d', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'b0a9b40d357ff80bbc2c9dbeeb946626ed4ead39', width: icon.width, height: icon.height, viewBox: "0 0 49 49", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'd95308d00d701265fe19eba34b9494eb4f3c525f', d: "M12.9648 16.4359L20.4648 8.93595", stroke: icon.color, "stroke-width": icon.strokeWidth }), h("path", { key: 'b4199f4d637ee9c2181eaed3b532ee9713352b60', d: "M41.4668 8.93593H5.96878C4.86419 8.93593 3.96875 9.83138 3.96875 10.936V36.9023C3.96875 38.0061 4.86284 38.9011 5.96656 38.9024L41.4635 38.9418C43.1216 38.9436 44.4668 37.6 44.4668 35.9419V11.9359C44.4668 10.2791 43.1237 8.93593 41.4668 8.93593Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: 'a39e201606fb03ce4519f43b67eeb401bf460043', d: "M3.96875 16.4345H44.4671", stroke: icon.color, "stroke-width": icon.strokeWidth }), h("path", { key: '24f04e3a4b268d942a35fc4f0bfed26c5e451706', d: "M27.9643 16.4359L35.4643 8.93595", stroke: icon.color, "stroke-width": icon.strokeWidth }), h("ellipse", { key: 'a501f2eee9e02afda53931b82e929b56850f1923', cx: "24.2193", cy: "27.8668", rx: "5.96575", ry: "5.96571", transform: "rotate(-180 24.2193 27.8668)", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: 'd12730b8096d7112f0a327a0b89c7476f93262a6', d: "M20.0472 32.0403L28.3931 23.6945", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-blocked-video"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconBlockedVideo$1;},KsIconBlockedVideo$1 = GetKsIconBlockedVideo$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-blocked-video"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-blocked-video":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconBlockedVideo$1(transTagName));
        }
        break;
    }});
}

const KsIconBlockedVideo = KsIconBlockedVideo$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconBlockedVideo, defineCustomElement };
//# sourceMappingURL=ks-icon-blocked-video.js.map
//# sourceMappingURL=ks-icon-blocked-video.js.map