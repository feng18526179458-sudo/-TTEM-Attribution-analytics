import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledHelp$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledHelp$1 =

    proxyCustomElement(class KsIconFilledHelp extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-help';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
        this.innerColor = '#fff';
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '65418fec06d2d5238ba0f019d9dab297c0830bf8', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: '35e3cedbb2476f491edcecfa1d4aab37a94b04ae', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("g", { key: '87cb545a2ed067b6f1f64f3e09f32701bb95a02a', "stroke-width": icon.strokeWidth }, h("path", { key: 'ecd71b2e6e0d0975710694abcb05bee5b2e81275', d: "M1.714 24A22.29 22.29 0 0 1 24 1.714 22.29 22.29 0 0 1 46.286 24 22.29 22.29 0 0 1 24 46.286 22.29 22.29 0 0 1 1.714 24z", fill: icon.color, stroke: icon.color }), h("path", { key: '2bd7f20bc1318907a37796739e0f489c89143665', d: "M17.985 15.305c1.014-1.943 3.183-3.286 5.695-3.286 3.482 0 6.305 2.58 6.305 5.763 0 2.225-1.38 4.156-3.4 5.116-1.496.711-2.905 1.99-2.905 3.646v3.454", stroke: this.innerColor, "stroke-linecap": "round" })), h("circle", { key: 'eaeb8c2799a969a4ec838c5cd10a22ce84ba97e1', cx: "23.25", cy: "35.25", r: "2.25", fill: this.innerColor })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-help"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"],
      "innerColor": [1, "inner-color"]
    }]);return innerKsIconFilledHelp$1;},KsIconFilledHelp$1 = GetKsIconFilledHelp$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-help"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-help":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledHelp$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledHelp = KsIconFilledHelp$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledHelp, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-help.js.map
//# sourceMappingURL=ks-icon-filled-help.js.map