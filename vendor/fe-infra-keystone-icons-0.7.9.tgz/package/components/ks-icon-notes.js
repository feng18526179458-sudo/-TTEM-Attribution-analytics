import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconNotes$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconNotes$1 =

    proxyCustomElement(class KsIconNotes extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-notes';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'eb9cd5399af36b7e7b6e0ac27c0961370a78e403', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: 'c7208914a726d8c5e9e4dad736492b39134a0d8e', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: '086eff40e16d7e6d427698fbc9c68ecfaf88aa88', d: "M9 6a1.5 1.5 0 0 1 1.5-1.5h19.412a1.5 1.5 0 0 1 1.04.419l7.588 7.299a1.5 1.5 0 0 1 .46 1.081V42a1.5 1.5 0 0 1-1.5 1.5h-27A1.5 1.5 0 0 1 9 42V6z" }), h("path", { key: 'f0a2c10bbfe66b2f5a5662af02174dc94cf5e2ca', d: "M16.459 16.527h15.013m-15.013 7.5h15.013m-15.013 7.499h8.991", "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-notes"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconNotes$1;},KsIconNotes$1 = GetKsIconNotes$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-notes"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-notes":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconNotes$1(transTagName));
        }
        break;
    }});
}

const KsIconNotes = KsIconNotes$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconNotes, defineCustomElement };
//# sourceMappingURL=ks-icon-notes.js.map
//# sourceMappingURL=ks-icon-notes.js.map