import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconPlay$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconPlay$1 =

    proxyCustomElement(class KsIconPlay extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-play';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '1be46c732bd3483f07d7f2b9e8cb84b57b025423', class: "ks-icon", "ks-icon": true }, h("svg", { key: '273cac82382c4a7d16639255b78d172ae0ad8055', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '91660528c893d2703b10bfc84e69bc7cc1cce144', d: "M39.956 21.25L12.107.675C9.85-.992 6.656.619 6.656 3.425v41.149c0 2.806 3.194 4.418 5.451 2.75L39.956 26.75a3.42 3.42 0 0 0 0-5.5z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-play"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconPlay$1;},KsIconPlay$1 = GetKsIconPlay$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-play"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-play":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconPlay$1(transTagName));
        }
        break;
    }});
}

const KsIconPlay = KsIconPlay$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconPlay, defineCustomElement };
//# sourceMappingURL=ks-icon-play.js.map
//# sourceMappingURL=ks-icon-play.js.map