import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconUnapprovedConversion$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconUnapprovedConversion$1 =

    proxyCustomElement(class KsIconUnapprovedConversion extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-unapproved-conversion';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'c438a35b71e5e12591f0525bea925b401631193f', class: "ks-icon", "ks-icon": true }, h("svg", { key: '15e6bbca29c23fd897432375ec2a76c0196ded8f', width: icon.width, height: icon.height, viewBox: "0 0 49 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'bcdc96e07b8d2accaba2868a3e673cdb7337e752', d: "M23.8887 3.11133C24.1055 3.0625 24.331 3.06252 24.5479 3.11133L41.0479 6.82617C41.7321 6.98029 42.2178 7.58864 42.2178 8.29004V27.9814C42.2176 31.4551 40.3469 34.7486 37.1475 36.7295L25.0078 44.2461C24.5241 44.5455 23.9124 44.5456 23.4287 44.2461L11.2891 36.7295C8.08965 34.7486 6.21888 31.4551 6.21875 27.9814V8.29004L6.22461 8.15918C6.28059 7.51394 6.74816 6.97059 7.38965 6.82617L23.8887 3.11133Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("line", { key: '383b237a56c10a8fea4c92f35a5beea88024dfef', x1: "24.4705", y1: "14.0823", x2: "24.4705", y2: "27.3085", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("line", { key: '447fe69a791732cd9aea1a2773872e6ba835efa5', x1: "24.4705", y1: "33.7135", x2: "24.4705", y2: "33.8525", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-unapproved-conversion"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconUnapprovedConversion$1;},KsIconUnapprovedConversion$1 = GetKsIconUnapprovedConversion$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-unapproved-conversion"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-unapproved-conversion":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconUnapprovedConversion$1(transTagName));
        }
        break;
    }});
}

const KsIconUnapprovedConversion = KsIconUnapprovedConversion$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconUnapprovedConversion, defineCustomElement };
//# sourceMappingURL=ks-icon-unapproved-conversion.js.map
//# sourceMappingURL=ks-icon-unapproved-conversion.js.map