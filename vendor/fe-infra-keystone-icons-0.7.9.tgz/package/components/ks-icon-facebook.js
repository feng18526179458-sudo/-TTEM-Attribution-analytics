import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFacebook$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFacebook$1 =

    proxyCustomElement(class KsIconFacebook extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-facebook';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'b8a6fbff494f5ef21ae5f99fe0b9cd0d58434e9c', class: "ks-icon", "ks-icon": true }, h("svg", { key: '3513c8c0ac68580c6b0eb62906091e7da989df57', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'd0043926e9fee62d913c91eb4217e10beeb48e61', d: "M46 24.134C46 11.91 36.15 2 24 2S2 11.91 2 24.134C2 35.182 10.045 44.34 20.563 46V30.533h-5.586v-6.398h5.586v-4.876c0-5.547 3.285-8.612 8.31-8.612 2.406 0 4.925.432 4.925.432v5.447h-2.774c-2.733 0-3.585 1.706-3.585 3.459v4.15h6.102l-.975 6.398h-5.126V46C37.955 44.34 46 35.182 46 24.134z", fill: "#1877f2" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-facebook"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFacebook$1;},KsIconFacebook$1 = GetKsIconFacebook$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-facebook"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-facebook":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFacebook$1(transTagName));
        }
        break;
    }});
}

const KsIconFacebook = KsIconFacebook$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFacebook, defineCustomElement };
//# sourceMappingURL=ks-icon-facebook.js.map
//# sourceMappingURL=ks-icon-facebook.js.map