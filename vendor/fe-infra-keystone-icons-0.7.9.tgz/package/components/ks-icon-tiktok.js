import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconTiktok$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconTiktok$1 =

    proxyCustomElement(class KsIconTiktok extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-tiktok';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'fcd34c4e2d4dfa74b7abe926f13cbea9d4f6aba3', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'eaa0a44bb9bbb3474359404208b1f6886cce00bd', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '56e1b09ede1a4b0642f6362bb9001f8b0b74bdeb', d: "M43.059 13.5c-5.756 0-10.423-4.701-10.423-10.5h-6.949v28.583c0 3.544-2.852 6.417-6.369 6.417s-6.37-2.873-6.37-6.417 2.852-6.417 6.37-6.417a6.35 6.35 0 0 1 1.502.178 6.21 6.21 0 0 1 .235.062V18.28c-.57-.075-1.15-.114-1.737-.114C11.963 18.167 6 24.174 6 31.583S11.963 45 19.318 45s13.318-6.007 13.318-13.417V17.001A17.21 17.21 0 0 0 43.059 20.5v-7z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-tiktok"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconTiktok$1;},KsIconTiktok$1 = GetKsIconTiktok$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-tiktok"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-tiktok":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconTiktok$1(transTagName));
        }
        break;
    }});
}

const KsIconTiktok = KsIconTiktok$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconTiktok, defineCustomElement };
//# sourceMappingURL=ks-icon-tiktok.js.map
//# sourceMappingURL=ks-icon-tiktok.js.map