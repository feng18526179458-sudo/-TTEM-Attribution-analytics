import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconSearch$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconSearch$1 =

    proxyCustomElement(class KsIconSearch extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-search';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '49b1ebdafe50abee0c59cf4b476bec1d39aad19e', class: "ks-icon", "ks-icon": true }, h("svg", { key: '95fe60204efc25fc0d54de8430bdd3ac496056e1', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'fc5adeb59b6126e9514fcb0a9972b73a14228ce2', d: "M22.4985 4.50043C31.6109 4.50058 38.9975 11.8881 38.9975 21.0004C38.9973 30.1126 31.6108 37.4993 22.4985 37.4995C13.3861 37.4995 5.99873 30.1127 5.9985 21.0004C5.9985 11.888 13.3859 4.50043 22.4985 4.50043Z" }), h("path", { key: '7d1b4fb2ce36b6ee90efb4a231153cbf04867f20', d: "M25.9958 12.2047C27.1136 12.5998 28.1301 13.2094 28.9957 13.9842C30.1103 14.9818 30.9748 16.2531 31.4836 17.6924", "stroke-linecap": "round" }), h("path", { key: '493192e561996b43b137a349d2beb79629df6394', d: "M32.9179 34.4158L43.5017 44.9996", "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-search"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconSearch$1;},KsIconSearch$1 = GetKsIconSearch$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-search"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-search":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconSearch$1(transTagName));
        }
        break;
    }});
}

const KsIconSearch = KsIconSearch$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconSearch, defineCustomElement };
//# sourceMappingURL=ks-icon-search.js.map
//# sourceMappingURL=ks-icon-search.js.map