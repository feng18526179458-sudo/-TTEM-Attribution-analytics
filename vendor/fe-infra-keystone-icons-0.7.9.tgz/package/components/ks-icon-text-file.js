import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconTextFile$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconTextFile$1 =

    proxyCustomElement(class KsIconTextFile extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-text-file';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '0d141095efff224af152e0540c808ea603e9e844', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'b9e02ea1481bd247c54c56209547279a51177b64', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'fa6db47f9e56b196dbe311b9c00def53edc95ca9', d: "M37.1917 19.4375V15.6306C37.1917 14.95 36.9603 14.2896 36.5354 13.7579L30.6382 6.37732C30.0689 5.66484 29.2065 5.25 28.2945 5.25H10.0042C8.45088 5.25 7.19168 6.5092 7.19168 8.0625V39.9375C7.19168 41.4908 8.45088 42.75 10.0042 42.75H17.3792M15.2545 18.8091V15.5563H22.2974M29.3403 18.8091V15.5563H22.2974M22.2974 15.5563V29.4691M22.2974 29.4691H20.0354M22.2974 29.4691H24.6107M28.9702 41.987L25.8658 42.707C24.6999 42.9774 23.6551 41.9301 23.9283 40.7649L24.6526 37.6748C24.6988 37.4778 24.7995 37.2978 24.9433 37.1554L35.802 26.4028C36.4337 25.7772 37.4521 25.7797 38.0807 26.4083L40.3352 28.6628C40.968 29.2956 40.9657 30.3222 40.3302 30.9521L29.485 41.7028C29.3431 41.8435 29.1649 41.9419 28.9702 41.987Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-text-file"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconTextFile$1;},KsIconTextFile$1 = GetKsIconTextFile$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-text-file"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-text-file":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconTextFile$1(transTagName));
        }
        break;
    }});
}

const KsIconTextFile = KsIconTextFile$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconTextFile, defineCustomElement };
//# sourceMappingURL=ks-icon-text-file.js.map
//# sourceMappingURL=ks-icon-text-file.js.map