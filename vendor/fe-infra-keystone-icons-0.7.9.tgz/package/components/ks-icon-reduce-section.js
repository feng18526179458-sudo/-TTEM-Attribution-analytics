import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconReduceSection$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconReduceSection$1 =

    proxyCustomElement(class KsIconReduceSection extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-reduce-section';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'ca26628573fb03dbae9f6d29a9c9b479636f8513', class: "ks-icon", "ks-icon": true }, h("svg", { key: '34f2ce19aa5985c5ff90de3ef96b1bc26901d924', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: 'f5a847bc5af29926494024890b797e556d731403', d: "M12 24h24", "stroke-linecap": "round", "stroke-linejoin": "round" }), h("rect", { key: '5eb313229d5e672b1e8a20a4994f6cdfd11fd9f3', x: "4.466", y: "4.515", width: "39", height: "39", rx: "1.5" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-reduce-section"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconReduceSection$1;},KsIconReduceSection$1 = GetKsIconReduceSection$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-reduce-section"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-reduce-section":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconReduceSection$1(transTagName));
        }
        break;
    }});
}

const KsIconReduceSection = KsIconReduceSection$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconReduceSection, defineCustomElement };
//# sourceMappingURL=ks-icon-reduce-section.js.map
//# sourceMappingURL=ks-icon-reduce-section.js.map