import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconEventsManager$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconEventsManager$1 =

    proxyCustomElement(class KsIconEventsManager extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-events-manager';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '34607c687cc559ef733acc3ce3b6a39fe374317d', class: "ks-icon", "ks-icon": true }, h("svg", { key: '0a53295ac0f42df3a655be4661a306118fd47db1', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'f45cbce9fad81c0a0a308e59febc787abd9be941', d: "M15.302 10.875L15.302 5.49988", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("rect", { key: '58cef44ba34f56fdd19293ceedca635b28946598', x: "5.5", y: "8", width: "37", height: "32", rx: "3", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '9ad5a0a57b632df7e1e7868465c0f31df5063ab7', d: "M33.198 10.875L33.198 5.49988", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '47612fd0963fe297c3b0c4d17def49b8dfbcb53b', d: "M17.6204 25.2832L20.6676 28.8413C21.0467 29.2839 21.7223 29.31 22.1343 28.898L30.4849 20.5474", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-events-manager"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconEventsManager$1;},KsIconEventsManager$1 = GetKsIconEventsManager$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-events-manager"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-events-manager":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconEventsManager$1(transTagName));
        }
        break;
    }});
}

const KsIconEventsManager = KsIconEventsManager$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconEventsManager, defineCustomElement };
//# sourceMappingURL=ks-icon-events-manager.js.map
//# sourceMappingURL=ks-icon-events-manager.js.map