import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconShopify$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconShopify$1 =

    proxyCustomElement(class KsIconShopify extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-shopify';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '1a5541bb172d9df1b88ec3e410f10f37cac63a58', class: "ks-icon", "ks-icon": true }, h("svg", { key: '98c82c15850f8ed7827ec5030227d532cfcff72c', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '862908f101fdd473d649fe564310d2af80a11ac6', "fill-rule": "evenodd", d: "M14.784 12.926l-4.442 1.366a1.5 1.5 0 0 0-1.045 1.237L6 40.535 31.735 45V7.713l-1.703.524c-.144-.658-.478-1.65-1.065-2.434-.656-.877-1.66-1.645-3.071-1.645a3.76 3.76 0 0 0-.483.031 3.41 3.41 0 0 0-.45-.413C24.319 3.283 23.468 3 22.373 3c-2.289 0-4.098 1.831-5.345 3.892-1.201 1.984-1.983 4.343-2.243 6.034zm1.063-.327l4.016-1.235c.171-1.213.803-2.979 1.799-4.45.674-.995 1.558-1.918 2.629-2.402-.439-.31-1.049-.52-1.918-.52-1.736 0-3.288 1.414-4.499 3.415-1.023 1.691-1.723 3.676-2.027 5.192zm5.08-1.563l4.824-1.484c.003-.931-.072-2.558-.439-3.597a3.62 3.62 0 0 0-.306-.659c-.956.317-1.815 1.124-2.526 2.174a10.99 10.99 0 0 0-1.553 3.566zm5.813-1.788l2.342-.72c-.107-.532-.393-1.444-.906-2.13-.507-.678-1.198-1.192-2.123-1.244a4.91 4.91 0 0 1 .193.471c.384 1.088.482 2.652.495 3.624zm5.819-1.081v36.791l10.64-2.522-4.549-31.265a.6.6 0 0 0-.556-.512l-2.937-.177-2.598-2.315zm-11.791 8.357c1.89-.308 3.76-.086 4.893.238l-1.133 3.975c-.6-.172-1.857-.335-3.097-.133-1.235.201-2.098.693-2.544 1.48-.452.799-.471 2.138.814 3.02l.558.374c.929.615 2.094 1.387 2.918 2.345 1.197 1.393 1.735 3.151 1.353 5.445-.316 1.902-1.289 3.312-2.817 4.042-1.378.658-2.898.608-4.095.411-2.16-.356-4.301-1.393-4.971-1.718l-.165-.079 1.718-3.758.273.129c.773.367 2.311 1.099 3.815 1.347.855.141 1.259.128 1.527 0 .119-.057.514-.256.647-1.053.196-1.178-.071-1.674-.41-2.068-.416-.484-.968-.853-1.835-1.434l-.844-.57c-3.416-2.343-3.352-6.212-2.072-8.472 1.301-2.297 3.573-3.211 5.468-3.52z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-shopify"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconShopify$1;},KsIconShopify$1 = GetKsIconShopify$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-shopify"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-shopify":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconShopify$1(transTagName));
        }
        break;
    }});
}

const KsIconShopify = KsIconShopify$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconShopify, defineCustomElement };
//# sourceMappingURL=ks-icon-shopify.js.map
//# sourceMappingURL=ks-icon-shopify.js.map