import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconShare$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconShare$1 =

    proxyCustomElement(class KsIconShare extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-share';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '37c5ae2c3a4a43d796979b6e4f41309ee74a769a', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'cfed97bfa26f5a89b3880f7b15bd6b5d408982c7', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: 'fe522eb8b5b67e5809cb42e5a289b7f1710d16bc', d: "M14.998 19.501h-7.5a1.5 1.5 0 0 0-1.5 1.5v21a1.5 1.5 0 0 0 1.5 1.5h33a1.5 1.5 0 0 0 1.5-1.5v-21a1.5 1.5 0 0 0-1.5-1.5h-7.5m-.841-6.841l-8.159-8.159" }), h("path", { key: 'dd586033d32ef60edc05cfb6ccf4c63e14bd5dd2', d: "M15.839 12.66l8.159-8.159m0 0v25.456" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-share"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconShare$1;},KsIconShare$1 = GetKsIconShare$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-share"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-share":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconShare$1(transTagName));
        }
        break;
    }});
}

const KsIconShare = KsIconShare$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconShare, defineCustomElement };
//# sourceMappingURL=ks-icon-share.js.map
//# sourceMappingURL=ks-icon-share.js.map