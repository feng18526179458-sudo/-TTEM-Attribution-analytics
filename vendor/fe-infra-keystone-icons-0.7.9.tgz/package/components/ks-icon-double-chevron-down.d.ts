import type { Components, JSX } from "../dist/types/components";

interface KsIconDoubleChevronDown extends Components.KsIconDoubleChevronDown, HTMLElement {}
export const KsIconDoubleChevronDown: {
    prototype: KsIconDoubleChevronDown;
    new (): KsIconDoubleChevronDown;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
