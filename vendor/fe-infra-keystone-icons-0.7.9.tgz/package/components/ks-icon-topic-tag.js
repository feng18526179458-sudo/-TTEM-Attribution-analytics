import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconTopicTag$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconTopicTag$1 =

    proxyCustomElement(class KsIconTopicTag extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-topic-tag';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'b0f3c2bb5c4d6e879f38773c8bf2d3aa827e2d75', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'f2629ba47e0a4fa986f4306e17dc4fe3be19dd97', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("g", { key: 'f45866c92313b024e796403dc7185d9e16522863', "stroke-linecap": "round" }, h("path", { key: 'd328b52266705c7da2b53d5fa396ba1cb7a91b6f', d: "M10.639 17.921h27m-27 12.185h27" }), h("path", { key: '2938719751f41d42c7c9e6a9a1f53769bffc3ec4', d: "M27.89 37.309l4.689-26.59m-16.874 26.59l4.688-26.59" })), h("rect", { key: 'cd9e592862c73b42fe4e581f2d77077446cf5680', x: "4.5", y: "4.5", width: "39", height: "39", rx: "1.5" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-topic-tag"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconTopicTag$1;},KsIconTopicTag$1 = GetKsIconTopicTag$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-topic-tag"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-topic-tag":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconTopicTag$1(transTagName));
        }
        break;
    }});
}

const KsIconTopicTag = KsIconTopicTag$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconTopicTag, defineCustomElement };
//# sourceMappingURL=ks-icon-topic-tag.js.map
//# sourceMappingURL=ks-icon-topic-tag.js.map