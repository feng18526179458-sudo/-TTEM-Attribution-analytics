import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconTuxShare$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconTuxShare$1 =

    proxyCustomElement(class KsIconTuxShare extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-tux-share';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '5c11ccbcde11044b6cc85214f500949e187653d5', class: "ks-icon", "ks-icon": true }, h("svg", { key: '7bd13d5ba1b7ad419c5c13f042155d44cb86b378', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '219effe33d291519c4da39dfc95c82c3cf64377d', d: "M27.484 16.119C16.616 16.699 6.08 26.655 2.43 40.925c8.201-7.244 15.307-9.043 25.013-9.665v11.905L45.57 24.166 27.484 4.836v11.283z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-tux-share"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconTuxShare$1;},KsIconTuxShare$1 = GetKsIconTuxShare$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-tux-share"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-tux-share":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconTuxShare$1(transTagName));
        }
        break;
    }});
}

const KsIconTuxShare = KsIconTuxShare$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconTuxShare, defineCustomElement };
//# sourceMappingURL=ks-icon-tux-share.js.map
//# sourceMappingURL=ks-icon-tux-share.js.map