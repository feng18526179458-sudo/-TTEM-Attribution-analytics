import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconColoredPdf$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconColoredPdf$1 =

    proxyCustomElement(class KsIconColoredPdf extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-colored-pdf';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '04eae5b331de3ff9eb6c2e7a18bc3f71dc221a91', class: "ks-icon", "ks-icon": true }, h("svg", { key: '2a84ffd9ce51f5e42b02810562db168701a29364', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("rect", { key: 'bfa71d82b53442d9adbbf70119a444327a236cda', width: "48", height: "48", rx: "1.556", fill: "#de2134" }), h("path", { key: '0393eaac0370c58bc716bc9c40ddd66b1e6ff821', d: "M12.451 31.891c2.399-.178 4.71-1.069 6.576-2.673 3.644.802 7.109 1.96 10.575 3.386C32.357 37.505 34.935 40 37.156 40c.444 0 .978-.089 1.333-.356.977-.446 1.511-1.426 1.511-2.406 0-.802-.178-3.03-8.62-6.683-1.955-3.564-3.466-7.218-4.71-11.05 1.066-2.139 3.377-7.396 1.777-10.069-.533-.98-1.6-1.515-2.755-1.426-.889 0-1.777.446-2.311 1.158-1.155 1.604-1.066 4.99.444 9.98-1.422 2.673-3.288 5.079-5.51 7.129-1.866-.356-3.733-.624-5.599-.624-4.177.089-4.799 2.05-4.71 3.208 0 3.03 2.933 3.03 4.443 3.03h0zm24.883 5.525l-.267-.089c-1.244-.446-2.222-1.337-2.933-2.495 1.333.535 2.399 1.426 3.199 2.584h0zM25.515 10.683h.267c.089 0 .267 0 .356.089.355 1.515.089 3.119-.533 4.545-.533-1.515-.533-3.119-.089-4.634h0zm-.622 12.921l.089.178.089-.089c.8 2.049 1.689 4.099 2.666 6.06l-.178-.089v.178c-1.955-.713-4.088-1.337-6.043-1.782l.089-.089h-.267c1.333-1.337 2.577-2.851 3.555-4.366h0zm-12.086 4.723c.8 0 1.511 0 2.311.178-.889.446-1.777.624-2.666.713-.622.089-1.244 0-1.777-.178 0-.267.355-.713 2.133-.713z", fill: "#fff" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-colored-pdf"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconColoredPdf$1;},KsIconColoredPdf$1 = GetKsIconColoredPdf$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-colored-pdf"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-colored-pdf":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconColoredPdf$1(transTagName));
        }
        break;
    }});
}

const KsIconColoredPdf = KsIconColoredPdf$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconColoredPdf, defineCustomElement };
//# sourceMappingURL=ks-icon-colored-pdf.js.map
//# sourceMappingURL=ks-icon-colored-pdf.js.map