import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconAuto$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconAuto$1 =

    proxyCustomElement(class KsIconAuto extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-auto';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'a743d055757d11e2aad1396da61a92df962baeb3', class: "ks-icon", "ks-icon": true }, h("svg", { key: '31ab315825317ab5c0a45ec4999b0c8dacc5b3dd', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'b6746536df077a803d2721864bdc1439527ad375', d: "M15.2611 5.63715H30.7478L24.7006 19.059H36.5L19.1696 42.3628L21.1608 25.0324H11.5L15.2611 5.63715Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-auto"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconAuto$1;},KsIconAuto$1 = GetKsIconAuto$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-auto"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-auto":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconAuto$1(transTagName));
        }
        break;
    }});
}

const KsIconAuto = KsIconAuto$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconAuto, defineCustomElement };
//# sourceMappingURL=ks-icon-auto.js.map
//# sourceMappingURL=ks-icon-auto.js.map