import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconGoogleDrive$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconGoogleDrive$1 =

    proxyCustomElement(class KsIconGoogleDrive extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-google-drive';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '2f5bf5844f9d0cacad3ca64aee09c4b916a92752', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'cb9d96cd6f4c344b059e8a39465f53daffd72599', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'c00d0ad11f43ecf24c9215e193c69ec2b3090166', d: "M44.2137 31.6112H31.7705L19.5909 6M44.2137 31.6112L31.4489 6.97417C31.1141 6.37278 30.4804 6 29.7918 6H19.5909M44.2137 31.6112L38.129 40.4072C37.7809 40.9546 37.1776 41.2866 36.5278 41.2866H10.3045M44.2137 31.6112H15.4843L10.3045 41.2866M19.5909 6L4.12648 29.7018C3.7831 30.3107 3.80397 31.0592 4.17865 31.6492L10.3045 41.2866M19.5909 6L24.1092 15.501L10.3045 41.2866", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-google-drive"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconGoogleDrive$1;},KsIconGoogleDrive$1 = GetKsIconGoogleDrive$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-google-drive"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-google-drive":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconGoogleDrive$1(transTagName));
        }
        break;
    }});
}

const KsIconGoogleDrive = KsIconGoogleDrive$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconGoogleDrive, defineCustomElement };
//# sourceMappingURL=ks-icon-google-drive.js.map
//# sourceMappingURL=ks-icon-google-drive.js.map