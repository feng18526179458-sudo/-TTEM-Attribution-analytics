import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconCampaignList$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconCampaignList$1 =

    proxyCustomElement(class KsIconCampaignList extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-campaign-list';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '3f9dc197c2a981c805fade010d689937393120f0', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'ba4a2e27aa18ba8bdba6e73d3340e79eea92c3ed', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("rect", { key: '7c814c34430a271c08734980cea16c88c952d5a6', x: "6.85742", y: "6.85742", width: "34.2857", height: "34.2857", rx: "3.11688", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("line", { key: '477ec717fe3d35d971bb32adb168cd8ce89536cb', x1: "17.8525", y1: "40.1492", x2: "17.8525", y2: "7.76233", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: '7d6581185c09df7cf7d95cd78d61a3b1cbdf71ce', d: "M41.1432 18.6111H18.3574", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: 'f24dab7ecdb1f1d38808333a8f770f2d1876653b', d: "M41.1432 29.3889H18.3574", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-campaign-list"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconCampaignList$1;},KsIconCampaignList$1 = GetKsIconCampaignList$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-campaign-list"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-campaign-list":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconCampaignList$1(transTagName));
        }
        break;
    }});
}

const KsIconCampaignList = KsIconCampaignList$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconCampaignList, defineCustomElement };
//# sourceMappingURL=ks-icon-campaign-list.js.map
//# sourceMappingURL=ks-icon-campaign-list.js.map