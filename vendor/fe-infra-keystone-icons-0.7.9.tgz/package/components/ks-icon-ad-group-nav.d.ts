import type { Components, JSX } from "../dist/types/components";

interface KsIconAdGroupNav extends Components.KsIconAdGroupNav, HTMLElement {}
export const KsIconAdGroupNav: {
    prototype: KsIconAdGroupNav;
    new (): KsIconAdGroupNav;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
