import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconPuzzle$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconPuzzle$1 =

    proxyCustomElement(class KsIconPuzzle extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-puzzle';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'ee952660fb2b5e397cb23bd91b165f7ebe79a247', class: "ks-icon", "ks-icon": true }, h("svg", { key: '0e3ef188826924f73ff768ba4f15bb471dfbbba1', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '8f6f13d5abcc07d790ba6b3fdd70ab74075ec73f', d: "M40.413 15.153a5.38 5.38 0 0 1-3.852 1.58c-.313-.002-.623.102-.844.324-.409.409-.409 1.071 0 1.48l7.506 7.506a1.15 1.15 0 0 1 0 1.629l-4.596 4.596c-.503.503-1.194.771-1.905.739-1.31-.059-2.358-1.107-2.417-2.417l-.05-1.115c-.162-.724-.524-1.413-1.088-1.977a4.05 4.05 0 0 0-5.723 0 4.05 4.05 0 0 0 0 5.723 4.03 4.03 0 0 0 2.139 1.121l1.278.24c.999.188 1.78.969 1.967 1.967.15.8-.104 1.622-.679 2.197l-4.585 4.585c-.384.384-1.007.384-1.391 0l-7.603-7.603a1.08 1.08 0 0 0-1.525 0c-.228.228-.336.547-.335.869a5.38 5.38 0 0 1-1.58 3.837c-2.107 2.107-5.523 2.107-7.63 0s-2.107-5.523 0-7.63a5.38 5.38 0 0 1 3.978-1.578c.312.009.622-.092.843-.312.396-.396.396-1.039 0-1.436L4.763 21.92a1.11 1.11 0 0 1 0-1.568l4.701-4.701c.454-.454 1.083-.686 1.723-.636 1.078.084 1.934.94 2.018 2.018l.079 1.008a4.03 4.03 0 0 0 1.121 2.139 4.05 4.05 0 0 0 5.723 0 4.05 4.05 0 0 0 0-5.723c-.564-.564-1.252-.926-1.977-1.088l-1.158-.201c-.942-.164-1.68-.901-1.843-1.843-.126-.726.109-1.468.63-1.989l4.663-4.663a1 1 0 0 1 1.412 0l7.66 7.66c.384.384 1.007.384 1.391 0 .214-.214.312-.514.302-.816a5.38 5.38 0 0 1 1.577-3.993c2.107-2.107 5.523-2.107 7.63 0s2.107 5.523 0 7.63z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-puzzle"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconPuzzle$1;},KsIconPuzzle$1 = GetKsIconPuzzle$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-puzzle"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-puzzle":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconPuzzle$1(transTagName));
        }
        break;
    }});
}

const KsIconPuzzle = KsIconPuzzle$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconPuzzle, defineCustomElement };
//# sourceMappingURL=ks-icon-puzzle.js.map
//# sourceMappingURL=ks-icon-puzzle.js.map