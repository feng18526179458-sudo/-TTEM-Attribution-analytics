import type { Components, JSX } from "../dist/types/components";

interface KsIconChevronRight extends Components.KsIconChevronRight, HTMLElement {}
export const KsIconChevronRight: {
    prototype: KsIconChevronRight;
    new (): KsIconChevronRight;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
