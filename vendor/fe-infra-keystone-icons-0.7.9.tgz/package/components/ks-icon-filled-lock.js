import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledLock$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledLock$1 =

    proxyCustomElement(class KsIconFilledLock extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-lock';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
        this.innerColor = '#fff';
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'aac082df843f29160642eac346e3815e96e093ae', class: "ks-icon", "ks-icon": true }, h("svg", { key: '8af37e3838facd2cee87105b21b320bcb501141e', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '7fe979291a22bf65b32938d6a3362f6b132bcbb6', d: "M22.9911 17.2502C30.3087 17.2503 36.2411 23.1826 36.2411 30.5002C36.241 37.8175 30.3086 43.749 22.9911 43.7492C15.6736 43.7492 9.74132 37.8176 9.74115 30.5002C9.74115 23.1825 15.6735 17.2502 22.9911 17.2502Z", fill: icon.color, stroke: icon.color, "stroke-width": icon.strokeWidth * 0.3333333333333333 }), h("ellipse", { key: '29321a2ce471c7a5161467592fbd0adf75ffa7ec', cx: "22.9999", cy: "27.8994", rx: "4.19993", ry: "4.1999", fill: this.innerColor }), h("path", { key: '0f0dc750f9f37105efc132ed3d1ea406ffe521a4', d: "M21.5049 37.8998C21.5049 38.7282 22.1765 39.3997 23.0049 39.3997C23.8333 39.3997 24.5048 38.7282 24.5048 37.8998H21.5049ZM21.5049 26.7V37.8998H24.5048V26.7H21.5049Z", fill: this.innerColor }), h("path", { key: '3ec2e2b52eca796106441cfb634c2b3c14222743', d: "M32.9885 25.5002V14.2505C32.9885 8.8658 28.6234 4.50064 23.2387 4.50064C17.854 4.50064 13.4888 8.8658 13.4888 14.2505V24.7336", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-lock"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"],
      "innerColor": [1, "inner-color"]
    }]);return innerKsIconFilledLock$1;},KsIconFilledLock$1 = GetKsIconFilledLock$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-lock"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-lock":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledLock$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledLock = KsIconFilledLock$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledLock, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-lock.js.map
//# sourceMappingURL=ks-icon-filled-lock.js.map