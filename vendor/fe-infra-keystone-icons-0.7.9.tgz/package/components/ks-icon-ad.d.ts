import type { Components, JSX } from "../dist/types/components";

interface KsIconAd extends Components.KsIconAd, HTMLElement {}
export const KsIconAd: {
    prototype: KsIconAd;
    new (): KsIconAd;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
