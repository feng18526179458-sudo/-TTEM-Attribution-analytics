import type { Components, JSX } from "../dist/types/components";

interface KsIconCart extends Components.KsIconCart, HTMLElement {}
export const KsIconCart: {
    prototype: KsIconCart;
    new (): KsIconCart;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
