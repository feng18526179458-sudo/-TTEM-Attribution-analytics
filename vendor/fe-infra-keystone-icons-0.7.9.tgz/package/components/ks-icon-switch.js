import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconSwitch$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconSwitch$1 =

    proxyCustomElement(class KsIconSwitch extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-switch';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'c2256177b1846a727759b3b1e52e51310c4b30d5', class: "ks-icon", "ks-icon": true }, h("svg", { key: '1f917e9b89c952bbbba3c0376e27fc89caecf1b3', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '43f4aea61b27becf674daa02c5ffcc66334daf9e', d: "M4.264 27a1.75 1.75 0 1 0 3.5 0h-3.5zm13.75-10.25h22.233v-3.5H18.014v3.5zM7.764 27c0-5.661 4.589-10.25 10.25-10.25v-3.5c-7.594 0-13.75 6.156-13.75 13.75h3.5z", fill: icon.color }), h("path", { key: '9c7e279b591a116122429e4b32afd69068cb5f0b', d: "M35.226 9.689l4.244 4.25a1.5 1.5 0 0 1-.001 2.122l-4.252 4.252", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '2697fda3f83d8f1d074d7f80ab9e94eac4914b48', d: "M42.275 22.5a1.75 1.75 0 1 0-3.5 0h3.5zm-13.75 10.25H6.868v3.5h21.657v-3.5zm10.25-10.25c0 5.661-4.589 10.25-10.25 10.25v3.5c7.594 0 13.75-6.156 13.75-13.75h-3.5z", fill: icon.color }), h("path", { key: '71b72f7eaee001b971e105f7927fe9eb557237e4', d: "M11.328 39.811l-4.244-4.25a1.5 1.5 0 0 1 .001-2.122l4.252-4.252", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-switch"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconSwitch$1;},KsIconSwitch$1 = GetKsIconSwitch$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-switch"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-switch":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconSwitch$1(transTagName));
        }
        break;
    }});
}

const KsIconSwitch = KsIconSwitch$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconSwitch, defineCustomElement };
//# sourceMappingURL=ks-icon-switch.js.map
//# sourceMappingURL=ks-icon-switch.js.map