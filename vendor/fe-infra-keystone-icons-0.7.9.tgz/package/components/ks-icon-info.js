import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconInfo$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconInfo$1 =

    proxyCustomElement(class KsIconInfo extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-info';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '6a52229648ead09508ea2e2f8f0952108e3425a7', class: "ks-icon", "ks-icon": true }, h("svg", { key: '38f7082fa569dc8126572854426887c4b911fdd7', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("circle", { key: '471cc9dd1c0a93668e05d522ec355c78a381f2ea', cx: "24", cy: "24", r: "18.5", transform: "rotate(-180 24 24)", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '8e18b682ef5bb8b976746f2746cc9bb1e7e4cfb3', d: "M23.7255 14.2369V14.2269", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '70fec300534541d431019277c05b31c1a0797719', d: "M23.7227 19.034L23.7227 32.9872", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: '0a08114b0047420511f479d9fea3f7daa074d1b6', d: "M27.4753 33.5341L19.9753 33.5341", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: 'f9eab6b0c14ee169951197dc0db312e74db88767', d: "M23.7227 19.034H21.2147", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-info"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconInfo$1;},KsIconInfo$1 = GetKsIconInfo$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-info"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-info":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconInfo$1(transTagName));
        }
        break;
    }});
}

const KsIconInfo = KsIconInfo$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconInfo, defineCustomElement };
//# sourceMappingURL=ks-icon-info.js.map
//# sourceMappingURL=ks-icon-info.js.map