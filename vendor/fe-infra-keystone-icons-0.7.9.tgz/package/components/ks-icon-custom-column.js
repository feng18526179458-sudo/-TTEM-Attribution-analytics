import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconCustomColumn$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconCustomColumn$1 =

    proxyCustomElement(class KsIconCustomColumn extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-custom-column';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'e486e3d9626372c5c1a2c6274552575ce85f8836', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'd45515a93b63bf802ee012d079b60d2f753d1bb9', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'cd1c76d24a241ca14d22e9f614b28c18e8792915', d: "M7.46289 8.62799H40.4629C41.8436 8.62799 42.9629 9.74728 42.9629 11.128V39.003C42.9629 40.3837 41.8436 41.503 40.4629 41.503H7.46289C6.08218 41.503 4.96289 40.3837 4.96289 39.003V11.128C4.9629 9.74728 6.08218 8.628 7.46289 8.62799Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '126c8331c316747ef8076f8f258d00da1f8b3829', d: "M30.1415 40.8134L30.1415 9.85699", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '3d2a1a7001484f602c7ddd5de4f870fe368982f7', d: "M17.9305 40.8134L17.9305 9.85699", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-custom-column"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconCustomColumn$1;},KsIconCustomColumn$1 = GetKsIconCustomColumn$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-custom-column"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-custom-column":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconCustomColumn$1(transTagName));
        }
        break;
    }});
}

const KsIconCustomColumn = KsIconCustomColumn$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconCustomColumn, defineCustomElement };
//# sourceMappingURL=ks-icon-custom-column.js.map
//# sourceMappingURL=ks-icon-custom-column.js.map