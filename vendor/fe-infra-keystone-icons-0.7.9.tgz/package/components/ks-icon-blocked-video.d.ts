import type { Components, JSX } from "../dist/types/components";

interface KsIconBlockedVideo extends Components.KsIconBlockedVideo, HTMLElement {}
export const KsIconBlockedVideo: {
    prototype: KsIconBlockedVideo;
    new (): KsIconBlockedVideo;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
