import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconColorDropper$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconColorDropper$1 =

    proxyCustomElement(class KsIconColorDropper extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-color-dropper';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '10e189b3eea23c721aa74f1d16372e30bab3473c', class: "ks-icon", "ks-icon": true }, h("svg", { key: '7dd57ae881daf3796ff8c7852d52ed5ea2f133f1', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'ba09491a3008a23d6f356f28a10ebf8bfd22376b', d: "M33.085 21.681l-7.273-7.273L9.83 30.389c-.301.301-.186.786.205.867.781.161 1.011 1.133.41 1.734l-1.71 1.71c-1.325 1.325-1.476 3.323-.337 4.463s3.137.988 4.462-.337l1.753-1.753c.576-.576 1.506-.346 1.646.407.07.376.535.491.823.203l16.003-16.003z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" }), h("path", { key: '8d2447c951027a8eec9b1821626acb4d31f82e4f', d: "M39.561 8.068a8.01 8.01 0 0 0-11.326 0l-3.177 3.177-2.343-2.343c-.669-.669-1.755-.669-2.424 0s-.67 1.755 0 2.424l15.874 15.874c.669.669 1.755.669 2.424 0s.669-1.755 0-2.424l-2.205-2.205 3.177-3.177a8.01 8.01 0 0 0 0-11.326z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-color-dropper"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconColorDropper$1;},KsIconColorDropper$1 = GetKsIconColorDropper$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-color-dropper"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-color-dropper":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconColorDropper$1(transTagName));
        }
        break;
    }});
}

const KsIconColorDropper = KsIconColorDropper$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconColorDropper, defineCustomElement };
//# sourceMappingURL=ks-icon-color-dropper.js.map
//# sourceMappingURL=ks-icon-color-dropper.js.map