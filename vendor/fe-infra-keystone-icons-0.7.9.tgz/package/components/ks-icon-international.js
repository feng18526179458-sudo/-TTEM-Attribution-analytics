import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconInternational$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconInternational$1 =

    proxyCustomElement(class KsIconInternational extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-international';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '4d6616e2caa654749fe194b19111951921c3dcd6', class: "ks-icon", "ks-icon": true }, h("svg", { key: '5f1bdcd935d036f94f375fb99f3ef1b5b7d38b45', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("circle", { key: '046b14625c1ce274ac27cca0b2de7dcba21b3b83', cx: "24", cy: "24", r: "19.5" }), h("path", { key: '4b70d798b64d7d1fb3432e89a546a481e51fc189', d: "M27.074 42.093c-.469-1.761-.803-5.494 1.62-6.339 3.029-1.056-.634-6.198 3.522-8.03 3.325-1.465 8.382.413 10.354 2.432M30.284 5.333c-.272 1.27-.516 4.041.681 4.966 1.496 1.156 3.469 2.381 2.313 3.741s-4.49.476-5.986 3.129 2.041 7.687-2.857 9.388-5.443-5.034-9.388-3.129 1.769 6.667-2.448 8.843c-3.374 1.742-6.168-.771-7.143-2.245" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-international"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconInternational$1;},KsIconInternational$1 = GetKsIconInternational$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-international"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-international":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconInternational$1(transTagName));
        }
        break;
    }});
}

const KsIconInternational = KsIconInternational$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconInternational, defineCustomElement };
//# sourceMappingURL=ks-icon-international.js.map
//# sourceMappingURL=ks-icon-international.js.map