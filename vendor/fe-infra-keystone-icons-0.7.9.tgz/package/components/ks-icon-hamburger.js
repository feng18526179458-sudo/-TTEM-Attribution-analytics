import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconHamburger$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconHamburger$1 =

    proxyCustomElement(class KsIconHamburger extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-hamburger';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '04d765c2415d59dccd284c442f62a0366d08b939', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: 'e6df82058343e312a9ed11a92b24f3186528549e', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: 'd058408fa857a58818269662f14f6e3f8f48e9ee', d: "M11.399 24h33.599M3 7.201h41.999M2.998 40.8h41.999" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-hamburger"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconHamburger$1;},KsIconHamburger$1 = GetKsIconHamburger$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-hamburger"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-hamburger":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconHamburger$1(transTagName));
        }
        break;
    }});
}

const KsIconHamburger = KsIconHamburger$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconHamburger, defineCustomElement };
//# sourceMappingURL=ks-icon-hamburger.js.map
//# sourceMappingURL=ks-icon-hamburger.js.map