import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconAndroid$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconAndroid$1 =

    proxyCustomElement(class KsIconAndroid extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-android';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'dce709be67fd65266f76b3590561ae2707351394', class: "ks-icon", "ks-icon": true }, h("svg", { key: '2836af79b535acd7c9697896e33eff318c9019c6', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("g", { key: '653e7faffe861b5afbf143974a6985e033c07ae1', stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" }, h("path", { key: '6f7ce937cbf0af6c84e7b4d69a04f32b838b53dd', d: "M43.501 34.5h-39c.983-9.887 9.338-17.609 19.5-17.609s18.517 7.722 19.5 17.609z" }), h("path", { key: 'b14c41c20dcf8bded80af0d30b93a3cf8124ec60', d: "M14.199 18.848L10.279 12m22.541 6.848L36.74 12", "stroke-linecap": "round" })), h("g", { key: '03816a9cbd95720e3a2e6ca246edf58b51e07004', fill: icon.color }, h("use", { key: '8f132c45764a79876a084d1b713272964102034e', href: "#B" }), h("use", { key: 'd45b1b9c2491809dc604963f5bd50b36798e82a6', href: "#B", x: "17.633" })), h("defs", { key: '8e6c8ba632b4875c4e4167b48f03804e8179d4f7' }, h("path", { key: 'f2449a3ddd68bd040e823366efc4a65ad584f957', id: "B", d: "M15.182 29.608a1.96 1.96 0 0 0 1.96-1.956 1.96 1.96 0 0 0-1.96-1.957 1.96 1.96 0 0 0-1.96 1.957 1.96 1.96 0 0 0 1.96 1.956z" }))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-android"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconAndroid$1;},KsIconAndroid$1 = GetKsIconAndroid$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-android"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-android":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconAndroid$1(transTagName));
        }
        break;
    }});
}

const KsIconAndroid = KsIconAndroid$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconAndroid, defineCustomElement };
//# sourceMappingURL=ks-icon-android.js.map
//# sourceMappingURL=ks-icon-android.js.map