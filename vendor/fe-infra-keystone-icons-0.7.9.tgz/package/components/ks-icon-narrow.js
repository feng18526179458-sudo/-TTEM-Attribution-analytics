import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconNarrow$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconNarrow$1 =

    proxyCustomElement(class KsIconNarrow extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-narrow';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '1d621ccc0c76b408efb79c4deb77f306f3d755e9', class: "ks-icon", "ks-icon": true }, h("svg", { key: '2f66dd54aae1d03c7f1f0e6aa8826f32a5102d11', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '68fa15c1386a0ad9269b34329e2df7db0d3d6e52', d: "M17.27 16.906H8.571a3.43 3.43 0 0 0-3.429 3.429v18.852a3.43 3.43 0 0 0 3.429 3.429h18.366a3.43 3.43 0 0 0 3.428-3.429v-8.334M17.27 16.906V8.814a3.43 3.43 0 0 1 3.429-3.429h18.731a3.43 3.43 0 0 1 3.428 3.429v18.609a3.43 3.43 0 0 1-3.428 3.429h-9.062M17.27 16.906h9.668a3.43 3.43 0 0 1 3.428 3.428v10.517M17.27 16.906v10.517a3.43 3.43 0 0 0 3.429 3.429h9.668", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '81dcf8af0cc5fb1fef5dece1257e889f68ea3680', "fill-rule": "evenodd", d: "M28.084 31.085a2.92 2.92 0 0 0 2.917-2.917v-8.308a2.92 2.92 0 0 0-2.917-2.917H20.19a2.92 2.92 0 0 0-2.917 2.917v8.308a2.92 2.92 0 0 0 2.917 2.917h7.894z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-narrow"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconNarrow$1;},KsIconNarrow$1 = GetKsIconNarrow$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-narrow"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-narrow":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconNarrow$1(transTagName));
        }
        break;
    }});
}

const KsIconNarrow = KsIconNarrow$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconNarrow, defineCustomElement };
//# sourceMappingURL=ks-icon-narrow.js.map
//# sourceMappingURL=ks-icon-narrow.js.map