import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconHero$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconHero$1 =

    proxyCustomElement(class KsIconHero extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-hero';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '681b4ba2e3538ed9f96733fd11a92caab632b72b', class: "ks-icon", "ks-icon": true }, h("svg", { key: '0a337b79dd7e52e8de64640ea5b8a426ee18aaac', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("g", { key: '8a1d39e121094663256a3ae5b9d881677a713d64', "clip-path": "url(#A)", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("circle", { key: '4cff5e1ab17441b4cb9c14685a567968295b7f8a', cx: "24", cy: "24", r: "22.5" }), h("path", { key: '4052ca3f27a05173fd1b637e1dc9eb93aa89035f', d: "M24 13.123l2.749 7.093 7.596.423-5.896 4.807 1.945 7.354L24 28.678 17.607 32.8l1.945-7.354-5.896-4.806 7.596-.423L24 13.123z", "stroke-linejoin": "round" })), h("defs", { key: '59a791d8dd9679441ea79a7365feffb9bef6ccea' }, h("clipPath", { key: '301907f1eed788bf75e0acda26cc43e66a54ca82', id: "A" }, h("path", { key: '3097055ada24c1310625b4395b7fe15b8f569870', fill: "#fff", d: "M0 0h48v48H0z" })))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-hero"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconHero$1;},KsIconHero$1 = GetKsIconHero$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-hero"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-hero":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconHero$1(transTagName));
        }
        break;
    }});
}

const KsIconHero = KsIconHero$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconHero, defineCustomElement };
//# sourceMappingURL=ks-icon-hero.js.map
//# sourceMappingURL=ks-icon-hero.js.map