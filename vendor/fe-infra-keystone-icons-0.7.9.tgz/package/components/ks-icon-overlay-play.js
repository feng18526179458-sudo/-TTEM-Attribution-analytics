import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconOverlayPlay$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconOverlayPlay$1 =

    proxyCustomElement(class KsIconOverlayPlay extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-overlay-play';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'd6b7996b4937a0ccc49e810cd4c0c0f13dd49543', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'f560c1d99f77d0f61d3745d8b05363c9a745608d', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'aa94d35340cb8dc2896e02dcd88c6bef00d1d977', "fill-rule": "evenodd", "clip-rule": "evenodd", d: "M24.0151 4.49866C34.7845 4.49866 43.5151 13.2294 43.5151 23.9987C43.5149 34.7678 34.7844 43.4977 24.0151 43.4977C13.2461 43.4974 4.51633 34.7676 4.51611 23.9987C4.51611 13.2295 13.246 4.49889 24.0151 4.49866Z", fill: "#262627", "fill-opacity": "0.7" }), h("path", { key: '3340d4af4b8a87b26ff884342b1270890db5992f', d: "M19.1819 16.9488C19.1821 15.9873 20.2768 15.4353 21.0502 16.0067L30.5934 23.0569C31.2273 23.5252 31.2272 24.4735 30.5934 24.9419L21.0502 31.9922C20.2767 32.5636 19.1819 32.0117 19.1819 31.05V16.9488Z", fill: "white" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-overlay-play"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconOverlayPlay$1;},KsIconOverlayPlay$1 = GetKsIconOverlayPlay$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-overlay-play"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-overlay-play":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconOverlayPlay$1(transTagName));
        }
        break;
    }});
}

const KsIconOverlayPlay = KsIconOverlayPlay$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconOverlayPlay, defineCustomElement };
//# sourceMappingURL=ks-icon-overlay-play.js.map
//# sourceMappingURL=ks-icon-overlay-play.js.map