import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconSave$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconSave$1 =

    proxyCustomElement(class KsIconSave extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-save';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '13fb2b2d80d9530622294b384a7ee9a521cb0e48', class: "ks-icon", "ks-icon": true }, h("svg", { key: '0668553a8b6c599bda4c75fa119ba98e94cb52a0', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: 'cf83ada8048d5172e4aba1ca52673d9e026ed782', d: "M42.003 16.146a3 3 0 0 0-.611-1.814l-6.566-8.646A3 3 0 0 0 32.437 4.5H9.003a3 3 0 0 0-3 3v33a3 3 0 0 0 3 3h30a3 3 0 0 0 3-3V16.146z" }), h("rect", { key: '56cc6447a5f404798c2cf28c0d8e3685b776b857', width: "12", height: "9", rx: "1.5", transform: "matrix(-1 0 0 1 27.0041 4.5)" }), h("path", { key: 'a127414a9dcaf515b8b41c5178b14455d39382eb', d: "M36.001 30a1.5 1.5 0 0 0-1.5-1.5h-21a1.5 1.5 0 0 0-1.5 1.5v12a1.5 1.5 0 0 0 1.5 1.5h21a1.5 1.5 0 0 0 1.5-1.5V30z" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-save"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconSave$1;},KsIconSave$1 = GetKsIconSave$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-save"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-save":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconSave$1(transTagName));
        }
        break;
    }});
}

const KsIconSave = KsIconSave$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconSave, defineCustomElement };
//# sourceMappingURL=ks-icon-save.js.map
//# sourceMappingURL=ks-icon-save.js.map