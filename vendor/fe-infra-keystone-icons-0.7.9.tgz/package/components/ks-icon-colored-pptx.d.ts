import type { Components, JSX } from "../dist/types/components";

interface KsIconColoredPptx extends Components.KsIconColoredPptx, HTMLElement {}
export const KsIconColoredPptx: {
    prototype: KsIconColoredPptx;
    new (): KsIconColoredPptx;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
