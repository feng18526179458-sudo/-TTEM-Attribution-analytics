import type { Components, JSX } from "../dist/types/components";

interface KsIconBrowserWindow extends Components.KsIconBrowserWindow, HTMLElement {}
export const KsIconBrowserWindow: {
    prototype: KsIconBrowserWindow;
    new (): KsIconBrowserWindow;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
