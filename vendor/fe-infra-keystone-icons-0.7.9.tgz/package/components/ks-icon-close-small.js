import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconCloseSmall$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconCloseSmall$1 =

    proxyCustomElement(class KsIconCloseSmall extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-close-small';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '5fcbda508c317c40862fc5fd3f65037da2a1da2f', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'b024c1a022d837fc168a4f350b20c21c30910a32', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: '1e52f0642ad239f68008f4b8e9711a24f8f5ce1f', d: "M13.5 13.5l21 21" }), h("path", { key: '45615196fd26ca8bcbe0b9b01c53174101088957', d: "M13.5 34.5l21-21" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-close-small"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconCloseSmall$1;},KsIconCloseSmall$1 = GetKsIconCloseSmall$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-close-small"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-close-small":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconCloseSmall$1(transTagName));
        }
        break;
    }});
}

const KsIconCloseSmall = KsIconCloseSmall$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconCloseSmall, defineCustomElement };
//# sourceMappingURL=ks-icon-close-small.js.map
//# sourceMappingURL=ks-icon-close-small.js.map