import type { Components, JSX } from "../dist/types/components";

interface KsIconDelete extends Components.KsIconDelete, HTMLElement {}
export const KsIconDelete: {
    prototype: KsIconDelete;
    new (): KsIconDelete;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
