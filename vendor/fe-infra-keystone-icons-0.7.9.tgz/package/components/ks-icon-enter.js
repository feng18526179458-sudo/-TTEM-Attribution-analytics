import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconEnter$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconEnter$1 =

    proxyCustomElement(class KsIconEnter extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-enter';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '52b53de4b92c8dbd0a9a70b5f499f1f6832cc00a', class: "ks-icon", "ks-icon": true }, h("svg", { key: '300cdbaaa52eb57f7ef6dfcf429633aded3c5da4', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '894f25d5abd163c7b9fdf923fe2da464c5d6d11e', d: "M40.148 8.77102V28.9114C40.148 31.5153 38.0372 33.7624 35.4333 33.7624L7.85201 33.7624M7.85201 33.7624L13.5124 27.9688M7.85201 33.7624L13.5124 39.229", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-enter"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconEnter$1;},KsIconEnter$1 = GetKsIconEnter$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-enter"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-enter":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconEnter$1(transTagName));
        }
        break;
    }});
}

const KsIconEnter = KsIconEnter$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconEnter, defineCustomElement };
//# sourceMappingURL=ks-icon-enter.js.map
//# sourceMappingURL=ks-icon-enter.js.map