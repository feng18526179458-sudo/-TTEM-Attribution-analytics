import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconBookmarked$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconBookmarked$1 =

    proxyCustomElement(class KsIconBookmarked extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-bookmarked';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
        this.innerColor = 'white';
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'b7deaa252fa3e37e6b1b94deed1e85d11509b5aa', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: '38f88c749b1869242701c88b4d6a91b4bb3ea263', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("rect", { key: 'cc8b814c96d8f29c79aa5cdc4b2ce18a3788ef42', x: "7.5", y: "3", width: "33", height: "42", rx: "3", fill: icon.color }), h("path", { key: 'a31d55c509fb479be6754f316c4d9c2d6b8104d1', d: "M21.001 7.5a1.5 1.5 0 0 1 1.5-1.5h12A1.5 1.5 0 0 1 36 7.5v16.048c0 1.311-1.565 1.991-2.523 1.097l-4.567-4.263a.6.6 0 0 0-.819 0l-4.567 4.263c-.959.895-2.524.215-2.524-1.097V7.5z", fill: this.innerColor })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-bookmarked"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"],
      "innerColor": [1, "inner-color"]
    }]);return innerKsIconBookmarked$1;},KsIconBookmarked$1 = GetKsIconBookmarked$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-bookmarked"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-bookmarked":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconBookmarked$1(transTagName));
        }
        break;
    }});
}

const KsIconBookmarked = KsIconBookmarked$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconBookmarked, defineCustomElement };
//# sourceMappingURL=ks-icon-bookmarked.js.map
//# sourceMappingURL=ks-icon-bookmarked.js.map