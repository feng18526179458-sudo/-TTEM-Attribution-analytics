import type { Components, JSX } from "../dist/types/components";

interface KsIconFilledLimitedApproval extends Components.KsIconFilledLimitedApproval, HTMLElement {}
export const KsIconFilledLimitedApproval: {
    prototype: KsIconFilledLimitedApproval;
    new (): KsIconFilledLimitedApproval;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
