import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconBulletedList$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconBulletedList$1 =

    proxyCustomElement(class KsIconBulletedList extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-bulleted-list';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '67af70e9906253e376b6db2d37cbc2ed0528db93', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: '495a5c40c44d9cae4484e5b28a14f694215420fa', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'bf407572c0662b297051fe33cbfadd8ff056dbfd', d: "M16.199 24h26.727M16.199 8.727h26.727M16.199 39.273h26.727", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("g", { key: '90379d8890780efd9b00b860b771e4fa03e78939', fill: icon.color }, h("rect", { key: 'fcca21b30d4e1cb412fd75a759dc4823341d9077', x: "6.082", y: "22.015", width: "4", height: "4", rx: "2" }), h("rect", { key: 'c097d5433dc2e4f3d644d5891ab61b1864ce44a6', x: "6.171", y: "37.273", width: "4", height: "4", rx: "2" }), h("rect", { key: '41c01ff4d41f1ea478d828f5c5e905fd9f3e136f', x: "6.082", y: "6.728", width: "4", height: "4", rx: "2" }))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-bulleted-list"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconBulletedList$1;},KsIconBulletedList$1 = GetKsIconBulletedList$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-bulleted-list"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-bulleted-list":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconBulletedList$1(transTagName));
        }
        break;
    }});
}

const KsIconBulletedList = KsIconBulletedList$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconBulletedList, defineCustomElement };
//# sourceMappingURL=ks-icon-bulleted-list.js.map
//# sourceMappingURL=ks-icon-bulleted-list.js.map