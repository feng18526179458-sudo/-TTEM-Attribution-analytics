import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFeelGood$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFeelGood$1 =

    proxyCustomElement(class KsIconFeelGood extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-feel-good';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '79ec460bd392df9dc83087e4477d9585f1d31f48', class: "ks-icon", "ks-icon": true }, h("svg", { key: '3c85104dccf62e1d66220a5baa628fa707de7553', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: 'ed803d2a1df0fe52c56d15be3f7c59ab293cff63', d: "M12 27c7.5 7.5 16.5 7.5 24 0", "stroke-linecap": "round" }), h("circle", { key: '1f4103f9bcafc5177bef1b463f313aefa7247df8', cx: "24", cy: "24", r: "19.5" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-feel-good"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFeelGood$1;},KsIconFeelGood$1 = GetKsIconFeelGood$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-feel-good"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-feel-good":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFeelGood$1(transTagName));
        }
        break;
    }});
}

const KsIconFeelGood = KsIconFeelGood$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFeelGood, defineCustomElement };
//# sourceMappingURL=ks-icon-feel-good.js.map
//# sourceMappingURL=ks-icon-feel-good.js.map