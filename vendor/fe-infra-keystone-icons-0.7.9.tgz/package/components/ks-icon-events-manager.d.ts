import type { Components, JSX } from "../dist/types/components";

interface KsIconEventsManager extends Components.KsIconEventsManager, HTMLElement {}
export const KsIconEventsManager: {
    prototype: KsIconEventsManager;
    new (): KsIconEventsManager;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
