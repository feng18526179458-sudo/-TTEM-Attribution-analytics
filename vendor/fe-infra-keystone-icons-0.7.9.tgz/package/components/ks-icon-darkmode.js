import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconDarkmode$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconDarkmode$1 =

    proxyCustomElement(class KsIconDarkmode extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-darkmode';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '4a7286141717272ba29185cfa608eda1dbf2fb8c', class: "ks-icon", "ks-icon": true }, h("svg", { key: '3a977a82ebdb0d7cfc22a1e185aba12d110c979c', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'f6dbcedcb965c8f5c4ab207f8aaa5dbe703f6caa', d: "M20.5806 5.18024C20.1899 6.6682 19.983 8.23081 19.983 9.84137C19.9832 19.9481 28.176 28.1412 38.2828 28.1412C39.8423 28.1412 41.356 27.9448 42.8013 27.5777C40.7406 35.4278 33.5969 41.2183 25.1002 41.2183C14.9935 41.2181 6.80044 33.0252 6.80035 22.9185C6.80035 14.3715 12.6596 7.19251 20.5806 5.18024Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-darkmode"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconDarkmode$1;},KsIconDarkmode$1 = GetKsIconDarkmode$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-darkmode"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-darkmode":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconDarkmode$1(transTagName));
        }
        break;
    }});
}

const KsIconDarkmode = KsIconDarkmode$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconDarkmode, defineCustomElement };
//# sourceMappingURL=ks-icon-darkmode.js.map
//# sourceMappingURL=ks-icon-darkmode.js.map