import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconBlockNone$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconBlockNone$1 =

    proxyCustomElement(class KsIconBlockNone extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-block-none';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '608a3f8c7a4d895a5b6e7aee1e5b70c0c5a8ddd1', class: "ks-icon", "ks-icon": true }, h("svg", { key: '79fcbac6c4b9a008c3b4f29004e30ca9a2a5a9d4', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("circle", { key: '6841595a603c4f84cc318505a7322bed3d6026de', cx: "24", cy: "24", r: "19.5" }), h("path", { key: 'dbb24bc941e2f38c3aa119fef1d2fde6fc47aead', d: "M10.619 37.381l27.28-27.28", "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-block-none"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconBlockNone$1;},KsIconBlockNone$1 = GetKsIconBlockNone$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-block-none"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-block-none":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconBlockNone$1(transTagName));
        }
        break;
    }});
}

const KsIconBlockNone = KsIconBlockNone$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconBlockNone, defineCustomElement };
//# sourceMappingURL=ks-icon-block-none.js.map
//# sourceMappingURL=ks-icon-block-none.js.map