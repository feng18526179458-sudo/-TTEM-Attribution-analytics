import type { Components, JSX } from "../dist/types/components";

interface KsIconFilledChevronRight extends Components.KsIconFilledChevronRight, HTMLElement {}
export const KsIconFilledChevronRight: {
    prototype: KsIconFilledChevronRight;
    new (): KsIconFilledChevronRight;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
