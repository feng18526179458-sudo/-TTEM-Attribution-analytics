import type { Components, JSX } from "../dist/types/components";

interface KsIconDoubleDay extends Components.KsIconDoubleDay, HTMLElement {}
export const KsIconDoubleDay: {
    prototype: KsIconDoubleDay;
    new (): KsIconDoubleDay;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
