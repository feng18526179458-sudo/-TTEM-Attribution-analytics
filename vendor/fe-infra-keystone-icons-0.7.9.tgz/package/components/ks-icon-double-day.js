import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconDoubleDay$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconDoubleDay$1 =

    proxyCustomElement(class KsIconDoubleDay extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-double-day';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '688dbff21bf279c1ab1616b2530967eca5a3b922', class: "ks-icon", "ks-icon": true }, h("svg", { key: '42163537dc0ec125298bba7fea90f194ccd119f0', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '0e232184a2682be3d7b0fc41cf21115800d794f0', d: "M34.8789 18.5508C34.8789 9.71423 27.7155 2.55078 18.8789 2.55078C10.0424 2.55078 2.87891 9.71423 2.87891 18.5508C2.87891 27.3873 10.0424 34.5508 18.8789 34.5508C27.7155 34.5508 34.8789 27.3873 34.8789 18.5508Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" }), h("path", { key: 'beba9932cf3b311fcd181771835d0ab8bdda9ca5', d: "M24.1885 34.5508C24.1885 40.3821 28.9157 45.1094 34.7471 45.1094C40.5784 45.1094 45.3057 40.3821 45.3057 34.5508C45.3057 28.7194 40.5784 23.9922 34.7471 23.9922", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" }), h("path", { key: 'fecde1168d512fbf219802277e9ee44736427634', d: "M18.8779 7.81934L22.2211 13.9494L29.0841 15.2346L24.2872 20.3084L25.1857 27.2327L18.8779 24.2384L12.5701 27.2327L13.4686 20.3084L8.67172 15.2346L15.5348 13.9494L18.8779 7.81934Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-double-day"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconDoubleDay$1;},KsIconDoubleDay$1 = GetKsIconDoubleDay$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-double-day"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-double-day":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconDoubleDay$1(transTagName));
        }
        break;
    }});
}

const KsIconDoubleDay = KsIconDoubleDay$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconDoubleDay, defineCustomElement };
//# sourceMappingURL=ks-icon-double-day.js.map
//# sourceMappingURL=ks-icon-double-day.js.map