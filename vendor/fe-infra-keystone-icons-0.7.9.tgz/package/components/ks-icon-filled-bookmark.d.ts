import type { Components, JSX } from "../dist/types/components";

interface KsIconFilledBookmark extends Components.KsIconFilledBookmark, HTMLElement {}
export const KsIconFilledBookmark: {
    prototype: KsIconFilledBookmark;
    new (): KsIconFilledBookmark;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
