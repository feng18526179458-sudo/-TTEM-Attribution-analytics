import type { Components, JSX } from "../dist/types/components";

interface KsIconFacebook extends Components.KsIconFacebook, HTMLElement {}
export const KsIconFacebook: {
    prototype: KsIconFacebook;
    new (): KsIconFacebook;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
