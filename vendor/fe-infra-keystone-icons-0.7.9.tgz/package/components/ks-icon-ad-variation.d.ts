import type { Components, JSX } from "../dist/types/components";

interface KsIconAdVariation extends Components.KsIconAdVariation, HTMLElement {}
export const KsIconAdVariation: {
    prototype: KsIconAdVariation;
    new (): KsIconAdVariation;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
