import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconPrivateVideo$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconPrivateVideo$1 =

    proxyCustomElement(class KsIconPrivateVideo extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-private-video';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '82c5ea2340d804d26103b4a47cc626c0137c3a76', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'aa040ee6a5335bf2fc08e53dca5b70fc0c23dcac', width: icon.width, height: icon.height, viewBox: "0 0 48 49", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'f3d306d90ee28bca4fc72bf614e2f493e4d9cf16', d: "M12.7461 16.4359L20.2461 8.93592", stroke: icon.color, "stroke-width": icon.strokeWidth }), h("path", { key: 'c46c35f55ae9c88b05bc1e438b22813342de8761', d: "M41.2481 8.93592H5.75003C4.64544 8.93592 3.75 9.83136 3.75 10.936V36.9023C3.75 38.006 4.64409 38.9011 5.74781 38.9024L41.2447 38.9418C42.9029 38.9436 44.248 37.6 44.248 35.9418V11.9359C44.248 10.279 42.9049 8.93592 41.2481 8.93592Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: 'f1ed1c4283553fd6e9a9478ed8fceed00350d902', d: "M3.75 16.4344H44.2483", stroke: icon.color, "stroke-width": icon.strokeWidth }), h("path", { key: 'd1b6a99addde33d424a5a936af278bfa41e1dd04', d: "M27.7456 16.4359L35.2456 8.93592", stroke: icon.color, "stroke-width": icon.strokeWidth }), h("path", { key: '8492db7513065dcfea735873dd75c36dae49e632', d: "M16.1645 23.9404C17.9421 26.3338 20.7903 27.8846 24.0007 27.8846C27.2111 27.8846 30.0592 26.3338 31.8369 23.9404M24.0232 31.7932V27.9007M16.4471 30.062L19.4374 27.0718M30.7666 30.0619L27.9518 27.2471", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-private-video"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconPrivateVideo$1;},KsIconPrivateVideo$1 = GetKsIconPrivateVideo$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-private-video"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-private-video":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconPrivateVideo$1(transTagName));
        }
        break;
    }});
}

const KsIconPrivateVideo = KsIconPrivateVideo$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconPrivateVideo, defineCustomElement };
//# sourceMappingURL=ks-icon-private-video.js.map
//# sourceMappingURL=ks-icon-private-video.js.map