import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconMoney$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconMoney$1 =

    proxyCustomElement(class KsIconMoney extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-money';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '653fc0e804f05afe1e2a92a5539038bfec0ae611', class: "ks-icon", "ks-icon": true }, h("svg", { key: '4091f57a5dc4ed30448daa21949b698f5c622ae7', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '212762bc672d4544f001de84e75d479ee72dae41', d: "M40.0117 9.53125C41.9447 9.53125 43.5117 11.0983 43.5117 13.0312V34.9688C43.5117 36.9018 41.9447 38.4687 40.0117 38.4688H7.98828C6.05529 38.4687 4.48828 36.9017 4.48828 34.9688V13.0312C4.48828 11.0983 6.05529 9.53125 7.98828 9.53125H40.0117Z", stroke: icon.color, "stroke-width": icon.strokeWidth }), h("path", { key: '995efc35e35ff4c2ebcb458cc7efee01125541c2', d: "M30.9531 24C30.9531 27.8401 27.8401 30.9531 24 30.9531C20.1599 30.9531 17.0469 27.8401 17.0469 24C17.0469 20.1599 20.1599 17.0469 24 17.0469C27.8401 17.0469 30.9531 20.1599 30.9531 24Z", fill: icon.color }), h("path", { key: '36a7a54f61dd0336b9349b39a3aefe9f7bd7bec3', d: "M13.9375 37.9375C13.9375 36.8936 13.7319 35.8599 13.3324 34.8955C12.9329 33.931 12.3474 33.0547 11.6092 32.3166C10.8711 31.5784 9.99476 30.9929 9.03032 30.5934C8.06587 30.1939 7.03219 29.9883 5.98828 29.9883L5.98828 37.9375H13.9375Z", fill: icon.color }), h("path", { key: 'e2d645d72d8e251525c47db6f669805cf72957de', d: "M34.0625 37.9375C34.0625 36.8936 34.2681 35.8599 34.6676 34.8955C35.0671 33.931 35.6526 33.0547 36.3908 32.3166C37.1289 31.5784 38.0052 30.9929 38.9697 30.5934C39.9341 30.1939 40.9678 29.9883 42.0117 29.9883V37.9375H34.0625Z", fill: icon.color }), h("path", { key: '6b9c5f71a114cb28dcd639f3b7fe687ced10ae87', d: "M13.9375 10.082C13.9375 11.1259 13.7319 12.1596 13.3324 13.1241C12.9329 14.0885 12.3474 14.9648 11.6092 15.703C10.8711 16.4411 9.99476 17.0267 9.03032 17.4262C8.06587 17.8256 7.03219 18.0312 5.98828 18.0312L5.98828 10.082H13.9375Z", fill: icon.color }), h("path", { key: '1e8f09094380c3e60a5fddd61757c3dff6cc2208', d: "M34.0625 10.082C34.0625 11.1259 34.2681 12.1596 34.6676 13.1241C35.0671 14.0885 35.6526 14.9648 36.3908 15.703C37.1289 16.4411 38.0052 17.0267 38.9697 17.4262C39.9341 17.8256 40.9678 18.0312 42.0117 18.0312V10.082H34.0625Z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-money"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconMoney$1;},KsIconMoney$1 = GetKsIconMoney$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-money"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-money":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconMoney$1(transTagName));
        }
        break;
    }});
}

const KsIconMoney = KsIconMoney$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconMoney, defineCustomElement };
//# sourceMappingURL=ks-icon-money.js.map
//# sourceMappingURL=ks-icon-money.js.map