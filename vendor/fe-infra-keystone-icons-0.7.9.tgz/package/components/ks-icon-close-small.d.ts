import type { Components, JSX } from "../dist/types/components";

interface KsIconCloseSmall extends Components.KsIconCloseSmall, HTMLElement {}
export const KsIconCloseSmall: {
    prototype: KsIconCloseSmall;
    new (): KsIconCloseSmall;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
