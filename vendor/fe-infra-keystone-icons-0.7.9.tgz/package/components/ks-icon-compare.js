import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconCompare$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconCompare$1 =

    proxyCustomElement(class KsIconCompare extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-compare';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '1d33d8679210df54523929f3d283febe0626f804', class: "ks-icon", "ks-icon": true }, h("svg", { key: '3d042a1907cd55d8e194c14f2a0d9f1b022f8e9a', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '8934876a34c0479341a09cf201174f585414651d', d: "M9.5 23.9995L38.5 23.9992", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '395f03910f0e24e32b128480dbd7600d9014b135', d: "M35.6367 17.6354L41.5764 23.5751C41.8107 23.8094 41.8107 24.1893 41.5764 24.4236L35.6367 30.3633", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '1590e8a37aba3842bc600389dcdb543b48279861', d: "M12.3633 30.3649L6.4236 24.4252C6.18928 24.1909 6.18928 23.811 6.4236 23.5766L12.3633 17.6369", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-compare"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconCompare$1;},KsIconCompare$1 = GetKsIconCompare$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-compare"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-compare":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconCompare$1(transTagName));
        }
        break;
    }});
}

const KsIconCompare = KsIconCompare$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconCompare, defineCustomElement };
//# sourceMappingURL=ks-icon-compare.js.map
//# sourceMappingURL=ks-icon-compare.js.map