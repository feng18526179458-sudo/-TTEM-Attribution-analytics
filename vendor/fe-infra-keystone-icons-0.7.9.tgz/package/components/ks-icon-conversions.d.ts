import type { Components, JSX } from "../dist/types/components";

interface KsIconConversions extends Components.KsIconConversions, HTMLElement {}
export const KsIconConversions: {
    prototype: KsIconConversions;
    new (): KsIconConversions;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
