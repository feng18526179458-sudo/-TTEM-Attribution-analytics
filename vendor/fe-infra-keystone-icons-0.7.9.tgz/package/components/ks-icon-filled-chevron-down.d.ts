import type { Components, JSX } from "../dist/types/components";

interface KsIconFilledChevronDown extends Components.KsIconFilledChevronDown, HTMLElement {}
export const KsIconFilledChevronDown: {
    prototype: KsIconFilledChevronDown;
    new (): KsIconFilledChevronDown;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
