import type { Components, JSX } from "../dist/types/components";

interface KsIconArrowUpSmall extends Components.KsIconArrowUpSmall, HTMLElement {}
export const KsIconArrowUpSmall: {
    prototype: KsIconArrowUpSmall;
    new (): KsIconArrowUpSmall;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
