import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFolder$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFolder$1 =

    proxyCustomElement(class KsIconFolder extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-folder';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '358809132c827e617b137d93f71e8b8498a90211', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: '1f5fb26e552edf64985e4c7a73e2fc12b91173dc', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("mask", { key: '2ee8fe8b8edc17632fa0de5c40be7b73de1101b9', id: "A", fill: "#fff" }, h("path", { key: '0f45a2733eb57d7603eb96d0c396a59f2d7f8184', d: "M3.146 8.208a3 3 0 0 1 3-3h19.657a3 3 0 0 1 2.466 1.292l6.377 9.208h-31.5v-7.5z" })), h("path", { key: 'b5e139f1486a03560746db3dad84283338ef03f4', d: "M34.645 15.708v3h5.727L37.112 14l-2.466 1.708zm-31.5 0h-3v3h3v-3zm25.123-9.208l2.466-1.708-2.466 1.708zM6.146 8.208h19.657v-6H6.146v6zm19.657 0l6.377 9.208L37.112 14l-6.377-9.208-4.933 3.416zm8.843 4.5h-31.5v6h31.5v-6zm-28.5 3v-7.5h-6v7.5h6zm19.657-7.5h0l4.933-3.416a6 6 0 0 0-4.933-2.584v6zm-19.657-6a6 6 0 0 0-6 6h6 0v-6z", fill: icon.color, mask: "url(#A)" }), h("rect", { key: 'b8d801496160ff1f971cc342b7382d5e782595f3', x: "4.638", y: "14.22", width: "39", height: "27", rx: "1.5", stroke: icon.color, "stroke-width": icon.strokeWidth })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-folder"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFolder$1;},KsIconFolder$1 = GetKsIconFolder$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-folder"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-folder":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFolder$1(transTagName));
        }
        break;
    }});
}

const KsIconFolder = KsIconFolder$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFolder, defineCustomElement };
//# sourceMappingURL=ks-icon-folder.js.map
//# sourceMappingURL=ks-icon-folder.js.map