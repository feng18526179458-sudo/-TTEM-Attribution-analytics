import type { Components, JSX } from "../dist/types/components";

interface KsIconExpand extends Components.KsIconExpand, HTMLElement {}
export const KsIconExpand: {
    prototype: KsIconExpand;
    new (): KsIconExpand;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
