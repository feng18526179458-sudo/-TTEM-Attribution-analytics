import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconCart$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconCart$1 =

    proxyCustomElement(class KsIconCart extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-cart';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '26019ae9fb64499aa900fcc04e84da121af02967', class: "ks-icon", "ks-icon": true }, h("svg", { key: '7d12fbf454fcdf4b14d7ce0fbe3b4e73d2289140', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("g", { key: '4c840403e825860124037d6cbe52507a921dacc1', stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: 'de35680dc84b5893aeaea24af70ea71f7eea04b6', d: "M9 12a1.5 1.5 0 0 1 1.5-1.5h29.751a1.5 1.5 0 0 1 1.483 1.728l-2.538 16.5A1.5 1.5 0 0 1 37.713 30H10.5A1.5 1.5 0 0 1 9 28.5V12z" }), h("path", { key: 'f03cfd65668ce6eccc48ea9cf82d14403d87f4b4', d: "M3 3l5.643 6.639A1.5 1.5 0 0 1 9 10.61V34.5a1.5 1.5 0 0 0 1.5 1.5H39", "stroke-linecap": "round" })), h("g", { key: '11de64e594f08e58cc8b598a9cbe97768425d802', fill: icon.color }, h("circle", { key: '5df5e18c37ddd91090fb6809b1c81fd98753082b', cx: "9", cy: "42", r: "3" }), h("circle", { key: '1ba4199cd914b5c599a7049ba8e645537124c2f7', cx: "39", cy: "42", r: "3" }))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-cart"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconCart$1;},KsIconCart$1 = GetKsIconCart$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-cart"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-cart":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconCart$1(transTagName));
        }
        break;
    }});
}

const KsIconCart = KsIconCart$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconCart, defineCustomElement };
//# sourceMappingURL=ks-icon-cart.js.map
//# sourceMappingURL=ks-icon-cart.js.map