import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";

const spinCss = "@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}:host(.ks-icon){animation:spin 1s linear infinite}";const GetKsIconLoading$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconLoading$1 =

    proxyCustomElement(class KsIconLoading extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-loading';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'cc4c3ddb254fdb3915a86f8d94a7bcd9fdb3bcbd', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'e10d138e725a12fc57e39773322ae161abe11564', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'b64f45de470fdfb571d639b484a7350254a200bb', d: "M4.491 24a19.51 19.51 0 0 0 19.507 19.507A19.51 19.51 0 0 0 43.505 24 19.51 19.51 0 0 0 23.998 4.493", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("animation", { key: '2180ac64035b44589cd7bf58a26d622ad997f4c3', from: "transform: rotate(0)", to: "transform: rotate(360deg)" })));
      }
      static get style() {return indexCss + spinCss;}
    }, [257, transTagName("ks-icon-loading"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconLoading$1;},KsIconLoading$1 = GetKsIconLoading$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-loading"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-loading":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconLoading$1(transTagName));
        }
        break;
    }});
}

const KsIconLoading = KsIconLoading$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconLoading, defineCustomElement };
//# sourceMappingURL=ks-icon-loading.js.map
//# sourceMappingURL=ks-icon-loading.js.map