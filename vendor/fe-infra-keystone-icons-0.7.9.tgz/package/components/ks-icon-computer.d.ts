import type { Components, JSX } from "../dist/types/components";

interface KsIconComputer extends Components.KsIconComputer, HTMLElement {}
export const KsIconComputer: {
    prototype: KsIconComputer;
    new (): KsIconComputer;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
