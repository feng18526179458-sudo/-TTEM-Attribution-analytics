import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconPauseCircle$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconPauseCircle$1 =

    proxyCustomElement(class KsIconPauseCircle extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-pause-circle';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '3cffe3f9e001be28598a15e7ef3db28e4b755522', class: "ks-icon", "ks-icon": true }, h("svg", { key: '76f2a9474e06cfc0d3e2e5e4e47adc47bd22ad6e', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color }, h("circle", { key: '24b1edeef9d2b021cdf626739a93f7ce125f857c', cx: "24", cy: "24", "stroke-width": icon.strokeWidth, r: "19.5" }), h("path", { key: '825975b3d9f65ae91f101afd5a17e7b19d973df4', d: "M18.575 17.147v13.5m10.494-13.5v13.5", "stroke-width": icon.strokeWidth * 2, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-pause-circle"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconPauseCircle$1;},KsIconPauseCircle$1 = GetKsIconPauseCircle$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-pause-circle"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-pause-circle":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconPauseCircle$1(transTagName));
        }
        break;
    }});
}

const KsIconPauseCircle = KsIconPauseCircle$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconPauseCircle, defineCustomElement };
//# sourceMappingURL=ks-icon-pause-circle.js.map
//# sourceMappingURL=ks-icon-pause-circle.js.map