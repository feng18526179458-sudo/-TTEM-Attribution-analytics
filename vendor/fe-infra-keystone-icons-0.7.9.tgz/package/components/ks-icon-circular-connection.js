import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconCircularConnection$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconCircularConnection$1 =

    proxyCustomElement(class KsIconCircularConnection extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-circular-connection';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'bfab26c3ab3f1671494fe95d9d37cfa01f747b5f', class: "ks-icon", "ks-icon": true }, h("svg", { key: '7cb9047a0e67420a215447fc9d61d92c54a28785', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("g", { key: '23d4c7bb822e1d9582c27b7f2c60d0360d49741d', fill: icon.color }, h("rect", { key: '8c6da3f9f021af49b9931ec5565af7ee75cdac4c', width: "11.522", height: "11.522", rx: "5.761", transform: "matrix(.707105 .707108 -.707105 .707108 24.0461 -1.02051)" }), h("rect", { key: '2b1e06a69c8f62e653a082e54c933131f18118e1', width: "11.522", height: "11.522", rx: "5.761", transform: "matrix(.707105 .707108 -.707105 .707108 24.0461 32.5337)" }), h("rect", { key: '891ed4859e3020577e3b80c2abb3f4e88f177c01', width: "11.522", height: "11.522", rx: "5.761", transform: "matrix(.707105 .707108 -.707105 .707108 40.9219 16.2393)" })), h("circle", { key: '64479d5e8fd2f2cec9f433046466b9ce94b440e4', cx: "18", cy: "18", r: "18", transform: "matrix(-.707105 -.707108 .707105 -.707108 24.0387 49.4702)", stroke: icon.color, "stroke-width": icon.strokeWidth }), h("rect", { key: '01c6c4b77b8edb8ecf6baf4e86929e7f286a951e', width: "11.522", height: "11.522", rx: "5.761", transform: "matrix(.707105 .707108 -.707105 .707108 7.14761 16.2393)", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-circular-connection"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconCircularConnection$1;},KsIconCircularConnection$1 = GetKsIconCircularConnection$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-circular-connection"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-circular-connection":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconCircularConnection$1(transTagName));
        }
        break;
    }});
}

const KsIconCircularConnection = KsIconCircularConnection$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconCircularConnection, defineCustomElement };
//# sourceMappingURL=ks-icon-circular-connection.js.map
//# sourceMappingURL=ks-icon-circular-connection.js.map