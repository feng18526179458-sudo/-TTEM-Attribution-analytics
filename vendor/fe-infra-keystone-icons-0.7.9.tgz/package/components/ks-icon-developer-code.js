import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconDeveloperCode$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconDeveloperCode$1 =

    proxyCustomElement(class KsIconDeveloperCode extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-developer-code';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'db7cd6a8fd69c4a2a3ff9c885ce3a38ef113f0cf', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'f09f985bab9d4ea8a6a6bf313c4c091c884c9e1d', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: 'a9cff9577b117828fdacc4fc3f0351209d9da5d9', d: "M13.606 13.287L2.893 24l10.713 10.713m20.787-21.426L45.107 24 34.394 34.713", "stroke-linejoin": "round" }), h("path", { key: '2e55d952fc6bcb43b5fb3934f3d6a97aa6b1c39d', d: "M19.747 31.366l8.505-14.731" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-developer-code"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconDeveloperCode$1;},KsIconDeveloperCode$1 = GetKsIconDeveloperCode$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-developer-code"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-developer-code":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconDeveloperCode$1(transTagName));
        }
        break;
    }});
}

const KsIconDeveloperCode = KsIconDeveloperCode$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconDeveloperCode, defineCustomElement };
//# sourceMappingURL=ks-icon-developer-code.js.map
//# sourceMappingURL=ks-icon-developer-code.js.map