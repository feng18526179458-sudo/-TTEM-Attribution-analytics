import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconHelp$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconHelp$1 =

    proxyCustomElement(class KsIconHelp extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-help';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'fa37664ebe76c208c9ff4fab7838008aeaafbf56', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: '086bcc5eb08e7ecddf56d361e61d922cca0998a8', width: icon.width, height: icon.height, viewBox: "0 0 49 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("circle", { key: '96f263de9aede26c2b2354a1d64976d4ef252c31', cx: "24.4934", cy: "23.7367", r: "18.5", transform: "rotate(-180 24.4934 23.7367)", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '5b98e17b1617f6f4f5c8696d5f53825f96469c6b', d: "M20.0198 17.6599C20.775 16.2121 22.3912 15.2115 24.2631 15.2115C26.8579 15.2115 28.9614 17.134 28.9614 19.5055C28.9614 21.1636 27.9331 22.6022 26.4276 23.3176C25.3125 23.8475 24.2631 24.8003 24.2631 26.0348L24.2631 28.6087", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '31cd09fa5464e9506afe9d43e64159f7fbfc06f5', d: "M24.3679 33.6947V33.7047", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-help"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconHelp$1;},KsIconHelp$1 = GetKsIconHelp$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-help"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-help":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconHelp$1(transTagName));
        }
        break;
    }});
}

const KsIconHelp = KsIconHelp$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconHelp, defineCustomElement };
//# sourceMappingURL=ks-icon-help.js.map
//# sourceMappingURL=ks-icon-help.js.map