import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconAdGroupNav$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconAdGroupNav$1 =

    proxyCustomElement(class KsIconAdGroupNav extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-ad-group-nav';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'fff2fe6b59af97274655a7512b45cb518e0c672a', class: "ks-icon", "ks-icon": true }, h("svg", { key: '642e12cdc30d229ebb281a5191d48d948f017f43', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '103c717e8b5d883136946e8571a95449c882beea', d: "M8.25 9.85547C8.25 8.19861 9.59315 6.85547 11.25 6.85547H29.25C30.9069 6.85547 32.25 8.19861 32.25 9.85547V38.1412C32.25 39.798 30.9069 41.1412 29.25 41.1412H11.25C9.59315 41.1412 8.25 39.798 8.25 38.1412V9.85547Z", stroke: icon.color, "stroke-width": icon.strokeWidth }), h("path", { key: '7914ced3d3b24ce329a4edfd955de82895e1f23c', d: "M16.5 32.3379L24 32.3379", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '78892fe092cfe9048ad170915e5527d31f6f1502', d: "M40.5 36.9961V12.9961", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-ad-group-nav"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconAdGroupNav$1;},KsIconAdGroupNav$1 = GetKsIconAdGroupNav$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-ad-group-nav"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-ad-group-nav":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconAdGroupNav$1(transTagName));
        }
        break;
    }});
}

const KsIconAdGroupNav = KsIconAdGroupNav$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconAdGroupNav, defineCustomElement };
//# sourceMappingURL=ks-icon-ad-group-nav.js.map
//# sourceMappingURL=ks-icon-ad-group-nav.js.map