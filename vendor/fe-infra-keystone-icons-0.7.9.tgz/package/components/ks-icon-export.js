import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconExport$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconExport$1 =

    proxyCustomElement(class KsIconExport extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-export';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'b70bad60eaddfa3670cc9bd6888e1562759373e3', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: '50f3372733495d9ab7a4d2ecc7e5433cbe3d7076', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: 'c4b43a262f3839a0db721cd61174042cd3418802', d: "M9 5.25a1.5 1.5 0 0 1 1.5-1.5h19.412a1.5 1.5 0 0 1 1.04.419l7.588 7.299a1.5 1.5 0 0 1 .46 1.081V41.25a1.5 1.5 0 0 1-1.5 1.5h-27a1.5 1.5 0 0 1-1.5-1.5v-36z" }), h("g", { key: '57746d748c1d510ac355e292e789702095072caf', "stroke-linecap": "round" }, h("path", { key: '9eced19c78e1b4dc0f9d8e43b029d76182951c68', d: "M24.019 14.444v14.061m0-.018l-6.545-6.545" }), h("path", { key: '49bb79e6e783e52b95e18c6e5b11600c1763ca76', d: "M24 28.487l6.546-6.545m-15.55 9.971v3.273h18v-3.273" }))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-export"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconExport$1;},KsIconExport$1 = GetKsIconExport$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-export"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-export":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconExport$1(transTagName));
        }
        break;
    }});
}

const KsIconExport = KsIconExport$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconExport, defineCustomElement };
//# sourceMappingURL=ks-icon-export.js.map
//# sourceMappingURL=ks-icon-export.js.map