import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconDropbox$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconDropbox$1 =

    proxyCustomElement(class KsIconDropbox extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-dropbox';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '7a9e5e09d728ceec615e2f436fa6558b88385fa7', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'd1da259a643f13007ca0555e838e76d9608b1e5d', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '91d4a86032552d7cbc5cda38d21f404e718b555c', d: "M12.6416 19.1022L4.45868 12.8734L16.3667 5.05682L24 11.7131M12.6416 19.1022L24 11.7131M12.6416 19.1022L24 26.3691M12.6416 19.1022L4.45868 25.392L16.3667 32.4147L24 26.3691M24 11.7131L35.908 18.7358M24 11.7131L31.9998 5.05682L43.5414 12.507L35.908 18.7358M35.908 18.7358L24 26.3691M35.908 18.7358L43.5414 25.392L31.8166 32.4147L24 26.3691", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" }), h("path", { key: '9fe352403565a877cdd1ad58eec783f1d8271edf', d: "M11.8033 30.303V36.369L24.001 44.5903L36.4494 36.4884V30.9717", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-dropbox"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconDropbox$1;},KsIconDropbox$1 = GetKsIconDropbox$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-dropbox"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-dropbox":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconDropbox$1(transTagName));
        }
        break;
    }});
}

const KsIconDropbox = KsIconDropbox$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconDropbox, defineCustomElement };
//# sourceMappingURL=ks-icon-dropbox.js.map
//# sourceMappingURL=ks-icon-dropbox.js.map