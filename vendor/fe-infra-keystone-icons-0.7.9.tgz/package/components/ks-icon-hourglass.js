import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconHourglass$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconHourglass$1 =

    proxyCustomElement(class KsIconHourglass extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-hourglass';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '391f67084da8ec964f185ef9315bfa8aa6a51e21', class: "ks-icon", "ks-icon": true }, h("svg", { key: '96629a95c9f4d974285a8035d74f3554b3349233', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: '7f6105e1cb82225f697c5bde1d6e2e764c2631b6', d: "M9 4.5h30m-30 39h30" }), h("path", { key: '6494e173ba9a8f3f6848370c884c6e3159414db9', d: "M36 42v-6c0-6.627-5.372-12-12-12h0c-6.627 0-12 5.373-12 12v6" }), h("path", { key: '18cc238fd4c4aeaa617d587626a497cfe2026ff7', d: "M36 6v6c0 6.627-5.372 12-12 12h0c-6.627 0-12-5.373-12-12V6" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-hourglass"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconHourglass$1;},KsIconHourglass$1 = GetKsIconHourglass$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-hourglass"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-hourglass":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconHourglass$1(transTagName));
        }
        break;
    }});
}

const KsIconHourglass = KsIconHourglass$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconHourglass, defineCustomElement };
//# sourceMappingURL=ks-icon-hourglass.js.map
//# sourceMappingURL=ks-icon-hourglass.js.map