import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconLog$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconLog$1 =

    proxyCustomElement(class KsIconLog extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-log';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'e093150d4383a66d00159dc81e6db68da53d0e0d', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: 'c04be5ef1127230076a96e13f1b586526782f600', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }, h("path", { key: '20d0e073451bd946ab3a68b482b15f6928c45e40', d: "M29.996 4.5v9h9M16.5 21h15m-15 7.5h15" }), h("path", { key: 'f2d359b6a92330ffce752839d0e3e0327a484e12', d: "M9 5.25a1.5 1.5 0 0 1 1.5-1.5h19.412a1.5 1.5 0 0 1 1.04.419l7.588 7.299a1.5 1.5 0 0 1 .46 1.081V41.25a1.5 1.5 0 0 1-1.5 1.5h-27a1.5 1.5 0 0 1-1.5-1.5v-36z" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-log"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconLog$1;},KsIconLog$1 = GetKsIconLog$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-log"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-log":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconLog$1(transTagName));
        }
        break;
    }});
}

const KsIconLog = KsIconLog$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconLog, defineCustomElement };
//# sourceMappingURL=ks-icon-log.js.map
//# sourceMappingURL=ks-icon-log.js.map