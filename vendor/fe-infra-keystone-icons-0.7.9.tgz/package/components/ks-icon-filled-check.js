import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledCheck$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledCheck$1 =

    proxyCustomElement(class KsIconFilledCheck extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-check';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
        this.innerColor = '#fff';
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '89672ec87beebc262bcbe92decd85e534c3d1d54', class: "ks-icon", "ks-icon": true }, h("svg", { key: '019b3de47fbfb7fa2ec00325664e952d5771e7a1', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("ellipse", { key: 'f64421b0b3ab1aea009eccdfc51a2befc9994364', cx: "24", cy: "24", rx: "19.5", ry: "19.5", fill: icon.color }), h("path", { key: '301846741f4e08e632b6f2635fbd665be832197b', d: "M14.5001 24.8802L20.3464 31.9174L33.5004 16.0838", stroke: this.innerColor, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-check"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"],
      "innerColor": [1, "inner-color"]
    }]);return innerKsIconFilledCheck$1;},KsIconFilledCheck$1 = GetKsIconFilledCheck$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-check"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-check":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledCheck$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledCheck = KsIconFilledCheck$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledCheck, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-check.js.map
//# sourceMappingURL=ks-icon-filled-check.js.map