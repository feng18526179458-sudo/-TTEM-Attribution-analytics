import type { Components, JSX } from "../dist/types/components";

interface KsIconDoubleChevronRight extends Components.KsIconDoubleChevronRight, HTMLElement {}
export const KsIconDoubleChevronRight: {
    prototype: KsIconDoubleChevronRight;
    new (): KsIconDoubleChevronRight;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
