import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconArrowLeft$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconArrowLeft$1 =

    proxyCustomElement(class KsIconArrowLeft extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-arrow-left';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '8a944867efa19542007362a62ba548f114e1f811', class: "ks-icon", "ks-icon": true }, h("svg", { key: '820245c99c3cb42691af8185accc13a9710db70b', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }, h("path", { key: '8782e21a867937a48f5ad0c5e381ce93d6fd70fb', d: "M12.932 12L2.489 22.966a1.5 1.5 0 0 0 0 2.069L12.932 36M4.505 23.986h39" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-arrow-left"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconArrowLeft$1;},KsIconArrowLeft$1 = GetKsIconArrowLeft$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-arrow-left"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-arrow-left":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconArrowLeft$1(transTagName));
        }
        break;
    }});
}

const KsIconArrowLeft = KsIconArrowLeft$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconArrowLeft, defineCustomElement };
//# sourceMappingURL=ks-icon-arrow-left.js.map
//# sourceMappingURL=ks-icon-arrow-left.js.map