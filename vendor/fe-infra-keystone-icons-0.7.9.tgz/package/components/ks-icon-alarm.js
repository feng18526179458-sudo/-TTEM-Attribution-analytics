import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconAlarm$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconAlarm$1 =

    proxyCustomElement(class KsIconAlarm extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-alarm';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '59eb45560e3c304b973f61384fd1c0203ff1fb06', class: "ks-icon", "ks-icon": true }, h("svg", { key: '5f2b947942e3e9bb5d22b360ad21259e95cf17c2', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("circle", { key: 'add9a5bb83458fcdad29104d0f435e82efc48b9d', cx: "23.987", cy: "24.571", r: "18" }), h("g", { key: 'c6ce498ff8763228c7e31b211a05c85721c93935', "stroke-linecap": "round" }, h("path", { key: '4b6a9f3d430bf25503bbac987bdca32dce18a5d9', d: "M6.651 17.677c-.334-.228-.652-.49-.948-.786a6.55 6.55 0 0 1 0-9.26 6.55 6.55 0 0 1 9.26 0c.265.265.502.546.711.841m25.659 9.204c.334-.228.652-.49.948-.786a6.55 6.55 0 0 0 0-9.26 6.55 6.55 0 0 0-9.26 0 6.69 6.69 0 0 0-.712.841" }), h("path", { key: '7f5d28d05e96d86ef9865efaaf36c597bad892bf', d: "M23.993 15.578v9l6 6", "stroke-linejoin": "round" }))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-alarm"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconAlarm$1;},KsIconAlarm$1 = GetKsIconAlarm$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-alarm"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-alarm":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconAlarm$1(transTagName));
        }
        break;
    }});
}

const KsIconAlarm = KsIconAlarm$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconAlarm, defineCustomElement };
//# sourceMappingURL=ks-icon-alarm.js.map
//# sourceMappingURL=ks-icon-alarm.js.map