import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconAddLink$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconAddLink$1 =

    proxyCustomElement(class KsIconAddLink extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-add-link';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'bd4bf1372dee0b098e27a048cc386a8f23982c2a', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'c4f4232ef0880ca7e379a3638d975ae831c15d17', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: icon.color, "fill-rule": "evenodd", stroke: icon.color }, h("path", { key: '34dfc17ea70e94b588836c65f27acaa0d369c440', d: "M21.712 22.422c-4.137 0-7.491 3.354-7.491 7.492s3.354 7.492 7.492 7.492H37.49c3.853 0 6.976-3.123 6.976-6.976v-2.728a4.25 4.25 0 0 0-4.248-4.248 1.5 1.5 0 1 1 0-3 7.25 7.25 0 0 1 7.248 7.248v2.728a9.98 9.98 0 0 1-9.976 9.976H21.712c-5.794 0-10.491-4.697-10.491-10.492s4.697-10.492 10.492-10.492h2.669a1.5 1.5 0 1 1 0 3h-2.669zm4.57 3.156c4.137 0 7.492-3.354 7.492-7.492s-3.354-7.492-7.492-7.492H10.505c-3.852 0-6.975 3.123-6.975 6.976v2.728a4.25 4.25 0 0 0 4.248 4.248 1.5 1.5 0 1 1 0 3A7.25 7.25 0 0 1 .53 20.298V17.57a9.98 9.98 0 0 1 9.975-9.975h15.777c5.794 0 10.492 4.697 10.492 10.492s-4.697 10.492-10.492 10.492h-2.669a1.5 1.5 0 1 1 0-3h2.669z" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-add-link"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconAddLink$1;},KsIconAddLink$1 = GetKsIconAddLink$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-add-link"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-add-link":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconAddLink$1(transTagName));
        }
        break;
    }});
}

const KsIconAddLink = KsIconAddLink$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconAddLink, defineCustomElement };
//# sourceMappingURL=ks-icon-add-link.js.map
//# sourceMappingURL=ks-icon-add-link.js.map