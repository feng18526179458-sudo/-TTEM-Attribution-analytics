import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconGoogle$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconGoogle$1 =

    proxyCustomElement(class KsIconGoogle extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-google';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'a694fb9e0ac8d284e7b6916d93c1c36b1935dfc8', class: "ks-icon", "ks-icon": true }, h("svg", { key: '5a6e01e1b21b229ff80cb648dac3649782bca23b', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '74e7d2248a2163579ecd247b57dc2549adf6cf55', d: "M45.12 24.5a25.28 25.28 0 0 0-.4-4.5H24v8.52h11.84c-.52 2.74-2.08 5.06-4.42 6.62v5.54h7.14c4.16-3.84 6.56-9.48 6.56-16.18z", fill: "#4285f4" }), h("path", { key: '3cff0079f9ef634278764f7cab189c91d817ea98', d: "M24 46c5.94 0 10.92-1.96 14.56-5.32l-7.14-5.54c-1.96 1.32-4.46 2.12-7.42 2.12-5.72 0-10.58-3.86-12.32-9.06H4.36v5.68C7.98 41.06 15.4 46 24 46z", fill: "#34a853" }), h("path", { key: '456944be793fc3a1001169d0de6185e352212cb2', d: "M11.68 28.18c-.44-1.32-.7-2.72-.7-4.18s.26-2.86.7-4.18v-5.68H4.36a21.73 21.73 0 0 0 0 19.72l5.7-4.44 1.62-1.24z", fill: "#fbbc05" }), h("path", { key: 'ace6f9e07e3a0af975b696fb1df38afade54198a', d: "M24 10.76c3.24 0 6.12 1.12 8.42 3.28l6.3-6.3C34.9 4.18 29.94 2 24 2 15.4 2 7.98 6.94 4.36 14.14l7.32 5.68c1.74-5.2 6.6-9.06 12.32-9.06z", fill: "#ea4335" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-google"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconGoogle$1;},KsIconGoogle$1 = GetKsIconGoogle$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-google"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-google":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconGoogle$1(transTagName));
        }
        break;
    }});
}

const KsIconGoogle = KsIconGoogle$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconGoogle, defineCustomElement };
//# sourceMappingURL=ks-icon-google.js.map
//# sourceMappingURL=ks-icon-google.js.map