import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledInfo$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledInfo$1 =

    proxyCustomElement(class KsIconFilledInfo extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-info';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
        this.innerColor = '#fff';
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '9c22bb0adeaa07684ca130821830e97a8c003263', class: "ks-icon", "ks-icon": true }, h("svg", { key: '0f16f017e2f9e2f9954090fac67012a255526423', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("ellipse", { key: '0cf25a7dd3cb0369d8f8ee0f03188d208aae4fe2', cx: "24", cy: "24", rx: "19.5", ry: "19.5", fill: icon.color }), h("ellipse", { key: '1b489d9f22ac8db08015516f8a1d885f30afac06', cx: "23.2706", cy: "11.5579", rx: "2.18836", ry: "2.18838", fill: this.innerColor }), h("path", { key: 'c6401d7001e0777fb88adc99bc0e1a1e6e37851c', d: "M24.0023 18.1226L24.0023 35.6299", stroke: this.innerColor, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: '889efac2e33d984fde2971ee54b0f661ffc4fbd7', d: "M28.3764 35.6295L19.6228 35.6295", stroke: this.innerColor, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: '846b665166c05c48bfc0653147e1042a94a7cd9c', d: "M24.0019 18.1222H21.0748", stroke: this.innerColor, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-info"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"],
      "innerColor": [1, "inner-color"]
    }]);return innerKsIconFilledInfo$1;},KsIconFilledInfo$1 = GetKsIconFilledInfo$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-info"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-info":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledInfo$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledInfo = KsIconFilledInfo$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledInfo, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-info.js.map
//# sourceMappingURL=ks-icon-filled-info.js.map