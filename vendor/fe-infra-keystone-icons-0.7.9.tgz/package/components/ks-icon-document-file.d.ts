import type { Components, JSX } from "../dist/types/components";

interface KsIconDocumentFile extends Components.KsIconDocumentFile, HTMLElement {}
export const KsIconDocumentFile: {
    prototype: KsIconDocumentFile;
    new (): KsIconDocumentFile;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
