import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconHeadset$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconHeadset$1 =

    proxyCustomElement(class KsIconHeadset extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-headset';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'eba366692cd5d4f3e6e149b8d3073e42142fc6a6', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'f497fe21812b126a5cb550bfc975447c2de0b3e2', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", "stroke-width": icon.strokeWidth, stroke: icon.color }, h("rect", { key: '7667c1f7fa98cde12a680b85129e06c5d65126d4', x: "1.837", y: "1.06", width: "8.093", height: "15.367", rx: "1.5", transform: "matrix(.96587 -.259029 .25861 .965982 1.28149 22.8903)" }), h("rect", { key: '79b11735a3d6f356e5bc75d08a94c9735f94c095', x: "-1.837", y: "1.06", width: "8.093", height: "15.367", rx: "1.5", transform: "matrix(-.96587 -.259029 -.25861 .965982 43.1569 21.9392)" }), h("path", { key: '5e56e067294bc654df3610c6b256f831f31d5b7c', d: "M40.857 21.482A16.98 16.98 0 0 0 23.89 4.5 16.98 16.98 0 0 0 6.922 21.482M23.889 43.5a16.92 16.92 0 0 0 12.92-5.974", "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-headset"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconHeadset$1;},KsIconHeadset$1 = GetKsIconHeadset$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-headset"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-headset":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconHeadset$1(transTagName));
        }
        break;
    }});
}

const KsIconHeadset = KsIconHeadset$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconHeadset, defineCustomElement };
//# sourceMappingURL=ks-icon-headset.js.map
//# sourceMappingURL=ks-icon-headset.js.map