import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconCardList$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconCardList$1 =

    proxyCustomElement(class KsIconCardList extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-card-list';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'e14f6017c91286e0c231e1c5650cdac200971776', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: 'b3057b084825d2b42d4f1d118054689f3d219a9e', width: icon.width, height: icon.height, viewBox: "0 0 49 49", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '1169dd20e115229f7fafd3fa1344b0472563d76f', d: "M8.10851 29.3135V41.3135H20.1085V29.3135H8.10851ZM23.1085 41.3135C23.1083 42.9701 21.7652 44.3134 20.1085 44.3135H8.10851C6.50353 44.3135 5.19287 43.0528 5.11241 41.4678L5.10851 41.3135V29.3135C5.10851 27.6566 6.45168 26.3135 8.10851 26.3135H20.1085C21.7652 26.3136 23.1085 27.6567 23.1085 29.3135V41.3135Z", fill: icon.color }), h("path", { key: '03c04b7ac0f09f6e0aa0eecd30d9ed79419d268d', d: "M29.1091 29.3135V41.3135H41.1091V29.3135H29.1091ZM44.1091 41.3135C44.109 42.9701 42.7658 44.3134 41.1091 44.3135H29.1091C27.5042 44.3135 26.1935 43.0528 26.113 41.4678L26.1091 41.3135V29.3135C26.1091 27.6566 27.4523 26.3135 29.1091 26.3135H41.1091C42.7659 26.3136 44.1091 27.6567 44.1091 29.3135V41.3135Z", fill: icon.color }), h("path", { key: 'cd81215b77e97ada6e0d921482090f66d9e59115', d: "M8.10815 8.31348V20.3135H20.1082V8.31348H8.10815ZM23.1082 20.3135C23.108 21.9701 21.7648 23.3134 20.1082 23.3135H8.10815C6.50318 23.3135 5.19252 22.0528 5.11206 20.4678L5.10815 20.3135V8.31348C5.10815 6.65665 6.45133 5.31348 8.10815 5.31348H20.1082C21.7649 5.31358 23.1082 6.65671 23.1082 8.31348V20.3135Z", fill: icon.color }), h("path", { key: '86f2f6f2851d393102327b6950b79c7ac5f9745e', d: "M29.1085 8.31368V20.3137H41.1085V8.31368H29.1085ZM44.1085 20.3137C44.1083 21.9703 42.7651 23.3136 41.1085 23.3137H29.1085C27.5035 23.3137 26.1929 22.053 26.1124 20.468L26.1085 20.3137V8.31368C26.1085 6.65685 27.4517 5.31368 29.1085 5.31368H41.1085C42.7652 5.31378 44.1085 6.65691 44.1085 8.31368V20.3137Z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-card-list"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconCardList$1;},KsIconCardList$1 = GetKsIconCardList$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-card-list"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-card-list":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconCardList$1(transTagName));
        }
        break;
    }});
}

const KsIconCardList = KsIconCardList$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconCardList, defineCustomElement };
//# sourceMappingURL=ks-icon-card-list.js.map
//# sourceMappingURL=ks-icon-card-list.js.map