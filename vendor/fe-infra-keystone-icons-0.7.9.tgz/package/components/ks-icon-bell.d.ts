import type { Components, JSX } from "../dist/types/components";

interface KsIconBell extends Components.KsIconBell, HTMLElement {}
export const KsIconBell: {
    prototype: KsIconBell;
    new (): KsIconBell;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
