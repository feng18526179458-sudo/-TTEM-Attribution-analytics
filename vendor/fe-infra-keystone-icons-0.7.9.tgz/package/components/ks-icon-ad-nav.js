import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconAdNav$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconAdNav$1 =

    proxyCustomElement(class KsIconAdNav extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-ad-nav';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'ecfee663e07577fdd3c5f469e6c92e0d1008a6bf', class: "ks-icon", "ks-icon": true }, h("svg", { key: '64e6ff08044244da634a2ce84e6ac0335dbfe03e', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '37e6e4a0c39f62aba953621671155400919eedf2', d: "M9 9.85547C9 8.19861 10.3431 6.85547 12 6.85547H36C37.6569 6.85547 39 8.19861 39 9.85547V38.1412C39 39.798 37.6569 41.1412 36 41.1412H12C10.3431 41.1412 9 39.798 9 38.1412V9.85547Z", stroke: icon.color, "stroke-width": icon.strokeWidth }), h("path", { key: '59dffbdfc8cc56aa26567ae68929183cbbe6f6a6', d: "M17.4646 29.7012L30.5349 29.7012", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-ad-nav"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconAdNav$1;},KsIconAdNav$1 = GetKsIconAdNav$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-ad-nav"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-ad-nav":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconAdNav$1(transTagName));
        }
        break;
    }});
}

const KsIconAdNav = KsIconAdNav$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconAdNav, defineCustomElement };
//# sourceMappingURL=ks-icon-ad-nav.js.map
//# sourceMappingURL=ks-icon-ad-nav.js.map