import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconTransitions$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconTransitions$1 =

    proxyCustomElement(class KsIconTransitions extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-transitions';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '4dac75f6ed7a76aa9c42175f83104f862b92b86e', class: "ks-icon", "ks-icon": true }, h("svg", { key: '153287af2190e57f7b601a9b0188c9c1e5c1415e', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '007dc176d3d84b93091ad62e6b125d63802ceb78', d: "M36.325 13.497h2.787a3.43 3.43 0 0 1 3.429 3.429v12.539a3.43 3.43 0 0 1-3.429 3.429h-2.787m0-19.396v-1.467a3.43 3.43 0 0 0-3.429-3.429h-4.255m7.684 4.896v19.396M28.642 8.601v-.549a3.43 3.43 0 0 0-3.428-3.429H8.818a3.43 3.43 0 0 0-3.429 3.429v32.326a3 3 0 0 0 3 3h16.824a3.43 3.43 0 0 0 3.428-3.429v-.75m0-30.598v30.598m0 0h4.255a3.43 3.43 0 0 0 3.429-3.429v-2.877", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" }), h("path", { key: '1fba7a9479cad23edfe115527b317c937a14238a', d: "M22.651 22.814l-7.336-5.42c-.974-.719-2.351-.024-2.351 1.186v10.84c0 1.21 1.378 1.906 2.351 1.186l7.336-5.42c.798-.59.798-1.783 0-2.372z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-transitions"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconTransitions$1;},KsIconTransitions$1 = GetKsIconTransitions$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-transitions"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-transitions":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconTransitions$1(transTagName));
        }
        break;
    }});
}

const KsIconTransitions = KsIconTransitions$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconTransitions, defineCustomElement };
//# sourceMappingURL=ks-icon-transitions.js.map
//# sourceMappingURL=ks-icon-transitions.js.map