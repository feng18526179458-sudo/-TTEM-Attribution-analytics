import type { Components, JSX } from "../dist/types/components";

interface KsIconConnect extends Components.KsIconConnect, HTMLElement {}
export const KsIconConnect: {
    prototype: KsIconConnect;
    new (): KsIconConnect;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
