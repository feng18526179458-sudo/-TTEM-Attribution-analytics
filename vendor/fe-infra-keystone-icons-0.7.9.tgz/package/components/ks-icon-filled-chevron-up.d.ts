import type { Components, JSX } from "../dist/types/components";

interface KsIconFilledChevronUp extends Components.KsIconFilledChevronUp, HTMLElement {}
export const KsIconFilledChevronUp: {
    prototype: KsIconFilledChevronUp;
    new (): KsIconFilledChevronUp;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
