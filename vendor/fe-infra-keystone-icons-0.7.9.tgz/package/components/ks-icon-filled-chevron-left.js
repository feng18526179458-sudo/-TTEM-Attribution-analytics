import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledChevronLeft$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledChevronLeft$1 =

    proxyCustomElement(class KsIconFilledChevronLeft extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-chevron-left';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '329a7ac4431bb1d545580380a859ee46cdaa2963', class: "ks-icon", "ks-icon": true }, h("svg", { key: '84b38fe8075b8d9b745167b76f31d433928755ce', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'addd77434d44e2227cf48b647940405dbfacfd3f', d: "M13.9606 25.0581C13.3785 24.473 13.3785 23.5275 13.9605 22.9424L31.9127 4.89578C32.3411 4.46516 32.9869 4.33538 33.5483 4.56709C34.1098 4.7988 34.4761 5.34625 34.4761 5.95366V42.0464C34.4761 42.6539 34.1098 43.2013 33.5483 43.433C32.9869 43.6647 32.3411 43.535 31.9127 43.1043L13.9606 25.0581Z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-chevron-left"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFilledChevronLeft$1;},KsIconFilledChevronLeft$1 = GetKsIconFilledChevronLeft$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-chevron-left"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-chevron-left":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledChevronLeft$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledChevronLeft = KsIconFilledChevronLeft$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledChevronLeft, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-chevron-left.js.map
//# sourceMappingURL=ks-icon-filled-chevron-left.js.map