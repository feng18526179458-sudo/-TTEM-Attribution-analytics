import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconCopyContent$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconCopyContent$1 =

    proxyCustomElement(class KsIconCopyContent extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-copy-content';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '380ac0bf6f40eaa85b563e9911a36e59205b2471', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: '0fb45d0ca956e897092d05f68b6908f406bfae67', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("rect", { key: '38e802c3d7be5b03061aa863e61d291f877b961f', x: "4.503", y: "4.5", width: "30.75", height: "30.75", rx: "1.5" }), h("path", { key: '0f501aaa0e9d4d14163a3b8a92b5914e430e2ddc', d: "M13.127 36.244V42a1.5 1.5 0 0 0 1.5 1.5h27.375a1.5 1.5 0 0 0 1.5-1.5V14.625a1.5 1.5 0 0 0-1.5-1.5h-5.756" }), h("g", { key: 'e1dfb7a1aff70522b399b585e1ab3b62d306d1f0', "stroke-linecap": "round", "stroke-linejoin": "round" }, h("path", { key: '94c07424456839279e87273c8932fdb540f44b0f', d: "M13.125 19.875h13.5" }), h("path", { key: 'fc245cef322c5d67d1050ba5c71c6e9f7a21ac19', d: "M19.875 13.125v13.5" }))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-copy-content"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconCopyContent$1;},KsIconCopyContent$1 = GetKsIconCopyContent$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-copy-content"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-copy-content":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconCopyContent$1(transTagName));
        }
        break;
    }});
}

const KsIconCopyContent = KsIconCopyContent$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconCopyContent, defineCustomElement };
//# sourceMappingURL=ks-icon-copy-content.js.map
//# sourceMappingURL=ks-icon-copy-content.js.map