import type { Components, JSX } from "../dist/types/components";

interface KsIconAlignRight extends Components.KsIconAlignRight, HTMLElement {}
export const KsIconAlignRight: {
    prototype: KsIconAlignRight;
    new (): KsIconAlignRight;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
