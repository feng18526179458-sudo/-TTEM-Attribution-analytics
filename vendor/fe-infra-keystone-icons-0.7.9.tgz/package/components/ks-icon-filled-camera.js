import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledCamera$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledCamera$1 =

    proxyCustomElement(class KsIconFilledCamera extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-camera';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
        this.innerColor = 'white';
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'da72830bb8f147e8933b4a7d740c684a0a555368', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'ab1ada4b18c81f24a409f3c2e9d4251d7befea6e', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '35aa0f1f321a5dc1654bbc87997c535247b4727a', d: "M3.002 16.5a3 3 0 0 1 3-3h7.5 6.697a1.5 1.5 0 0 0 1.248-.668l2.109-3.164A1.5 1.5 0 0 1 24.805 9h8.894a1.5 1.5 0 0 1 1.248.668l2.109 3.164a1.5 1.5 0 0 0 1.248.668h3.697a3 3 0 0 1 3 3v21a3 3 0 0 1-3 3h-36a3 3 0 0 1-3-3v-21z", fill: icon.color }), h("circle", { key: 'b8780f5039e24fa49880a3aaee2d13dd67d0fdf3', cx: "30.005", cy: "27", stroke: this.innerColor, "stroke-width": icon.strokeWidth, r: "7.5" }), h("path", { key: '542e5faa5695de0b1226cc950634a6e8efd465ee', d: "M7.499 21a1.5 1.5 0 0 1 3 0v12a1.5 1.5 0 0 1-3 0V21z", fill: this.innerColor, "fill-opacity": ".8" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-camera"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"],
      "innerColor": [1, "inner-color"]
    }]);return innerKsIconFilledCamera$1;},KsIconFilledCamera$1 = GetKsIconFilledCamera$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-camera"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-camera":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledCamera$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledCamera = KsIconFilledCamera$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledCamera, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-camera.js.map
//# sourceMappingURL=ks-icon-filled-camera.js.map