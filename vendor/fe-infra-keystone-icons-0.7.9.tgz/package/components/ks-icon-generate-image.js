import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconGenerateImage$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconGenerateImage$1 =

    proxyCustomElement(class KsIconGenerateImage extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-generate-image';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '3c9ae6d2f57c6d88014ef51641d4c0ca496c72ba', class: "ks-icon", "ks-icon": true }, h("svg", { key: '9bd7db90a7b5592306c5677f0e51fe10230eea6d', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '4f5b4bce7e870a9738c2050c7d055ff2c169d8e4', d: "M18.7616 11.5245H8.46881C6.81196 11.5245 5.46881 12.8677 5.46881 14.5245V37.7054C5.46881 39.3623 6.81195 40.7054 8.46881 40.7054H39.5979C41.2548 40.7054 42.5979 39.3623 42.5979 37.7055V26.1981", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '4a31c5d37cd30ccbce8f23763e5f1deb1896bd8b', d: "M8.16757 39.649L23.3837 25.4575C24.5996 24.3235 26.506 24.3947 27.6339 25.6163L39.949 38.9535", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '127ada491d37fd34de689b27cf3b6326d2c1eb37', d: "M16.6169 20.4267C16.6169 21.4527 15.7851 22.2845 14.7591 22.2845C13.733 22.2845 12.9012 21.4527 12.9012 20.4267C12.9012 19.4006 13.733 18.5688 14.7591 18.5688C15.7851 18.5688 16.6169 19.4006 16.6169 20.4267Z", fill: icon.color, stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" }), h("path", { key: 'db02aa0bc3ecde2ba91d15f2b63bfda3a66c917b', d: "M32.9776 4C33.5948 3.99868 34.1938 4.35675 34.4058 4.95095C34.7305 6.07307 34.9744 7.20459 35.4111 8.29368C36.309 10.5332 37.4854 11.6975 39.7192 12.5813C40.8049 13.0108 41.927 13.2499 43.0441 13.5686C43.6394 13.7784 43.9994 14.3735 44 14.9898C44.0006 15.6057 43.6416 16.2015 43.0471 16.4124C41.9304 16.7362 40.8068 16.9747 39.7207 17.4066C37.4853 18.2956 36.3093 19.4653 35.4103 21.7078C34.9969 22.7391 34.7089 23.807 34.4514 24.8852C34.2988 25.5658 33.6565 26.0015 32.9776 26C32.2759 25.9985 31.7008 25.5514 31.5092 24.8784C31.3066 23.9561 31.0002 22.8017 30.5646 21.7033C29.681 19.4753 28.5194 18.3003 26.2808 17.4096C25.4638 17.0846 24.6145 16.8303 23.8511 16.6376C22.9315 16.4202 21.9989 16.083 22 14.9898C22.0011 13.8968 22.9329 13.5607 23.8534 13.3457C24.6168 13.1546 25.4661 12.9024 26.2831 12.579C28.5192 11.6939 29.6809 10.5222 30.5631 8.29823C30.9958 7.20737 31.2343 6.07972 31.554 4.95702C31.7631 4.36285 32.3611 4.00137 32.9776 4Z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-generate-image"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconGenerateImage$1;},KsIconGenerateImage$1 = GetKsIconGenerateImage$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-generate-image"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-generate-image":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconGenerateImage$1(transTagName));
        }
        break;
    }});
}

const KsIconGenerateImage = KsIconGenerateImage$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconGenerateImage, defineCustomElement };
//# sourceMappingURL=ks-icon-generate-image.js.map
//# sourceMappingURL=ks-icon-generate-image.js.map