import type { Components, JSX } from "../dist/types/components";

interface KsIconCatalog extends Components.KsIconCatalog, HTMLElement {}
export const KsIconCatalog: {
    prototype: KsIconCatalog;
    new (): KsIconCatalog;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
