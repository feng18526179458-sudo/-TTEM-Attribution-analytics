import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconVolumeDown$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconVolumeDown$1 =

    proxyCustomElement(class KsIconVolumeDown extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-volume-down';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '8c39002506a09258447b7dad382b77080dc258fb', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: '16c5a7e2bba8c15f8226c8ecb27bd24e65f9c4c1', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 47 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: 'df12adfe971bd930afcc98a6056e08532dca1e2c', d: "M10.239 15.957c-1.6 0-2.896 1.324-2.896 2.958v11.01c0 1.633 1.297 2.958 2.896 2.958h4.057c.535 0 1.045.227 1.411.625l8.568 9.363c1.196 1.307 3.342.443 3.342-1.347V6.476c0-1.828-2.225-2.672-3.393-1.287l-8.511 10.084c-.367.435-.901.684-1.463.684h-4.011z" }), h("path", { key: 'd7793f2e58e29ed158302b532e85887cf0a13d0c', d: "M33.813 32.418s3.072-3.769 3.072-8.419-3.072-8.419-3.072-8.419", "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-volume-down"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconVolumeDown$1;},KsIconVolumeDown$1 = GetKsIconVolumeDown$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-volume-down"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-volume-down":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconVolumeDown$1(transTagName));
        }
        break;
    }});
}

const KsIconVolumeDown = KsIconVolumeDown$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconVolumeDown, defineCustomElement };
//# sourceMappingURL=ks-icon-volume-down.js.map
//# sourceMappingURL=ks-icon-volume-down.js.map