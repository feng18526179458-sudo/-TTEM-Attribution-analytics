import type { Components, JSX } from "../dist/types/components";

interface KsIconArrowLeftSmall extends Components.KsIconArrowLeftSmall, HTMLElement {}
export const KsIconArrowLeftSmall: {
    prototype: KsIconArrowLeftSmall;
    new (): KsIconArrowLeftSmall;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
