import type { Components, JSX } from "../dist/types/components";

interface KsIconChevronDown extends Components.KsIconChevronDown, HTMLElement {}
export const KsIconChevronDown: {
    prototype: KsIconChevronDown;
    new (): KsIconChevronDown;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
