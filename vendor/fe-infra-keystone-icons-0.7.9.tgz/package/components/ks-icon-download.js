import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconDownload$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconDownload$1 =

    proxyCustomElement(class KsIconDownload extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-download';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'b78464142b94f131e203feead92c57b48eda1a94', class: "ks-icon", "ks-icon": true }, h("svg", { key: '3281aa93dc4e143e89c503ccd9c6e7a46e1d9992', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: '66e100fb01a74549df4c0a994734d5cb3a5f3aeb', d: "M24.038 7.222V33m0-.034l-12-12" }), h("path", { key: 'b8bb0db2a4bc669edcb97b4cd323436296441567', d: "M24.001 32.967l12-12M7.501 33v6h33v-6" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-download"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconDownload$1;},KsIconDownload$1 = GetKsIconDownload$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-download"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-download":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconDownload$1(transTagName));
        }
        break;
    }});
}

const KsIconDownload = KsIconDownload$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconDownload, defineCustomElement };
//# sourceMappingURL=ks-icon-download.js.map
//# sourceMappingURL=ks-icon-download.js.map