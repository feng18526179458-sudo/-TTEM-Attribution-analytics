import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconUppercase$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconUppercase$1 =

    proxyCustomElement(class KsIconUppercase extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-uppercase';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'c7b4150b476880dfe9a9e84b114b0733b206fe94', class: "ks-icon", "ks-icon": true }, h("svg", { key: '38d4c831d1f3637a318a4e9b1930d2cf04d0a81b', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '1b74466253a61d166c10ed848cfec6e6d51729ac', d: "M36.3189 23.4388H43.2935V26.945C43.2935 31.1655 39.8464 34.5868 35.5942 34.5868H34.5214C30.8617 34.5868 27.895 31.6422 27.895 28.0098L27.895 20.9946C27.895 13.6843 37.3038 10.6239 41.6631 16.5163", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: '715fb8a19472a36db1e6bb1a43c2a157e5c57018', d: "M22.4601 35.2319L13.0398 12.7681L4.70649 35.2319M19.0794 27.1703H7.69708", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-uppercase"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconUppercase$1;},KsIconUppercase$1 = GetKsIconUppercase$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-uppercase"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-uppercase":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconUppercase$1(transTagName));
        }
        break;
    }});
}

const KsIconUppercase = KsIconUppercase$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconUppercase, defineCustomElement };
//# sourceMappingURL=ks-icon-uppercase.js.map
//# sourceMappingURL=ks-icon-uppercase.js.map