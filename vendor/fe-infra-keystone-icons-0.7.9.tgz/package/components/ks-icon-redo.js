import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconRedo$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconRedo$1 =

    proxyCustomElement(class KsIconRedo extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-redo';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '8597fdfdcd00cd14017a912f82bb1628fac3c97a', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: '136e3839172cc0aee553169014aefe85d1bdedb9', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: 'ed6776e95b01d7726f9577807410b5165859873f', d: "M37.768 18.83l5.509-5.509m-5.51-5.509l5.509 5.509m-.824-.127h-25.97A12 12 0 0 0 4.484 25.191h0a12 12 0 0 0 11.998 11.998h21.002" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-redo"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconRedo$1;},KsIconRedo$1 = GetKsIconRedo$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-redo"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-redo":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconRedo$1(transTagName));
        }
        break;
    }});
}

const KsIconRedo = KsIconRedo$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconRedo, defineCustomElement };
//# sourceMappingURL=ks-icon-redo.js.map
//# sourceMappingURL=ks-icon-redo.js.map