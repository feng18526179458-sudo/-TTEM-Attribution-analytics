import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconArrowDown$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconArrowDown$1 =

    proxyCustomElement(class KsIconArrowDown extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-arrow-down';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'bbd43404083d88ceeddaa4b1d4abb5a48724b963', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'b3728bf725f528144505329a1139e619cfa80848', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }, h("path", { key: 'c1eaa05ed089b21fd88c4ef21c20763642fd8c27', d: "M36.003 35.071L25.037 45.515a1.5 1.5 0 0 1-2.069 0L12.003 35.071M24.02 43.5v-39" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-arrow-down"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconArrowDown$1;},KsIconArrowDown$1 = GetKsIconArrowDown$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-arrow-down"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-arrow-down":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconArrowDown$1(transTagName));
        }
        break;
    }});
}

const KsIconArrowDown = KsIconArrowDown$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconArrowDown, defineCustomElement };
//# sourceMappingURL=ks-icon-arrow-down.js.map
//# sourceMappingURL=ks-icon-arrow-down.js.map