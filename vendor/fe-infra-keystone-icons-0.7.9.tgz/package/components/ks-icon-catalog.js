import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconCatalog$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconCatalog$1 =

    proxyCustomElement(class KsIconCatalog extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-catalog';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '5f026c28aa5ea59889724449f95b0c3d356dc0a1', class: "ks-icon", "ks-icon": true }, h("svg", { key: '89d18cd4c9bbf23537d9ac7b510a3d3d9faeb8ba', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '02f70b82aa264178765038418e4f3cb8c8b43c37', d: "M10.5001 4.28613H30.8455C32.7391 4.28613 34.2741 5.82116 34.2741 7.7147V34.5004C34.2741 36.394 32.7391 37.929 30.8455 37.929H10.5001M10.5001 4.28613H6.85728C4.96373 4.28613 3.42871 5.82116 3.42871 7.7147V34.5004C3.42871 36.394 4.96374 37.929 6.85728 37.929H10.5001M10.5001 4.28613V37.929", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: '26915994efcbe89abde6101a7c307a1b8b272495', d: "M35.3916 13.9492L42.2369 16.1492C43.9626 16.7038 44.9584 18.5058 44.5098 20.262L38.7547 42.789C38.2729 44.6752 36.319 45.7822 34.4534 45.226L10.4981 38.0849", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("line", { key: '33cd45e75e051b38efa6788b277cefe96ffd143d', x1: "16.9795", y1: "13.1387", x2: "28.0768", y2: "13.1387", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("line", { key: '32a90f38df7345c41b418a9fadd2239fed6ba100', x1: "16.9795", y1: "20.4941", x2: "28.0768", y2: "20.4941", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-catalog"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconCatalog$1;},KsIconCatalog$1 = GetKsIconCatalog$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-catalog"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-catalog":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconCatalog$1(transTagName));
        }
        break;
    }});
}

const KsIconCatalog = KsIconCatalog$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconCatalog, defineCustomElement };
//# sourceMappingURL=ks-icon-catalog.js.map
//# sourceMappingURL=ks-icon-catalog.js.map