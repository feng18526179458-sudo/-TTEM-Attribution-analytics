import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconSplit$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconSplit$1 =

    proxyCustomElement(class KsIconSplit extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-split';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '95819d408ec10dc899f826db5833a715e850eaa4', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'edc502b24659a50007113c8cafa0d464dd411cb6', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: '8dbb3bda840e27bdd032d4e51df4a5cd404bdfd8', d: "M19.713 7.49927H9.74434C8.91594 7.49927 8.24439 8.17082 8.24439 8.99922L8.24438 38.9993C8.24438 39.8277 8.91594 40.4993 9.74434 40.4993H19.713" }), h("path", { key: '2747771c52e2347dd1a2a7abf712668fde6637e1', d: "M28.2686 7.50024H38.2372C39.0656 7.50024 39.7372 8.1718 39.7372 9.0002L39.7372 39.0003C39.7372 39.8287 39.0656 40.5002 38.2372 40.5002H28.2686" }), h("line", { key: 'f6971c0e8b99b4517b4781d6d3fb0f5aef812d59', x1: "24.358", y1: "45.2373", x2: "24.358", y2: "2.76283" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-split"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconSplit$1;},KsIconSplit$1 = GetKsIconSplit$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-split"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-split":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconSplit$1(transTagName));
        }
        break;
    }});
}

const KsIconSplit = KsIconSplit$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconSplit, defineCustomElement };
//# sourceMappingURL=ks-icon-split.js.map
//# sourceMappingURL=ks-icon-split.js.map