import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconThumbsDown$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconThumbsDown$1 =

    proxyCustomElement(class KsIconThumbsDown extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-thumbs-down';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'a5e4f5774c407a2b260a888bcd124515fa02d916', class: "ks-icon", "ks-icon": true }, h("svg", { key: '479b381b73a533186d80c328e5f2d5538aa18ff3', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: '96bfffffcc949d16f4d08847d546733ae995858e', d: "M34.498 28.5l-6.506 10.121c-.152.236-.413.379-.694.379h0a3.3 3.3 0 0 1-3.3-3.3v-7.2H9.487a1.5 1.5 0 0 1-1.442-1.912l5.143-18A1.5 1.5 0 0 1 14.629 7.5h19.868v21z" }), h("path", { key: '0796647126903185c95d21814723aa0c9a33087d', d: "M40.501 27a1.5 1.5 0 0 1-1.5 1.5h-4.5v-21h4.5a1.5 1.5 0 0 1 1.5 1.5v18z" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-thumbs-down"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconThumbsDown$1;},KsIconThumbsDown$1 = GetKsIconThumbsDown$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-thumbs-down"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-thumbs-down":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconThumbsDown$1(transTagName));
        }
        break;
    }});
}

const KsIconThumbsDown = KsIconThumbsDown$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconThumbsDown, defineCustomElement };
//# sourceMappingURL=ks-icon-thumbs-down.js.map
//# sourceMappingURL=ks-icon-thumbs-down.js.map