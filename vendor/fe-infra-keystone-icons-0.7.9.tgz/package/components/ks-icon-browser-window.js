import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconBrowserWindow$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconBrowserWindow$1 =

    proxyCustomElement(class KsIconBrowserWindow extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-browser-window';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'da2a33ae907a7073378f005fbc66154c2fd34041', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: '0a6db205cba7f464980959f7bf6766f16e491520', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("g", { key: '3e18c2b4916100c2be83576e8cdb3ac4bbeae5f4', stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: 'ddfb41a2c19dcb3256ab7a8900427695bb530ac3', d: "M4.5 10.5A1.5 1.5 0 0 1 6 9h36a1.5 1.5 0 0 1 1.5 1.5v27A1.5 1.5 0 0 1 42 39H6a1.5 1.5 0 0 1-1.5-1.5v-27z" }), h("path", { key: 'f02306f88eaf7e5d9646da4cb584049eb93742aa', d: "M4.5 18h39", "stroke-linecap": "round" })), h("g", { key: '6497c3a898f735706c406021eb8407d18c5e9f24', fill: icon.color }, h("circle", { key: 'b0207dc20d2681627420e76dde376f0632cb7283', cx: "10.5", cy: "13.5", r: "1.5" }), h("circle", { key: '17b850ce5e4c45bb79cd12248349f20f324b4ed5', cx: "16.5", cy: "13.5", r: "1.5" }))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-browser-window"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconBrowserWindow$1;},KsIconBrowserWindow$1 = GetKsIconBrowserWindow$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-browser-window"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-browser-window":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconBrowserWindow$1(transTagName));
        }
        break;
    }});
}

const KsIconBrowserWindow = KsIconBrowserWindow$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconBrowserWindow, defineCustomElement };
//# sourceMappingURL=ks-icon-browser-window.js.map
//# sourceMappingURL=ks-icon-browser-window.js.map