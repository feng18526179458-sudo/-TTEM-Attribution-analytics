import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconCarousel$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconCarousel$1 =

    proxyCustomElement(class KsIconCarousel extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-carousel';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'e8dbe4df5f90d6ee688af7ea2b710e6cb22ca660', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'c09b3b79d79b5ad8bb4e9061da7b8737b3c11995', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("rect", { key: '4636b2f95e44e5295f74eb81c50f258cfe5882e8', x: "34.5", y: "43.5", width: "21", height: "39", rx: "1.5", transform: "rotate(180 34.499 43.5)", stroke: icon.color, "stroke-width": icon.strokeWidth }), h("path", { key: '6fa1c7a88eacf6bd9b3527a838422aa707cbcbb8', d: "M24.019 8.996v27.485V8.996zM12.019 42h-3a3 3 0 0 1-3-3V9a3 3 0 0 1 3-3h3v3h-3v30h3v3zm11.98-33.004V36.5 8.996zm12 33.004h3a3 3 0 0 0 3-3V9a3 3 0 0 0-3-3h-3v3h3v30h-3v3z", "fill-rule": "evenodd", fill: icon.color }), h("path", { key: '00375e00bb707a082a72a47f788ae705e97a8336', d: "M28.655 22.481l-5.968-4.409c-.99-.732-2.391-.025-2.391 1.206v8.819c0 1.231 1.401 1.938 2.391 1.206l5.968-4.409a1.5 1.5 0 0 0 0-2.413z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-carousel"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconCarousel$1;},KsIconCarousel$1 = GetKsIconCarousel$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-carousel"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-carousel":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconCarousel$1(transTagName));
        }
        break;
    }});
}

const KsIconCarousel = KsIconCarousel$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconCarousel, defineCustomElement };
//# sourceMappingURL=ks-icon-carousel.js.map
//# sourceMappingURL=ks-icon-carousel.js.map