import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconHeart$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconHeart$1 =

    proxyCustomElement(class KsIconHeart extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-heart';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '0169867a948f8db6b9c5ccd45876b3e55d3c2a69', class: "ks-icon", "ks-icon": true }, h("svg", { key: '39c033131ed5feee1ba3980d1502919bc50cd641', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '9aa61287dfca8d48a1ce1b961109147591752798', d: "M23.001 9.646l1.002.898 1.001-.899c4.344-3.899 11.059-3.768 15.243.424h0a11.1 11.1 0 0 1 .465 15.205L25.061 40.949a1.5 1.5 0 0 1-2.123 0L7.288 25.274c-3.864-4.358-3.709-11.03.464-15.204 4.188-4.188 10.892-4.33 15.249-.424z", stroke: icon.color, "stroke-width": icon.strokeWidth })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-heart"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconHeart$1;},KsIconHeart$1 = GetKsIconHeart$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-heart"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-heart":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconHeart$1(transTagName));
        }
        break;
    }});
}

const KsIconHeart = KsIconHeart$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconHeart, defineCustomElement };
//# sourceMappingURL=ks-icon-heart.js.map
//# sourceMappingURL=ks-icon-heart.js.map