import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconErase$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconErase$1 =

    proxyCustomElement(class KsIconErase extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-erase';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'fc86458f18ff7a9c56036d1e5c86e6447797e369', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'e3b7d752dfae7c2ba15f9166790d2277b8139e72', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '3e47b6a0b2fa76c320d695c9dc1e376363ae62e3', d: "M20.5853 42.6804L44.988 42.6804", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: 'e2557df573f0beb47a3a3fffacdda89d6876d6c6', d: "M11.2425 22.0779L28.0479 38.8834", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '3da5829bb6dc6917a76df9aacb72b9227e33128b', d: "M2.34373 28.4263L3.39865 29.4813L27.0874 5.79241C27.6749 5.20493 28.6273 5.20493 29.2148 5.79241L44.5223 21.1C45.1098 21.6875 45.1098 22.6399 44.5223 23.2274L25.5131 42.2367C25.231 42.5188 24.8484 42.6773 24.4494 42.6773H15.0903C14.6913 42.6773 14.3087 42.5188 14.0266 42.2367L3.39865 31.6087C2.81117 31.0212 2.81117 30.0687 3.39865 29.4813L2.34373 28.4263Z", stroke: icon.color, "stroke-width": icon.strokeWidth })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-erase"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconErase$1;},KsIconErase$1 = GetKsIconErase$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-erase"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-erase":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconErase$1(transTagName));
        }
        break;
    }});
}

const KsIconErase = KsIconErase$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconErase, defineCustomElement };
//# sourceMappingURL=ks-icon-erase.js.map
//# sourceMappingURL=ks-icon-erase.js.map