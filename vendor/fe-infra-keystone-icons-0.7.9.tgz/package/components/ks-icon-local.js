import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconLocal$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconLocal$1 =

    proxyCustomElement(class KsIconLocal extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-local';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'b3e8a29ad73a0183ecd7acac2ae213ab1f1ce46a', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: 'c6023f80768edbfde99f60af91f96e46750a195f', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: '64f23c4035cb3069d1b8489a952eff7465b900c5', d: "M12.114 9.117c6.151-6.156 16.122-6.156 22.273 0 5.841 5.846 6.178 15.216.77 21.466L24.464 42.945c-.64.74-1.786.74-2.427 0L11.344 30.583c-5.407-6.251-5.071-15.62.771-21.466z" }), h("path", { key: '5b904f2d93c7ea669c2f930c0b220f5a4047f3c3', d: "M29.047 19.893c0 3.209-2.599 5.808-5.802 5.808s-5.802-2.599-5.802-5.808 2.599-5.808 5.802-5.808 5.802 2.599 5.802 5.808z" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-local"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconLocal$1;},KsIconLocal$1 = GetKsIconLocal$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-local"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-local":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconLocal$1(transTagName));
        }
        break;
    }});
}

const KsIconLocal = KsIconLocal$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconLocal, defineCustomElement };
//# sourceMappingURL=ks-icon-local.js.map
//# sourceMappingURL=ks-icon-local.js.map