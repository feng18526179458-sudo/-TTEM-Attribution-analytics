import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconCoupon$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconCoupon$1 =

    proxyCustomElement(class KsIconCoupon extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-coupon';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'cc3bc8bf2d2088cc1de186acb51424bde1ed3e4e', class: "ks-icon", "ks-icon": true }, h("svg", { key: '7e4b27e0b7772f552e0e23d57bda2f1ae8468238', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: 'd419ca728db7e065abb714d49ae526c24bfc00f8', d: "M5.018 13.901h37.965v5.695c-2.847 0-5.695 1.898-5.695 5.22s2.847 6.169 5.695 6.169v5.695H5.018v-5.695c2.848 0 5.695-1.898 5.695-5.695s-2.847-5.695-5.695-5.695v-5.695z", "stroke-linejoin": "round" }), h("g", { key: 'a38d31b2aec62ff7a633df034251f2b24f414748', "stroke-linecap": "round" }, h("path", { key: '6b6344ac864a7c76ab86242e15a31767e9250c06', d: "M17.173 22.204h5.968m-5.968 5.968H31.1" }), h("path", { key: 'c8a2cc93e29472be831ce78d648e07b8a349dc7e', d: "M13.999 13.901l20.757-8.303 3.322 8.303", "stroke-linejoin": "round" }))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-coupon"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconCoupon$1;},KsIconCoupon$1 = GetKsIconCoupon$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-coupon"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-coupon":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconCoupon$1(transTagName));
        }
        break;
    }});
}

const KsIconCoupon = KsIconCoupon$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconCoupon, defineCustomElement };
//# sourceMappingURL=ks-icon-coupon.js.map
//# sourceMappingURL=ks-icon-coupon.js.map