import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconReusePrompt$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconReusePrompt$1 =

    proxyCustomElement(class KsIconReusePrompt extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-reuse-prompt';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'd8fbe82712bb2a37587c0d4fb47aa90f24fc3908', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'ce5cea9101bf5303c138d599bcace1d46be755a4', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '245c9bde79a7044af0f6115f78b155b68d52f9a7', d: "M21.8211 21.0486H5.70068M42.2992 6.92194H5.70068M10.2184 35.688H5.70068M25.0944 41.0781L20.6004 36.5841L25.0944 32.0902M21.1145 36.5841H34.5314C38.8214 36.5841 42.2992 33.1064 42.2992 28.8164C42.2992 24.5264 38.8214 21.0486 34.5315 21.0486H21.1145", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-reuse-prompt"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconReusePrompt$1;},KsIconReusePrompt$1 = GetKsIconReusePrompt$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-reuse-prompt"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-reuse-prompt":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconReusePrompt$1(transTagName));
        }
        break;
    }});
}

const KsIconReusePrompt = KsIconReusePrompt$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconReusePrompt, defineCustomElement };
//# sourceMappingURL=ks-icon-reuse-prompt.js.map
//# sourceMappingURL=ks-icon-reuse-prompt.js.map