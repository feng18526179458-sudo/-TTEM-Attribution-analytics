import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconSettingsConfig$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconSettingsConfig$1 =

    proxyCustomElement(class KsIconSettingsConfig extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-settings-config';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '9d4f0958531250b16658e887e3edc7751f3afb19', class: "ks-icon", "ks-icon": true }, h("svg", { key: '48bff8df454c46824c198e188a112cf5069893a9', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }, h("path", { key: '17b18d71a57da7908ad9842b94ca27e76ac698ce', d: "M6 7.599h7.5M6 40.416h7.5m6-35.818V10.6m9 10.399v6.002m-9 10.414v6.002M42 24h-7.5" }), h("path", { key: '5ed58b9ebd80c40fa5b0b0a1fdc6bf932db4f2e5', d: "M19.5 7.599H42M19.5 40.416H42M28.5 24.014H6" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-settings-config"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconSettingsConfig$1;},KsIconSettingsConfig$1 = GetKsIconSettingsConfig$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-settings-config"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-settings-config":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconSettingsConfig$1(transTagName));
        }
        break;
    }});
}

const KsIconSettingsConfig = KsIconSettingsConfig$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconSettingsConfig, defineCustomElement };
//# sourceMappingURL=ks-icon-settings-config.js.map
//# sourceMappingURL=ks-icon-settings-config.js.map