import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconTargeting$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconTargeting$1 =

    proxyCustomElement(class KsIconTargeting extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-targeting';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '6b43f3e55c9be10d542eab9773a6408d805574a1', class: "ks-icon", "ks-icon": true }, h("svg", { key: '7caa25bd2e936036b56747e180fcd2ddd71636e4', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("g", { key: '28ab71abe0c9a3c093327ac0d74ee930c2229b43', "stroke-linecap": "round" }, h("path", { key: '4d6d64bf0a53ebecce6bf9711417d1e7d26b0f29', d: "M45 24.014c0 11.598-9.402 21-21 21s-21-9.402-21-21 9.402-21 21-21" }), h("path", { key: '9e8998685b0e4b75db58c2456d371f9972b2ce14', d: "M34.501 24.014c0 5.799-4.701 10.5-10.5 10.5s-10.5-4.701-10.5-10.5 4.701-10.5 10.5-10.5" })), h("path", { key: '7486690e37fed20d077aa5860f784930d2b082e2', d: "M38.001 3.014v7h7l-7 7h-7v-7l7-7z", "stroke-linejoin": "round" }), h("path", { key: 'd14aed12ede8c1e29a3d4f9f333ad6219769f465', d: "M31.002 17.015l-7 7", "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-targeting"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconTargeting$1;},KsIconTargeting$1 = GetKsIconTargeting$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-targeting"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-targeting":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconTargeting$1(transTagName));
        }
        break;
    }});
}

const KsIconTargeting = KsIconTargeting$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconTargeting, defineCustomElement };
//# sourceMappingURL=ks-icon-targeting.js.map
//# sourceMappingURL=ks-icon-targeting.js.map