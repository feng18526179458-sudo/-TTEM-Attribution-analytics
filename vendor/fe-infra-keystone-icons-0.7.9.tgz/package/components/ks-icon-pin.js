import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconPin$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconPin$1 =

    proxyCustomElement(class KsIconPin extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-pin';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '35233f79b93cb88b7cb8f736d03b1f3f1817b2b7', class: "ks-icon", "ks-icon": true }, h("svg", { key: '12080298bbbdd843c9ca6dc4c9f7d99bbcb6e3cc', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'c4897bf3d52298f8fb4310f5c70046f2c0c480e0', d: "M30.0504 24.0076L34 27.9853V31.8387H14L14 27.9708L18.0536 24.1151V11.979H30.0504V24.0076Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" }), h("path", { key: 'b934ccc8804e91e6517f47dcc7dab6a2887115d1', d: "M25.98 39.6267V30.3982H22.0244V39.6338L24.016 41.7776L25.98 39.6267Z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-pin"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconPin$1;},KsIconPin$1 = GetKsIconPin$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-pin"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-pin":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconPin$1(transTagName));
        }
        break;
    }});
}

const KsIconPin = KsIconPin$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconPin, defineCustomElement };
//# sourceMappingURL=ks-icon-pin.js.map
//# sourceMappingURL=ks-icon-pin.js.map