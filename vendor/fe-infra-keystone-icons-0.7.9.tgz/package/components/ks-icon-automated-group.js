import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconAutomatedGroup$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconAutomatedGroup$1 =

    proxyCustomElement(class KsIconAutomatedGroup extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-automated-group';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '31dec5ed79faa458911c8314cbe012b63092cb95', class: "ks-icon", "ks-icon": true }, h("svg", { key: '170c9aa67bdaad24445abd8632a4efe8dbcd6d1b', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'c5fd53dd93bb28281325db4fb6254a8cefb22a80', d: "M32.9781 22.0002C33.5953 21.9989 34.1943 22.357 34.4063 22.9512C34.731 24.0733 34.9749 25.2048 35.4116 26.2939C36.3095 28.5334 37.4859 29.6978 39.7197 30.5815C40.8054 31.0111 41.9275 31.2501 43.0446 31.5689C43.6399 31.7786 43.9998 32.3737 44.0005 32.99C44.0011 33.606 43.6421 34.2018 43.0476 34.4126C41.9309 34.7365 40.8073 34.9749 39.7212 35.4068C37.4858 36.2958 36.3098 37.4656 35.4108 39.7081C34.9974 40.7394 34.7094 41.8072 34.4518 42.8855C34.2993 43.566 33.657 44.0017 32.9781 44.0002C32.2764 43.9987 31.7013 43.5516 31.5097 42.8787C31.3071 41.9564 31.0007 40.8019 30.5651 39.7035C29.6815 37.4755 28.5198 36.3005 26.2813 35.4098C25.4643 35.0848 24.615 34.8306 23.8516 34.6379C22.9319 34.4204 21.9994 34.0833 22.0005 32.99C22.0016 31.8971 22.9334 31.561 23.8539 31.3459C24.6173 31.1549 25.4666 30.9026 26.2836 30.5793C28.5197 29.6941 29.6814 28.5224 30.5636 26.2985C30.9963 25.2076 31.2348 24.08 31.5544 22.9573C31.7636 22.3631 32.3616 22.0016 32.9781 22.0002Z", fill: icon.color }), h("path", { key: 'e9827ebb849dafedb1e3f36ea4f0e5d450e6c865', d: "M5.40234 15.4568V8.31236C5.40234 6.73411 6.68186 5.45459 8.26011 5.45459L21.8145 5.48335C22.475 5.48475 23.0922 5.81213 23.4637 6.35816L27.6002 12.4368M19.1165 42.5691H8.40225C6.74545 42.5691 5.40234 41.226 5.40234 39.5692V15.8423C5.40234 14.1855 6.74545 12.8424 8.40225 12.8424H39.8361C41.4934 12.8424 42.8368 14.1863 42.8361 15.8436L42.834 20.7058", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-automated-group"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconAutomatedGroup$1;},KsIconAutomatedGroup$1 = GetKsIconAutomatedGroup$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-automated-group"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-automated-group":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconAutomatedGroup$1(transTagName));
        }
        break;
    }});
}

const KsIconAutomatedGroup = KsIconAutomatedGroup$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconAutomatedGroup, defineCustomElement };
//# sourceMappingURL=ks-icon-automated-group.js.map
//# sourceMappingURL=ks-icon-automated-group.js.map