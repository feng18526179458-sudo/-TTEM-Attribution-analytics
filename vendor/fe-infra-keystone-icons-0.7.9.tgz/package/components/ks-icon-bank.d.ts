import type { Components, JSX } from "../dist/types/components";

interface KsIconBank extends Components.KsIconBank, HTMLElement {}
export const KsIconBank: {
    prototype: KsIconBank;
    new (): KsIconBank;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
