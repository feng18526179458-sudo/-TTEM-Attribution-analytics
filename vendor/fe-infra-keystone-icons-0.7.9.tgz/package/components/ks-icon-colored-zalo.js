import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconColoredZalo$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconColoredZalo$1 =

    proxyCustomElement(class KsIconColoredZalo extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-colored-zalo';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '2896ac0edc072d8d419f16dcccf2c1e5a94d38fa', class: "ks-icon", "ks-icon": true }, h("svg", { key: '3b6be5ba45b166751c7aa845cdcd15db36104b18', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("rect", { key: 'ec909016864939299d9d2e26d1b3c5601f533ace', width: "48", height: "48", rx: "8", fill: "#2A6AF6" }), h("path", { key: '4d1d0493eaa4edfc9a5c1863cb083e4ea1b6f58a', "fill-rule": "evenodd", "clip-rule": "evenodd", d: "M23.8477 21.7165C24.0853 21.4097 24.3327 21.1227 24.7385 21.0435C25.5204 20.8851 26.2529 21.3899 26.2628 22.1817C26.2924 24.1613 26.2825 26.1408 26.2628 28.1203C26.2628 28.635 25.9262 29.0903 25.4412 29.2388C24.9464 29.4268 24.3822 29.2784 24.0556 28.8528C23.8873 28.6449 23.818 28.6053 23.5805 28.7934C22.6798 29.5258 21.6603 29.6545 20.5617 29.2982C18.7999 28.7241 18.0774 27.3483 17.8794 25.6756C17.6716 23.8643 18.2753 22.3203 19.8986 21.3701C21.2446 20.5684 22.6105 20.6377 23.8477 21.7165ZM22.175 23.1519C22.3169 23.158 22.456 23.1834 22.5888 23.2267C22.8952 23.3209 23.168 23.514 23.3627 23.7852C23.917 24.5374 23.917 25.7746 23.3627 26.5268C23.2638 26.6555 23.1549 26.7644 23.0361 26.8534C22.7498 27.0652 22.4169 27.1698 22.086 27.1745C21.7357 27.1822 21.3798 27.0781 21.0763 26.8537C20.9576 26.7646 20.8487 26.6557 20.7497 26.527C20.5023 26.1806 20.3637 25.7649 20.3439 25.3294C20.334 23.9339 21.0961 23.0926 22.175 23.1519Z", fill: "white" }), h("path", { key: 'a73bddeda6f12c42dc4ed58b8f1f044820b23d8c', "fill-rule": "evenodd", "clip-rule": "evenodd", d: "M30.7068 25.3886C30.6276 22.8449 32.3003 20.9445 34.6758 20.8752C37.1997 20.7961 39.0406 22.4886 39.1198 24.963C39.199 27.4671 37.6649 29.2388 35.2993 29.4763C32.716 29.7337 30.6672 27.863 30.7068 25.3886ZM33.1911 25.1513C33.1911 25.1176 33.1916 25.0843 33.1928 25.0513C33.2322 23.8704 33.9723 23.1038 35.0123 23.1616C36.0668 23.184 36.6201 24.2444 36.6119 25.1876C36.6061 25.9965 36.2206 26.8302 35.4092 27.0928C35.1003 27.1952 34.7706 27.1998 34.4639 27.1133C33.6179 26.8785 33.158 25.9938 33.1911 25.1525L33.1911 25.1513Z", fill: "white" }), h("path", { key: '19d540a4be53e8429da6f24bf91b789a18b3a072', d: "M29.8358 28.0214C29.8457 28.7241 29.2914 29.3081 28.5887 29.3278C28.4699 29.3278 28.3413 29.318 28.2225 29.2883C27.7276 29.1596 27.3515 28.635 27.3515 28.0115V18.7571C27.3614 17.995 27.8464 17.5001 28.5788 17.5001C29.331 17.4902 29.8358 17.9851 29.8358 18.7769V28.0214Z", fill: "white" }), h("path", { key: '47f0fd0e165820f50868d3818c2015d1ee2240a3', d: "M13.8549 26.9206C13.3669 26.9218 12.8717 26.9229 12.3664 26.9229C12.5248 26.7051 12.6237 26.5765 12.7326 26.4478C14.0292 24.8147 15.3258 23.1717 16.6224 21.5188C16.9985 21.0338 17.3746 20.5488 17.6121 19.9846C17.8794 19.3314 17.5924 18.7078 16.9193 18.4802C16.6125 18.401 16.3057 18.3614 15.9889 18.3713C14.2271 18.3614 12.4555 18.3614 10.6937 18.3713C10.4462 18.3713 10.1988 18.401 9.96126 18.4604C9.58515 18.5495 9.28822 18.8563 9.19914 19.2324C9.07047 19.7867 9.41689 20.3508 9.98105 20.4795C10.2186 20.529 10.466 20.5587 10.7135 20.5587C11.7824 20.5686 12.8613 20.5587 13.9302 20.5686C13.9615 20.5712 13.9942 20.5676 14.0271 20.564C14.1192 20.5539 14.2136 20.5436 14.2865 20.6676C14.1975 20.7764 14.1084 20.8952 14.0193 21.014C12.4852 22.9539 10.951 24.9038 9.42679 26.8437C9.05067 27.3287 8.85272 27.8632 9.12986 28.457C9.40699 29.0509 9.97116 29.1697 10.5452 29.1994C10.8772 29.2205 11.204 29.2165 11.5331 29.2125C11.6652 29.2109 11.7976 29.2092 11.9309 29.2092C12.332 29.2092 12.7326 29.2099 13.1328 29.2105C14.3323 29.2123 15.529 29.2142 16.7313 29.1994C17.5825 29.1895 18.0377 28.6649 17.9487 27.883C17.8695 27.2594 17.4439 26.9328 16.662 26.9229C15.7383 26.9163 14.8103 26.9185 13.8549 26.9206Z", fill: "white" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-colored-zalo"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconColoredZalo$1;},KsIconColoredZalo$1 = GetKsIconColoredZalo$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-colored-zalo"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-colored-zalo":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconColoredZalo$1(transTagName));
        }
        break;
    }});
}

const KsIconColoredZalo = KsIconColoredZalo$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconColoredZalo, defineCustomElement };
//# sourceMappingURL=ks-icon-colored-zalo.js.map
//# sourceMappingURL=ks-icon-colored-zalo.js.map