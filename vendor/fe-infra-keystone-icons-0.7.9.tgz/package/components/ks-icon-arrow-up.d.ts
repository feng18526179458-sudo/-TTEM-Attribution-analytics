import type { Components, JSX } from "../dist/types/components";

interface KsIconArrowUp extends Components.KsIconArrowUp, HTMLElement {}
export const KsIconArrowUp: {
    prototype: KsIconArrowUp;
    new (): KsIconArrowUp;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
