import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconCamera$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconCamera$1 =

    proxyCustomElement(class KsIconCamera extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-camera';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '1ad1cefc3db1335986feba45baf49b75c662b1e7', class: "ks-icon", "ks-icon": true }, h("svg", { key: '3f8644e630cb7501f0834e5bdd810f36e2c825a3', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: '3ad0af38327d3c368cf98341f8bcb39fa3d9cadd', d: "M3.033 16.497a3 3 0 0 1 3-3h7.5 6.697a1.5 1.5 0 0 0 1.248-.668l2.109-3.164a1.5 1.5 0 0 1 1.248-.668h8.894a1.5 1.5 0 0 1 1.248.668l2.109 3.164a1.5 1.5 0 0 0 1.248.668h3.697a3 3 0 0 1 3 3v21a3 3 0 0 1-3 3h-36a3 3 0 0 1-3-3V16.497z" }), h("circle", { key: '8738f4fc522d0eafed210bf2c37f8dfa6f25d246', cx: "30.049", cy: "26.997", r: "7.5" }), h("path", { key: 'd94421e58dd6ac0af558a767831afc70f86db8af', d: "M11.948 32.707V21.284", "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-camera"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconCamera$1;},KsIconCamera$1 = GetKsIconCamera$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-camera"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-camera":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconCamera$1(transTagName));
        }
        break;
    }});
}

const KsIconCamera = KsIconCamera$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconCamera, defineCustomElement };
//# sourceMappingURL=ks-icon-camera.js.map
//# sourceMappingURL=ks-icon-camera.js.map