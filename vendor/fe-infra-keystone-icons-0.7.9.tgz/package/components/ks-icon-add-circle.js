import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconAddCircle$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconAddCircle$1 =

    proxyCustomElement(class KsIconAddCircle extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-add-circle';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '4af5d73a8955c5519f2f5fdefafb5fb6795d3aa3', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'e7ac73ac853931fe377b9ffa42630664beedf46d', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("g", { key: '74a7828543c41d59b5c202104173ca73f072e0dd', "stroke-linecap": "round", "stroke-linejoin": "round" }, h("path", { key: '533957cc4fa48c4d6b13437a1456f36f31e190cd', d: "M12.185 24h24" }), h("path", { key: 'bf6a35d214d85cdaa0b826afcad237de87bbb108', d: "M24.187 12v24" })), h("path", { key: 'b292b6b5ca94c396609857b1b011dd3c6cc5f11c', d: "M4.687 24.015c0-10.769 8.73-19.5 19.5-19.5s19.5 8.73 19.5 19.5-8.73 19.5-19.5 19.5-19.5-8.73-19.5-19.5z" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-add-circle"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconAddCircle$1;},KsIconAddCircle$1 = GetKsIconAddCircle$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-add-circle"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-add-circle":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconAddCircle$1(transTagName));
        }
        break;
    }});
}

const KsIconAddCircle = KsIconAddCircle$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconAddCircle, defineCustomElement };
//# sourceMappingURL=ks-icon-add-circle.js.map
//# sourceMappingURL=ks-icon-add-circle.js.map