import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconVolumeUp$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconVolumeUp$1 =

    proxyCustomElement(class KsIconVolumeUp extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-volume-up';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'be4cffea23647826f00382d9affa305e439e6e6e', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: '408e6ff9a3bf941451cedf079d3ccb01e1aa004b', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: '6d2bf8d4bc3e985d64184ba03ecc0cddccd8905f', d: "M10.459 15.957a2.96 2.96 0 0 0-2.958 2.958v11.01a2.96 2.96 0 0 0 2.958 2.958h4.143a1.97 1.97 0 0 1 1.441.625l8.751 9.363c1.222 1.307 3.413.443 3.413-1.347V6.476c0-1.828-2.272-2.672-3.466-1.287l-8.692 10.084a1.97 1.97 0 0 1-1.494.684h-4.096z" }), h("path", { key: '9305c2156ead8d5eadd09309c979d3458f22bd8d', d: "M34.533 32.418s3.138-3.769 3.138-8.419-3.138-8.419-3.138-8.419m7.096 19.785S44.767 30.277 44.767 24s-3.138-11.366-3.138-11.366", "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-volume-up"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconVolumeUp$1;},KsIconVolumeUp$1 = GetKsIconVolumeUp$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-volume-up"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-volume-up":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconVolumeUp$1(transTagName));
        }
        break;
    }});
}

const KsIconVolumeUp = KsIconVolumeUp$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconVolumeUp, defineCustomElement };
//# sourceMappingURL=ks-icon-volume-up.js.map
//# sourceMappingURL=ks-icon-volume-up.js.map