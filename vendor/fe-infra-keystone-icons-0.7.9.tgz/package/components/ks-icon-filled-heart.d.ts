import type { Components, JSX } from "../dist/types/components";

interface KsIconFilledHeart extends Components.KsIconFilledHeart, HTMLElement {}
export const KsIconFilledHeart: {
    prototype: KsIconFilledHeart;
    new (): KsIconFilledHeart;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
