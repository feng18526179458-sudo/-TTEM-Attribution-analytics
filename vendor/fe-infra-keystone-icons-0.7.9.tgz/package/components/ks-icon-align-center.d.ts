import type { Components, JSX } from "../dist/types/components";

interface KsIconAlignCenter extends Components.KsIconAlignCenter, HTMLElement {}
export const KsIconAlignCenter: {
    prototype: KsIconAlignCenter;
    new (): KsIconAlignCenter;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
