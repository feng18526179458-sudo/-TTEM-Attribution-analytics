import type { Components, JSX } from "../dist/types/components";

interface KsIconCamera extends Components.KsIconCamera, HTMLElement {}
export const KsIconCamera: {
    prototype: KsIconCamera;
    new (): KsIconCamera;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
