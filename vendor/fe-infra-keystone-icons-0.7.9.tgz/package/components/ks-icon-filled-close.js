import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledClose$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledClose$1 =

    proxyCustomElement(class KsIconFilledClose extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-close';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
        this.innerColor = 'white';
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '1ed3f3b3ac0b39135ac514115c0e1243b522fc63', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'c56db4e34aa89cb93fe248cbe9e861cef92ad9e6', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("ellipse", { key: '62b3634ad058e18b347d5df7404eaf87bb69d98d', cx: "24", cy: "24", rx: "24", ry: "24", fill: icon.color }), h("path", { key: '915bbadd8c7bdc722dbf97d5789aef940efb739f', d: "M13.5002 13.4998L34.5002 34.4998M13.5 34.4997L34.5 13.4998", stroke: this.innerColor, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-close"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"],
      "innerColor": [1, "inner-color"]
    }]);return innerKsIconFilledClose$1;},KsIconFilledClose$1 = GetKsIconFilledClose$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-close"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-close":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledClose$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledClose = KsIconFilledClose$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledClose, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-close.js.map
//# sourceMappingURL=ks-icon-filled-close.js.map