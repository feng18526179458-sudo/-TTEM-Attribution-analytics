import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconSaveProject$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconSaveProject$1 =

    proxyCustomElement(class KsIconSaveProject extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-save-project';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '5f08fe2011b25feb33dce8647f18b106730992ce', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'f8313a02bb0021312021054c20c4b2ea3b349f9b', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("rect", { key: '838a7d343cb230b664414146aad138227c39a07e', x: "4.5", y: "4.5", width: "39", height: "39", rx: "1.5", stroke: icon.color, "stroke-width": icon.strokeWidth }), h("path", { key: '4f61889493b7e45ee915c2b051aebdd23442eace', d: "M29.636 24.112l-7.46-5.512c-.99-.731-2.391-.025-2.391 1.207v11.024c0 1.231 1.401 1.938 2.391 1.206l7.461-5.512a1.5 1.5 0 0 0 0-2.413zm2.181-14.38a1.24 1.24 0 0 1 2.239 0l1.236 2.649c.123.263.334.474.597.597l2.649 1.236a1.24 1.24 0 0 1 0 2.239l-2.649 1.236c-.263.123-.474.334-.597.597l-1.236 2.649a1.24 1.24 0 0 1-2.239 0l-1.236-2.649c-.123-.263-.334-.474-.597-.597l-2.649-1.236a1.24 1.24 0 0 1 0-2.239l2.649-1.236c.263-.123.474-.334.597-.597l1.236-2.649z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-save-project"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconSaveProject$1;},KsIconSaveProject$1 = GetKsIconSaveProject$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-save-project"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-save-project":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconSaveProject$1(transTagName));
        }
        break;
    }});
}

const KsIconSaveProject = KsIconSaveProject$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconSaveProject, defineCustomElement };
//# sourceMappingURL=ks-icon-save-project.js.map
//# sourceMappingURL=ks-icon-save-project.js.map