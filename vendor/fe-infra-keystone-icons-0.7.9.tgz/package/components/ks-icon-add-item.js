import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconAddItem$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconAddItem$1 =

    proxyCustomElement(class KsIconAddItem extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-add-item';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'de3f72b3295b12f75a530568cd23328a25d7f243', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'd25d37046290a219cf358910431b3a4d7068f6a0', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: 'e86440de6cebb84ed342e6dff48dc664661e1f2e', d: "M7.5 6a3 3 0 0 1 3-3h19.412a3 3 0 0 1 2.08.838l7.588 7.299a3 3 0 0 1 .92 2.162v15.212V42a3 3 0 0 1-3 3H24 10.5a3 3 0 0 1-3-3V6z" }), h("g", { key: '60a3afa81145dbc0ef86d2e066750a105666ded2', "stroke-linecap": "round" }, h("path", { key: 'f9c055c6e004b00a4da4e103a5bb06a98624067c', d: "M31.506 24h-15" }), h("path", { key: '9a1e5102d7ec3d7e9d80bbfa6ad417270b40b439', d: "M24.005 31.5v-15" }))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-add-item"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconAddItem$1;},KsIconAddItem$1 = GetKsIconAddItem$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-add-item"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-add-item":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconAddItem$1(transTagName));
        }
        break;
    }});
}

const KsIconAddItem = KsIconAddItem$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconAddItem, defineCustomElement };
//# sourceMappingURL=ks-icon-add-item.js.map
//# sourceMappingURL=ks-icon-add-item.js.map