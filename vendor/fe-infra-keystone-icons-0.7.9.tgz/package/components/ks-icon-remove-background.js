import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconRemoveBackground$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconRemoveBackground$1 =

    proxyCustomElement(class KsIconRemoveBackground extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-remove-background';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'b6940a529414f0692bcc5de63f570ae9118d55b6', class: "ks-icon", "ks-icon": true }, h("svg", { key: '74cbaea344631baafaf91d7e0331c9cb0e12a9fe', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("rect", { key: '3a4f1480a512d408ed65177fcd2f9f326cf91b63', x: "3.42857", y: "8.17593", width: "41.1429", height: "31.6484", rx: "3.16484", stroke: icon.color, "stroke-width": icon.strokeWidth }), h("path", { key: '513c5a9381ea1917df5d6c06e42b8a1a98e8bfb0', "fill-rule": "evenodd", "clip-rule": "evenodd", d: "M29.5063 15.3682C29.1646 16.8235 28.7444 18.6127 27.6447 19.7124C26.5449 20.8121 24.7558 21.2323 23.3005 21.5741C21.9761 21.8851 20.9282 22.1312 20.9282 22.7655C20.9282 23.3998 21.9761 23.6459 23.3005 23.9569C24.7558 24.2987 26.5449 24.7188 27.6447 25.8186C28.7444 26.9183 29.1646 28.7074 29.5063 30.1627C29.8174 31.4872 30.0634 32.5351 30.6977 32.5351C31.3321 32.5351 31.5781 31.4872 31.8892 30.1627C32.2309 28.7074 32.6511 26.9183 33.7508 25.8186C34.8506 24.7188 36.6397 24.2987 38.095 23.9569C39.4194 23.6459 40.4673 23.3998 40.4673 22.7655C40.4673 22.1312 39.4194 21.8851 38.095 21.5741C36.6397 21.2323 34.8506 20.8121 33.7508 19.7124C32.6511 18.6127 32.2309 16.8235 31.8892 15.3682C31.5781 14.0438 31.3321 12.9959 30.6977 12.9959C30.0634 12.9959 29.8174 14.0438 29.5063 15.3682Z", fill: icon.color }), h("path", { key: '49e6cedc7e8f4f980a046bb27e0de4b813d3f632', "fill-rule": "evenodd", "clip-rule": "evenodd", d: "M13.5101 23.2505C13.3035 22.3706 13.0495 21.2889 12.3846 20.624C11.7197 19.9591 10.638 19.7051 9.75818 19.4985C8.95743 19.3104 8.32388 19.1617 8.32388 18.7782C8.32388 18.3947 8.95743 18.2459 9.75818 18.0578C10.638 17.8512 11.7197 17.5972 12.3846 16.9323C13.0495 16.2674 13.3035 15.1857 13.5101 14.3059C13.6982 13.5051 13.847 12.8716 14.2305 12.8716C14.614 12.8716 14.7627 13.5051 14.9508 14.3059C15.1574 15.1857 15.4115 16.2674 16.0763 16.9323C16.7412 17.5972 17.8229 17.8512 18.7028 18.0578C19.5035 18.2459 20.1371 18.3947 20.1371 18.7782C20.1371 19.1617 19.5035 19.3104 18.7028 19.4985C17.8229 19.7051 16.7412 19.9591 16.0763 20.624C15.4115 21.2889 15.1574 22.3706 14.9508 23.2505C14.7627 24.0512 14.614 24.6848 14.2305 24.6848C13.847 24.6848 13.6982 24.0512 13.5101 23.2505Z", fill: icon.color }), h("path", { key: 'e9c79d96933f6765caef3520dffefc94cb1d9a51', "fill-rule": "evenodd", "clip-rule": "evenodd", d: "M17.0645 33.6276C16.8483 32.7068 16.5824 31.5747 15.8866 30.8789C15.1907 30.1831 14.0587 29.9172 13.1379 29.701C12.2998 29.5042 11.6368 29.3484 11.6368 28.9471C11.6368 28.5457 12.2998 28.39 13.1379 28.1932C14.0587 27.977 15.1907 27.7111 15.8866 27.0153C16.5824 26.3194 16.8483 25.1874 17.0645 24.2666C17.2613 23.4285 17.417 22.7655 17.8184 22.7655C18.2197 22.7655 18.3755 23.4285 18.5723 24.2666C18.7885 25.1874 19.0544 26.3194 19.7502 27.0153C20.446 27.7111 21.5781 27.977 22.4989 28.1932C23.3369 28.39 24 28.5457 24 28.9471C24 29.3484 23.3369 29.5042 22.4989 29.701C21.5781 29.9172 20.446 30.1831 19.7502 30.8789C19.0544 31.5747 18.7885 32.7068 18.5723 33.6276C18.3755 34.4657 18.2197 35.1287 17.8184 35.1287C17.417 35.1287 17.2613 34.4657 17.0645 33.6276Z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-remove-background"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconRemoveBackground$1;},KsIconRemoveBackground$1 = GetKsIconRemoveBackground$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-remove-background"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-remove-background":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconRemoveBackground$1(transTagName));
        }
        break;
    }});
}

const KsIconRemoveBackground = KsIconRemoveBackground$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconRemoveBackground, defineCustomElement };
//# sourceMappingURL=ks-icon-remove-background.js.map
//# sourceMappingURL=ks-icon-remove-background.js.map