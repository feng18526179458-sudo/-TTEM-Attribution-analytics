import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconPicture$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconPicture$1 =

    proxyCustomElement(class KsIconPicture extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-picture';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '52744acb9692e315686205a9c3bd9b7266f578fd', class: "ks-icon", "ks-icon": true }, h("svg", { key: '272eeccfe5bad1be5c561b353625654693a71c7d', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("g", { key: '5ddf4d993b85ed3078eadf246e2d3adb1d7109d5', stroke: icon.color, "stroke-width": icon.strokeWidth }, h("rect", { key: 'f8bbeeb943ae27e048944cedaf2584ec7f70b035', x: "4.5", y: "9", width: "39", height: "30", rx: "1.5" }), h("path", { key: '0922a72a8f99a9f018462ea530f80044beb66923', d: "M6 37.5l20.177-20.177a3 3 0 0 1 4.426.201L43.5 33", "stroke-linecap": "round" })), h("circle", { key: '35f389642e0029b9ec1b7aa03df8dec9fe0e052f', cx: "13.5", cy: "16.5", fill: icon.color, r: "3" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-picture"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconPicture$1;},KsIconPicture$1 = GetKsIconPicture$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-picture"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-picture":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconPicture$1(transTagName));
        }
        break;
    }});
}

const KsIconPicture = KsIconPicture$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconPicture, defineCustomElement };
//# sourceMappingURL=ks-icon-picture.js.map
//# sourceMappingURL=ks-icon-picture.js.map