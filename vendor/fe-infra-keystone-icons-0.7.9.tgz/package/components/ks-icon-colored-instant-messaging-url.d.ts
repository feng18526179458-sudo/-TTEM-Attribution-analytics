import type { Components, JSX } from "../dist/types/components";

interface KsIconColoredInstantMessagingUrl extends Components.KsIconColoredInstantMessagingUrl, HTMLElement {}
export const KsIconColoredInstantMessagingUrl: {
    prototype: KsIconColoredInstantMessagingUrl;
    new (): KsIconColoredInstantMessagingUrl;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
