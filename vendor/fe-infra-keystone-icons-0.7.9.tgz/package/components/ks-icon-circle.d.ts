import type { Components, JSX } from "../dist/types/components";

interface KsIconCircle extends Components.KsIconCircle, HTMLElement {}
export const KsIconCircle: {
    prototype: KsIconCircle;
    new (): KsIconCircle;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
