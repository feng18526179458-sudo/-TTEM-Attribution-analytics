import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconCreditCard$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconCreditCard$1 =

    proxyCustomElement(class KsIconCreditCard extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-credit-card';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '721f56389c48dcdce64f8de236f25f5c13dc6bd3', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'a7125ebabf3c30f0bd314cdd4e08699e1b2e01e5', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("rect", { key: '3490266c2c83fdfa9302a2402c55fb5c3251fc02', x: "4.499", y: "10.5", width: "39", height: "27", rx: "1.5" }), h("path", { key: 'eb80e1ba4fe14aca5dd587c54a59ff36ed17f6a4', d: "M35.999 24h-9M42 18H6", "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-credit-card"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconCreditCard$1;},KsIconCreditCard$1 = GetKsIconCreditCard$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-credit-card"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-credit-card":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconCreditCard$1(transTagName));
        }
        break;
    }});
}

const KsIconCreditCard = KsIconCreditCard$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconCreditCard, defineCustomElement };
//# sourceMappingURL=ks-icon-credit-card.js.map
//# sourceMappingURL=ks-icon-credit-card.js.map