import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledBookmark$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledBookmark$1 =

    proxyCustomElement(class KsIconFilledBookmark extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-bookmark';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '958b4b8852ed8930f88e88ab522a900c4fa206ab', class: "ks-icon", "ks-icon": true }, h("svg", { key: '4a33b8e5ce693bcf3e5da09aed7f3eb67d602730', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'd41c1df3235abd1338794ba95407e7fdf0946b6f', d: "M9.539 8.069c0-1.593 1.292-2.885 2.885-2.885h23.082c1.593 0 2.885 1.292 2.885 2.885v30.869c0 2.523-3.01 3.831-4.854 2.109l-8.785-8.199c-.444-.414-1.132-.414-1.575 0l-8.785 8.199c-1.844 1.721-4.854.413-4.854-2.109V8.069z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-bookmark"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFilledBookmark$1;},KsIconFilledBookmark$1 = GetKsIconFilledBookmark$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-bookmark"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-bookmark":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledBookmark$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledBookmark = KsIconFilledBookmark$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledBookmark, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-bookmark.js.map
//# sourceMappingURL=ks-icon-filled-bookmark.js.map