import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconWhatsapp$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconWhatsapp$1 =

    proxyCustomElement(class KsIconWhatsapp extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-whatsapp';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '8ca7890d78e17caa75ad1f4d8e50d63cfef2c6b1', class: "ks-icon", "ks-icon": true }, h("svg", { key: '53eb83e378116de51dccb6ef49c4441df18a6d4e', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '6f09f349a79c3f0c31db1d56d157b2845ecde32b', d: "M33.576 28.172l-3.553-1.692c-.477-.174-.823-.26-1.17.26s-1.343 1.692-1.647 2.039-.607.391-1.127.13-2.196-.809-4.182-2.581c-1.546-1.379-2.59-3.082-2.893-3.602s-.032-.802.228-1.061c.234-.233.52-.608.78-.911s.347-.521.52-.867.087-.651-.043-.911-1.17-2.82-1.603-3.861c-.422-1.014-.851-.877-1.17-.893l-.997-.018c-.347 0-.91.13-1.387.651s-1.82 1.779-1.82 4.338 1.863 5.032 2.123 5.38 3.667 5.6 8.884 7.852c1.241.536 2.209.856 2.965 1.095 1.246.396 2.379.34 3.275.206.999-.149 3.077-1.258 3.51-2.472s.433-2.256.303-2.473-.477-.347-.997-.607zm-9.488 12.953h-.007c-3.104-.001-6.148-.835-8.804-2.411l-.632-.375-6.547 1.718 1.747-6.383-.411-.655c-1.732-2.754-2.646-5.937-2.645-9.206.004-9.537 7.764-17.297 17.305-17.297a17.18 17.18 0 0 1 12.23 5.073 17.19 17.19 0 0 1 5.062 12.238c-.004 9.538-7.764 17.298-17.298 17.298zM38.81 9.104C34.88 5.17 29.655 3.002 24.087 3 12.616 3 3.28 12.336 3.275 23.811c-.001 3.668.957 7.248 2.778 10.405L3.101 45l11.033-2.894c3.04 1.658 6.462 2.532 9.946 2.533h.008c11.47 0 20.807-9.337 20.812-20.812.002-5.561-2.161-10.79-6.09-14.724z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-whatsapp"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconWhatsapp$1;},KsIconWhatsapp$1 = GetKsIconWhatsapp$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-whatsapp"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-whatsapp":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconWhatsapp$1(transTagName));
        }
        break;
    }});
}

const KsIconWhatsapp = KsIconWhatsapp$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconWhatsapp, defineCustomElement };
//# sourceMappingURL=ks-icon-whatsapp.js.map
//# sourceMappingURL=ks-icon-whatsapp.js.map