import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconPause$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconPause$1 =

    proxyCustomElement(class KsIconPause extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-pause';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'a85ad1845d3732edff5534d0311594b7b57e69fe', class: "ks-icon", "ks-icon": true }, h("svg", { key: '47aa1627040c2d18af589de9fb93a5f91532772f', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: icon.color, "fill-rule": "evenodd" }, h("path", { key: '49df50712349b3ee5bb3567bf1a96d9a46c382f2', d: "M11.124.793c3.995 0 7.234 3.239 7.234 7.234v32.552c0 3.995-3.239 7.234-7.234 7.234S3.89 44.574 3.89 40.579V8.027c0-3.995 3.239-7.234 7.234-7.234zm25.318 0c3.995 0 7.234 3.239 7.234 7.234v32.552c0 3.995-3.239 7.234-7.234 7.234s-7.234-3.239-7.234-7.234V8.027c0-3.995 3.239-7.234 7.234-7.234z" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-pause"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconPause$1;},KsIconPause$1 = GetKsIconPause$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-pause"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-pause":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconPause$1(transTagName));
        }
        break;
    }});
}

const KsIconPause = KsIconPause$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconPause, defineCustomElement };
//# sourceMappingURL=ks-icon-pause.js.map
//# sourceMappingURL=ks-icon-pause.js.map