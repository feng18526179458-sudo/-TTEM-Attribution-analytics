import type { Components, JSX } from "../dist/types/components";

interface KsIconAscend extends Components.KsIconAscend, HTMLElement {}
export const KsIconAscend: {
    prototype: KsIconAscend;
    new (): KsIconAscend;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
