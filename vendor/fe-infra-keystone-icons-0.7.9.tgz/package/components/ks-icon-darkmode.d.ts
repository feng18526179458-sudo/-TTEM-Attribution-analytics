import type { Components, JSX } from "../dist/types/components";

interface KsIconDarkmode extends Components.KsIconDarkmode, HTMLElement {}
export const KsIconDarkmode: {
    prototype: KsIconDarkmode;
    new (): KsIconDarkmode;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
