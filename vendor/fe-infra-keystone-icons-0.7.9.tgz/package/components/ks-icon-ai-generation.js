import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconAiGeneration$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconAiGeneration$1 =

    proxyCustomElement(class KsIconAiGeneration extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-ai-generation';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '2840c6d412a7f3e8b68257008649e08bf29d8a8d', class: "ks-icon", "ks-icon": true }, h("svg", { key: '4de7de898a5a6c626a29b46ee8ca7a1e7b864f96', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("g", { key: '86462993ba2f975b84582ed963c78d6a46c9d2e0', opacity: ".9" }, h("g", { key: '9a68b6c4d12da1fab52fb14bde333d22b3a487f2', fill: icon.color }, h("use", { key: '5b23d94ddfa1e4356893913390182807ecf35f54', href: "#B" }), h("use", { key: '99b07c4a91d0f41f6cac7793f909944d167b3437', href: "#C" })), h("g", { key: 'fb39c775de159c8ba525a094b925fa3aa9d3288f', stroke: icon.color, "stroke-width": icon.strokeWidth }, h("use", { key: '0100dc808b48ff9625e99b37c6785cedaddb2afd', href: "#B" }), h("use", { key: 'ea0e225d93ac117b13a71d2b2b39491618377e97', href: "#C" }))), h("defs", { key: '4836473b8d6925237208f0e506f5b381851996c3' }, h("path", { key: 'd03bb27f42aedec99d90f3bc121ae043a33c0d53', id: "B", d: "M32.497 5.421c.053-.242.535-.243.589-.001.378 1.694 1.154 4.303 2.545 5.684 1.381 1.372 3.975 2.135 5.655 2.505.241.053.242.532.001.585-1.68.374-4.275 1.142-5.656 2.517-1.391 1.385-2.169 4-2.547 5.689-.054.241-.532.24-.585-.001-.37-1.689-1.136-4.302-2.522-5.687-1.374-1.374-3.956-2.139-5.646-2.513-.242-.053-.242-.54.001-.593 1.69-.37 4.271-1.13 5.645-2.501 1.385-1.382 2.15-3.989 2.52-5.683z" }), h("path", { key: 'cc69019a47c4866924604a0c94ee0822a428797d', id: "C", d: "M18.726 17.697c.077-.353.782-.355.86-.002.552 2.474 1.686 6.285 3.717 8.303 2.018 2.004 5.807 3.118 8.261 3.659.353.078.353.776.001.855-2.455.546-6.244 1.668-8.262 3.676-2.032 2.023-3.168 5.843-3.72 8.31-.079.352-.777.351-.855-.002-.541-2.467-1.66-6.284-3.684-8.308-2.007-2.007-5.779-3.124-8.247-3.67-.354-.078-.353-.789.001-.867 2.468-.541 6.238-1.65 8.246-3.653 2.023-2.019 3.14-5.828 3.681-8.301z" }))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-ai-generation"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconAiGeneration$1;},KsIconAiGeneration$1 = GetKsIconAiGeneration$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-ai-generation"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-ai-generation":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconAiGeneration$1(transTagName));
        }
        break;
    }});
}

const KsIconAiGeneration = KsIconAiGeneration$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconAiGeneration, defineCustomElement };
//# sourceMappingURL=ks-icon-ai-generation.js.map
//# sourceMappingURL=ks-icon-ai-generation.js.map