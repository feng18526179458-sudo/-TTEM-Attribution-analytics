import type { Components, JSX } from "../dist/types/components";

interface KsIconArrowLeft extends Components.KsIconArrowLeft, HTMLElement {}
export const KsIconArrowLeft: {
    prototype: KsIconArrowLeft;
    new (): KsIconArrowLeft;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
