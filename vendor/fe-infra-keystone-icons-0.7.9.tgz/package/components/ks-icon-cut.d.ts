import type { Components, JSX } from "../dist/types/components";

interface KsIconCut extends Components.KsIconCut, HTMLElement {}
export const KsIconCut: {
    prototype: KsIconCut;
    new (): KsIconCut;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
