import type { Components, JSX } from "../dist/types/components";

interface KsIconFilledRocket extends Components.KsIconFilledRocket, HTMLElement {}
export const KsIconFilledRocket: {
    prototype: KsIconFilledRocket;
    new (): KsIconFilledRocket;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
