import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconColoredUnknown$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconColoredUnknown$1 =

    proxyCustomElement(class KsIconColoredUnknown extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-colored-unknown';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '6c508861da5b53a50ae50ab46088327574b09096', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'b4dbd37337a0614bd3fb4c9d45cc2ffa1c5181b3', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("rect", { key: '191f0d907b00665204f9ec4b32f488a00f56d396', width: "48", height: "48", rx: "1.556", fill: "#f0f0f0" }), h("path", { key: 'e63c8a92b7c61f02180d5acb47b1dbd23424d689', "fill-rule": "evenodd", d: "M19.446 18.827c.161 0 .291-.131.301-.292a4.3 4.3 0 0 1 4.291-4.009c2.341 0 4.225 1.891 4.225 4.301 0 1.596-.735 2.763-2.032 3.514-1.949 1.129-4.46 3.306-4.46 6.579v1.248c0 .161.131.292.292.292h3.95c.161 0 .292-.13.292-.292v-1.248c0-.766.653-1.761 2.2-2.657 2.625-1.521 4.292-4.144 4.292-7.437 0-4.845-3.846-8.834-8.759-8.834-4.781 0-8.675 3.798-8.83 8.542-.005.161.126.292.287.292h3.95zm4.552 19.42a2.84 2.84 0 0 0 2.84-2.84 2.84 2.84 0 0 0-2.84-2.84 2.84 2.84 0 0 0-2.84 2.84 2.84 2.84 0 0 0 2.84 2.84z", fill: "#bfbfbf" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-colored-unknown"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconColoredUnknown$1;},KsIconColoredUnknown$1 = GetKsIconColoredUnknown$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-colored-unknown"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-colored-unknown":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconColoredUnknown$1(transTagName));
        }
        break;
    }});
}

const KsIconColoredUnknown = KsIconColoredUnknown$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconColoredUnknown, defineCustomElement };
//# sourceMappingURL=ks-icon-colored-unknown.js.map
//# sourceMappingURL=ks-icon-colored-unknown.js.map