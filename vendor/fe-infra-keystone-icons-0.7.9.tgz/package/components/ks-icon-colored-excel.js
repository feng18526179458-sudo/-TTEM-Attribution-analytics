import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconColoredExcel$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconColoredExcel$1 =

    proxyCustomElement(class KsIconColoredExcel extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-colored-excel';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '2ddff88950b07f19b9ec4b311ae03667a63bee5c', class: "ks-icon", "ks-icon": true }, h("svg", { key: '5473dc302fd0c61819da7a8d5e9cdc6a7161358a', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("g", { key: 'e1ce9f081f2d14e9f372e5a906bb106b3ecf6be5', "clip-path": "url(#clip0_67_12)" }, h("path", { key: '5d78d7c6a01edbc2ec0ca960c597f11efe53c46a', d: "M43.3333 0H4.66668C2.08934 0 0 2.08934 0 4.66668V43.3333C0 45.9107 2.08934 48 4.66668 48H43.3333C45.9107 48 48 45.9107 48 43.3333V4.66668C48 2.08934 45.9107 0 43.3333 0Z", fill: "#219C26" }), h("path", { key: 'aae97eeba0ce24eef03e3380fb08ab08e4a894d3', d: "M32.4293 34.6668C33.1388 34.6668 33.5534 33.867 33.1442 33.2874L26.3736 23.6908L32.6729 14.6998C33.0791 14.1199 32.6642 13.3228 31.9562 13.3228H28.6356C28.3421 13.3228 28.0682 13.4699 27.9061 13.7146L23.3336 20.6188L18.6976 13.7102C18.5351 13.468 18.2627 13.3228 17.9711 13.3228H14.7081C14.0006 13.3228 13.5856 14.1188 13.9907 14.6988L20.2936 23.7228L13.5264 33.2862C13.1163 33.8658 13.5308 34.6668 14.2407 34.6668H17.4977C17.7857 34.6668 18.0551 34.5252 18.2184 34.2879L23.3336 26.8588L28.417 34.2861C28.5801 34.5243 28.8503 34.6668 29.1391 34.6668H32.4293Z", fill: "white" })), h("defs", { key: 'e3eb41982bd71ad3094d6598b67223d4170929fa' }, h("clipPath", { key: '7d242c609e5d8da1396dff071d9377a2157465b8', id: "clip0_67_12" }, h("rect", { key: 'af75cfce2b7aec3d33bff27ce08bda20d529c5a6', width: "48", height: "48", fill: "white" })))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-colored-excel"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconColoredExcel$1;},KsIconColoredExcel$1 = GetKsIconColoredExcel$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-colored-excel"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-colored-excel":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconColoredExcel$1(transTagName));
        }
        break;
    }});
}

const KsIconColoredExcel = KsIconColoredExcel$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconColoredExcel, defineCustomElement };
//# sourceMappingURL=ks-icon-colored-excel.js.map
//# sourceMappingURL=ks-icon-colored-excel.js.map