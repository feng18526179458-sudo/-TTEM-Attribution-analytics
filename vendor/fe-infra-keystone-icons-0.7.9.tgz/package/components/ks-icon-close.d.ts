import type { Components, JSX } from "../dist/types/components";

interface KsIconClose extends Components.KsIconClose, HTMLElement {}
export const KsIconClose: {
    prototype: KsIconClose;
    new (): KsIconClose;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
