import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconUploadImage$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconUploadImage$1 =

    proxyCustomElement(class KsIconUploadImage extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-upload-image';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'f579cad8d986aaabf06e603d65a5731d28555569', class: "ks-icon", "ks-icon": true }, h("svg", { key: '3d5872f803008e3cf692bec682df0c15882fc3b6', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("g", { key: '4f5dc2f8fb12bb1d9178c3a6336845da7e32667d', stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: '98bd29c53b7e94c088b1884567153a5fd3b45ab8', d: "M27.126 9.281H7.699a3 3 0 0 0-3 3V36.06a3 3 0 0 0 3 3h32.625a3 3 0 0 0 3-3V22.115" }), h("path", { key: 'a1c31746ac625442ae7e84801eb368dbae695eb5', d: "M7.067 38.334l14.842-14.842a3 3 0 0 1 4.267.025L40.15 37.819M39.04 8.396v8.749" }), h("path", { key: 'c2e90f123b15b576bbc77265461340ef05a983ec', d: "M34.959 9.281l1.36-1.36L39.04 5.2l4.081 4.081", "stroke-linejoin": "round" })), h("circle", { key: 'a2d60a42a99117d1dbd27a873eba4ed4a631cf36', cx: "13.722", cy: "17.146", r: "3", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-upload-image"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconUploadImage$1;},KsIconUploadImage$1 = GetKsIconUploadImage$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-upload-image"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-upload-image":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconUploadImage$1(transTagName));
        }
        break;
    }});
}

const KsIconUploadImage = KsIconUploadImage$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconUploadImage, defineCustomElement };
//# sourceMappingURL=ks-icon-upload-image.js.map
//# sourceMappingURL=ks-icon-upload-image.js.map