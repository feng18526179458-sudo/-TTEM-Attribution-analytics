import type { Components, JSX } from "../dist/types/components";

interface KsIconAddCaptions extends Components.KsIconAddCaptions, HTMLElement {}
export const KsIconAddCaptions: {
    prototype: KsIconAddCaptions;
    new (): KsIconAddCaptions;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
