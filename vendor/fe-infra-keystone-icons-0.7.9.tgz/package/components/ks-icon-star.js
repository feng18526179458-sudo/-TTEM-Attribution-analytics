import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconStar$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconStar$1 =

    proxyCustomElement(class KsIconStar extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-star';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '86d891cf1729f465fc101f38339589de7bd8b327', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'b593839c721feb850b16ce2e427e842f8939544f', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '78057d8fe05bdf5aafa0badede03538bab1d03db', d: "M22.6595 4.74904C23.213 3.64615 24.7873 3.64614 25.3408 4.74904L30.0083 14.0493C30.6631 15.354 31.9101 16.26 33.3533 16.4796L43.6407 18.0448C44.8607 18.2304 45.3472 19.7276 44.4693 20.5948L37.0666 27.9079C36.0281 28.9338 35.5518 30.3998 35.7889 31.8402L37.4793 42.1078C37.6798 43.3254 36.4062 44.2507 35.3101 43.6838L26.0675 38.9033C24.7709 38.2326 23.2295 38.2326 21.9328 38.9033L12.6902 43.6838C11.5941 44.2507 10.3205 43.3254 10.521 42.1078L12.2114 31.8402C12.4486 30.3998 11.9722 28.9338 10.9337 27.9079L3.53105 20.5948L2.4941 21.6445L3.53105 20.5948C2.65317 19.7276 3.13965 18.2304 4.3596 18.0448L14.647 16.4796C16.0902 16.26 17.3372 15.354 17.992 14.0493L22.6595 4.74904Z", stroke: icon.color, "stroke-width": icon.strokeWidth })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-star"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconStar$1;},KsIconStar$1 = GetKsIconStar$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-star"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-star":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconStar$1(transTagName));
        }
        break;
    }});
}

const KsIconStar = KsIconStar$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconStar, defineCustomElement };
//# sourceMappingURL=ks-icon-star.js.map
//# sourceMappingURL=ks-icon-star.js.map