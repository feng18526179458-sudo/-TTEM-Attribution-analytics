import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconStop$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconStop$1 =

    proxyCustomElement(class KsIconStop extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-stop';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '592d6e2aeafd5d41b43f772721bb85864de95407', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'd4744aaee5698b3ec22c4519c050984e4f154e68', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '81434846a4c0fa5c88bc1244d44301e0d8449970', d: "M7.7478 37.2521V10.7479C7.7478 9.09104 9.09095 7.74789 10.7478 7.74789H37.252C38.9089 7.74789 40.252 9.09104 40.252 10.7479V37.2521C40.252 38.909 38.9089 40.2521 37.252 40.2521H10.7478C9.09095 40.2521 7.7478 38.909 7.7478 37.2521Z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-stop"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconStop$1;},KsIconStop$1 = GetKsIconStop$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-stop"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-stop":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconStop$1(transTagName));
        }
        break;
    }});
}

const KsIconStop = KsIconStop$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconStop, defineCustomElement };
//# sourceMappingURL=ks-icon-stop.js.map
//# sourceMappingURL=ks-icon-stop.js.map