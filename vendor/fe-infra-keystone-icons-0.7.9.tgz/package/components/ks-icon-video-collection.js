import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconVideoCollection$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconVideoCollection$1 =

    proxyCustomElement(class KsIconVideoCollection extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-video-collection';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '96fa09f8973a80274853a8f53a4af5fef692aaf6', class: "ks-icon", "ks-icon": true }, h("svg", { key: '8e657462a8827eecae682ce1b160517ae334485b', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '34ef49046494c871ba98bfa47ea0ea4f7d44670c', d: "M11.4989 14.1352L18.2848 8.125", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '5e44ef41e689759f86524a7ae483bff2a7b13ce0', d: "M25.8418 23.0083L19.0912 18.021C18.1953 17.3591 16.9276 17.9987 16.9276 19.1126L16.9276 29.0871C16.9276 30.201 18.1953 30.8405 19.0912 30.1787L25.8418 25.1914C26.576 24.6489 26.576 23.5508 25.8418 23.0083Z", fill: icon.color }), h("rect", { key: '3f8e6819ec49e9bf449a191563498ccdcf832005', x: "3.49937", y: "7.49121", width: "35.0009", height: "26.8576", rx: "1.5", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '041e87d7449c93e4db6c5ec9517aa7e54461e39a', d: "M4.49986 14.5715H37.4999", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '1d0ff0920a147b5665c6a6afbb3b84970b181627', d: "M25.0715 14.1352L31.8574 8.125", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: 'b1abc6278e00cd6f34e1f9806b3c2873fe3b3f87', d: "M17.0664 40.5009H41.8464C43.4156 40.5009 44.6878 39.2288 44.6878 37.6595V20.2595", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-video-collection"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconVideoCollection$1;},KsIconVideoCollection$1 = GetKsIconVideoCollection$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-video-collection"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-video-collection":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconVideoCollection$1(transTagName));
        }
        break;
    }});
}

const KsIconVideoCollection = KsIconVideoCollection$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconVideoCollection, defineCustomElement };
//# sourceMappingURL=ks-icon-video-collection.js.map
//# sourceMappingURL=ks-icon-video-collection.js.map