import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconStickers$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconStickers$1 =

    proxyCustomElement(class KsIconStickers extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-stickers';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '80136a25b0722254530063b46b85701eda005d95', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'cfef4627528ea3242ed454384df07bb51346b880', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("g", { key: '308a1795615b50c0ed5b9eb38d5c89f782d08b3c', stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: '8b2b888331f8dc7f8867715b52d35e88db71ddfa', d: "M4.645 24l.012-.697C5.024 12.856 13.609 4.5 24.145 4.5c10.58 0 19.192 8.426 19.492 18.934l.008.566-19.5 19.5-.469-.005C13.123 43.245 4.645 34.612 4.645 24z" }), h("path", { key: '0b45516a9b0809a6031e49557b2d9a9a3c4125ba', d: "M42.555 23.898h-2.583c-8.836 0-16 7.163-16 16v2.582", "stroke-linecap": "round" })), h("g", { key: '67e7424d7d7cf07a1cd9ca986c123360c6be194a', fill: icon.color }, h("ellipse", { key: '94e9e53d30e811d88255781650b5300f24eb3e4c', cx: "17.702", cy: "17.11", rx: "2.333", ry: "5.761" }), h("ellipse", { key: 'eef0c762c099e44d6f8e0e3d46d9ced843a1e7b3', cx: "30.059", cy: "17.11", rx: "2.333", ry: "5.761" }))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-stickers"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconStickers$1;},KsIconStickers$1 = GetKsIconStickers$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-stickers"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-stickers":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconStickers$1(transTagName));
        }
        break;
    }});
}

const KsIconStickers = KsIconStickers$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconStickers, defineCustomElement };
//# sourceMappingURL=ks-icon-stickers.js.map
//# sourceMappingURL=ks-icon-stickers.js.map