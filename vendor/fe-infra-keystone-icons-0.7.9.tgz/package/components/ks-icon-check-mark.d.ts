import type { Components, JSX } from "../dist/types/components";

interface KsIconCheckMark extends Components.KsIconCheckMark, HTMLElement {}
export const KsIconCheckMark: {
    prototype: KsIconCheckMark;
    new (): KsIconCheckMark;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
