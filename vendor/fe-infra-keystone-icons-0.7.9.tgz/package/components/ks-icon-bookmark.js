import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconBookmark$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconBookmark$1 =

    proxyCustomElement(class KsIconBookmark extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-bookmark';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '618574337fb65e7bf02ccd81e1d71e1dd25cd224', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'ba9702e1ad279ce97a3762f24fb7992ab79c06d2', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '523055605e964049d7499546646fc33b2f73c1cb', d: "M11.8975 5.99902H34.9805C35.7451 5.99927 36.365 6.61911 36.3652 7.38379V38.2529C36.3651 39.4639 34.9206 40.0917 34.0352 39.2656L25.25 31.0664L25.0527 30.8984C24.1028 30.1698 22.7751 30.1698 21.8252 30.8984L21.6279 31.0664L12.8428 39.2656C11.9573 40.0917 10.5128 39.4639 10.5127 38.2529V7.38379C10.5129 6.61911 11.1328 5.99926 11.8975 5.99902Z", stroke: icon.color, "stroke-width": icon.strokeWidth })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-bookmark"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconBookmark$1;},KsIconBookmark$1 = GetKsIconBookmark$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-bookmark"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-bookmark":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconBookmark$1(transTagName));
        }
        break;
    }});
}

const KsIconBookmark = KsIconBookmark$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconBookmark, defineCustomElement };
//# sourceMappingURL=ks-icon-bookmark.js.map
//# sourceMappingURL=ks-icon-bookmark.js.map