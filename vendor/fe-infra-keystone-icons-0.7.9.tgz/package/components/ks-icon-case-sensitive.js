import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconCaseSensitive$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconCaseSensitive$1 =

    proxyCustomElement(class KsIconCaseSensitive extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-case-sensitive';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '484d0c233c64ce96e82c45de54b5be1195d0a758', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'b9f6fb891c62e3231a5fcec5b31b57913d770cc5', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: '6843c25ed46439013549ea745bd0f2a8fd454a9d', d: "M5.032 8.97h12.304m12.304 0H17.336m0 0v30.495" }), h("path", { key: '3476eb4fb9969e527635fdb061dabfc21ae24729', d: "M35.174 9.456v6.883m0 0v19.714c0 1.951 1.581 3.532 3.532 3.532h.314a3.22 3.22 0 0 0 3.218-3.219m-7.064-20.028H29.64m5.534 0h5.652", "stroke-linejoin": "bevel" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-case-sensitive"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconCaseSensitive$1;},KsIconCaseSensitive$1 = GetKsIconCaseSensitive$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-case-sensitive"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-case-sensitive":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconCaseSensitive$1(transTagName));
        }
        break;
    }});
}

const KsIconCaseSensitive = KsIconCaseSensitive$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconCaseSensitive, defineCustomElement };
//# sourceMappingURL=ks-icon-case-sensitive.js.map
//# sourceMappingURL=ks-icon-case-sensitive.js.map