import type { Components, JSX } from "../dist/types/components";

interface KsIconColoredPicture extends Components.KsIconColoredPicture, HTMLElement {}
export const KsIconColoredPicture: {
    prototype: KsIconColoredPicture;
    new (): KsIconColoredPicture;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
