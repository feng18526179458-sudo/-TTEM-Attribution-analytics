import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconLeftParenthesis$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconLeftParenthesis$1 =

    proxyCustomElement(class KsIconLeftParenthesis extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-left-parenthesis';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '816b996f04987c3622fbf83111c8e18e1a55b585', class: "ks-icon", "ks-icon": true }, h("svg", { key: '6f73b34d9efe609204ae9a0944415bc402a3572e', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '5a96b76adf81464a70e473f9359830c9b9390ee4', d: "M29.0276 42.5824C23.9407 39.6454 18.9724 34.2629 18.9724 24.0002C18.9724 13.7376 24.6146 7.96591 29.0276 5.41806", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-left-parenthesis"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconLeftParenthesis$1;},KsIconLeftParenthesis$1 = GetKsIconLeftParenthesis$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-left-parenthesis"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-left-parenthesis":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconLeftParenthesis$1(transTagName));
        }
        break;
    }});
}

const KsIconLeftParenthesis = KsIconLeftParenthesis$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconLeftParenthesis, defineCustomElement };
//# sourceMappingURL=ks-icon-left-parenthesis.js.map
//# sourceMappingURL=ks-icon-left-parenthesis.js.map