import type { Components, JSX } from "../dist/types/components";

interface KsIconDoubleChevronUp extends Components.KsIconDoubleChevronUp, HTMLElement {}
export const KsIconDoubleChevronUp: {
    prototype: KsIconDoubleChevronUp;
    new (): KsIconDoubleChevronUp;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
