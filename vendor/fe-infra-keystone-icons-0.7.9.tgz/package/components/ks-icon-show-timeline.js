import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconShowTimeline$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconShowTimeline$1 =

    proxyCustomElement(class KsIconShowTimeline extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-show-timeline';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '1aad1b36c863b66eb78216ea488a504d761939d7', class: "ks-icon", "ks-icon": true }, h("svg", { key: '5af11ce743bc8869ddf0105fe769916c8c852cea', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'c92511a4f54a78a7401ab7ce0b9ef0eed07178a4', d: "M5.143 19.6496H42.8569C43.922 19.6496 44.7856 20.5132 44.7856 21.5783V42.1496C44.7856 43.2147 43.922 44.0783 42.8569 44.0783H5.143C4.07788 44.0783 3.21429 43.2147 3.21429 42.1496V21.5783C3.21429 20.5797 3.9732 19.7581 4.94573 19.6594L5.143 19.6496Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("path", { key: '0d677ad0c9aad6c712d1ea842a615f01f812509a', d: "M35.0163 12.9021L24.0227 1.90857L13.0291 12.9021", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-show-timeline"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconShowTimeline$1;},KsIconShowTimeline$1 = GetKsIconShowTimeline$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-show-timeline"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-show-timeline":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconShowTimeline$1(transTagName));
        }
        break;
    }});
}

const KsIconShowTimeline = KsIconShowTimeline$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconShowTimeline, defineCustomElement };
//# sourceMappingURL=ks-icon-show-timeline.js.map
//# sourceMappingURL=ks-icon-show-timeline.js.map