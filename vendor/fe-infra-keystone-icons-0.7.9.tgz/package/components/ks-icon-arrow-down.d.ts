import type { Components, JSX } from "../dist/types/components";

interface KsIconArrowDown extends Components.KsIconArrowDown, HTMLElement {}
export const KsIconArrowDown: {
    prototype: KsIconArrowDown;
    new (): KsIconArrowDown;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
