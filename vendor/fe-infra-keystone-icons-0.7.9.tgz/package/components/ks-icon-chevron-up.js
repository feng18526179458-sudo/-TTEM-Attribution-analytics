import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconChevronUp$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconChevronUp$1 =

    proxyCustomElement(class KsIconChevronUp extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-chevron-up';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'c470e15dcdebbabdafc5ed27e6c7a1dbe1bed0ff', class: "ks-icon", "ks-icon": true }, h("svg", { key: '051b17bfdbfcea87cc18409f48f61611b37bd843', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '080461cd1e811963d8a0fc6ded280848eafdc38a', d: "M6 33l16.939-16.939a1.5 1.5 0 0 1 2.121 0L42 33", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-chevron-up"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconChevronUp$1;},KsIconChevronUp$1 = GetKsIconChevronUp$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-chevron-up"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-chevron-up":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconChevronUp$1(transTagName));
        }
        break;
    }});
}

const KsIconChevronUp = KsIconChevronUp$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconChevronUp, defineCustomElement };
//# sourceMappingURL=ks-icon-chevron-up.js.map
//# sourceMappingURL=ks-icon-chevron-up.js.map