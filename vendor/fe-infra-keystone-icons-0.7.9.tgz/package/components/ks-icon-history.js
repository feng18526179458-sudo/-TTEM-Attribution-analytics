import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconHistory$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconHistory$1 =

    proxyCustomElement(class KsIconHistory extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-history';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '390672674d5ecbe1a792935287596e70fc3b725b', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'b07f4c96c8a975bcec1f73756c90bd993a8828a0', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'd66a9075d9e0d49139e01984651cdcd20c506faa', d: "M5.96403 18.9272L4.62057 19.5943C4.94018 20.2379 5.67133 20.5645 6.36391 20.3729L5.96403 18.9272ZM5.03184 13.6776C4.66337 12.9356 3.76318 12.6328 3.02121 13.0013C2.27924 13.3698 1.97645 14.27 2.34492 15.0119L5.03184 13.6776ZM10.9209 19.1124C11.7193 18.8916 12.1876 18.0653 11.9667 17.2668C11.7459 16.4684 10.9196 16.0001 10.1211 16.221L10.9209 19.1124ZM7.04203 26.9738C6.90631 26.1566 6.13379 25.6041 5.31656 25.7398C4.49932 25.8755 3.94685 26.6481 4.08256 27.4653L7.04203 26.9738ZM26.3058 14.9996C26.3058 14.1712 25.6342 13.4996 24.8058 13.4996C23.9773 13.4996 23.3058 14.1712 23.3058 14.9996H26.3058ZM24.8058 26.9996H23.3058C23.3058 27.3975 23.4638 27.779 23.7451 28.0603L24.8058 26.9996ZM29.7451 34.0603C30.3309 34.6461 31.2806 34.6461 31.8664 34.0603C32.4522 33.4745 32.4522 32.5248 31.8664 31.939L29.7451 34.0603ZM24.8047 4.49323V5.99323C34.7497 5.99323 42.8116 14.0552 42.8116 24.0001H44.3116H45.8116C45.8116 12.3983 36.4065 2.99323 24.8047 2.99323V4.49323ZM44.3116 24.0001H42.8116C42.8116 33.945 34.7497 42.007 24.8047 42.007V43.507V45.007C36.4065 45.007 45.8116 35.6019 45.8116 24.0001H44.3116ZM5.96403 18.9272L7.41269 19.3163C9.47407 11.6413 16.4817 5.99323 24.8047 5.99323V4.49323V2.99323C15.0905 2.99323 6.91988 9.58561 4.51537 18.5381L5.96403 18.9272ZM5.96403 18.9272L7.30749 18.26L5.03184 13.6776L3.68838 14.3448L2.34492 15.0119L4.62057 19.5943L5.96403 18.9272ZM5.96403 18.9272L6.36391 20.3729L10.9209 19.1124L10.521 17.6667L10.1211 16.221L5.56414 17.4815L5.96403 18.9272ZM24.8047 43.507V42.007C15.8736 42.007 8.45855 35.5034 7.04203 26.9738L5.5623 27.2196L4.08256 27.4653C5.73549 37.4185 14.3825 45.007 24.8047 45.007V43.507ZM24.8058 14.9996H23.3058V26.9996H24.8058H26.3058V14.9996H24.8058ZM24.8058 26.9996L23.7451 28.0603L29.7451 34.0603L30.8057 32.9996L31.8664 31.939L25.8664 25.939L24.8058 26.9996Z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-history"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconHistory$1;},KsIconHistory$1 = GetKsIconHistory$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-history"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-history":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconHistory$1(transTagName));
        }
        break;
    }});
}

const KsIconHistory = KsIconHistory$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconHistory, defineCustomElement };
//# sourceMappingURL=ks-icon-history.js.map
//# sourceMappingURL=ks-icon-history.js.map