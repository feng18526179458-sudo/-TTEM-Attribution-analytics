import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconPayment$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconPayment$1 =

    proxyCustomElement(class KsIconPayment extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-payment';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'b472c689bd2a0f3de3241b00854499a9260dbd3a', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: 'bcd64d7a12547e40c05002d5c1d46d4f7fff98d9', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }, h("path", { key: '5159d76125ae5691d01b9e7fe452e798b52d40d0', d: "M4.498 16.885h39l-9.52-9m9.519 21.001h-39l9.52 9" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-payment"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconPayment$1;},KsIconPayment$1 = GetKsIconPayment$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-payment"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-payment":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconPayment$1(transTagName));
        }
        break;
    }});
}

const KsIconPayment = KsIconPayment$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconPayment, defineCustomElement };
//# sourceMappingURL=ks-icon-payment.js.map
//# sourceMappingURL=ks-icon-payment.js.map