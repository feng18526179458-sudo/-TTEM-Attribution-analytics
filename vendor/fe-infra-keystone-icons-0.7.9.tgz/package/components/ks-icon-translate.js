import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconTranslate$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconTranslate$1 =

    proxyCustomElement(class KsIconTranslate extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-translate';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '601787496a1179c6dc2c4847ae6d5045ea6ac468', class: "ks-icon", "ks-icon": true }, h("svg", { key: '24e26a4614427fd30ed6b80df6a9e16fab69abb4', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'e863582d56e249686b454c59952db853594b0b87', d: "M31.502 37.5L25.77 19.952l-2.866-8.774M31.502 37.5H19.949m11.553 0l-5.076 8.577m-3.522-34.899l-2.094-6.41a3.43 3.43 0 0 0-3.259-2.364H6.224a3.43 3.43 0 0 0-3.429 3.429v28.239A3.43 3.43 0 0 0 6.224 37.5h13.725m2.954-26.322h19.085a3.43 3.43 0 0 1 3.429 3.428v28.042a3.43 3.43 0 0 1-3.429 3.428H26.426m0 0L19.949 37.5", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" }), h("path", { key: 'd223a529ccc37e7d3fda8724fdfe18d4de65eeaf', d: "M38.54 24.781l1.878.543c-1.849 5.282-5.267 8.363-10.52 10.007-.205-.44-.763-1.291-1.115-1.717 5.077-1.335 8.231-4.05 9.757-8.833zm-5.664.117c1.482 4.343 4.651 7.468 9.875 8.642-.425.411-.998 1.247-1.276 1.761-5.502-1.438-8.525-4.798-10.359-9.875l1.761-.528zm-3.829-1.071h13.44v1.731h-13.44v-1.731zm5.766-2.318h1.819v3.375h-1.819v-3.375zM7.296 24.241l4.119-13.021h3.989l4.137 13.021h-2.9l-3.158-11.359h-.111l-3.177 11.359h-2.9zm2.992-3.084v-2.179h6.261v2.179h-6.261z", fill: icon.color })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-translate"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconTranslate$1;},KsIconTranslate$1 = GetKsIconTranslate$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-translate"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-translate":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconTranslate$1(transTagName));
        }
        break;
    }});
}

const KsIconTranslate = KsIconTranslate$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconTranslate, defineCustomElement };
//# sourceMappingURL=ks-icon-translate.js.map
//# sourceMappingURL=ks-icon-translate.js.map