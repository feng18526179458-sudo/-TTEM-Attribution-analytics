import type { Components, JSX } from "../dist/types/components";

interface KsIconColorDropper extends Components.KsIconColorDropper, HTMLElement {}
export const KsIconColorDropper: {
    prototype: KsIconColorDropper;
    new (): KsIconColorDropper;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
