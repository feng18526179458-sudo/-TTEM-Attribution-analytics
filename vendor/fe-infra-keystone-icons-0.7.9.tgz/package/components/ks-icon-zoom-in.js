import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconZoomIn$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconZoomIn$1 =

    proxyCustomElement(class KsIconZoomIn extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-zoom-in';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '360c152f52ef12e2bccf1f1dbd109a835b1f7213', class: "ks-icon", "ks-icon": true }, h("svg", { key: '2ea6e95c5875302e340a3bf09e0eb28ce25798b0', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'ca4a66f3ffae7e0914a8a9665e3c332f99f38f84', d: "M37.5 21c0 9.113-7.387 16.5-16.5 16.5S4.5 30.113 4.5 21 11.887 4.5 21 4.5 37.5 11.887 37.5 21z", stroke: icon.color, "stroke-width": icon.strokeWidth }), h("path", { key: 'dc4fc8437ec8afaec7e7db5f25698c41e667fe0d', d: "M34.061 31.939L33 30.879 30.879 33l1.061 1.061 2.121-2.121zm9.879 14.121a1.5 1.5 0 0 0 2.121-2.121l-2.121 2.121zm-12-12l12 12 2.121-2.121-12-12-2.121 2.121z", fill: icon.color }), h("g", { key: '46a3edf8fbe415b812e0316e396aa81d08551dea', stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }, h("path", { key: 'fddb4bf46f39402fcd7f0714fa27a373eb2d78b9', d: "M13.496 21h15" }), h("path", { key: '427e4e58e5dd083d94701f7049b4942360d263b0', d: "M20.993 13.5v15" }))));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-zoom-in"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconZoomIn$1;},KsIconZoomIn$1 = GetKsIconZoomIn$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-zoom-in"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-zoom-in":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconZoomIn$1(transTagName));
        }
        break;
    }});
}

const KsIconZoomIn = KsIconZoomIn$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconZoomIn, defineCustomElement };
//# sourceMappingURL=ks-icon-zoom-in.js.map
//# sourceMappingURL=ks-icon-zoom-in.js.map