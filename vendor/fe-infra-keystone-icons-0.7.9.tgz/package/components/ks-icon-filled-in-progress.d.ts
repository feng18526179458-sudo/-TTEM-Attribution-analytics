import type { Components, JSX } from "../dist/types/components";

interface KsIconFilledInProgress extends Components.KsIconFilledInProgress, HTMLElement {}
export const KsIconFilledInProgress: {
    prototype: KsIconFilledInProgress;
    new (): KsIconFilledInProgress;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
