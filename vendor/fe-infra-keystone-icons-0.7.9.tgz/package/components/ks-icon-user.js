import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconUser$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconUser$1 =

    proxyCustomElement(class KsIconUser extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-user';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '173df460cd9c0b218dcb423f3a9fd5ebffdc4b20', class: "ks-icon", "ks-icon": true }, h("svg", { key: '021b00f551961de7fed9aaf7e6db1b7010d83df3', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("circle", { key: '1bc2bd7546d35a84832be389d303c8f769b11d21', cx: "23.967", cy: "16.127", r: "9" }), h("path", { key: '306dd3662371e35aa31d1156dbd86071c448739c', d: "M38.968 40.127c0-8.284-6.716-15-15-15s-15 6.716-15 15", "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-user"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconUser$1;},KsIconUser$1 = GetKsIconUser$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-user"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-user":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconUser$1(transTagName));
        }
        break;
    }});
}

const KsIconUser = KsIconUser$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconUser, defineCustomElement };
//# sourceMappingURL=ks-icon-user.js.map
//# sourceMappingURL=ks-icon-user.js.map