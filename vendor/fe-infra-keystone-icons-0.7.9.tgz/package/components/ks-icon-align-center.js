import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconAlignCenter$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconAlignCenter$1 =

    proxyCustomElement(class KsIconAlignCenter extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-align-center';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '744a6927705545c741ae91c731f67270f552a581', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'e419d02dcf3fb659a74156a411d6bf2c55f2fc83', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: 'd1a63b95a274b0c635c66bd74ba28a4baa24f610', d: "M6.01169 8.90112L41.9877 8.90112M10.8507 29.4723L37.1497 29.4723M33.0741 39.758H14.9255M33.0741 19.1867L14.9255 19.1867", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-align-center"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconAlignCenter$1;},KsIconAlignCenter$1 = GetKsIconAlignCenter$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-align-center"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-align-center":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconAlignCenter$1(transTagName));
        }
        break;
    }});
}

const KsIconAlignCenter = KsIconAlignCenter$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconAlignCenter, defineCustomElement };
//# sourceMappingURL=ks-icon-align-center.js.map
//# sourceMappingURL=ks-icon-align-center.js.map