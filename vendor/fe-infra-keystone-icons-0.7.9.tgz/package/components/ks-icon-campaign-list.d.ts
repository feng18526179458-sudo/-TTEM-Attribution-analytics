import type { Components, JSX } from "../dist/types/components";

interface KsIconCampaignList extends Components.KsIconCampaignList, HTMLElement {}
export const KsIconCampaignList: {
    prototype: KsIconCampaignList;
    new (): KsIconCampaignList;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
