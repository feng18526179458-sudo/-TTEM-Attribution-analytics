import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconDoubleChevronUp$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconDoubleChevronUp$1 =

    proxyCustomElement(class KsIconDoubleChevronUp extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-double-chevron-up';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '1ab7b15d319096ebdffb181e74efdea67a6a9256', class: "ks-icon", "ks-icon": true }, h("svg", { key: '264ae97cdd3c6c172734f877b2ff109ead1e89c0', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }, h("path", { key: '1528d652d42931bd76cdbe8ee0bee8a6520ad6b6', d: "M38.996 24l-15-12-15 12m30 12l-15-12-15 12" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-double-chevron-up"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconDoubleChevronUp$1;},KsIconDoubleChevronUp$1 = GetKsIconDoubleChevronUp$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-double-chevron-up"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-double-chevron-up":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconDoubleChevronUp$1(transTagName));
        }
        break;
    }});
}

const KsIconDoubleChevronUp = KsIconDoubleChevronUp$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconDoubleChevronUp, defineCustomElement };
//# sourceMappingURL=ks-icon-double-chevron-up.js.map
//# sourceMappingURL=ks-icon-double-chevron-up.js.map