import type { Components, JSX } from "../dist/types/components";

interface KsIconEdit extends Components.KsIconEdit, HTMLElement {}
export const KsIconEdit: {
    prototype: KsIconEdit;
    new (): KsIconEdit;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
