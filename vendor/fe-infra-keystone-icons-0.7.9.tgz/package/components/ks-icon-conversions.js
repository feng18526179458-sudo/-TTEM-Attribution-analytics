import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconConversions$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconConversions$1 =

    proxyCustomElement(class KsIconConversions extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-conversions';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'c4ded86ff891e11f74ade6c853f71ca520842fd6', class: "ks-icon", "ks-icon": true }, h("svg", { key: '692c1e6ce40a2c25341c5e536085a84ea014de5d', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: '3f5f6689ffa4971ee382dfbcbd15e74db8f6fab3', d: "M10.505 31.5l9-9 6 6 10.5-10.5m-9.002 0h9v9", "stroke-linecap": "round", "stroke-linejoin": "round" }), h("rect", { key: 'f1055d5e5c35b3fbf0e01751359f9bd996759026', x: "4.5", y: "4.5", width: "39", height: "39", rx: "1.5" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-conversions"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconConversions$1;},KsIconConversions$1 = GetKsIconConversions$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-conversions"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-conversions":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconConversions$1(transTagName));
        }
        break;
    }});
}

const KsIconConversions = KsIconConversions$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconConversions, defineCustomElement };
//# sourceMappingURL=ks-icon-conversions.js.map
//# sourceMappingURL=ks-icon-conversions.js.map