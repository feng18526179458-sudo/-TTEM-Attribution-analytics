import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconProtection$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconProtection$1 =

    proxyCustomElement(class KsIconProtection extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-protection';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '5cbe374ba19d2a3a8c8b9f240a03ab5966539f0d', class: "ks-icon", "ks-icon": true }, h("svg", { key: '10f6b14c080470e9bbee905d89ab017d01156390', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" }, h("path", { key: '3072bddb63ab9bf9f0371748643eafab0552383e', d: "M7.225 7.07l16.5-3.715a1.25 1.25 0 0 1 .549 0l16.5 3.715a1.25 1.25 0 0 1 .975 1.219v19.692c0 3.382-1.821 6.598-4.952 8.536l-12.14 7.516a1.25 1.25 0 0 1-1.316 0l-12.14-7.516c-3.131-1.938-4.952-5.155-4.952-8.536V8.29a1.25 1.25 0 0 1 .975-1.219z" }), h("path", { key: '402ba08c329ba758e71c775418a26d0ed94debf0', d: "M15.001 23.423l5.539 5.538L33.001 16.5", "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-protection"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconProtection$1;},KsIconProtection$1 = GetKsIconProtection$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-protection"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-protection":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconProtection$1(transTagName));
        }
        break;
    }});
}

const KsIconProtection = KsIconProtection$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconProtection, defineCustomElement };
//# sourceMappingURL=ks-icon-protection.js.map
//# sourceMappingURL=ks-icon-protection.js.map