import type { Components, JSX } from "../dist/types/components";

interface KsIconAscendDown extends Components.KsIconAscendDown, HTMLElement {}
export const KsIconAscendDown: {
    prototype: KsIconAscendDown;
    new (): KsIconAscendDown;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
