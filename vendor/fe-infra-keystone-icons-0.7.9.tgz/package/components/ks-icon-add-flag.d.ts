import type { Components, JSX } from "../dist/types/components";

interface KsIconAddFlag extends Components.KsIconAddFlag, HTMLElement {}
export const KsIconAddFlag: {
    prototype: KsIconAddFlag;
    new (): KsIconAddFlag;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
