import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconDisconnect$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconDisconnect$1 =

    proxyCustomElement(class KsIconDisconnect extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-disconnect';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'a1143f134d15c66927df86a88df920e33d84c005', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'ad819bde7352300210d1be438ffe8527b0249d18', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth }, h("path", { key: '1146c6b17622cbe32f3b4e9fac26d97b23e35a67', d: "M26.038 8.746a9.37 9.37 0 0 1 13.249 0 9.37 9.37 0 0 1 0 13.25l-3.643 3.643a1.5 1.5 0 0 1-2.121 0L22.395 14.51a1.5 1.5 0 0 1 0-2.121l3.643-3.643zM8.746 26.038a9.37 9.37 0 0 0 0 13.25 9.37 9.37 0 0 0 13.249 0l3.643-3.643a1.5 1.5 0 0 0 0-2.121L14.51 22.395a1.5 1.5 0 0 0-2.121 0l-3.643 3.643z" }), h("path", { key: '63e0ee40f57f24bf1f892e3bba462816b661d59b', d: "M24.498 16.812l-2.885 2.885m9.608 3.839l-2.885 2.885M39.388 8.646L45 2.897M8.647 39.388L3 44.898", "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-disconnect"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconDisconnect$1;},KsIconDisconnect$1 = GetKsIconDisconnect$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-disconnect"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-disconnect":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconDisconnect$1(transTagName));
        }
        break;
    }});
}

const KsIconDisconnect = KsIconDisconnect$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconDisconnect, defineCustomElement };
//# sourceMappingURL=ks-icon-disconnect.js.map
//# sourceMappingURL=ks-icon-disconnect.js.map