import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconOption$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconOption$1 =

    proxyCustomElement(class KsIconOption extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-option';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'c072d52ba5c8a0153bc8009e296c20691f634d21', class: "ks-icon", "ks-icon": true }, h("svg", { key: '4b2a22319402980430a7214117f0520fb9d88fe8', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '209e3e077b4d69a2782747674bcf47113b381120', d: "M42.5469 36.003H24.0244L17.9757 11.9971H5.45312", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: '2079336782ba595d405384dea2d5a4440c48cfd5', d: "M25.5781 11.9971L42.4844 11.9971", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-option"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconOption$1;},KsIconOption$1 = GetKsIconOption$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-option"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-option":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconOption$1(transTagName));
        }
        break;
    }});
}

const KsIconOption = KsIconOption$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconOption, defineCustomElement };
//# sourceMappingURL=ks-icon-option.js.map
//# sourceMappingURL=ks-icon-option.js.map