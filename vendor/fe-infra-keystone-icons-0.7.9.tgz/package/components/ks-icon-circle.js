import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconCircle$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconCircle$1 =

    proxyCustomElement(class KsIconCircle extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-circle';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '8da82b2a5c28c81307b3d98010abc132507ca4bb', class: "ks-icon", "ks-icon": true }, h("svg", { key: '48e4fedf0934cc6ba3371d2d28dbdd6712435665', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '45c98444f375e295b3b9b9be99b2679bc1cf3a92', d: "M45.0001 23.9999C45.0001 12.4019 35.5981 2.99986 24.0001 2.99986C12.4022 2.99986 3.00014 12.4019 3.00014 23.9999C3.00014 35.5978 12.4022 44.9999 24.0001 44.9999C35.5981 44.9999 45.0001 35.5978 45.0001 23.9999Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-circle"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconCircle$1;},KsIconCircle$1 = GetKsIconCircle$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-circle"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-circle":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconCircle$1(transTagName));
        }
        break;
    }});
}

const KsIconCircle = KsIconCircle$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconCircle, defineCustomElement };
//# sourceMappingURL=ks-icon-circle.js.map
//# sourceMappingURL=ks-icon-circle.js.map