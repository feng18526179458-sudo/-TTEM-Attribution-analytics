import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFilledUnmarkedFlag$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFilledUnmarkedFlag$1 =

    proxyCustomElement(class KsIconFilledUnmarkedFlag extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-filled-unmarked-flag';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
        this.innerColor = 'white';
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: 'dd98697e8cc1921d5763732701f6f2c4d88fe457', class: "ks-icon", "ks-icon": true }, h("svg", { key: '1b4b9d73d03509ea53696032eb8e2c114ccf47a7', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: 'e5fe06e0b7bb55c608abf66bad117243d2ce6e17', d: "M40.955 16.584c1.339.469 1.339 2.363 0 2.832l-23.959 8.386A1.5 1.5 0 0 1 15 26.386V9.614a1.5 1.5 0 0 1 1.995-1.416l23.959 8.386z", fill: icon.color }), h("path", { key: '939a85797b43911fe04ba836e2614cb30e6e53ef', d: "M14.999 6v34.5m-4.499.363h9", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }), h("rect", { key: '4b401adeeecd46aa17bbe21b4052d5e41e96fbbd', width: "3", height: "41.214", rx: "1.5", transform: "matrix(.75869 -.651452 .651448 .758693 7.67784 3.63232)", fill: this.innerColor })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-filled-unmarked-flag"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"],
      "innerColor": [1, "inner-color"]
    }]);return innerKsIconFilledUnmarkedFlag$1;},KsIconFilledUnmarkedFlag$1 = GetKsIconFilledUnmarkedFlag$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-filled-unmarked-flag"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-filled-unmarked-flag":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFilledUnmarkedFlag$1(transTagName));
        }
        break;
    }});
}

const KsIconFilledUnmarkedFlag = KsIconFilledUnmarkedFlag$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFilledUnmarkedFlag, defineCustomElement };
//# sourceMappingURL=ks-icon-filled-unmarked-flag.js.map
//# sourceMappingURL=ks-icon-filled-unmarked-flag.js.map