import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconLogout$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconLogout$1 =

    proxyCustomElement(class KsIconLogout extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-logout';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '2b3b53e3da7f5df24058b1dd3dcdeb7e16762edd', class: "ks-icon ks-icon--rtlable", "ks-icon": true }, h("svg", { key: 'f80f3a04a270426e516e2865610bd7866b4ec78f', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: '01bca7afb2ada01f712b318f36e2e98f3388dbb9', d: "M39 9V6a1.5 1.5 0 0 0-1.5-1.5h-7.027H10.5A1.5 1.5 0 0 0 9 6v36a1.5 1.5 0 0 0 1.5 1.5h27A1.5 1.5 0 0 0 39 42v-3" }), h("path", { key: '95e56dd34b2198aea3a8683c0146e77a0a60a04d', d: "M38.999 24H14.997m24.002 0l-6.001-6.001M38.999 24l-6.001 6.001", "stroke-linejoin": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-logout"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconLogout$1;},KsIconLogout$1 = GetKsIconLogout$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-logout"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-logout":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconLogout$1(transTagName));
        }
        break;
    }});
}

const KsIconLogout = KsIconLogout$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconLogout, defineCustomElement };
//# sourceMappingURL=ks-icon-logout.js.map
//# sourceMappingURL=ks-icon-logout.js.map