import type { Components, JSX } from "../dist/types/components";

interface KsIconColoredTelegram extends Components.KsIconColoredTelegram, HTMLElement {}
export const KsIconColoredTelegram: {
    prototype: KsIconColoredTelegram;
    new (): KsIconColoredTelegram;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
