import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconFullScreen$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconFullScreen$1 =

    proxyCustomElement(class KsIconFullScreen extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-full-screen';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '941e44ef1b3415dba2dea1adb1af607b766b8ac8', class: "ks-icon", "ks-icon": true }, h("svg", { key: '2cb621f2b174f100a1ee467022b8c7d999979273', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: '755a845ff2560f60627d0293cb22b2ed2ba56406', d: "M16.499 6h-9a1.5 1.5 0 0 0-1.5 1.5V18M31.498 6h9a1.5 1.5 0 0 1 1.5 1.5V18m-10.5 24h9a1.5 1.5 0 0 0 1.5-1.5V30M16.499 42h-9a1.5 1.5 0 0 1-1.5-1.5V30" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-full-screen"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconFullScreen$1;},KsIconFullScreen$1 = GetKsIconFullScreen$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-full-screen"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-full-screen":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconFullScreen$1(transTagName));
        }
        break;
    }});
}

const KsIconFullScreen = KsIconFullScreen$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconFullScreen, defineCustomElement };
//# sourceMappingURL=ks-icon-full-screen.js.map
//# sourceMappingURL=ks-icon-full-screen.js.map