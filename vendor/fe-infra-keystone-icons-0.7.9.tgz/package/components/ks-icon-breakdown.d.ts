import type { Components, JSX } from "../dist/types/components";

interface KsIconBreakdown extends Components.KsIconBreakdown, HTMLElement {}
export const KsIconBreakdown: {
    prototype: KsIconBreakdown;
    new (): KsIconBreakdown;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
