import type { Components, JSX } from "../dist/types/components";

interface KsIconArrowRightSmall extends Components.KsIconArrowRightSmall, HTMLElement {}
export const KsIconArrowRightSmall: {
    prototype: KsIconArrowRightSmall;
    new (): KsIconArrowRightSmall;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
