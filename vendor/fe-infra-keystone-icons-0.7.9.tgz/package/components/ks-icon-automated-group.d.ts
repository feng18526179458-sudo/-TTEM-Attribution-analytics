import type { Components, JSX } from "../dist/types/components";

interface KsIconAutomatedGroup extends Components.KsIconAutomatedGroup, HTMLElement {}
export const KsIconAutomatedGroup: {
    prototype: KsIconAutomatedGroup;
    new (): KsIconAutomatedGroup;
};
/**
 * Used to define this component and all nested components recursively.
 */
export const defineCustomElement: () => void;
