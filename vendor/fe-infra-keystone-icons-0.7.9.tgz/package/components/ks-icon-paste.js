import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconPaste$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconPaste$1 =

    proxyCustomElement(class KsIconPaste extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-paste';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '33322f1e2621d1301f549e794b619aeb2195423d', class: "ks-icon", "ks-icon": true }, h("svg", { key: '72372fca3f6626277f73081bc85889b74bd6cd59', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none" }, h("path", { key: '97a4bb6042a72de552dc19e8d15025c162350e30', d: "M35.933 13.41H23.015c-1.931 0-3.497 1.565-3.497 3.496v23.957c0 1.931 1.565 3.496 3.497 3.496h17.968c1.931 0 3.496-1.565 3.496-3.496v-19.1c0-.951-.387-1.861-1.073-2.52l-5.05-4.858c-.651-.626-1.52-.977-2.424-.977z", stroke: icon.color, "stroke-width": icon.strokeWidth }), h("mask", { key: '24ceabf1924d0ccb68879e7a83a6f7b1fd5bbda4', id: "A", maskUnits: "userSpaceOnUse", x: "3.02", y: "2.144", width: "31", height: "38", fill: "#000" }, h("path", { key: 'f0c552081d7ba7525d8c30a936e79a7a74d96071', fill: "#fff", d: "M3.02 2.144h31v38h-31z" }), h("path", { key: '4530054ebfcfe6bcd8807620ef7e92b98c6d1668', d: "M12.068 6.234a1.09 1.09 0 0 1 1.09-1.09h10.704a1.09 1.09 0 1 1 0 2.18H13.158a1.09 1.09 0 0 1-1.09-1.09z" })), h("path", { key: '376c3c8f6a77068dcd6bec1435441c3715d3a05d', d: "M10.157 7.432a1.5 1.5 0 1 0 0-3v3zm16.317-3a1.5 1.5 0 1 0 0 3v-3zM6.52 34.785V9.356h-3v25.429h3zM8.443 7.432h1.714v-3H8.443v3zm18.031 0h2.102v-3h-2.102v3zM8.443 36.708c-1.062 0-1.923-.861-1.923-1.923h-3c0 2.719 2.204 4.923 4.923 4.923v-3zM33.5 9.356c0-2.719-2.204-4.923-4.923-4.923v3c1.062 0 1.923.861 1.923 1.923h3zm-26.98 0c0-1.062.861-1.923 1.923-1.923v-3c-2.719 0-4.923 2.204-4.923 4.923h3zm23.98 0v5.361h3V9.356h-3zM19.215 36.708H8.443v3h10.772v-3zM13.158 8.144h10.704v-6H13.158v6zm10.704-3.82H13.158v6h10.704v-6zm-10.704 0a1.91 1.91 0 0 1 1.91 1.91h-6a4.09 4.09 0 0 0 4.09 4.09v-6zm8.794 1.91a1.91 1.91 0 0 1 1.91-1.91v6a4.09 4.09 0 0 0 4.09-4.09h-6zm1.91 1.91a1.91 1.91 0 0 1-1.91-1.91h6a4.09 4.09 0 0 0-4.09-4.09v6zm-10.704-6a4.09 4.09 0 0 0-4.09 4.09h6a1.91 1.91 0 0 1-1.91 1.91v-6z", fill: icon.color, mask: "url(#A)" }), h("path", { key: '1a7ff0b4240218505d788eb84b3615c82fde3012', d: "M25.881 23.389h9.991m-9.991 7.203h9.991m-9.991 6.7h5.983", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-paste"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconPaste$1;},KsIconPaste$1 = GetKsIconPaste$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-paste"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-paste":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconPaste$1(transTagName));
        }
        break;
    }});
}

const KsIconPaste = KsIconPaste$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconPaste, defineCustomElement };
//# sourceMappingURL=ks-icon-paste.js.map
//# sourceMappingURL=ks-icon-paste.js.map