import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconLowercase$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconLowercase$1 =

    proxyCustomElement(class KsIconLowercase extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-lowercase';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '447d716e4ccc317d264b9a1257acf02b67b1a583', class: "ks-icon", "ks-icon": true }, h("svg", { key: '89db2d56a15634cbca6577f3fba8b5a200bf141c', width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, h("path", { key: '03344cf7bfb413286b21885281d6cad4795dc007', d: "M10.3167 14.4457L11.0458 13.6766C12.9019 11.7185 16.0099 11.6841 17.9089 13.6005C18.8479 14.5481 19.3747 15.8282 19.3747 17.1622V28.3044M18.7987 19.6184H12.9442C10.5426 19.6184 8.5957 21.5861 8.5957 24.0133C8.5957 26.6358 10.8536 28.6746 13.4321 28.3804L14.2405 28.2882C16.9121 27.9833 19.0262 25.863 19.3484 23.1653L19.3747 22.9448", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round", "stroke-linejoin": "round" }), h("path", { key: '0455965e61acaa2405a780bdac3f3b2722594bde', d: "M40.0273 13.8191V30.4677C40.0273 35.7794 32.2654 37.6153 28.6112 33.7603M40.0273 20.3191C40.0273 23.9089 37.1172 26.8191 33.5273 26.8191C29.9375 26.8191 27.0273 23.9089 27.0273 20.3191C27.0273 16.7292 29.9375 13.8191 33.5273 13.8191C37.1172 13.8191 40.0273 16.7292 40.0273 20.3191Z", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-lowercase"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconLowercase$1;},KsIconLowercase$1 = GetKsIconLowercase$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-lowercase"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-lowercase":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconLowercase$1(transTagName));
        }
        break;
    }});
}

const KsIconLowercase = KsIconLowercase$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconLowercase, defineCustomElement };
//# sourceMappingURL=ks-icon-lowercase.js.map
//# sourceMappingURL=ks-icon-lowercase.js.map