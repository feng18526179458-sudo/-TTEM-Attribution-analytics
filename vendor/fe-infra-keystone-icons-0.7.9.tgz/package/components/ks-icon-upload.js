import { proxyCustomElement, HTMLElement, h, Host } from '@stencil/core/internal/client';
import { u as useIcon } from './index2.js';

const indexCss = ":host(.ks-icon){display:flex;align-items:center;justify-content:center}:host(.ks-icon--rtlable[dir='rtl']){transform:scaleX(-1);-o-transform:scaleX(-1);-ms-transform:scaleX(-1);-moz-transform:scaleX(-1);-webkit-transform:scaleX(-1);filter:FlipH;-ms-filter:'FlipH'}";const GetKsIconUpload$1 = /*@__PURE__*/function (transTagName) {transTagName = transTagName || function (tagName) {return tagName;};const innerKsIconUpload$1 =

    proxyCustomElement(class KsIconUpload extends HTMLElement {
      constructor(registerHost) {
        super();
        if (registerHost !== false) {
          this.__registerHost();
        }
        this.__attachShadow();
        this['ks-icon-name'] = 'ks-icon-upload';
        this.size = 16;
        this.color = 'currentColor';
        /**
         * @deprecated
         */
        this.absoluteStrokeWidth = false;
      }
      render() {
        const icon = useIcon({ size: this.size, color: this.color });
        return h(Host, { key: '9c8b96d594bfcf62fdcb6624df34aef01946fe44', class: "ks-icon", "ks-icon": true }, h("svg", { key: 'de88c69018d62fe6f055c27d31ec5d17426e18b9', xmlns: "http://www.w3.org/2000/svg", width: icon.width, height: icon.height, viewBox: "0 0 48 48", fill: "none", stroke: icon.color, "stroke-width": icon.strokeWidth, "stroke-linecap": "round" }, h("path", { key: 'dbf26bea4c90894f27f7bd6204b8c5eaa23c7126', d: "M14.25 42H5.998a1.5 1.5 0 0 1-1.5-1.5v-33a1.5 1.5 0 0 1 1.5-1.5h36.009a1.5 1.5 0 0 1 1.5 1.5v33a1.5 1.5 0 0 1-1.5 1.5h-8.252m-.79-16.498l-8.995-9.003m-8.996 9.003l8.995-9.003m-.004-.005v25.5" })));
      }
      static get style() {return indexCss;}
    }, [257, transTagName("ks-icon-upload"), {
      "size": [8],
      "color": [1],
      "strokeWidth": [8, "stroke-width"],
      "absoluteStrokeWidth": [4, "absolute-stroke-width"]
    }]);return innerKsIconUpload$1;},KsIconUpload$1 = GetKsIconUpload$1();
function defineCustomElement$1(transTagName) {transTagName = transTagName || function (tagName) {return tagName;};
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["ks-icon-upload"];
  components.forEach((tagName) => {switch (tagName) {
      case "ks-icon-upload":
        if (!customElements.get(transTagName(tagName))) {
          customElements.define(transTagName(tagName), GetKsIconUpload$1(transTagName));
        }
        break;
    }});
}

const KsIconUpload = KsIconUpload$1;
const defineCustomElement = defineCustomElement$1;

export { KsIconUpload, defineCustomElement };
//# sourceMappingURL=ks-icon-upload.js.map
//# sourceMappingURL=ks-icon-upload.js.map