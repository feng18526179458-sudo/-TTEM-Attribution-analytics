/* eslint-disable @typescript-eslint/no-explicit-any */
export class Memo {
  private _cache?: Record<string, [any[], any]>;

  protected memoize<TDeps extends readonly any[], TResult>(
    key: string,
    getDeps: () => [...TDeps],
    fn: (...args: NoInfer<[...TDeps]>) => TResult,
    opts?: {
      key?: any;
      debug?: () => any;
      onChange?: (result: TResult) => void;
    },
  ): TResult {
    const debugKey = opts?.key ?? key;
    let depTime = 0;
    // const isDebug = opts?.debug?.()
    const isDebug = true;

    if (debugKey && isDebug) depTime = Date.now();

    const newDeps = getDeps();

    if (!this._cache) {
      this._cache = {};
    }

    const cacheEntry = this._cache[key];
    const [oldDeps, oldResult] = cacheEntry || [[], undefined];

    let depsChanged = !cacheEntry;
    if (cacheEntry) {
      depsChanged =
        newDeps.length !== oldDeps.length || newDeps.some((dep: any, index: number) => oldDeps[index] !== dep);
    }

    if (!depsChanged) {
      return oldResult as TResult;
    }

    let resultTime = 0;
    if (debugKey && isDebug) resultTime = Date.now();

    const result = fn(...newDeps);

    this._cache[key] = [newDeps, result];

    opts?.onChange?.(result);

    if (debugKey && isDebug) {
      const depEndTime = Math.round((Date.now() - depTime) * 100) / 100;
      const resultEndTime = Math.round((Date.now() - resultTime) * 100) / 100;
      const resultFpsPercentage = resultEndTime / 16;

      const pad = (str: number | string, num: number) => {
        str = String(str);
        while (str.length < num) {
          str = ` ${str}`;
        }
        return str;
      };

      console.info(
        `%c⏱ ${pad(resultEndTime, 5)} /${pad(depEndTime, 5)} ms`,
        `
            font-size: .6rem;
            font-weight: bold;
            color: hsl(${Math.max(0, Math.min(120 - 120 * resultFpsPercentage, 120))}deg 100% 31%);`,
        debugKey,
      );
    }

    return result;
  }
}
