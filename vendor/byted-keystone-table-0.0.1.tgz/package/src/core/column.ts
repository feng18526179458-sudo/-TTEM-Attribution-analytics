/* eslint-disable max-lines */
import { _getVisibleLeafColumns, VisibilityColumn } from '../features/ColumnVisibility';
import { ColumnPinningColumn, ColumnPinningPosition } from '../features/ColumnPinning';
import { FacetedColumn } from '../features/ColumnFaceting';
import { ColumnFiltersColumn, FilterFn, shouldAutoRemoveFilter } from '../features/ColumnFiltering';
import { GlobalFilterColumn } from '../features/GlobalFiltering';
import { SortDirection, SortingColumn, SortingFn, SortingState } from '../features/RowSorting';
import { AggregationFn, GroupingColumn } from '../features/ColumnGrouping';
import { ColumnSizingColumn, defaultColumnSizing } from '../features/ColumnSizing';
import { Table, AccessorFn, ColumnDef, RowData, ColumnDefResolved, RowModel, Updater } from '../types';
import { functionalUpdate, getMemoOptions, isFunction } from '../utils';
import { Memo } from './memo';
import { BuiltInFilterFn, filterFns } from '../filterFns';
import { BuiltInSortingFn, reSplitAlphaNumeric, sortingFns } from '../sortingFns';
import { aggregationFns, BuiltInAggregationFn } from '../aggregationFns';
import { ColumnOrderColumn } from '../features/ColumnOrdering';

export interface CoreColumn<TData extends RowData, TValue> {
  /**
   * The resolved accessor function to use when extracting the value for the column from each row. Will only be defined if the column def has a valid accessor key or function defined.
   * @link [API Docs](https://tanstack.com/table/v8/docs/api/core/column#accessorfn)
   * @link [Guide](https://tanstack.com/table/v8/docs/guide/column-defs)
   */
  accessorFn?: AccessorFn<TData, TValue>;
  /**
   * The original column def used to create the column.
   * @link [API Docs](https://tanstack.com/table/v8/docs/api/core/column#columndef)
   * @link [Guide](https://tanstack.com/table/v8/docs/guide/column-defs)
   */
  columnDef: ColumnDef<TData, TValue>;
  /**
   * The child column (if the column is a group column). Will be an empty array if the column is not a group column.
   * @link [API Docs](https://tanstack.com/table/v8/docs/api/core/column#columns)
   * @link [Guide](https://tanstack.com/table/v8/docs/guide/column-defs)
   */
  columns: Column<TData, TValue>[];
  /**
   * The depth of the column (if grouped) relative to the root column def array.
   * @link [API Docs](https://tanstack.com/table/v8/docs/api/core/column#depth)
   * @link [Guide](https://tanstack.com/table/v8/docs/guide/column-defs)
   */
  depth: number;
  /**
   * Returns the flattened array of this column and all child/grand-child columns for this column.
   * @link [API Docs](https://tanstack.com/table/v8/docs/api/core/column#getflatcolumns)
   * @link [Guide](https://tanstack.com/table/v8/docs/guide/column-defs)
   */
  getFlatColumns: () => Column<TData, TValue>[];
  /**
   * Returns an array of all leaf-node columns for this column. If a column has no children, it is considered the only leaf-node column.
   * @link [API Docs](https://tanstack.com/table/v8/docs/api/core/column#getleafcolumns)
   * @link [Guide](https://tanstack.com/table/v8/docs/guide/column-defs)
   */
  getLeafColumns: () => Column<TData, TValue>[];
  /**
   * The resolved unique identifier for the column resolved in this priority:
      - A manual `id` property from the column def
      - The accessor key from the column def
      - The header string from the column def
   * @link [API Docs](https://tanstack.com/table/v8/docs/api/core/column#id)
   * @link [Guide](https://tanstack.com/table/v8/docs/guide/column-defs)
   */
  id: string;
  /**
   * The parent column for this column. Will be undefined if this is a root column.
   * @link [API Docs](https://tanstack.com/table/v8/docs/api/core/column#parent)
   * @link [Guide](https://tanstack.com/table/v8/docs/guide/column-defs)
   */
  parent?: Column<TData, TValue>;
}

export class Column<TData extends RowData, TValue = unknown>
  extends Memo
  implements
    CoreColumn<TData, TValue>,
    VisibilityColumn,
    ColumnPinningColumn,
    FacetedColumn<TData>,
    ColumnFiltersColumn<TData>,
    GlobalFilterColumn,
    SortingColumn<TData>,
    GroupingColumn<TData>,
    ColumnSizingColumn,
    ColumnOrderColumn
{
  private table: Table<TData>;

  public id: string;
  public accessorFn?: AccessorFn<TData, TValue>;
  public parent?: Column<TData, TValue>;
  public depth: number;
  public columnDef: ColumnDef<TData, TValue>;
  public columns: Column<TData, TValue>[];

  constructor(params: {
    table: Table<TData>;
    id: string;
    accessorFn?: AccessorFn<TData, TValue>;
    parent?: Column<TData, any>;
    depth: number;
    columnDef: ColumnDef<TData, TValue>;
  }) {
    super();
    this.table = params.table;
    this.id = params.id;
    this.accessorFn = params.accessorFn;
    this.parent = params.parent;
    this.depth = params.depth;
    this.columnDef = params.columnDef;
    this.columns = [];
  }

  getFlatColumns(): Column<TData, TValue>[] {
    return this.memoize(
      'getFlatColumns',
      () => [true],
      (_: boolean) => [this, ...this.columns.flatMap((d) => d.getFlatColumns())],
      getMemoOptions(this.table.options, 'debugColumns', 'column.getFlatColumns'),
    );
  }

  getLeafColumns(): Column<TData, TValue>[] {
    return this.memoize(
      'getLeafColumns',
      () => [
        this.table._getOrderColumnsFn() as unknown as (columns: Column<TData, TValue>[]) => Column<TData, TValue>[],
      ],
      (orderColumns) => {
        if (this.columns?.length) {
          const leafColumns = this.columns.flatMap((column) => column.getLeafColumns());
          return orderColumns(leafColumns);
        }
        return [this];
      },
      getMemoOptions(this.table.options, 'debugColumns', 'column.getLeafColumns'),
    );
  }

  // ====== Column Visibility ======
  getCanHide(): boolean {
    return (this.columnDef.enableHiding ?? true) && (this.table.options.enableHiding ?? true);
  }
  getIsVisible(): boolean {
    const childColumns = this.columns;
    return (
      (childColumns.length
        ? childColumns.some((c) => c.getIsVisible())
        : this.table.getState().columnVisibility?.[this.id]) ?? true
    );
  }
  getToggleVisibilityHandler(): (event: unknown) => void {
    return (e: unknown) => {
      this.toggleVisibility?.(((e as MouseEvent).target as HTMLInputElement).checked);
    };
  }
  toggleVisibility(value?: boolean): void {
    if (this.getCanHide()) {
      this.table.setColumnVisibility((old) => ({
        ...old,
        [this.id]: value ?? !this.getIsVisible(),
      }));
    }
  }

  // ====== Column Pinning ======
  getCanPin(): boolean {
    const leafColumns = this.getLeafColumns();

    return leafColumns.some(
      (d) =>
        (d.columnDef.enablePinning ?? true) &&
        (this.table.options.enableColumnPinning ?? this.table.options.enablePinning ?? true),
    );
  }
  getIsPinned(): ColumnPinningPosition {
    const leafColumnIds = this.getLeafColumns().map((d) => d.id);

    const { left, right } = this.table.getState().columnPinning;

    const isLeft = leafColumnIds.some((d) => left?.includes(d));
    const isRight = leafColumnIds.some((d) => right?.includes(d));

    return isLeft ? 'left' : isRight ? 'right' : false;
  }
  getPinnedIndex(): number {
    const position = this.getIsPinned();

    return position ? (this.table.getState().columnPinning?.[position]?.indexOf(this.id) ?? -1) : 0;
  }
  pin(position: ColumnPinningPosition): void {
    const columnIds = this.getLeafColumns()
      .map((d) => d.id)
      .filter(Boolean) as string[];

    this.table.setColumnPinning((old) => {
      if (position === 'right') {
        return {
          left: (old?.left ?? []).filter((d) => !columnIds?.includes(d)),
          right: [...(old?.right ?? []).filter((d) => !columnIds?.includes(d)), ...columnIds],
        };
      }

      if (position === 'left') {
        return {
          left: [...(old?.left ?? []).filter((d) => !columnIds?.includes(d)), ...columnIds],
          right: (old?.right ?? []).filter((d) => !columnIds?.includes(d)),
        };
      }

      return {
        left: (old?.left ?? []).filter((d) => !columnIds?.includes(d)),
        right: (old?.right ?? []).filter((d) => !columnIds?.includes(d)),
      };
    });
  }

  // ====== Column Faceting ======
  getFacetedMinMaxValues(): undefined | [number, number] {
    const _getFacetedMinMaxValues = this.table.options.getFacetedMinMaxValues?.(this.table, this.id);

    if (!_getFacetedMinMaxValues) {
      return undefined;
    }

    return _getFacetedMinMaxValues();
  }
  getFacetedRowModel(): RowModel<TData> {
    const _getFacetedRowModel = this.table.options.getFacetedRowModel?.(this.table, this.id);

    if (!_getFacetedRowModel) {
      return this.table.getPreFilteredRowModel();
    }
    return _getFacetedRowModel();
  }
  getFacetedUniqueValues(): Map<any, number> {
    const _getFacetedUniqueValues = this.table.options.getFacetedUniqueValues?.(this.table, this.id);

    if (!_getFacetedUniqueValues) {
      return new Map();
    }

    return _getFacetedUniqueValues();
  }

  // ====== Column Filtering ======
  getAutoFilterFn(): FilterFn<TData> | undefined {
    const firstRow = this.table.getCoreRowModel().flatRows[0];

    const value = firstRow?.getValue(this.id);

    if (typeof value === 'string') {
      return filterFns.includesString;
    }

    if (typeof value === 'number') {
      return filterFns.inNumberRange;
    }

    if (typeof value === 'boolean') {
      return filterFns.equals;
    }

    if (value !== null && typeof value === 'object') {
      return filterFns.equals;
    }

    if (Array.isArray(value)) {
      return filterFns.arrIncludes;
    }

    return filterFns.weakEquals;
  }
  getCanFilter(): boolean {
    return (
      (this.columnDef.enableColumnFilter ?? true) &&
      (this.table.options.enableColumnFilters ?? true) &&
      (this.table.options.enableFilters ?? true) &&
      !!this.accessorFn
    );
  }
  getFilterFn(): FilterFn<TData> | undefined {
    return isFunction(this.columnDef.filterFn)
      ? this.columnDef.filterFn
      : this.columnDef.filterFn === 'auto'
        ? this.getAutoFilterFn()
        : (this.table.options.filterFns?.[this.columnDef.filterFn as string] ??
          filterFns[this.columnDef.filterFn as BuiltInFilterFn]);
  }
  getFilterIndex(): number {
    return this.table.getState().columnFilters?.findIndex((d) => d.id === this.id) ?? -1;
  }
  getFilterValue(): unknown {
    return this.table.getState().columnFilters?.find((d) => d.id === this.id)?.value;
  }
  getIsFiltered(): boolean {
    return this.getFilterIndex() > -1;
  }
  setFilterValue(value: Updater<any>): void {
    this.table.setColumnFilters((old) => {
      const filterFn = this.getFilterFn();
      const previousFilter = old?.find((d) => d.id === this.id);

      const newFilter = functionalUpdate(value, previousFilter ? previousFilter.value : undefined);

      //
      if (shouldAutoRemoveFilter(filterFn as FilterFn<TData>, newFilter, this)) {
        return old?.filter((d) => d.id !== this.id) ?? [];
      }

      const newFilterObj = { id: this.id, value: newFilter };

      if (previousFilter) {
        return (
          old?.map((d) => {
            if (d.id === this.id) {
              return newFilterObj;
            }
            return d;
          }) ?? []
        );
      }

      if (old?.length) {
        return [...old, newFilterObj];
      }

      return [newFilterObj];
    });
  }

  // ====== Global Filtering ======
  getCanGlobalFilter(): boolean {
    return (
      (this.columnDef.enableGlobalFilter ?? true) &&
      (this.table.options.enableFilters ?? true) &&
      (this.table.options.getColumnCanGlobalFilter?.(this) ?? true) &&
      !!this.accessorFn
    );
  }

  // ====== Row Sorting ======
  clearSorting(): void {
    //clear sorting for just 1 column
    this.table.setSorting((old) => (old?.length ? old.filter((d) => d.id !== this.id) : []));
  }
  getAutoSortDir(): SortDirection {
    const firstRow = this.table.getFilteredRowModel().flatRows[0];

    const value = firstRow?.getValue(this.id);

    if (typeof value === 'string') {
      return 'asc';
    }

    return 'desc';
  }
  getAutoSortingFn(): SortingFn<TData> {
    const firstRows = this.table.getFilteredRowModel().flatRows.slice(10);

    let isString = false;

    for (const row of firstRows) {
      const value = row?.getValue(this.id);

      if (Object.prototype.toString.call(value) === '[object Date]') {
        return sortingFns.datetime;
      }

      if (typeof value === 'string') {
        isString = true;

        if (value.split(reSplitAlphaNumeric).length > 1) {
          return sortingFns.alphanumeric;
        }
      }
    }

    if (isString) {
      return sortingFns.text;
    }

    return sortingFns.basic;
  }
  getCanMultiSort(): boolean {
    return this.columnDef.enableMultiSort ?? this.table.options.enableMultiSort ?? !!this.accessorFn;
  }
  getCanSort(): boolean {
    return (this.columnDef.enableSorting ?? true) && (this.table.options.enableSorting ?? true) && !!this.accessorFn;
  }
  getFirstSortDir(): SortDirection {
    const sortDescFirst =
      this.columnDef.sortDescFirst ?? this.table.options.sortDescFirst ?? this.getAutoSortDir() === 'desc';
    return sortDescFirst ? 'desc' : 'asc';
  }
  getIsSorted(): false | SortDirection {
    const columnSort = this.table.getState().sorting?.find((d) => d.id === this.id);

    return !columnSort ? false : columnSort.desc ? 'desc' : 'asc';
  }
  getNextSortingOrder(multi?: boolean): SortDirection | false {
    const firstSortDirection = this.getFirstSortDir();
    const isSorted = this.getIsSorted();

    if (!isSorted) {
      return firstSortDirection;
    }

    if (
      isSorted !== firstSortDirection &&
      (this.table.options.enableSortingRemoval ?? true) && // If enableSortRemove, enable in general
      (multi ? (this.table.options.enableMultiRemove ?? true) : true) // If multi, don't allow if enableMultiRemove))
    ) {
      return false;
    }
    return isSorted === 'desc' ? 'asc' : 'desc';
  }
  getSortIndex(): number {
    return this.table.getState().sorting?.findIndex((d) => d.id === this.id) ?? -1;
  }
  getSortingFn(): SortingFn<TData> {
    if (!this) {
      throw new Error();
    }

    return isFunction(this.columnDef.sortingFn)
      ? this.columnDef.sortingFn
      : this.columnDef.sortingFn === 'auto'
        ? this.getAutoSortingFn()
        : (this.table.options.sortingFns?.[this.columnDef.sortingFn as string] ??
          sortingFns[this.columnDef.sortingFn as BuiltInSortingFn]);
  }
  getToggleSortingHandler(): undefined | ((event: unknown) => void) {
    const canSort = this.getCanSort();

    return (e: unknown) => {
      if (!canSort) return;
      (e as any).persist?.();
      this.toggleSorting?.(undefined, this.getCanMultiSort() ? this.table.options.isMultiSortEvent?.(e) : false);
    };
  }
  toggleSorting(desc?: boolean, multi?: boolean): void {
    // if (column.columns.length) {
    //   column.columns.forEach((c, i) => {
    //     if (c.id) {
    //       table.toggleColumnSorting(c.id, undefined, multi || !!i)
    //     }
    //   })
    //   return
    // }

    // this needs to be outside of table.setSorting to be in sync with rerender
    const nextSortingOrder = this.getNextSortingOrder();
    const hasManualValue = typeof desc !== 'undefined' && desc !== null;

    this.table.setSorting((old) => {
      // Find any existing sorting for this column
      const existingSorting = old?.find((d) => d.id === this.id);
      const existingIndex = old?.findIndex((d) => d.id === this.id);

      let newSorting: SortingState = [];

      // What should we do with this sort action?
      let sortAction: 'add' | 'remove' | 'toggle' | 'replace';
      const nextDesc = hasManualValue ? desc : nextSortingOrder === 'desc';

      // Multi-mode
      if (old?.length && this.getCanMultiSort() && multi) {
        if (existingSorting) {
          sortAction = 'toggle';
        } else {
          sortAction = 'add';
        }
      } else {
        // Normal mode
        if (old?.length && existingIndex !== old.length - 1) {
          sortAction = 'replace';
        } else if (existingSorting) {
          sortAction = 'toggle';
        } else {
          sortAction = 'replace';
        }
      }

      // Handle toggle states that will remove the sorting
      if (sortAction === 'toggle') {
        // If we are "actually" toggling (not a manual set value), should we remove the sorting?
        if (!hasManualValue) {
          // Is our intention to remove?
          if (!nextSortingOrder) {
            sortAction = 'remove';
          }
        }
      }

      if (sortAction === 'add') {
        newSorting = [
          ...old,
          {
            id: this.id,
            desc: nextDesc,
          },
        ];
        // Take latest n columns
        newSorting.splice(0, newSorting.length - (this.table.options.maxMultiSortColCount ?? Number.MAX_SAFE_INTEGER));
      } else if (sortAction === 'toggle') {
        // This flips (or sets) the
        newSorting = old.map((d) => {
          if (d.id === this.id) {
            return {
              ...d,
              desc: nextDesc,
            };
          }
          return d;
        });
      } else if (sortAction === 'remove') {
        newSorting = old.filter((d) => d.id !== this.id);
      } else {
        newSorting = [
          {
            id: this.id,
            desc: nextDesc,
          },
        ];
      }

      return newSorting;
    });
  }

  // ====== Column Grouping ======
  getAggregationFn(): AggregationFn<TData> | undefined {
    if (!this) {
      throw new Error();
    }

    return isFunction(this.columnDef.aggregationFn)
      ? this.columnDef.aggregationFn
      : this.columnDef.aggregationFn === 'auto'
        ? this.getAutoAggregationFn()
        : (this.table.options.aggregationFns?.[this.columnDef.aggregationFn as string] ??
          aggregationFns[this.columnDef.aggregationFn as BuiltInAggregationFn]);
  }
  getAutoAggregationFn(): AggregationFn<TData> | undefined {
    const firstRow = this.table.getCoreRowModel().flatRows[0];

    const value = firstRow?.getValue(this.id);

    if (typeof value === 'number') {
      return aggregationFns.sum;
    }

    if (Object.prototype.toString.call(value) === '[object Date]') {
      return aggregationFns.extent;
    }
  }
  getCanGroup(): boolean {
    return (
      (this.columnDef.enableGrouping ?? true) &&
      (this.table.options.enableGrouping ?? true) &&
      (!!this.accessorFn || !!this.columnDef.getGroupingValue)
    );
  }
  getGroupedIndex(): number {
    return this.table.getState().grouping?.indexOf(this.id);
  }
  getIsGrouped(): boolean {
    return this.table.getState().grouping?.includes(this.id);
  }
  getToggleGroupingHandler(): () => void {
    const canGroup = this.getCanGroup();

    return () => {
      if (!canGroup) return;
      this.toggleGrouping();
    };
  }
  toggleGrouping(): void {
    this.table.setGrouping((old) => {
      // Find any existing grouping for this column
      if (old?.includes(this.id)) {
        return old.filter((d) => d !== this.id);
      }

      return [...(old ?? []), this.id];
    });
  }

  // ====== Column Sizing ======
  getCanResize(): boolean {
    return (this.columnDef.enableResizing ?? true) && (this.table.options.enableColumnResizing ?? true);
  }
  getIsResizing(): boolean {
    return this.table.getState().columnSizingInfo.isResizingColumn === this.id;
  }
  getSize(): number {
    const columnSize = this.table.getState().columnSizing[this.id];

    return Math.min(
      Math.max(
        this.columnDef.minSize ?? defaultColumnSizing.minSize,
        columnSize ?? this.columnDef.size ?? defaultColumnSizing.size,
      ),
      this.columnDef.maxSize ?? defaultColumnSizing.maxSize,
    );
  }
  getStart(position?: ColumnPinningPosition | 'center'): number {
    return this.memoize(
      'getStart',
      () => [position, _getVisibleLeafColumns(this.table, position), this.table.getState().columnSizing],
      (position, columns, _) =>
        columns.slice(0, this.getIndex(position)).reduce((sum, column) => sum + column.getSize(), 0),
      getMemoOptions(this.table.options, 'debugColumns', 'getStart'),
    );
  }
  getAfter(position?: ColumnPinningPosition | 'center'): number {
    return this.memoize(
      'getAfter',
      () => [position, _getVisibleLeafColumns(this.table, position), this.table.getState().columnSizing],
      (position, columns, _) =>
        columns.slice(this.getIndex(position) + 1).reduce((sum, column) => sum + column.getSize(), 0),
      getMemoOptions(this.table.options, 'debugColumns', 'getAfter'),
    );
  }
  resetSize(): void {
    this.table.setColumnSizing(({ [this.id]: _, ...rest }) => rest);
  }

  // ====== Column Ordering ======
  getIndex(position?: ColumnPinningPosition | 'center'): number {
    return this.memoize(
      'getIndex',
      () => [position, _getVisibleLeafColumns(this.table, position)],
      (_position, columns) => columns.findIndex((d) => d.id === this.id),
      getMemoOptions(this.table.options, 'debugColumns', 'getIndex'),
    );
  }
  getIsFirstColumn(position?: ColumnPinningPosition | 'center'): boolean {
    const columns = _getVisibleLeafColumns(this.table, position);
    return columns[0]?.id === this.id;
  }
  getIsLastColumn(position?: ColumnPinningPosition | 'center'): boolean {
    const columns = _getVisibleLeafColumns(this.table, position);
    return columns[columns.length - 1]?.id === this.id;
  }
}

export function createColumn<TData extends RowData, TValue>(
  table: Table<TData>,
  columnDef: ColumnDef<TData, TValue>,
  depth: number,
  parent?: Column<TData, TValue>,
): Column<TData, TValue> {
  const defaultColumn = table._getDefaultColumnDef();

  const resolvedColumnDef = {
    ...defaultColumn,
    ...columnDef,
  } as ColumnDefResolved<TData, TValue>;

  const accessorKey = resolvedColumnDef.accessorKey;

  const id =
    resolvedColumnDef.id ??
    (accessorKey
      ? typeof String.prototype.replaceAll === 'function'
        ? accessorKey.replaceAll('.', '_')
        : accessorKey.replace(/\./g, '_')
      : undefined) ??
    (typeof resolvedColumnDef.header === 'string' ? resolvedColumnDef.header : undefined);

  let accessorFn: AccessorFn<TData, TValue> | undefined;

  if (resolvedColumnDef.accessorFn) {
    accessorFn = resolvedColumnDef.accessorFn as AccessorFn<TData, TValue>;
  } else if (accessorKey) {
    // Support deep accessor keys
    if (accessorKey.includes('.')) {
      accessorFn = (originalRow: TData) => {
        let result = originalRow as any;

        for (const key of accessorKey.split('.')) {
          result = result?.[key];
          if (process.env.NODE_ENV !== 'production' && result === undefined) {
            console.warn(`"${key}" in deeply nested key "${accessorKey}" returned undefined.`);
          }
        }

        return result;
      };
    } else {
      accessorFn = (originalRow: TData) => (originalRow as any)[resolvedColumnDef.accessorKey];
    }
  }

  if (!id) {
    if (process.env.NODE_ENV !== 'production') {
      throw new Error(
        resolvedColumnDef.accessorFn
          ? `Columns require an id when using an accessorFn`
          : `Columns require an id when using a non-string header`,
      );
    }
    throw new Error();
  }

  const column = new Column<TData, TValue>({
    table,
    id,
    accessorFn,
    parent,
    depth,
    columnDef: resolvedColumnDef as ColumnDef<TData, TValue>,
  });

  for (const feature of table._features) {
    feature.createColumn?.(column, table);
  }

  // Yes, we have to convert table to unknown, because we know more than the compiler here.
  return column as Column<TData, TValue>;
}
