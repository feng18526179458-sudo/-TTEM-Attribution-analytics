/* eslint-disable max-lines */
import { GroupingRow } from '../features/ColumnGrouping';
import { ColumnFiltersRow } from '../features/ColumnFiltering';
import { ColumnPinningRow } from '../features/ColumnPinning';
import { VisibilityRow } from '../features/ColumnVisibility';
import { RowPinningPosition, RowPinningRow } from '../features/RowPinning';
import { isRowSelected, isSubRowSelected, mutateRowIsSelected, RowSelectionRow } from '../features/RowSelection';
import { RowData, Cell, Table, FilterMeta, Column } from '../types';
import { flattenBy, getMemoOptions } from '../utils';
import { createCell } from './cell';
import { ExpandedRow, ExpandedStateList } from '../features/RowExpanding';
import { Memo } from './memo';

export interface CoreRow<TData extends RowData> {
  _getAllCellsByColumnId: () => Record<string, Cell<TData, unknown>>;
  _uniqueValuesCache: Record<string, unknown>;
  _valuesCache: Record<string, unknown>;
  /**
   * The depth of the row (if nested or grouped) relative to the root row array.
   * @link [API Docs](https://tanstack.com/table/v8/docs/api/core/row#depth)
   * @link [Guide](https://tanstack.com/table/v8/docs/guide/rows)
   */
  depth: number;
  /**
   * Returns all of the cells for the row.
   * @link [API Docs](https://tanstack.com/table/v8/docs/api/core/row#getallcells)
   * @link [Guide](https://tanstack.com/table/v8/docs/guide/rows)
   */
  getAllCells: () => Cell<TData, unknown>[];
  /**
   * Returns the leaf rows for the row, not including any parent rows.
   * @link [API Docs](https://tanstack.com/table/v8/docs/api/core/row#getleafrows)
   * @link [Guide](https://tanstack.com/table/v8/docs/guide/rows)
   */
  getLeafRows: () => Row<TData>[];
  /**
   * Returns the parent row for the row, if it exists.
   * @link [API Docs](https://tanstack.com/table/v8/docs/api/core/row#getparentrow)
   * @link [Guide](https://tanstack.com/table/v8/docs/guide/rows)
   */
  getParentRow: () => Row<TData> | undefined;
  /**
   * Returns the parent rows for the row, all the way up to a root row.
   * @link [API Docs](https://tanstack.com/table/v8/docs/api/core/row#getparentrows)
   * @link [Guide](https://tanstack.com/table/v8/docs/guide/rows)
   */
  getParentRows: () => Row<TData>[];
  /**
   * Returns a unique array of values from the row for a given columnId.
   * @link [API Docs](https://tanstack.com/table/v8/docs/api/core/row#getuniquevalues)
   * @link [Guide](https://tanstack.com/table/v8/docs/guide/rows)
   */
  getUniqueValues: <TValue>(columnId: string) => TValue[];
  /**
   * Returns the value from the row for a given columnId.
   * @link [API Docs](https://tanstack.com/table/v8/docs/api/core/row#getvalue)
   * @link [Guide](https://tanstack.com/table/v8/docs/guide/rows)
   */
  getValue: <TValue>(columnId: string) => TValue;
  /**
   * The resolved unique identifier for the row resolved via the `options.getRowId` option. Defaults to the row's index (or relative index if it is a subRow).
   * @link [API Docs](https://tanstack.com/table/v8/docs/api/core/row#id)
   * @link [Guide](https://tanstack.com/table/v8/docs/guide/rows)
   */
  id: string;
  /**
   * The index of the row within its parent array (or the root data array).
   * @link [API Docs](https://tanstack.com/table/v8/docs/api/core/row#index)
   * @link [Guide](https://tanstack.com/table/v8/docs/guide/rows)
   */
  index: number;
  /**
   * The original row object provided to the table. If the row is a grouped row, the original row object will be the first original in the group.
   * @link [API Docs](https://tanstack.com/table/v8/docs/api/core/row#original)
   * @link [Guide](https://tanstack.com/table/v8/docs/guide/rows)
   */
  original: TData;
  /**
   * An array of the original subRows as returned by the `options.getSubRows` option.
   * @link [API Docs](https://tanstack.com/table/v8/docs/api/core/row#originalsubrows)
   * @link [Guide](https://tanstack.com/table/v8/docs/guide/rows)
   */
  originalSubRows?: TData[];
  /**
   * If nested, this row's parent row id.
   * @link [API Docs](https://tanstack.com/table/v8/docs/api/core/row#parentid)
   * @link [Guide](https://tanstack.com/table/v8/docs/guide/rows)
   */
  parentId?: string;
  /**
   * Renders the value for the row in a given columnId the same as `getValue`, but will return the `renderFallbackValue` if no value is found.
   * @link [API Docs](https://tanstack.com/table/v8/docs/api/core/row#rendervalue)
   * @link [Guide](https://tanstack.com/table/v8/docs/guide/rows)
   */
  renderValue: <TValue>(columnId: string) => TValue;
  /**
   * An array of subRows for the row as returned and created by the `options.getSubRows` option.
   * @link [API Docs](https://tanstack.com/table/v8/docs/api/core/row#subrows)
   * @link [Guide](https://tanstack.com/table/v8/docs/guide/rows)
   */
  subRows: Row<TData>[];
}

export class Row<TData extends RowData>
  extends Memo
  implements
    CoreRow<TData>,
    VisibilityRow<TData>,
    ColumnPinningRow<TData>,
    RowPinningRow,
    ColumnFiltersRow<TData>,
    GroupingRow,
    RowSelectionRow,
    ExpandedRow
{
  static VALUE_CACHE = false;
  static CELL_CACHE = true;
  static cache({ value = false, cell = true }) {
    Row.VALUE_CACHE = value;
    Row.CELL_CACHE = cell;
  }

  private table: Table<TData>;
  _uniqueValuesCache: Record<string, unknown>;
  _valuesCache: Record<string, unknown>;
  depth: number;
  public id: string;
  public index: number;
  public original: TData;
  originalSubRows?: TData[] | undefined;
  parentId?: string | undefined;
  subRows: Row<TData>[];
  constructor(
    table: Table<TData>,
    id: string,
    original: TData,
    rowIndex: number,
    depth: number,
    subRows?: Row<TData>[],
    parentId?: string,
  ) {
    super();
    this.table = table;
    this.id = id;
    this.original = original;
    this.index = rowIndex;
    this.depth = depth;
    this.subRows = subRows ?? [];
    this.parentId = parentId;

    this._valuesCache = {};
    this._uniqueValuesCache = {};

    this.columnFilters = {};
    this.columnFiltersMeta = {};

    this._groupingValuesCache = {};
  }

  clone(): Row<TData> {
    const next = new Row(this.table, this.id, this.original, this.index, this.depth, this.subRows, this.parentId);
    next.originalSubRows = this.originalSubRows;
    next.columnFilters = this.columnFilters;
    next.columnFiltersMeta = this.columnFiltersMeta;
    return next;
  }

  getValue<TValue>(columnId: string): TValue {
    if (Row.VALUE_CACHE) {
      if (Object.prototype.hasOwnProperty.call(this._valuesCache, columnId)) {
        return this._valuesCache[columnId] as TValue;
      }
    }

    const column = this.table.getColumn(columnId);
    if (!column?.accessorFn) {
      return undefined as TValue;
    }

    const value = column.accessorFn(this.original as TData, this.index) as TValue;

    if (Row.VALUE_CACHE) {
      this._valuesCache[columnId] = value;
    }
    return value;
  }

  getUniqueValues<TValue>(columnId: string): TValue[] {
    if (Object.prototype.hasOwnProperty.call(this._uniqueValuesCache, columnId)) {
      return this._uniqueValuesCache[columnId] as TValue[];
    }

    const column = this.table.getColumn(columnId);

    if (!column?.accessorFn) {
      return undefined as unknown as TValue[];
    }

    if (!column.columnDef.getUniqueValues) {
      this._uniqueValuesCache[columnId] = [this.getValue(columnId)];
      return this._uniqueValuesCache[columnId] as TValue[];
    }

    this._uniqueValuesCache[columnId] = column.columnDef.getUniqueValues(this.original as TData, this.index);

    return this._uniqueValuesCache[columnId] as TValue[];
  }

  renderValue<TValue>(columnId: string): TValue {
    return this.getValue(columnId) ?? this.table.options.renderFallbackValue;
  }

  getLeafRows(): Row<TData>[] {
    return flattenBy(this.subRows, (d) => d.subRows);
  }

  getParentRow(): Row<TData> | undefined {
    return this.parentId ? this.table.getRow(this.parentId, true) : undefined;
  }

  getParentRows(): Row<TData>[] {
    const parentRows: Row<TData>[] = [];
    // eslint-disable-next-line @typescript-eslint/no-this-alias
    let currentRow: Row<TData> = this;
    while (true) {
      const parentRow = currentRow.getParentRow();
      if (!parentRow) break;
      parentRows.push(parentRow);
      currentRow = parentRow;
    }
    return parentRows.reverse();
  }

  getAllCells(): Cell<TData, unknown>[] {
    if (Row.CELL_CACHE) {
      return this.memoize(
        'getAllCells',
        () => [this.table.getAllLeafColumns()],
        (leafColumns) => leafColumns.map((column) => createCell(this.table, this, column)),
        getMemoOptions(this.table.options, 'debugRows', 'getAllCells'),
      );
    } else {
      return this.table.getAllLeafColumns().map((column) => createCell(this.table, this, column));
    }
  }

  _getAllCellsByColumnId(): Record<string, Cell<TData, unknown>> {
    const allCells = this.getAllCells();
    return allCells.reduce(
      (acc, cell) => {
        acc[cell.column.id] = cell;
        return acc;
      },
      {} as Record<string, Cell<TData, unknown>>,
    );
  }

  // ====== Column Visibility ======
  _getAllVisibleCells(): Cell<TData, unknown>[] {
    if (Row.CELL_CACHE) {
      return this.memoize(
        'getAllVisibleCells',
        () => [this.getAllCells(), this.table.getState().columnVisibility],
        (cells, _) => cells.filter((cell) => cell.column.getIsVisible()),
        getMemoOptions(this.table.options, 'debugRows', '_getAllVisibleCells'),
      );
    } else {
      return this.getAllCells().filter((cell) => cell.column.getIsVisible());
    }
  }
  getVisibleCells(columnIndexes?: number[]): Cell<TData, unknown>[] {
    if (Row.CELL_CACHE) {
      if (!columnIndexes) {
        return this.memoize(
          'getVisibleCells',
          () => [this.getLeftVisibleCells(), this.getCenterVisibleCells(), this.getRightVisibleCells()],
          (left, center, right) => [...left, ...center, ...right],
          getMemoOptions(this.table.options, 'debugRows', 'getVisibleCells'),
        );
      } else {
        const centerVisibleCells = this.getCenterVisibleCells();
        const centerCells = columnIndexes.map((idx) => centerVisibleCells[idx]).filter(Boolean) as Cell<
          TData,
          unknown
        >[];
        return [...this.getLeftVisibleCells(), ...centerCells, ...this.getRightVisibleCells()];
      }
    } else {
      if (!columnIndexes) {
        return [...this.getLeftVisibleCells(), ...this.getCenterVisibleCells(), ...this.getRightVisibleCells()];
      } else {
        const { left = [], right = [] } = this.table.getState().columnPinning;
        const leftAndRight: string[] = [...left, ...right];
        const visibleColumns = this.table
          .getAllLeafColumns()
          // Filter visible columns
          .filter((column) => column.getIsVisible());

        const visibleCenterColumns = visibleColumns.filter((column) => !leftAndRight.includes(column.id));

        const visibleCenterCells = columnIndexes
          ? columnIndexes
              .map((idx) => visibleCenterColumns[idx])
              // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
              .filter(Boolean)
              .map((column) => createCell(this.table, this, column!))
          : visibleCenterColumns.map((column) => createCell(this.table, this, column));

        return [...this.getLeftVisibleCells(), ...visibleCenterCells, ...this.getRightVisibleCells()];
      }
    }
  }

  getCenterVisibleCells(): Cell<TData, unknown>[] {
    if (Row.CELL_CACHE) {
      return this.memoize(
        'getCenterVisibleCells',
        () => [
          this._getAllVisibleCells(),
          this.table.getState().columnPinning.left,
          this.table.getState().columnPinning.right,
        ],
        (allCells, left, right) => {
          const leftAndRight: string[] = [...(left ?? []), ...(right ?? [])];

          return allCells.filter((d) => !leftAndRight.includes(d.column.id));
        },
        getMemoOptions(this.table.options, 'debugRows', 'getCenterVisibleCells'),
      );
    } else {
      const allCells = this._getAllVisibleCells();
      const { left, right } = this.table.getState().columnPinning;
      const leftAndRight: string[] = [...(left ?? []), ...(right ?? [])];

      return allCells.filter((d) => !leftAndRight.includes(d.column.id));
    }
  }
  getLeftVisibleCells(): Cell<TData, unknown>[] {
    if (Row.CELL_CACHE) {
      return this.memoize(
        'getLeftVisibleCells',
        () => [this._getAllVisibleCells(), this.table.getState().columnPinning.left],
        (allCells, left) => {
          const cells = (left ?? [])
            // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
            .map((columnId) => allCells.find((cell) => cell.column.id === columnId)!)
            .filter(Boolean)
            .map((d) => {
              d.position = 'left';
              return d;
            });

          return cells;
        },
        getMemoOptions(this.table.options, 'debugRows', 'getLeftVisibleCells'),
      );
    } else {
      // const allCells = this._getAllVisibleCells();
      // const { left } = this.table.getState().columnPinning;
      // const cells = (left ?? [])
      //   .map((columnId) => allCells.find((cell) => cell.column.id === columnId)!)
      //   .filter(Boolean)
      //   .map((d) => {
      //     d.position = 'left';
      //     return d;
      //   });

      // return cells;

      // only create left cells
      const { left = [] } = this.table.getState().columnPinning;
      const leftVisibleCells = left
        .map((columnId) => this.table.getColumn(columnId))
        // filter left
        .filter((column): column is Column<TData, unknown> => Boolean(column))
        // filter visible
        .filter((column) => column.getIsVisible())
        // create cell
        .map((column) => {
          const cell = createCell(this.table, this, column);
          cell.position = 'left';
          return cell;
        });
      return leftVisibleCells;
    }
  }
  getRightVisibleCells(): Cell<TData, unknown>[] {
    if (Row.CELL_CACHE) {
      return this.memoize(
        'getRightVisibleCells',
        () => [this._getAllVisibleCells(), this.table.getState().columnPinning.right],
        (allCells, right) => {
          const cells = (right ?? [])
            .map((columnId) => allCells.find((cell) => cell.column.id === columnId)!)
            .filter(Boolean)
            .map((d) => {
              d.position = 'right';
              return d;
            });

          return cells;
        },
        getMemoOptions(this.table.options, 'debugRows', 'getRightVisibleCells'),
      );
    } else {
      // const allCells = this._getAllVisibleCells();
      // const { right } = this.table.getState().columnPinning;
      // const cells = (right ?? [])
      //   .map((columnId) => allCells.find((cell) => cell.column.id === columnId)!)
      //   .filter(Boolean)
      //   .map((d) => {
      //     d.position = 'right';
      //     return d;
      //   });

      // return cells;
      const { right = [] } = this.table.getState().columnPinning;
      const rightVisibleCells = right
        .map((columnId) => this.table.getColumn(columnId))
        // filter right
        .filter((column): column is Column<TData, unknown> => Boolean(column))
        // filter visible
        .filter((column) => column.getIsVisible())
        // create cell
        .map((column) => {
          const cell = createCell(this.table, this, column);
          cell.position = 'right';
          return cell;
        });
      return rightVisibleCells;
    }
  }

  // ====== Row Pinning ======
  position?: RowPinningPosition;
  pin(position: RowPinningPosition, includeLeafRows?: boolean, includeParentRows?: boolean): void {
    const leafRowIds = includeLeafRows ? this.getLeafRows().map(({ id }) => id) : [];
    const parentRowIds = includeParentRows ? this.getParentRows().map(({ id }) => id) : [];
    const rowIds = new Set([...parentRowIds, this.id, ...leafRowIds]);

    this.table.setRowPinning((old) => {
      if (position === 'bottom') {
        return {
          top: (old?.top ?? []).filter((d) => !rowIds?.has(d)),
          bottom: [...(old?.bottom ?? []).filter((d) => !rowIds?.has(d)), ...Array.from(rowIds)],
        };
      }

      if (position === 'top') {
        return {
          top: [...(old?.top ?? []).filter((d) => !rowIds?.has(d)), ...Array.from(rowIds)],
          bottom: (old?.bottom ?? []).filter((d) => !rowIds?.has(d)),
        };
      }

      return {
        top: (old?.top ?? []).filter((d) => !rowIds?.has(d)),
        bottom: (old?.bottom ?? []).filter((d) => !rowIds?.has(d)),
      };
    });
  }
  getCanPin(): boolean {
    const { enableRowPinning, enablePinning } = this.table.options;
    if (typeof enableRowPinning === 'function') {
      return enableRowPinning(this);
    }
    return enableRowPinning ?? enablePinning ?? true;
  }
  getIsPinned(): RowPinningPosition {
    const rowIds = [this.id];

    const { top, bottom } = this.table.getState().rowPinning;

    const isTop = rowIds.some((d) => top?.includes(d));
    const isBottom = rowIds.some((d) => bottom?.includes(d));

    return isTop ? 'top' : isBottom ? 'bottom' : false;
  }
  getPinnedIndex(): number {
    const position = this.getIsPinned();
    if (!position) return -1;

    const visiblePinnedRowIds = (position === 'top' ? this.table.getTopRows() : this.table.getBottomRows())?.map(
      ({ id }) => id,
    );

    return visiblePinnedRowIds?.indexOf(this.id) ?? -1;
  }

  // ====== Column Filtering ======
  columnFilters: Record<string, boolean>;
  columnFiltersMeta: Record<string, FilterMeta>;

  // ====== Column Grouping ======
  _groupingValuesCache: Record<string, any>;
  groupingColumnId?: string;
  groupingValue?: unknown;
  getGroupingValue(columnId: string): unknown {
    if (Object.prototype.hasOwnProperty.call(this._groupingValuesCache, columnId)) {
      return this._groupingValuesCache[columnId];
    }

    const column = this.table.getColumn(columnId);

    if (!column?.columnDef.getGroupingValue) {
      return this.getValue(columnId);
    }

    this._groupingValuesCache[columnId] = column.columnDef.getGroupingValue(this.original);

    return this._groupingValuesCache[columnId];
  }
  getIsGrouped(): boolean {
    return !!this.groupingColumnId;
  }

  // ====== Row Selection ======
  getCanMultiSelect(): boolean {
    if (typeof this.table.options.enableMultiRowSelection === 'function') {
      return this.table.options.enableMultiRowSelection(this);
    }

    return this.table.options.enableMultiRowSelection ?? true;
  }
  getCanSelect(): boolean {
    if (typeof this.table.options.enableRowSelection === 'function') {
      return this.table.options.enableRowSelection(this);
    }

    return this.table.options.enableRowSelection ?? true;
  }
  getCanSelectSubRows(): boolean {
    if (typeof this.table.options.enableSubRowSelection === 'function') {
      return this.table.options.enableSubRowSelection(this);
    }

    return this.table.options.enableSubRowSelection ?? true;
  }
  getIsAllSubRowsSelected(): boolean {
    const { rowSelection } = this.table.getState();
    return isSubRowSelected(this, rowSelection, this.table) === 'all';
  }
  getIsSelected(): boolean {
    const { rowSelection } = this.table.getState();
    return isRowSelected(this, rowSelection);
  }
  getIsSomeSelected(): boolean {
    const { rowSelection } = this.table.getState();
    return isSubRowSelected(this, rowSelection, this.table) === 'some';
  }
  getToggleSelectedHandler(): (event: unknown) => void {
    const canSelect = this.getCanSelect();

    return (e: unknown) => {
      if (!canSelect) return;
      this.toggleSelected(((e as MouseEvent).target as HTMLInputElement)?.checked);
    };
  }
  toggleSelected(value?: boolean, opts?: { selectChildren?: boolean }): void {
    const isSelected = this.getIsSelected();

    this.table.setRowSelection((old) => {
      value = typeof value !== 'undefined' ? value : !isSelected;

      if (this.getCanSelect() && isSelected === value) {
        return old;
      }

      const selectedRowIds = { ...old };

      mutateRowIsSelected(selectedRowIds, this.id, value, opts?.selectChildren ?? true, this.table);

      return selectedRowIds;
    });
  }

  // ====== Row Expanding ======
  getCanExpand(): boolean {
    return (
      this.table.options.getRowCanExpand?.(this) ??
      ((this.table.options.enableExpanding ?? true) && !!this.subRows?.length)
    );
  }
  getIsAllParentsExpanded(): boolean {
    let isFullyExpanded = true;
    // eslint-disable-next-line @typescript-eslint/no-this-alias
    let currentRow = this as Row<TData>;

    while (isFullyExpanded && currentRow.parentId) {
      currentRow = this.table.getRow(currentRow.parentId, true);
      isFullyExpanded = currentRow.getIsExpanded();
    }

    return isFullyExpanded;
  }
  getIsExpanded(): boolean {
    const { expanded } = this.table.getState();
    return !!(this.table.options.getIsRowExpanded?.(this) ?? (expanded === true || expanded?.[this.id]));
  }
  getToggleExpandedHandler(): () => void {
    const canExpand = this.getCanExpand();

    return () => {
      if (!canExpand) return;
      this.toggleExpanded();
    };
  }
  toggleExpanded(expanded?: boolean): void {
    this.table.setExpanded((old) => {
      const exists = old === true ? true : !!old?.[this.id];

      let oldExpanded: ExpandedStateList = {};

      if (old === true) {
        Object.keys(this.table.getRowModel().rowsById).forEach((rowId) => {
          oldExpanded[rowId] = true;
        });
      } else {
        oldExpanded = old;
      }

      expanded = expanded ?? !exists;

      if (!exists && expanded) {
        return {
          ...oldExpanded,
          [this.id]: true,
        };
      }

      if (exists && !expanded) {
        const { [this.id]: _, ...rest } = oldExpanded;
        return rest;
      }

      return old;
    });
  }
}

export const createRow = <TData extends RowData>(
  table: Table<TData>,
  id: string,
  original: TData,
  rowIndex: number,
  depth: number,
  subRows?: Row<TData>[],
  parentId?: string,
): Row<TData> => {
  const row = new Row(table, id, original, rowIndex, depth, subRows, parentId);

  for (let i = 0; i < table._features.length; i++) {
    const feature = table._features[i];
    feature?.createRow?.(row as Row<TData>, table);
  }

  return row as Row<TData>;
};
