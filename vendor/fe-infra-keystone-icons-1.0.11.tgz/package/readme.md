# @fe-infra/keystone-icons

`@fe-infra/keystone-icons` provides Keystone icons as custom elements with runtime auto-registration. Importing the package registers all icon tags and keeps attribute-based usage stable across direct consumers and generated React/Vue wrappers.

## Installation

```bash
npm install @fe-infra/keystone-icons
```

## Usage

Import the package once before rendering icon tags:

```ts
import '@fe-infra/keystone-icons';
```

Then use icons directly in markup:

```html
<ks-icon-home size="24" color="#007bff"></ks-icon-home> <ks-icon-filled-help inner-color="#000"></ks-icon-filled-help>
```

## Available Attributes

- `size`: sets the rendered width and height
- `color`: sets the primary icon color
- `inner-color`: sets the inner fill color for icons that support it
- `ks-v`: selects a legacy render version when needed

## Framework Wrappers

For React and Vue applications, prefer the companion packages:

- `@fe-infra/keystone-icons-react`
- `@fe-infra/keystone-icons-vue`

## License

`@fe-infra/keystone-icons` is released under the MIT License. See the [LICENSE](./LICENSE) file for details.
