# @fe-infra/tailwindcss-keystone-preset

## [2.0.22] - 2026-03-16

### Changed

- Updated dependencies - ([87afc9197](https://code.byted.org/ad/byted-web-components/commit/87afc9197)).
  - @fe-infra/keystone-design-tokens@2.0.21

## [2.0.21] - 2026-01-13

### Changed

- (KsButtonGroupItem) Updated background color to use `--ks-color-neutral-surface`, hover text color to `--ks-color-neutral-highOnSurfaceHover`, and disabled state background color to `--ks-color-neutral-surface` - ([fb01aa2c5](https://code.byted.org/ad/byted-web-components/commit/fb01aa2c5)).
- (KsButtonGroup) Updated background color to use `--ks-color-neutral-surface` - ([fb01aa2c5](https://code.byted.org/ad/byted-web-components/commit/fb01aa2c5)).
- (KsButton) Added missing color token suffixes (`highOnSurfaceHover`, `highOnSurfaceActive`) to generated color styles, updated hover text color to `--ks-color-neutral-highOnSurfaceHover`, and active state text color to `--ks-color-neutral-highOnSurfaceActive` - ([fb01aa2c5](https://code.byted.org/ad/byted-web-components/commit/fb01aa2c5)).
- (KsValueField) Added `--ks-color-neutral-highOnSurface` color to input and label elements in the texted variant - ([fb01aa2c5](https://code.byted.org/ad/byted-web-components/commit/fb01aa2c5)).
- Updated dependencies - ([fb01aa2c5](https://code.byted.org/ad/byted-web-components/commit/fb01aa2c5)).
  - @fe-infra/keystone-design-tokens@2.0.20

## [2.0.20] - 2025-11-19

### Changed

- Updated dependencies - ([4183deb0a](https://code.byted.org/ad/byted-web-components/commit/4183deb0a)).
  - @fe-infra/keystone-design-tokens@2.0.19

## 2.0.17

### Major Changes

- 3a985030e: Updated spacing utilities to align with Tailwind CSS default theme.

### Patch Changes

- Updated dependencies [10daf7645]
  - @fe-infra/keystone-design-tokens@2.0.16

## 2.0.16

- Updated dependencies [ba01463fd]
  - @fe-infra/keystone-design-tokens@2.0.15

## 2.0.15

- Updated dependencies [22f210257]
  - @fe-infra/keystone-design-tokens@2.0.14

## 2.0.14

- Updated dependencies [51e02a607]
  - @fe-infra/keystone-design-tokens@2.0.13

## 2.0.13

- Updated dependencies [7ffb6daea]
  - @fe-infra/keystone-design-tokens@2.0.12

## 2.0.12

- Updated dependencies [258434cb2]
  - @fe-infra/keystone-design-tokens@2.0.11

## 2.0.11

- Updated dependencies [9f1632b43]
- Updated dependencies [a7e6530ce]
  - @fe-infra/keystone-design-tokens@2.0.10

## 2.0.10

- Updated dependencies [75b57e385]
  - @fe-infra/keystone-design-tokens@2.0.9

## 2.0.9

- Updated dependencies [7f9730cc1]
  - @fe-infra/keystone-design-tokens@2.0.8

## 2.0.8

- Updated dependencies [5d49cb4e3]
  - @fe-infra/keystone-design-tokens@2.0.7

## 2.0.7

- 38d96b61b: fix: supplement neutral overlay color tokens
- Updated dependencies [38d96b61b]
  - @fe-infra/keystone-design-tokens@2.0.6

## 2.0.6

- Updated dependencies [537764b4a]
  - @fe-infra/keystone-design-tokens@2.0.5

## 2.0.5

- Updated dependencies [4ed8aabe7]
  - @fe-infra/keystone-design-tokens@2.0.4

## 2.0.4

- 6f41bd564: Update design token `--ks-border-radius-full`
- Updated dependencies [6f41bd564]
  - @fe-infra/keystone-design-tokens@2.0.3

## 2.0.3

- Updated dependencies [823d82587]
  - @fe-infra/keystone-design-tokens@2.0.2

## 2.0.2

- Updated dependencies [2f4977cc4]
  - @fe-infra/keystone-design-tokens@2.0.1

## 2.0.1

- Updated dependencies [80356147f]
  - @fe-infra/keystone-design-tokens@2.0.0

## 2.0.0

## [2.0.19] - 2025-09-19

### Changed

- Updated dependencies - ([f10bf6c83](https://code.byted.org/ad/byted-web-components/commit/f10bf6c83)).
  - @fe-infra/keystone-design-tokens@2.0.18

## [2.0.18] - 2025-07-18

### Changed

- Updated dependencies - ([011709718](https://code.byted.org/ad/byted-web-components/commit/011709718)).
  - @fe-infra/keystone-design-tokens@2.0.17
