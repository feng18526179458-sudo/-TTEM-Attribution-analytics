module.exports = {
  root: true,
  extends: [require.resolve('@byted-keystone/config/.eslintrc.node')],
};
