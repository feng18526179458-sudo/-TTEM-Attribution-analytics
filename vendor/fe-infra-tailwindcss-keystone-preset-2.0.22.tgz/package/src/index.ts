import { ks } from '@fe-infra/keystone-design-tokens';
import plugin from 'tailwindcss/plugin';

export default {
  content: [],
  theme: {
    colors: ks.color,
    fontFamily: {
      sans: ks.ref.text.fontFamily.text,
      display: ks.ref.text.fontFamily.display,
    },
    fontWeight: {
      normal: ks.ref.text.weight.regular,
      medium: ks.ref.text.weight.medium,
    },
    borderRadius: {
      none: '0px',
      sm: ks.border.radius.sm,
      'inner-md': ks.border.radius.innerMd,
      DEFAULT: ks.border.radius.md,
      md: ks.border.radius.md,
      lg: ks.border.radius.lg,
      xl: ks.border.radius.xl,
      full: ks.border.radius.full,
    },
    boxShadow: {
      1: ks.elevation.shadow.level1,
      2: ks.elevation.shadow.level2,
      3: ks.elevation.shadow.level3,
      4: ks.elevation.shadow.level4,
    },
    extend: {
      spacing: {
        18: '4.5rem',
        22: '5.5rem',
      },
    },
  },
  plugins: [
    plugin(({ matchVariant }) => {
      matchVariant('part', (value) => `&::part(${value})`);
    }),
    plugin.withOptions(
      (options = {}) =>
        function ({ addComponents, theme }) {
          const { className = 'tiktok' } = options;
          // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
          const modifiers = theme('typography')!;

          addComponents(
            Object.keys(modifiers).map((modifier) => ({
              [`.${className}-${modifier}`]: modifiers[modifier],
            })),
          );
        },
      () => ({
        theme: { typography: ks.text },
      }),
    ),
  ],
} satisfies import('tailwindcss').Config;
