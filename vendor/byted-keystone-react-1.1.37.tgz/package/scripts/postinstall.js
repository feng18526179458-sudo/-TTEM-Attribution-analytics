const fs = require('fs');
const path = require('path');

const DIST_UTILS = path.join(__dirname, '../dist/utils');
const TARGET_FILENAME = 'compat';

/**
 * Copy file from source to destination within the dist/utils directory
 * @param {string} dir - The directory where the file is located
 * @param {string} sourceName - The source filename (e.g., 'latest.js')
 * @param {string} targetName - The target filename (e.g., 'compat.js')
 */
function copyFile(dir, sourceName, targetName) {
  const src = path.join(dir, sourceName);
  const dest = path.join(dir, targetName);

  if (!fs.existsSync(src)) {
    // Only warn if we expect the file to be there (e.g. during dev it might not be built yet)
    // But for postinstall in a consumed package, it should exist.
    console.warn(`[ui-next] Warning: Source file "${sourceName}" not found at ${src}. Skipping copy.`);
    return;
  }

  try {
    fs.copyFileSync(src, dest);
  } catch (err) {
    console.error(`[ui-next] Error: Failed to copy "${sourceName}" to "${targetName}".`, err);
  }
}

/**
 * Switch the compat implementation based on the version type
 * @param {'latest' | 'legacy'} versionType
 */
function switchVersion(versionType) {
  const isLatest = versionType === 'latest';
  // Match the actual filenames: latest.ts -> latest.js, below-v18.ts -> below-v18.js
  const sourceBase = isLatest ? 'latest' : 'below-v18';

  console.log(`[ui-next] Switching to React ${isLatest ? '18+' : '<18'} compatibility implementation.`);

  copyFile(DIST_UTILS, `${sourceBase}.js`, `${TARGET_FILENAME}.js`);

  // d.ts files are located in dist/types/utils
  const DIST_TYPES_UTILS = path.join(__dirname, '../dist/types/utils');
  copyFile(DIST_TYPES_UTILS, `${sourceBase}.d.ts`, `${TARGET_FILENAME}.d.ts`);
}

/**
 * Load module safely
 * @param {string} name
 * @returns {any}
 */
function loadModule(name) {
  try {
    return require(name);
  } catch (e) {
    return undefined;
  }
}

/**
 * Try to resolve react version from the environment
 * @returns {string | null}
 */
function getReactVersion() {
  const react = loadModule('react');
  return react ? react.version : null;
}

function main() {
  const version = getReactVersion();

  if (!version) {
    console.warn('[ui-next] Warning: React not found in dependencies. Defaulting to React 18+ mode.');
    switchVersion('latest');
    return;
  }

  console.log(`[ui-next] Detected React version: ${version}`);

  const majorVersion = parseInt(version.split('.')[0], 10);

  if (majorVersion >= 18) {
    switchVersion('latest');
  } else {
    switchVersion('legacy');
  }
}

main();
