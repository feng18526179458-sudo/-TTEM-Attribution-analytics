# @fe-infra/chart-theme

## [0.4.4] - 2026-03-16

### Changed

- Updated dependencies - ([87afc9197](https://code.byted.org/ad/byted-web-components/commit/87afc9197)).
  - @fe-infra/keystone-design-tokens@2.0.21

## [0.4.3] - 2026-01-21

### Fixed

- (ChartTooltip) Fixed the issue where the tooltip of the chart did not display 0 but instead showed an empty string when value=0 - ([f35e8ca5a](https://code.byted.org/ad/byted-web-components/commit/f35e8ca5a)).

## [0.4.2] - 2026-01-13

### Changed

- Updated dependencies - ([fb01aa2c5](https://code.byted.org/ad/byted-web-components/commit/fb01aa2c5)).
  - @fe-infra/keystone-design-tokens@2.0.20

## [0.4.1] - 2025-11-19

### Changed

- Updated dependencies - ([4183deb0a](https://code.byted.org/ad/byted-web-components/commit/4183deb0a)).
  - @fe-infra/keystone-design-tokens@2.0.19

## [0.4.0] - 2025-09-24

### Added

- (KsLegends) Added new legend component with pagination support for better control over chart legend display - ([9f3bd3603](https://code.byted.org/ad/byted-web-components/commit/9f3bd3603)).
- (KsAreaChart, KsBarChart, KsCommonChart, KsLineChart, KsScatterChart, KsPieChart) Added integrated tooltip rendering using built-in VChart tooltip system instead of custom handlers - ([9f3bd3603](https://code.byted.org/ad/byted-web-components/commit/9f3bd3603)).

### Changed

- (KsAreaChart, KsBarChart, KsCommonChart, KsLineChart, KsScatterChart) **[BREAKING]** Removed custom tooltip handler implementation in favor of VChart's native tooltip system - ([9f3bd3603](https://code.byted.org/ad/byted-web-components/commit/9f3bd3603)).

## [0.3.3] - 2025-09-19

### Changed

- Updated dependencies - ([f10bf6c83](https://code.byted.org/ad/byted-web-components/commit/f10bf6c83)).
  - @fe-infra/keystone-design-tokens@2.0.18

## [0.3.2] - 2025-09-05

### Patch Changes

- 7a213727e: chart: trimPadding of bottom axes
  search:search add ksCategoryChange event && fix dropdown selectable
  dropdown menu: add loadFail props
  input selector: add loadFail props
  dropdown menu button: support renderContent
  field presenter: fix clear bug
  multiple-cascader: support selectable is false
  new component:
  - ks-multiple-input
  - ks-cascader-columns

## 0.0.24

- 011d14d12: fix chart tooltip bug

## 0.0.23

- Updated dependencies [10daf7645]
  - @fe-infra/keystone-design-tokens@2.0.16

## 0.0.22

- bc5d979b9: chart support marktooltip hide delay

## 0.0.21

- 70fbbb030: data vis 0.0.7

## 0.0.20

- Updated dependencies [ba01463fd]
  - @fe-infra/keystone-design-tokens@2.0.15

## 0.0.19

- Updated dependencies [22f210257]
  - @fe-infra/keystone-design-tokens@2.0.14

## 0.0.18

- Updated dependencies [51e02a607]
  - @fe-infra/keystone-design-tokens@2.0.13

## 0.0.17

- Updated dependencies [7ffb6daea]
  - @fe-infra/keystone-design-tokens@2.0.12

## 0.0.16

- Updated dependencies [258434cb2]
  - @fe-infra/keystone-design-tokens@2.0.11

## 0.0.15

- Updated dependencies [9f1632b43]
- Updated dependencies [a7e6530ce]
  - @fe-infra/keystone-design-tokens@2.0.10

## 0.0.14

- Updated dependencies [75b57e385]
  - @fe-infra/keystone-design-tokens@2.0.9

## 0.0.13

- Updated dependencies [7f9730cc1]
  - @fe-infra/keystone-design-tokens@2.0.8

## 0.0.12

- Updated dependencies [5d49cb4e3]
  - @fe-infra/keystone-design-tokens@2.0.7

## 0.0.11

- 38d96b61b: fix: supplement neutral overlay color tokens
- Updated dependencies [38d96b61b]
  - @fe-infra/keystone-design-tokens@2.0.6

## 0.0.10

- Updated dependencies [537764b4a]
  - @fe-infra/keystone-design-tokens@2.0.5

## 0.0.9

- Updated dependencies [4ed8aabe7]
  - @fe-infra/keystone-design-tokens@2.0.4

## 0.0.8

- Updated dependencies [6f41bd564]
  - @fe-infra/keystone-design-tokens@2.0.3

## 0.0.7

- 83d3171c8: fix tooltip style

## 0.0.6

- Updated dependencies [823d82587]
  - @fe-infra/keystone-design-tokens@2.0.2

## 0.0.5

- Updated dependencies [2f4977cc4]
  - @fe-infra/keystone-design-tokens@2.0.1

## 0.0.4

- Updated dependencies [80356147f]
  - @fe-infra/keystone-design-tokens@2.0.0

## 0.0.3

- 8eae3f8f0: fix vue slot

## 0.0.2

- 49fbc0c49: initial chart

## [0.3.1] - 2025-07-18

### Changed

- Updated dependencies - ([011709718](https://code.byted.org/ad/byted-web-components/commit/011709718)).
  - @fe-infra/keystone-design-tokens@2.0.17
