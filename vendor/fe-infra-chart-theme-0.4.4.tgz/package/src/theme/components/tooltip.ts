import { TooltipParams, createDimensionTooltip, createMarkTooltip, updateTooltip } from '../../components/tooltip';
import { ITooltipActual, TooltipHandlerParams } from '@visactor/vchart';

export const getTooltipSpec = (props: any, tooltipParams?: TooltipParams, el?: HTMLElement) => {
  const series = props.series?.[0] || props;
  const _direction = series.direction || (series.spec as any)?.direction || 'vertical';
  const yField = series.yField || (series.spec as any)?.yField;
  const xField = series.xField || (series.spec as any)?.xField;
  const xFieldKey = Array.isArray(xField) ? xField[0] : xField;
  const yFieldKey = Array.isArray(yField) ? yField[0] : yField;
  const labelValue = _direction === 'vertical' ? (Array.isArray(yField) ? yField[0] : yField) : xFieldKey;
  const seriesField = series.seriesField ?? (series.spec as any)?.seriesField;
  const keyField = seriesField ? seriesField : _direction === 'vertical' ? xFieldKey : yFieldKey;
  const { renderContent, renderTitle } = tooltipParams || {};
  const tooltip = {
    mark: {
      title: {
        value: typeof series?.title === 'string' ? series.title : (series?.title?.text ?? ''),
      },
      content: [
        {
          key: (datum: any) => datum[keyField],
          value: (datum: any) => (datum[labelValue] !== undefined ? datum[labelValue] : ''),
        },
      ],
    },
    dimension: {
      title: {
        value: typeof series?.title === 'string' ? series.title : (series?.title?.text ?? ''),
      },
      content: [
        {
          key: (datum: any) => datum[keyField],
          value: (datum: any) => (datum[labelValue] !== undefined ? datum[labelValue] : ''),
        },
      ],
    },
    group: {
      title: {
        value: typeof series?.title === 'string' ? series.title : (series?.title?.text ?? ''),
      },
      content: [
        {
          key: (datum: any) => datum[keyField],
          value: (datum: any) => datum[labelValue],
        },
      ],
    },
    renderMode: 'html',
    confine: true,
    parentElement: el,
    updateElement: (tooltipElement: HTMLElement, actualTooltip: ITooltipActual, params: TooltipHandlerParams) => {
      let tooltipContent: HTMLElement | null = null;
      const renderDimensionTitle = (params.tooltipSpec?.dimension?.title as any)?.value;
      const renderMarkTitle = (params.tooltipSpec?.mark?.title as any)?.value;
      tooltipElement.style.padding = '0px';
      tooltipElement.style.backgroundColor = 'var(--ks-color-neutral-fillHigh';
      tooltipElement.style.boxShadow = 'var(--ks-elevation-shadow-level2)';
      tooltipElement.style.borderRadius = '4px';
      if (actualTooltip.updatePosition) {
        return;
      }

      if (actualTooltip.activeType === 'dimension') {
        const data = (actualTooltip.data?.[0] as any).data;
        const _datum = data.map((d: any) => d.datum);
        const _series = data.map((d: any) => d.series);
        const sortData = tooltipParams?.sortToolTipDatum?.(_datum, _series);
        const datum = sortData?.datum || _datum;
        const series = sortData?.series || _series;
        tooltipContent = createDimensionTooltip({
          datum: actualTooltip.data as any,
          renderTitle: renderTitle || renderDimensionTitle,
          params: tooltipParams,
        });
        updateTooltip({
          tooltip: tooltipContent,
          datum,
          series,
          params,
          renderTitle:
            renderTitle || (actualTooltip.activeType === 'dimension' ? renderDimensionTitle : renderMarkTitle),
          renderContent,
          activeType: actualTooltip.activeType as any,
          direction: tooltipParams?.direction,
        });
      } else if (actualTooltip.activeType === 'mark') {
        const data = actualTooltip.data as any;
        const _datum = data.map((d: any) => d.datum);
        const _series = data.map((d: any) => d.series);
        const sortData = tooltipParams?.sortToolTipDatum?.(_datum, _series);
        const datum = sortData?.datum || _datum;
        const series = sortData?.series || _series;
        tooltipContent = createMarkTooltip({
          datum: actualTooltip.data as any,
          renderTitle: renderTitle || renderMarkTitle,
          params: tooltipParams,
        });
        updateTooltip({
          tooltip: tooltipContent,
          datum,
          series,
          params,
          renderTitle: renderTitle || renderDimensionTitle,
          renderContent,
          activeType: actualTooltip.activeType as any,
          direction: tooltipParams?.direction,
        });
      }
      if (tooltipContent) {
        tooltipElement.replaceChildren(tooltipContent as Node);
        requestAnimationFrame(() => {
          tooltipElement.style.minWidth = `${tooltipContent?.scrollWidth}px`;
        });
      }
    },
  };
  return tooltip;
};
