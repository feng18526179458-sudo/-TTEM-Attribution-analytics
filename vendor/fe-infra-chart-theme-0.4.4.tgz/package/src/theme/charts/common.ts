import {
  theme,
  getBarTheme,
  type LegendSize,
  reverseSpec,
  cornerRadiusSizeMap,
  widthSizeMap,
  getColorList,
  getTheme,
} from '../utils';
import {
  type ICommonChartSpec,
  type ISpec,
  type IAreaSeriesSpec,
  type ILineSeriesSpec,
  type IBarSeriesSpec,
  type IPieSeriesSpec,
  IDataValues,
  IData,
} from '@visactor/vchart';
import { isNumber, merge, groupBy } from 'lodash-es';
import { BarSize, disabledBarColorMap } from './bar';
import { getCSSVariableValue } from '@fe-infra/keystone-design-tokens';
import { getTooltipSpec } from '../components/tooltip';
import { Datum } from '@visactor/vchart/esm/typings';
import { line2areaColorMap } from './area';
import { TooltipParams } from '../../components/tooltip';

const OUTERSIDE_OUTER_RADIUS = 1;
const OUTERSIDE_INNER_RADIUS = 0.85;
const INSIDE_OUTER_RADIUS = 0.8;
const INSIDE_INNER_RADIUS = 0.52;

type IKsPieSeriesSpec = IPieSeriesSpec & {
  position: 'inside' | 'outside';
};
type CommonSpec = Omit<ICommonChartSpec, 'series'> & {
  series: (IAreaSeriesSpec | ILineSeriesSpec | IBarSeriesSpec | IKsPieSeriesSpec)[];
};
export type KsCommonSpec = Omit<CommonSpec, 'type' | 'outerRadius' | 'innerRadius'>;

export const parentColorMap: any = {
  '#8987F6': ['support-650', 'support-750', 'support-850', 'support-900', 'support-950'].map((i) =>
    getCSSVariableValue(`--ks-ref-color-${i}`),
  ),
  '#00577D': ['blue-400', 'blue-450', 'blue-500', 'blue-550', 'blue-650'].map((i) =>
    getCSSVariableValue(`--ks-ref-color-${i}`),
  ),
  '#E3CBE1': ['pink-750', 'pink-650', 'pink-550', 'pink-500', 'pink-450'].map((i) =>
    getCSSVariableValue(`--ks-ref-color-${i}`),
  ),
  '#A45626': ['orange-500', 'orange-550', 'orange-650', 'orange-750', 'orange-850'].map((i) =>
    getCSSVariableValue(`--ks-ref-color-${i}`),
  ),
  '#3D9FD4': ['blue-650', 'blue-550', 'blue-500', 'blue-450', 'blue-400'].map((i) =>
    getCSSVariableValue(`--ks-ref-color-${i}`),
  ),
};

const disabledPieColorMap: any = {
  '#8987F6': '#CDCFFF',
  '#BABDFF': '#CDCFFF',
  '#CDCFFF': '#CDCFFF',
  '#DCDEFF': '#CDCFFF',
  '#E9EBFF': '#CDCFFF',
  '#00577D': '#CAE6FC',
  '#006697': '#CAE6FC',
  '#0074A6': '#CAE6FC',
  '#2D94C8': '#CAE6FC',
  '#3D9FD4': '#CAE6FC',
  '#7CC0ED': '#CAE6FC',
  '#B87BB4': '#EAD8E9',
  '#DAB6D7': '#EAD8E9',
  '#D19DCD': '#EAD8E9',
  '#AA72A7': '#EAD8E9',
  '#8B5A88': '#EAD8E9',
  '#A45626': '#F8DBCC',
  '#5548BD': '#C2D5FB',
};

const barWithAreaColorList = ['data1-fill', 'data2-fill', 'data3-fillMed', 'data4-fill', 'data5-fillMedHigh'].map((i) =>
  getCSSVariableValue(`--ks-color-data-${i}`),
);
const barWithLineColorList = ['data9-fill', 'data2-fill', 'data3-fill', 'data4-fillHigh', 'data5-fill'].map((i) =>
  getCSSVariableValue(`--ks-color-data-${i}`),
);
const lineColorList = ['data3-fillMedHigh', 'data4-fill', 'data5-fillMedHigh', 'data1-fill', 'data7-fillMedHigh'].map(
  (i) => getCSSVariableValue(`--ks-color-data-${i}`),
);
const areaColorList = ['data3-fillMedHigh', 'data4-fill', 'data5-fillMedHigh', 'data1-fill', 'data2-fill'].map((i) =>
  getCSSVariableValue(`--ks-color-data-${i}`),
);

export const formatDoubleDonutData = (data: any, spec: any, max_num = 5) => {
  const childrenDataIndex = Array.isArray(data) && data?.findIndex((_data: any) => _data.values[0].parent);
  const childrenSeries =
    Array.isArray(spec.series) && spec.series?.find((_series: any) => _series.position === 'outside');
  const childrenData =
    childrenDataIndex !== -1 && isNumber(childrenDataIndex) && Array.isArray(spec.data) && spec.data[childrenDataIndex];
  const { categoryField, valueField } = (childrenSeries as IKsPieSeriesSpec) || {};
  const processData = (values: any) => {
    let processedData: any[];
    if (values.length > 5 && Array.isArray(values)) {
      processedData = values.slice(0, max_num - 1);
      const other = values.slice(max_num - 1);
      processedData.push({
        [categoryField]: 'Other',
        [valueField]: other.reduce((pre, next) => pre + Number(next[valueField]), 0),
        parent: values[0].parent,
      });
      return {
        values: processedData,
        __other: other,
      };
    }
    return { values };
  };
  const groupByData = groupBy((childrenData as IDataValues).values as any[], (item) => item.parent);
  let newValues: any[] = [];
  const otherMap: any = {};
  Object.keys(groupByData).forEach((key) => {
    const { values, __other: other } = processData(groupByData[key]);
    newValues = newValues.concat(values);
    if (other) {
      otherMap[key] = other;
    }
  });
  if (isNumber(childrenDataIndex) && Array.isArray(data)) {
    data[childrenDataIndex] = {
      ...childrenData,
      values: newValues,
    };
  }
  return {
    data,
    otherMap,
  };
};

export const createKsCommonChartSpec = ({
  spec,
  barSize = 'md',
  legendSize = 'md',
  isRtl = false,
  renderToolTipContent,
  el,
}: {
  spec: KsCommonSpec;
  barSize: BarSize;
  legendSize?: LegendSize;
  isRtl?: boolean;
  renderToolTipContent: TooltipParams;
  el: HTMLElement;
}) => {
  const hasAreaChart = spec.series?.some((item) => item.type === 'area');
  const hasBarChart = spec.series?.some((item) => item.type === 'bar');
  const generateColorList = (spec: KsCommonSpec) => {
    const { data, series } = spec;
    const areaSeries = series.filter((item) => item.type === 'area')[0];
    const barSeries = series.filter((item) => item.type === 'bar')[0];
    const lineSeries = series.filter((item) => item.type === 'line')[0];
    const getDataFormSeries = (
      series: IAreaSeriesSpec | ILineSeriesSpec | IBarSeriesSpec | IKsPieSeriesSpec,
      data: IData,
    ) => {
      const { dataId, dataIndex } = series;
      return Array.isArray(data)
        ? isNumber(dataIndex)
          ? data[dataIndex]
          : data.find((item) => (item as IDataValues).id === dataId)
        : data;
    };
    const getDataCount = (data: IDataValues, seriesField: string) => {
      const dataList = ((data as IDataValues)?.values as Datum)?.map((item: any) => item[seriesField as string]);
      if (Array.isArray(dataList)) {
        const set = new Set(dataList);
        return set.size;
      }
      return 0;
    };
    if (series.length === 2 && Array.isArray(data)) {
      if (barSeries && lineSeries) {
        const barData = getDataFormSeries(barSeries, data);
        const lineData = getDataFormSeries(lineSeries, data);
        const barDataCount = getDataCount(barData as IDataValues, barSeries.seriesField as string);
        const lineDataCount = getDataCount(lineData as IDataValues, lineSeries.seriesField as string);
        return barWithLineColorList.slice(0, barDataCount).concat(lineColorList.slice(0, lineDataCount));
      } else if (barSeries && areaSeries) {
        const barData = getDataFormSeries(barSeries, data);
        const areaData = getDataFormSeries(areaSeries, data);
        const barDataCount = getDataCount(barData as IDataValues, barSeries.seriesField as string);
        const areaDataCount = getDataCount(areaData as IDataValues, areaSeries.seriesField as string);
        return barWithAreaColorList.slice(0, barDataCount).concat(areaColorList.slice(0, areaDataCount));
      }
    }
  };
  const series = spec.series?.map((item) => {
    if (item.type === 'bar') {
      return merge(
        {
          stackCornerRadius: !item.percent
            ? cornerRadiusSizeMap[item.direction ?? 'vertical'][barSize || 'md']
            : undefined,
          barWidth: widthSizeMap[barSize || 'md'],
          axes: [
            {
              type: 'linear',
              orient: isRtl ? 'right' : 'left',
            },
            {
              type: 'band',
              orient: 'bottom',
              inverse: isRtl ? true : false,
            },
          ],
          bar: {
            style: {
              globalZIndex: hasAreaChart ? 1 : undefined,
              outerBorder: {
                distance: 1,
                lineWidth: hasAreaChart ? 1 : 0,
                stroke: '#fff',
              },
            },
            state: {
              dimension_hover: {
                fill: (datum: any, option: any, _any: any) => {
                  const type = datum[item?.seriesField as string];
                  const fillColor: string = option.seriesColor(type);
                  return fillColor;
                },
              },
              dimension_hover_reverse: {
                fill: (datum: any, option: any, _any: any) => {
                  const type = datum[item?.seriesField as string];
                  const fillColor: string = option.seriesColor(type);
                  const disabledColor = disabledBarColorMap[fillColor.toLocaleUpperCase()] || option.seriesColor(type);
                  return disabledColor;
                },
              },
            },
          },
          barGapInGroup: 2,
        },
        item,
      );
    } else if (item.type === 'area') {
      return merge(
        {
          area: {
            zIndex: 1,
            style: {
              fill: item.stack
                ? (datum: any, context: any) => {
                    const type = datum[spec.seriesField as string];
                    const fillColor: string = context.seriesColor(type);
                    const stackColor = line2areaColorMap[fillColor.toLocaleUpperCase()] || context.seriesColor(type);
                    return stackColor;
                  }
                : undefined,
              fillOpacity: item.stack ? 0.8 : 0.2,
            },
          },
          line: {
            zIndex: 1,
            style: {
              lineWidth: 1.5,
            },
          },
          point: {
            style: {
              size: 0,
              innerBorder: {
                stroke: '#fff',
                distance: 3,
                lineWidth: 2,
              },
            },
            state: {
              dimension_hover: {
                globalZIndex: 1,
                size: 8,
                innerBorder: {
                  stroke: getCSSVariableValue('--ks-ref-color-white'),
                  distance: 3,
                  lineWidth: 2,
                },
              },
              hover: {
                globalZIndex: 1,
                size: 8,
                innerBorder: {
                  distance: 1,
                  lineWidth: 0,
                },
              },
            },
          },
          color: getColorList(
            item,
            ['1-fill', '2-fill', '3-fillMedHigh', '4-fill', '5-fillMedHigh', '6-fill'].map((i) =>
              getCSSVariableValue(`--ks-color-data-data${i}`),
            ),
          ),
          axes: [
            {
              orient: 'bottom',
              trimPadding: true,
            },
          ],
        },
        item,
      );
    } else if (item.type === 'line') {
      return merge(
        {
          line: {
            zIndex: 1,
            style: {
              lineWidth: 1.5,
            },
          },
          point: {
            style: {
              size: 0,
              innerBorder: {
                stroke: '#fff',
                distance: 3,
                lineWidth: 2,
              },
            },
            state: {
              dimension_hover: {
                globalZIndex: 1,
                size: 8,
                innerBorder: {
                  stroke: getCSSVariableValue('--ks-ref-color-white'),
                  distance: 3,
                  lineWidth: 2,
                },
              },
              hover: {
                globalZIndex: 1,
                size: 8,
                innerBorder: {
                  distance: 1,
                  lineWidth: 0,
                },
              },
            },
          },
          color: getColorList(
            item,
            ['1-fill', '2-fill', '3-fillMedHigh', '4-fill', '5-fillMedHigh', '6-fill'].map((i) =>
              getCSSVariableValue(`--ks-color-data-data${i}`),
            ),
          ),
          axes: [
            {
              orient: 'bottom',
              trimPadding: true,
            },
          ],
        },
        item,
      );
    } else if (item.type === 'pie') {
      return merge(
        {
          theme: {
            ...getTheme({ legendSize, isRtl }),
          },
          outerRadius: item.position === 'outside' ? OUTERSIDE_OUTER_RADIUS : INSIDE_OUTER_RADIUS,
          innerRadius: item.position === 'outside' ? OUTERSIDE_INNER_RADIUS : INSIDE_INNER_RADIUS,
          type: 'pie',
          tooltip: getTooltipSpec(spec, renderToolTipContent, el),
          label: {
            visible: item.position === 'outside',
            position: item.position,
            style: {
              type: 'text',
              formatMethod: (data: any) => `${data.value} (${data._percent_}%)`,
              fillOpacity: 0,
              boundsPadding: [8, 0, 8, 0],
              html: (data: any) => ({
                pointerEvents: 'auto',
                dom: isRtl
                  ? `<div class="label"><span class="labelTitle">${data[item.categoryField]}</span><span class="labelContent">%${data.value}</span></div>`
                  : `<div class="label"><span class="labelTitle">${data[item.categoryField]}</span><span class="labelContent">${data.value} (${data._percent_}%)</span></div>`,
                style: {
                  color: getCSSVariableValue('--ks-ref-color-neutral-450'),
                },
              }),
            },
            line: {
              zIndex: 0,
              style: {
                stroke: getCSSVariableValue('--ks-ref-color-neutral-900'),
              },
            },
          },
          pie: {
            state: {
              ks_hover_reverse: {
                fill: (datum: any, option: any) => {
                  const type = datum[item.categoryField as string];
                  let fillColor: string = option.seriesColor(type);
                  if (datum.parent) {
                    fillColor = option.seriesColor(datum.parent);
                  }
                  const disabledColor = disabledPieColorMap[fillColor.toLocaleUpperCase()] || '#EAD8E9';
                  return disabledColor;
                },
              },
            },
            style: {
              fill:
                item.position === 'outside'
                  ? (datum: any, option: any) => {
                      // const values = spec.data[]
                      const childDatum = Array.isArray(spec.data)
                        ? spec.data?.find((_data: any) => _data.values[0].parent)
                        : spec.data;
                      const childValues = (childDatum as IDataValues)?.values;
                      const parentType = datum?.parent;
                      const childWithSameParent = (childValues as Datum)?.filter(
                        (_child: any) => _child.parent === parentType,
                      );
                      const childIndex = childWithSameParent.findIndex(
                        (_child: any) => _child[item?.categoryField] === datum[item?.categoryField],
                      );
                      const parentColor: string = option.seriesColor(parentType).toLocaleUpperCase();
                      const childColor = parentColorMap[parentColor]?.[childIndex % 5];
                      return childColor;
                    }
                  : undefined,
            },
          },
          layoutRadius: 112,
        },
        item,
      );
    }
    return item;
  });
  return merge(
    {
      theme: merge(
        getBarTheme({
          stack: spec.series?.find((item) => item.type === 'bar')?.stack || false,
          size: barSize,
          direction: (spec.series?.find((item) => item.type === 'bar') as any)?.direction ?? 'vertical',
          legendSize,
          isRtl,
        }),
        theme,
      ),
      type: 'common',
      crosshair: !hasBarChart
        ? {
            gridZIndex: 500,
            xField: {
              visible: true,
              line: {
                visible: true,
                type: 'line',
              },
            },
          }
        : {
            xField: {
              visible: true,
              line: {
                type: 'rect',
                style: {
                  fill: '#F1F2F2',
                },
                width: '110%',
              },
            } as any,
            yField: {
              visible: false,
            },
          },
      series,
      tooltip: getTooltipSpec(spec, renderToolTipContent, el),
      legends: {
        visible: true,
        data: (data: any[]) => data.filter((item) => item.shape.fill),
        regionIndex: 0,
        customFilter: (data: any[], selectedRange: any[], datumField: any) => {
          if (data[0].parent) {
            return data.filter((_item: any) => selectedRange.includes(_item.parent));
          }
          return data.filter((_item: any) => selectedRange.includes(_item[datumField]));
        },
      },
      color: generateColorList(spec),
    },
    isRtl ? reverseSpec(spec) : spec,
  ) as ISpec;
};
