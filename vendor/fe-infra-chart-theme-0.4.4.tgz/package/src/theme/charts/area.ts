import { getColorList, getTheme, type LegendSize, legendSizeMap, reverseSpec } from '../utils';
import { type IAreaChartSpec, type ISpec } from '@visactor/vchart';
import { merge } from 'lodash-es';
import { getTooltipSpec } from '../components/tooltip';
import { TooltipParams } from '../../components/tooltip';
import { getCSSVariableValue } from '@fe-infra/keystone-design-tokens';

export const line2areaColorMap: any = {
  '#8987F6': '#CDCFFF',
  '#00577D': '#98CCF0',
  '#B87BB4': '#E3CBE1',
  '#A45626': '#F8DBCC',
  '#3D9FD4': '#CAE6FC',
  '#5548BD': '#C2D5FB',
};
export type KsAreaSpec = Omit<IAreaChartSpec, 'type'>;
export const createKsAreaChartSpec = ({
  spec,
  legendSize = 'md',
  isRtl = false,
  renderToolTipContent,
  el,
}: {
  spec: KsAreaSpec;
  legendSize?: LegendSize;
  isRtl?: boolean;
  renderToolTipContent: TooltipParams;
  el: HTMLElement;
}) =>
  merge(
    {
      theme: {
        ...getTheme({ legendSize, isRtl }),
      },
      tooltip: getTooltipSpec(spec, renderToolTipContent, el),
      legends: {
        position: isRtl ? 'start' : 'end',
        orient: 'top',
        item: {
          shape: {
            style: (item: any) => ({
              symbolType: 'circle',
              size: legendSizeMap[legendSize || 'md'],
              fill: item.shape.stroke,
              strokeOpacity: 0,
            }),
          },
        },
        reversed: isRtl,
      },
      type: 'area',
      crosshair: {
        gridZIndex: 500,
        xField: {
          visible: true,
          line: {
            visible: true,
            type: 'line',
          },
        },
      },
      area: {
        style: {
          fill: spec.stack
            ? (datum: any, context: any) => {
                const type = datum[spec.seriesField as string];
                const fillColor: string = context.seriesColor(type);
                const stackColor = line2areaColorMap[fillColor.toLocaleUpperCase()] || context.seriesColor(type);
                return stackColor;
              }
            : undefined,
          fillOpacity: spec.stack ? 0.8 : 0.2,
        },
      },
      line: {
        style: {
          lineWidth: 1.5,
        },
      },
      point: {
        style: {
          size: 0,
          innerBorder: {
            stroke: getCSSVariableValue('--ks-ref-color-white'),
            distance: 3,
            lineWidth: 2,
          },
        },
        state: {
          dimension_hover: {
            globalZIndex: 1,
            size: 8,
            innerBorder: {
              stroke: getCSSVariableValue('--ks-ref-color-white'),
              distance: 3,
              lineWidth: 2,
            },
          },
          hover: {
            globalZIndex: 1,
            size: 8,
            innerBorder: {
              distance: 1,
              lineWidth: 0,
            },
          },
        },
      },
      color: getColorList(
        spec,
        ['1-fill', '2-fill', '3-fillMedHigh', '4-fill', '5-fillMedHigh', '6-fill'].map((i) =>
          getCSSVariableValue(`--ks-color-data-data${i}`),
        ),
      ),
      axes: [
        {
          orient: 'bottom',
          trimPadding: true,
        },
      ],
    },
    isRtl ? reverseSpec(spec) : spec,
  ) as ISpec;
