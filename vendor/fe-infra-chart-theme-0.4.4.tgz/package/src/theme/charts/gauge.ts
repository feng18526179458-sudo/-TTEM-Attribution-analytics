import { getTheme, type LegendSize } from '../utils';
import { type IGaugeChartSpec, type ISpec } from '@visactor/vchart';
import { merge } from 'lodash-es';
// import { getTooltipSpec } from '../components/tooltip';
import { getCSSVariableValue } from '@fe-infra/keystone-design-tokens';
import { type DonutSize, sizeLayoutRadiusMap } from './pie';

export const sizeTitleSizeMap = {
  sm: 20,
  md: 24,
  lg: 32,
};
export const sizeTitleLineMap = {
  sm: 28,
  md: 32,
  lg: 40,
};

export const donutWeightMap = {
  lg: 22,
  md: 18,
  sm: 14,
};

export type KsGagueSpec = Omit<IGaugeChartSpec, 'type'>;
export const createKsGaugeChartSpec = ({
  spec,
  size = 'lg',
  legendSize = 'md',
  isRtl = false,
  isHalf = true,
  status = 'success',
  metric,
  hasLabel,
  tag,
}: {
  spec: KsGagueSpec;
  size?: DonutSize;
  legendSize?: LegendSize;
  isRtl?: boolean;
  isHalf?: boolean;
  status?: 'success' | 'warning' | 'error';
  metric?: string;
  tag?: string;
  hasLabel?: boolean;
}) => {
  const renderSize = isHalf ? 'lg' : size;
  return merge(
    {
      theme: {
        ...getTheme({ legendSize, isRtl }),
        markByName: {
          pie: {
            state: {
              hover: {
                outerRadius: 1.03,
                innerRadius: 0.63,
              },
              hover_reverse: {
                fill: (datum: any, option: any) => {
                  const disabledColorMap: any = {
                    '#8987F6': '#CDCFFF',
                    '#00577D': '#40819D',
                    '#B87BB4': '#EAD8E9',
                    '#A45626': '#BB805C',
                    '#3D9FD4': '#B2D9F4',
                    '#5548BD': '#C2D5FB',
                  };
                  const type = datum[spec.categoryField as string];
                  const fillColor: string = option.seriesColor(type);
                  const disabledColor = disabledColorMap[fillColor.toLocaleUpperCase()] || option.seriesColor(type);
                  return disabledColor;
                },
              },
            },
          },
        },
      },
      type: 'gauge',
      radiusField: 'type',
      categoryField: 'type',
      valueField: 'value',
      outerRadius: 1,
      innerRadius: (sizeLayoutRadiusMap[renderSize] - donutWeightMap[renderSize]) / sizeLayoutRadiusMap[renderSize],
      startAngle: isHalf ? 180 : -90,
      endAngle: isHalf ? 360 : 270,
      layoutRadius: sizeLayoutRadiusMap[renderSize ?? 'md'],
      gauge: {
        type: 'circularProgress',
        cornerRadius: 0,
        progress: {
          style: {
            fill: getCSSVariableValue(`--ks-color-data-${status}-fill`),
          },
        },
        track: {
          style: {
            fill: getCSSVariableValue(`--ks-color-neutral-surface3`),
            fillOpacity: 1,
          },
        },
      },
      pointer: {
        visible: false,
      },
      pin: {
        visible: false,
      },
      pinBackground: {
        visible: false,
      },
      indicator: [
        {
          visible: true,
          offsetY: isHalf ? (tag ? '-22' : '-12') : tag && size === 'lg' ? '-8' : '0%',
          title: {
            style: {
              text: metric,
              fontSize: sizeTitleSizeMap[renderSize ?? 'md'],
              fontWeight: 500,
              lineHeight: sizeTitleLineMap[renderSize ?? 'md'],
              pickable: true,
            },
          },
          content: {
            visible: renderSize === 'lg' || isHalf,
            style: {
              fontSize: 12,
              html: () => ({
                pointerEvents: 'auto',
                dom: tag,
                style: {
                  fontSize: '12px',
                  fontStyle: 'normal',
                  fontWeight: 400,
                  color: `var(--ks-color-${status}-onSurface)`,
                  background: `var(--ks-color-${status}-surface3)`,
                  borderRadius: 'var(--ks-border-radius-md)',
                  letterSpacing: '0.161px',
                  lineHeight: '20px',
                  height: 20,
                  padding: '0 6px',
                },
              }),
            },
          },
        },
        {
          visible: isHalf && hasLabel,
          offsetX: -82,
          offsetY: 10,
          title: {
            style: {
              text: '0',
              fontSize: 12,
              fill: '#87898B',
            },
          },
        },
        {
          visible: isHalf && hasLabel,
          offsetX: 82,
          offsetY: 10,
          title: {
            style: {
              text: '100',
              fontSize: 12,
              fill: '#87898B',
            },
          },
        },
      ],
      axes: [
        {
          type: 'linear',
          orient: 'angle',
          label: { visible: false },
        },
      ],
    },
    spec,
  ) as ISpec;
};
