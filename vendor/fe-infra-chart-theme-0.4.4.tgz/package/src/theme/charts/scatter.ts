import { getTheme, type LegendSize, reverseSpec } from '../utils';
import { type IScatterChartSpec, type ISpec } from '@visactor/vchart';
import { merge } from 'lodash-es';
import { getTooltipSpec } from '../components/tooltip';
import { TooltipParams } from '../../components/tooltip';

export type PointSize = 'sm' | 'md' | 'lg';
export const pointSizeMap: Record<PointSize, number> = {
  sm: 8,
  md: 20,
  lg: 32,
};

export type KsScatterSpec = Omit<IScatterChartSpec, 'type'>;
export const createKsScatterChartSpec = ({
  spec,
  size,
  legendSize = 'md',
  isRtl = false,
  renderToolTipContent,
  el,
}: {
  spec: KsScatterSpec;
  size?: PointSize;
  legendSize?: LegendSize;
  isRtl?: boolean;
  renderToolTipContent?: TooltipParams;
  el: HTMLElement;
}) =>
  merge(
    {
      theme: getTheme({ legendSize, isRtl }),
      tooltip: getTooltipSpec(spec, renderToolTipContent, el),
      size: pointSizeMap[size ?? 'md'],
      type: 'scatter',
      point: {
        style: {
          opacity: 0.8,
          fillOpacity: 0.6,
          strokeOpacity: 1,
          lineWidth: 1,
          stroke: (type: any, p: any) => p.seriesColor(type[spec.seriesField as string]),
        },
        state: {
          hover: {
            opacity: 1,
            fillOpacity: 0.8,
            strokeOpacity: 1,
            lineWidth: 1,
            stroke: (type: any, p: any) => p.seriesColor(type[spec.seriesField as string]),
          },
          selected: {
            opacity: 1,
            fillOpacity: 0.8,
            strokeOpacity: 1,
            lineWidth: 1,
            outerBorder: {
              lineWidth: 4,
              distance: 2,
              strokeOpacity: 0.2,
            },
            stroke: (type: any, p: any) => p.seriesColor(type[spec.seriesField as string]),
          },
        },
      },
    },
    isRtl ? reverseSpec(spec) : spec,
  ) as ISpec;
