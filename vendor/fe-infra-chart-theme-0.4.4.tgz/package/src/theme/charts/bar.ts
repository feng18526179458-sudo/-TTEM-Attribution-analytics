import { getBarTheme, type LegendSize, cornerRadiusSizeMap, widthSizeMap, reverseSpec } from '../utils';
import { type IBarChartSpec, type ISpec } from '@visactor/vchart';
import { merge } from 'lodash-es';
import { getTooltipSpec } from '../components/tooltip';
import { TooltipParams } from '../../components/tooltip';
import { getCSSVariableValue } from '@fe-infra/keystone-design-tokens';

export const disabledBarColorMap: any = {
  '#8987F6': '#CDCFFF',
  '#00577D': '#CAE6FC',
  '#B87BB4': '#EAD8E9',
  '#A45626': '#F8DBCC',
  '#3D9FD4': '#B2D9F4',
  '#5548BD': '#C2D5FB',
};
export type BarSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';
export type KsBarSpec = Omit<IBarChartSpec, 'type'>;
export const createKsBarChartSpec = ({
  spec,
  barSize = 'md',
  legendSize = 'md',
  isRtl = false,
  renderToolTipContent,
  el,
}: {
  spec: KsBarSpec;
  barSize?: BarSize;
  legendSize?: LegendSize;
  isRtl?: boolean;
  renderToolTipContent: TooltipParams;
  el: HTMLElement;
}) =>
  merge(
    {
      theme: getBarTheme({
        stack: spec.stack || false,
        size: barSize,
        direction: spec.direction ?? 'vertical',
        legendSize,
        isRtl,
      }),
      type: 'bar',
      tooltip: getTooltipSpec(spec, renderToolTipContent, el),
      stackCornerRadius: !spec.percent ? cornerRadiusSizeMap[spec.direction ?? 'vertical'][barSize || 'md'] : undefined,
      color: spec.percent
        ? [400, 550, 650, 900].map((i) => getCSSVariableValue(`--ks-ref-color-indigo-${i}`))
        : undefined,
      barWidth: widthSizeMap[barSize || 'md'],
      axes: [
        {
          type: 'linear',
          orient: isRtl ? 'right' : 'left',
        },
        {
          type: 'band',
          orient: 'bottom',
          inverse: isRtl ? true : false,
        },
      ],
      bar: {
        state: {
          dimension_hover: {
            fill: (datum: any, option: any, _any: any) => {
              const type = spec.seriesField
                ? datum[spec.seriesField]
                : datum.__VCHART_DEFAULT_DATA_SERIES_FIELD || datum.__VCHART_DEFAULT_DATA_KEY;
              const fillColor: string = option.seriesColor(type);
              return fillColor;
            },
          },
          dimension_hover_reverse: {
            fill: (datum: any, option: any, _any: any) => {
              const type = spec.seriesField
                ? datum[spec.seriesField]
                : datum.__VCHART_DEFAULT_DATA_SERIES_FIELD || datum.__VCHART_DEFAULT_DATA_KEY;
              const fillColor: string = option.seriesColor(type);
              const disabledColor = disabledBarColorMap[fillColor.toLocaleUpperCase()] || option.seriesColor(type);
              return disabledColor;
            },
          },
        },
      },
      barGapInGroup: 2,
    },
    isRtl ? reverseSpec(spec) : spec,
  ) as ISpec;
