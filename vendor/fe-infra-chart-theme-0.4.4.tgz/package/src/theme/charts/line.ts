import { getTheme, type LegendSize, reverseSpec, getColorList } from '../utils';
import { type ILineChartSpec, type ISpec } from '@visactor/vchart';
import { merge } from 'lodash-es';
import { getCSSVariableValue } from '@fe-infra/keystone-design-tokens';
import { TooltipParams } from '../../components/tooltip';
import { getTooltipSpec } from '../components/tooltip';

export type KsLineSpec = Omit<ILineChartSpec, 'type'> & { type: 'line' };
export const createKsLineChartSpec = ({
  spec,
  legendSize = 'md',
  isRtl = false,
  renderToolTipContent,
  el,
}: {
  spec: KsLineSpec;
  legendSize?: LegendSize;
  isRtl?: boolean;
  renderToolTipContent: TooltipParams;
  el: HTMLElement;
}) =>
  merge(
    {
      theme: getTheme({ legendSize, isRtl }),
      tooltip: getTooltipSpec(spec, renderToolTipContent, el),
      type: 'line',
      crosshair: {
        xField: {
          visible: true,
          line: {
            visible: true,
            type: 'line',
          },
        },
      },
      color: getColorList(
        spec,
        ['1-fill', '2-fill', '3-fillMedHigh', '4-fill', '5-fillMedHigh', '6-fill'].map((i) =>
          getCSSVariableValue(`--ks-color-data-data${i}`),
        ),
      ),
      axes: [
        {
          orient: 'bottom',
          trimPadding: true,
        },
      ],
    },
    isRtl ? reverseSpec(spec) : spec,
  ) as ISpec;
