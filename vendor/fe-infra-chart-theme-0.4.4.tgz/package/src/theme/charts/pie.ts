import { getTheme, type LegendSize } from '../utils';
import { type IPieChartSpec, type ISpec, type IData, type IDataValues } from '@visactor/vchart';
import { merge } from 'lodash-es';
import { getTooltipSpec } from '../components/tooltip';
import { getCSSVariableValue } from '@fe-infra/keystone-design-tokens';
import { TooltipParams } from '../../components/tooltip';

export const sizeLayoutRadiusMap = {
  sm: 40,
  md: 60,
  lg: 90,
};
export type DonutSize = 'sm' | 'md' | 'lg';

const MAX_NUM = 8;

const INNER_RADIUS = 0.66;
const OUTER_RADIUS = 1;

export const disabledPieColorMap: any = {
  '#8987F6': '#CDCFFF',
  '#00577D': '#CAE6FC',
  '#B87BB4': '#EAD8E9',
  '#A45626': '#F8DBCC',
  '#3D9FD4': '#B2D9F4',
  '#5548BD': '#C2D5FB',
};

export type KsPieSpec = Omit<IPieChartSpec, 'type'>;

export const formatData = (data: any, spec: any, max_num: number = MAX_NUM) => {
  if (!data) {
    return;
  }
  const { valueField, categoryField } = spec;
  const processData = (dataType: any) => {
    const { values } = dataType as IDataValues;
    let processedData: any[];
    if (values.length > max_num && Array.isArray(values)) {
      processedData = values.slice(0, MAX_NUM - 1);
      const other = values.slice(MAX_NUM - 1);
      processedData.push({
        [categoryField]: 'Other',
        [valueField]: other.reduce((pre, next) => pre + Number(next[valueField]), 0),
      });
      return {
        ...dataType,
        values: processedData,
        __other: other,
      };
    }
    return dataType;
  };
  return Array.isArray(data) ? data.map((item) => processData(item)) : processData(data);
};
export const createKsPieChartSpec = ({
  spec,
  pieSize,
  legendSize = 'md',
  isRtl = false,
  renderToolTipContent,
  el,
}: {
  spec: KsPieSpec;
  pieSize?: DonutSize;
  legendSize?: LegendSize;
  isRtl?: boolean;
  renderToolTipContent: TooltipParams;
  el: HTMLElement;
}) =>
  merge(
    {
      theme: {
        ...getTheme({ legendSize, isRtl }),
        markByName: {
          pie: {
            state: {
              hover: {
                outerRadius: 1.03,
                innerRadius: 0.63,
              },
              hover_reverse: {
                fill: (datum: any, option: any) => {
                  const type = datum[spec.categoryField as string];
                  const fillColor: string = option.seriesColor(type);
                  const disabledColor = disabledPieColorMap[fillColor.toLocaleUpperCase()] || option.seriesColor(type);
                  return disabledColor;
                },
              },
            },
          },
        },
      },
      type: 'pie',
      tooltip: getTooltipSpec(spec, renderToolTipContent, el),
      label: {
        visible: true,
        style: {
          type: 'text',
          formatMethod: () => '',
          fillOpacity: 0,
          html: (data: any) => ({
            pointerEvents: 'auto',
            dom: isRtl ? `%${data.value}` : `${data.value}%`,
            style: {
              fontSize: '12px',
              fontStyle: 'normal',
              fontWeight: 400,
              color: getCSSVariableValue('--ks-ref-color-neutral-450'),
              letterSpacing: '0.161px',
              lineHeight: '16px',
              height: 16,
            },
          }),
        },
        line: {
          zIndex: 0,
          style: {
            stroke: getCSSVariableValue('--ks-ref-color-neutral-900'),
          },
        },
      },
      layoutRadius: sizeLayoutRadiusMap[pieSize ?? 'md'],
      outerRadius: OUTER_RADIUS,
      innerRadius: INNER_RADIUS,
    },
    { ...spec, data: spec.data as IData },
  ) as ISpec;
