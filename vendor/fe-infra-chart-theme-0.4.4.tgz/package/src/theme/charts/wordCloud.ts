import { getTheme, type LegendSize } from '../utils';
import { type IWordCloudChartSpec, type ISpec } from '@visactor/vchart';
import { merge } from 'lodash-es';

export type KsWordCloudSpec = Omit<IWordCloudChartSpec, 'type'>;
export const createKsWordCloudChartSpec = ({
  spec,
  legendSize = 'md',
}: {
  spec: KsWordCloudSpec;
  legendSize?: LegendSize;
}) => {
  const keyField = spec.nameField;
  const valueField = spec.valueField || '';
  const { seriesField } = spec;
  return merge(
    {
      theme: getTheme({ legendSize }),
      fontSizeRange: [12, 32],
      fontWeightRange: [500, 500],
      type: 'wordCloud',
      word: {
        style: {
          fontWeight: 500,
          fontFamily: 'TikTok Sans Display',
          fontStyle: 'normal',
        },
      },
      tooltip: {
        mark: {
          content: [
            {
              key: (datum: any) => datum[seriesField || keyField],
              value: (datum: any) => datum[valueField],
            },
          ],
        },
      },
    },
    spec,
  ) as ISpec;
};
