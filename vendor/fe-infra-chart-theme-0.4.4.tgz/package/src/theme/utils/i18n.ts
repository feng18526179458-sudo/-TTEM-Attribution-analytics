export const reverseSpec = (spec: any) => {
  const { axes, ...rest } = spec;
  // if(data?.values && Array.isArray(data.values)){
  //   data.values = [...data.values.reverse()];
  // } else if(Array.isArray(data)){
  //   data.forEach((item)=>{
  //     if(item.values){
  //       item.values = item.values.reverse();
  //     }
  //   })
  // }
  axes?.forEach((item: any) => {
    if (item.orient === 'left') {
      item.orient = 'right';
    } else if (item.orient === 'right') {
      item.orient = 'left';
    } else if (item.orient === 'bottom') {
      item.inverse = true;
    }
  });
  return {
    // data,
    axes,
    ...rest,
  };
};
