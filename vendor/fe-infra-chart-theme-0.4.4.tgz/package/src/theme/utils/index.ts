import { KsLineSpec, KsAreaSpec } from '../charts';
export function getColorList(spec: KsLineSpec | KsAreaSpec, colorList: string[]) {
  if (spec.stack) {
    const typeCount = new Set((spec?.data as any)?.values?.map((item: any) => item[spec.seriesField as string])).size;
    return colorList.slice(0, typeCount || 7).reverse();
  } else {
    return colorList;
  }
}
export * from './theme';
export * from './i18n';
