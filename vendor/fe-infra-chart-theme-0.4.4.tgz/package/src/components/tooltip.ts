import { type ISeries } from '@visactor/vchart/esm/series';
import { type TooltipData, type ITooltipHandler, type TooltipHandlerParams } from '@visactor/vchart';

let markTooltipCanHide = true;
function createElement(id: string, className: string, tagName = 'div') {
  const element = document.createElement(tagName);
  element.id = id;
  element.className = className;
  return element;
}

function createTooltipsContainer(id: string, showTitle = false) {
  const tooltip = createElement(id, 'tooltip');
  if (showTitle) {
    const title = createElement('custom-tooltip-title', 'tooltip-title', 'p');
    tooltip.appendChild(title);
  }
  return tooltip;
}

function createContentListElement(i: number, j: number, direction?: 'horizontal' | 'vertical') {
  const list = createElement(`custom-tooltip-list-${j}-${i}`, 'tooltip-list');
  list.setAttributeNS(null, 'data-index', `${j}-${i}`);
  if (direction === 'horizontal') {
    list.style.flexDirection = 'row';
  }
  const typeContainer = createElement(`custom-tooltip-type-container-${j}-${i}`, 'tooltip-type-container');
  const s = createElement(`custom-tooltip-symbol-${j}-${i}`, 'tooltip-icon');
  typeContainer.appendChild(s);
  const type = createElement(`custom-tooltip-type-${j}-${i}`, 'tooltip-type');
  typeContainer.appendChild(type);
  list.appendChild(typeContainer);
  const value = createElement(`custom-tooltip-value-${j}-${i}`, 'tooltip-value');
  list.appendChild(value);
  return list;
}

function createContentElement(datumList: any[], direction: 'horizontal' | 'vertical') {
  const content = createElement('custom-tooltip-content', 'tooltip-content');

  for (let j = 0; j < datumList.length; j++) {
    const datum = datumList[j];
    for (let i = 0; i < datum.length; i++) {
      content.appendChild(createContentListElement(i, j, direction));
    }
  }
  return content;
}

export type RenderContentFn = (
  datum: any[],
  series: ISeries[],
  activeType: IActiveType,
) => HTMLElement | Element | HTMLDivElement;

export type IActiveType = 'mark' | 'dimension' | 'group';

export interface RenderTooltipConfig {
  renderToolTipContentFn?: RenderContentFn;
  renderToolTipTitleFn?: RenderContentFn;
  markTooltipDelayHideTime?: number;
}

export type SortToolTipDatumFn = (
  datum: any[],
  series: ISeries[],
) => {
  datum: any[];
  series: ISeries[];
};
export interface TooltipParams {
  direction?: 'horizontal' | 'vertical';
  renderContent?: RenderContentFn;
  renderTitle?: RenderContentFn;
  sortToolTipDatum?: SortToolTipDatumFn;
  markTooltipDelayHideTime?: number;
}

export function createDimensionTooltip({
  datum,
  renderTitle,
  params,
}: {
  datum: any[];
  renderTitle?: RenderContentFn;
  params?: TooltipParams;
}) {
  const { direction = 'vertical' } = params || {};
  const dimensionTooltip = createTooltipsContainer('custom-tooltip-dimension', !!renderTitle);
  dimensionTooltip.setAttribute('part', 'dimension-tooltip');
  const content = createContentElement(datum, direction);
  dimensionTooltip.appendChild(content);
  return dimensionTooltip;
}

export function createMarkTooltip({
  datum,
  renderTitle,
  params,
}: {
  datum: any[];
  renderTitle?: RenderContentFn;
  params?: TooltipParams;
}) {
  const { direction = 'vertical' } = params || {};
  const markTooltip = createTooltipsContainer('custom-tooltip-mark', !!renderTitle);
  markTooltip.setAttribute('part', 'mark-tooltip');
  const content = createContentElement(datum, direction);
  markTooltip.appendChild(content);
  return markTooltip;
}

const updateTooltipPosition = (tooltip: HTMLElement, params: TooltipHandlerParams) => {
  if (!markTooltipCanHide) {
    return;
  }
  const tooltipWidth = tooltip.offsetWidth;
  const tooltipHeight = tooltip.offsetHeight;
  const windowWidth = window.innerWidth;
  const windowHeight = window.innerHeight;
  const { x, y } = params.event.client;
  let left = x + 20;
  // if tooltip is out of screen, show it on the left of the mouse
  if (left + tooltipWidth > windowWidth) {
    left = x - tooltipWidth - 20;
  }

  let top = y - 24;
  // if tooltip is out of screen (top), show it below the mouse
  if (top < 0) {
    top = y + 20;
  }
  if (top + tooltipHeight > windowHeight) {
    top = windowHeight - tooltipHeight;
  }
  tooltip.style.left = `0px`;
  tooltip.style.top = `0px`;
  // tooltip.style.transition = `transform 50ms`;
  tooltip.style.transform = `translate(${left}px, ${top}px)`;
};

async function updateTooltipTitle({
  tooltip,
  renderTitle,
  datum,
  series,
  activeType,
}: {
  tooltip: HTMLElement;
  renderTitle: RenderContentFn;
  datum: any[];
  series: ISeries[];
  activeType: IActiveType;
}) {
  const title = tooltip.querySelector('#custom-tooltip-title') as HTMLElement;
  const titleText = typeof renderTitle === 'function' ? await renderTitle(datum, series, activeType) : renderTitle;
  if (title && titleText) {
    title.replaceChildren(titleText);
  }
}

async function updateTooltipContent({
  tooltip,
  datum,
  series,
  params,
  renderContent,
  activeType,
  direction,
}: {
  tooltip: HTMLElement;
  datum: any[];
  series: ISeries[];
  params: any;
  renderContent: any;
  activeType: IActiveType;
  direction?: 'horizontal' | 'vertical';
}) {
  if (renderContent && typeof renderContent === 'function') {
    const contentElement = tooltip.querySelector('#custom-tooltip-content') as HTMLElement;
    const element = document.createElement('slot');
    element.setAttribute('slot', 'tooltip');
    const ele = await renderContent(datum, series, activeType);
    element.appendChild(ele);
    contentElement.replaceChildren(element);
    return;
  }
  for (let j = 0; j < datum.length; j++) {
    for (let i = 0; i < datum[j].length; i++) {
      let list = tooltip.querySelector(`#custom-tooltip-list-${j}-${i}`) as HTMLElement;
      if (!list) {
        const content = tooltip.querySelector('#custom-tooltip-content');
        list = createContentListElement(i, j, direction);
        await content?.appendChild(list);
      }
      const s = list.querySelector(`#custom-tooltip-symbol-${j}-${i}`) as HTMLElement;
      s.style.background = series[j].getSeriesStyle(datum[j][i])('fill');
      const typeElement = list.querySelector(`#custom-tooltip-type-${j}-${i}`) as HTMLElement;
      const valueElement = list.querySelector(`#custom-tooltip-value-${j}-${i}`) as HTMLElement;
      const typeText =
        params.tooltipSpec?.[activeType]?.content?.[0]?.key?.(datum[j][i]) || datum[j][i].__VCHART_DEFAULT_DATA_KEY;
      const value = params.tooltipSpec?.[activeType]?.content?.[0]?.value?.(datum[j][i]);
      const seriesItem = series.find((s) => s.userId === datum[j][i].__VCHART_DEFAULT_DATA_SERIES_FIELD);
      let defaultValue = datum[j][i].__VCHART_ARC_TRANSFORM_VALUE;
      if (defaultValue === undefined) {
        defaultValue = datum[j][i][(seriesItem as any)?.fieldY?.[0]];
      }
      typeElement.innerText = typeText;
      const valueText = value === undefined ? defaultValue : value;
      typeElement.innerText = typeText;
      valueElement.innerText = valueText;
    }
  }
  const tooltipList = tooltip.querySelectorAll('.tooltip-list');
  tooltipList.forEach((list) => {
    const dataIndex = list.getAttribute('data-index');
    const [i, j] = dataIndex?.split('-') || [];
    if (!datum?.[Number(i)]?.[j]) {
      (list as HTMLElement).style.display = 'none';
    } else {
      (list as HTMLElement).style.display = 'flex';
    }
  });
}

function hideTooltip(tooltip: HTMLElement | null) {
  if (tooltip) {
    tooltip.style.visibility = 'hidden';
    tooltip.style.transition = 'none';
  }
}

const handleMouseenter = () => {
  markTooltipCanHide = false;
};
const handleMouseleave = (markTooltip: HTMLElement) => {
  markTooltipCanHide = true;
  hideTooltip(markTooltip);
};
export function updateTooltip({
  tooltip,
  datum,
  series,
  params,
  renderTitle,
  renderContent,
  activeType,
  direction,
}: {
  tooltip: HTMLElement;
  datum: any[];
  series: ISeries[];
  params: any;
  renderTitle: RenderContentFn;
  renderContent?: RenderContentFn;
  activeType: IActiveType;
  direction?: 'horizontal' | 'vertical';
}) {
  // tooltip.style.visibility = 'visible';
  // updateTooltipPosition(tooltip, params);
  updateTooltipTitle({ tooltip, renderTitle, datum, series, activeType });
  updateTooltipContent({ tooltip, datum, series, params, renderContent, activeType, direction });
}

type CreateTooltipHandle = (node: HTMLElement, tooltipParams?: TooltipParams) => ITooltipHandler;
export const createTooltipHandle: CreateTooltipHandle = (node: HTMLElement, tooltipParams?: TooltipParams) => ({
  showTooltip: (activeType: 'mark' | 'dimension' | 'group', tooltipData: TooltipData, params: TooltipHandlerParams) => {
    // some code of custom tooltip
    let dimensionTooltip = node.querySelector('#custom-tooltip-dimension') as HTMLElement;
    let markTooltip = node.querySelector('#custom-tooltip-mark') as HTMLElement;
    if (activeType === 'dimension') {
      hideTooltip(markTooltip);
      if (params.changePositionOnly) {
        setTimeout(() => {
          updateTooltipPosition(dimensionTooltip, params);
        }, tooltipParams?.markTooltipDelayHideTime || 0);
        return;
      }
      const renderDimensionTitle = (params.tooltipSpec?.dimension?.title as any)?.value;
      const data = (tooltipData[0] as any).data;
      const _datum = data.map((d: any) => d.datum);
      const _series = data.map((d: any) => d.series);
      const sortData = tooltipParams?.sortToolTipDatum?.(_datum, _series);
      const datum = sortData?.datum || _datum;
      const series = sortData?.series || _series;

      if (!dimensionTooltip) {
        dimensionTooltip = createDimensionTooltip({
          datum,
          renderTitle: tooltipParams?.renderTitle || renderDimensionTitle,
          params: tooltipParams,
        });
        if (tooltipParams?.markTooltipDelayHideTime) {
          dimensionTooltip.style.pointerEvents = 'auto';
          dimensionTooltip.addEventListener('mouseenter', handleMouseenter);
          dimensionTooltip.addEventListener('mouseleave', handleMouseleave.bind(this, markTooltip));
        }
        node.appendChild(dimensionTooltip);
      }
      updateTooltip({
        tooltip: dimensionTooltip,
        datum,
        series,
        params,
        renderTitle: tooltipParams?.renderTitle || renderDimensionTitle,
        renderContent: tooltipParams?.renderContent,
        activeType,
        direction: tooltipParams?.direction,
      });
    } else if (activeType === 'mark') {
      //
      hideTooltip(dimensionTooltip);
      if (params.changePositionOnly) {
        // throttle(() =>
        setTimeout(() => {
          updateTooltipPosition(markTooltip, params);
        }, tooltipParams?.markTooltipDelayHideTime || 0);
        return;
      }
      const renderMarkTitle = (params.tooltipSpec?.mark?.title as any)?.value;
      const { datum, series } = tooltipData[0] as any;
      if (!markTooltip) {
        markTooltip = createMarkTooltip({
          datum: [datum],
          renderTitle: tooltipParams?.renderTitle || renderMarkTitle,
          params: tooltipParams,
        });
        node.appendChild(markTooltip);
        if (tooltipParams?.markTooltipDelayHideTime) {
          markTooltip.style.pointerEvents = 'auto';
          // markTooltip.style.transition = `transform 50ms`;
          markTooltip.addEventListener('mouseenter', handleMouseenter);
          markTooltip.addEventListener('mouseleave', handleMouseleave.bind(this, markTooltip));
        }
      }
      updateTooltip({
        tooltip: markTooltip,
        datum: [datum],
        series: [series],
        params,
        renderTitle: tooltipParams?.renderTitle || renderMarkTitle,
        renderContent: tooltipParams?.renderContent,
        direction: tooltipParams?.direction,
        activeType,
      });
    } else {
      hideTooltip(markTooltip);
      hideTooltip(dimensionTooltip);
    }
    return null;
  },
  hideTooltip: () => {
    setTimeout(() => {
      // hide your custom tooltip
      if (markTooltipCanHide) {
        const markTooltip = node.querySelector('#custom-tooltip-mark') as HTMLElement;
        hideTooltip(markTooltip);

        const dimensionTooltip = node.querySelector('#custom-tooltip-dimension') as HTMLElement;
        hideTooltip(dimensionTooltip);
      }
    }, tooltipParams?.markTooltipDelayHideTime || 0);
    return null;
  },
  release: () => {
    const markTooltip = node.querySelector('#custom-tooltip-mark');
    if (!markTooltip) {
      return;
    }
    markTooltip.removeEventListener('mouseenter', handleMouseenter);
    markTooltip.removeEventListener('mouseleave', handleMouseleave.bind(this, markTooltip as HTMLElement));
    node.removeChild(markTooltip);
  },
});
