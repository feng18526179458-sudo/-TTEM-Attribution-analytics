import { moduleTools, defineConfig } from '@edenx/module-tools';

export default defineConfig({
  plugins: [moduleTools()],
  buildPreset: 'npm-library-es2019',
  buildConfig: {
    dts: {
      respectExternal: false,
    },
  },
});
